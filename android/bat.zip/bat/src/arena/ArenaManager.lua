local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local socket = require "socket"
local ArenaManager = class()-- 定义一个类 test 继承于 base_type


--组牌最大数量
local mMaxDeckNum = 40



--当前阶段  0没报名 1选牌阶段 2已选牌阶段
local mCurState = 0

--现在进行到第几轮选牌 总共23轮 1~3轮选择圣物,4~23轮选择普通卡牌
local mCurRound = 1--0

--竞技场5场胜负 0未打 1胜利 2失败
local mWinList = {}

--3张圣物牌随机数组
local mRandomEqList = {}
--4张卡牌候选列表
local mRandomCardList = {}
--根据圣物筛选出来的卡牌列表
local mRandomPoolList = {}

--当前选定的头像ID
local mHeadId = 1

--是否获取了后台保存的竞技场信息
local mIsGetMsg = false
--是否发送打开竞技场请求 如果为true则获取到2800信息可能会打开竞技场界面
local mIsSendOpen = false


--已经选择的卡牌列表
--当前编辑中的套牌普通卡牌数组[ data = 卡牌表的data, num = 卡牌数量]
local mSelectedCardList = {}


--当前后台保存的卡组信息
local mCurDeckData = {}
--后台保存的卡组索引ID 现在设定为9
local mCurDeckId = 17


--抽取到各品质的牌的概率
local mRandomQltList = { 
{0,0,100,0},
{0,100,0,0},
{0,100,0,0},
{100,0,0,0},
{100,0,0,0},
{100,0,0,0},
{100,0,0,0},
{0,100,0,0},
{70,30,0,0},
{90,10,0,0},
{100,0,0,0},
{0,0,100,0},
{0,100,0,0},
{0,100,0,0},
{100,0,0,0},
{100,0,0,0},
{100,0,0,0},
{100,0,0,0},
{0,100,0,0},
{0,0,70,30}
}

function ArenaManager:ctor()

	print("ArenaManager:ctor --------------------------")
	
end

function ArenaManager:instance()
    local o = _G.ArenaManager
    if o then
    	return o
	end
 
    o = ArenaManager:new()
	_G.ArenaManager = o
    ArenaManager:init()
    return o
end

function ArenaManager:init()

end

--按顺序排卡组卡牌
local function CardGroupSort(obj1, obj2)
    if obj1.data.cost < obj2.data.cost then
        return true
    elseif obj1.data.cost > obj2.data.cost then
        return false
    end
    return obj1.data.id < obj2.data.id
end

--设置卡组信息
function ArenaManager:setCurDeckData( obj )
    mCurDeckData = obj
    self:initData()
end 

--判断传进来的卡组ID是否是竞技场的卡组ID
function ArenaManager:checkCurDeckId( id )
    return mCurDeckId == id
end

function ArenaManager:getCurDeckId()
    return mCurDeckId
end

--清空竞技场信息
function ArenaManager:clear()
    mCurState = 0
    mIsGetMsg = false
    mCurDeckData = nil
    mCurRound = 1
    mWinList = {}
    mRandomEqList = {}
    mRandomCardList = {}
    mHeadId = 1
    ServMsgTransponder:SMTDelete_decks( mCurDeckId )--销毁已经创建的竞技场套牌
end 

--初始化数据
function ArenaManager:initData()
    if mCurState > 0 then
        local group = mCurDeckData
        if group == nil then
            if mRandomEqList == nil or #mRandomEqList == 0 then
                self:initEquip(true)
            else
                self:initEquip(false)
            end
            mSelectedCardList = {}
            return
        end
        if group.GroupEquipArr then
            mRandomEqList = group.GroupEquipArr
            mHeadId = group.headId
            self:initPool()
        else
            if mRandomEqList == nil or #mRandomEqList == 0 then
                self:initEquip(true)
            else
                self:initEquip(false)
            end
        end

        if group.GroupCardArr then
            mSelectedCardList = group.GroupCardArr
             self:sortDeckList()
        else
            mSelectedCardList = {}
        end
    end
end


----获取随机3张圣物牌 bolInit为true则重新随机3张候选卡牌,否则用当前的mRandomEqList
--function ArenaManager:initEquip( bolInit )    
--    if bolInit == true then
--        local dataList = DataManager.DataArenaEquipList
--        math.randomseed(tostring(socket.gettime()):reverse():sub(1, 4))
--        --随机第一张
--        local idx = math.random(1, #dataList[2])
--        local cardData = dataList[2][idx]
--        mRandomEqList[1] = cardData
--        mRandomEqList[2] = cardData

--        local qlt
--        local num = math.random(1, 100)
--        if num <= 50 then
--            qlt = 1
--        else
--            qlt = 2
--        end
--        math.randomseed(tostring(socket.gettime()):reverse():sub(1, 6))

--        while mRandomEqList[1] == mRandomEqList[2] do  --如果跟第一张相同的话继续随机
--            idx = math.random(1, #dataList[qlt])
--            cardData = dataList[qlt][idx]
--            mRandomEqList[2] = cardData
--        end
--    --    math.randomseed(tostring(socket.gettime())):reverse():sub(1, 6))
--        idx = math.random(1, #dataList[1])
--        cardData = dataList[1][idx]
--        mRandomEqList[3] = cardData

--        ArenaManager:SendRandomMsg()
--    end

--    mHeadId = math.random(1, 36)--这里顺便把头像也随机一个

--    ArenaManager:initPool()
--    ArenaManager:getCardsFromPool()

----    ArenaManager:SendRandomMsg() 
--end


--获取随机3张圣物牌 bolInit为true则重新随机3张候选卡牌,否则用当前的mRandomEqList
function ArenaManager:initEquip( bolInit )    
    if bolInit == true then
        local eqRanList = {10006, 20006,30006,40006,50006} --第一张圣物的随机列表
        for i = 1, #eqRanList do
            eqRanList[i] = DataManager:getEq(eqRanList[i]) --转换类型
        end

        local dataList = DataManager.DataArenaEquipList
        local bolSame = false --是否有相同的阵营派系
        math.randomseed(tostring(socket.gettime()):reverse():sub(1, 4))
--        local race = math.random(1, 5)
--        local idx = math.random(2, #dataList[race])  --从2开始，1是无技能圣物，之后如果圣物派系相同，会用来补
        local idx = math.random(1, #eqRanList)
        local cardData = eqRanList[idx] --随机第一张
        mRandomEqList[1] = cardData

        local race = math.random(1, 5)
        if mRandomEqList[1].race == race then
            bolSame = true
            mRandomEqList[2] = dataList[race][1]  --直接用圣物派系列表第一张的无技能圣物
        else
            idx = math.random(2, #dataList[race])
            mRandomEqList[2] = dataList[race][idx]  --随机第二张圣物
            while table.indexof(eqRanList, mRandomEqList[2]) ~= false  do  --如果跟第一张都是抽卡圣物的话继续随机
                idx = math.random(2, #dataList[race])
                mRandomEqList[2] = dataList[race][idx]
            end 
        end

        race = math.random(1, 5)
        if bolSame == false and (mRandomEqList[1].race == race or mRandomEqList[2].race == race) then --如果圣物3跟圣物1派系相同，但圣物1与圣物2派系不同，则直接用圣物派系列表第一张的无技能圣物
            bolSame = true
            mRandomEqList[3] = dataList[race][1]
        elseif mRandomEqList[1].race == race or mRandomEqList[2].race == race then --如果三张圣物派系都相同，则第三张可以再随机挑选
            bolSame = true
            idx = math.random(2, #dataList[race])
            mRandomEqList[3] =  dataList[race][idx]
            while mRandomEqList[1] == mRandomEqList[3] or table.indexof(eqRanList, mRandomEqList[3]) ~= false do  --如果跟第一张相同或者是抽卡圣物的话继续随机
                idx = math.random(2, #dataList[race])
                mRandomEqList[3] = dataList[race][idx]
            end 
        else                                                                    --如果三张圣物派系都不相同
            idx = math.random(2, #dataList[race])
            mRandomEqList[3] = dataList[race][idx]
            while table.indexof(eqRanList, mRandomEqList[3]) ~= false  do  --如果跟第一张都是抽卡圣物的话继续随机
                idx = math.random(2, #dataList[race])
                mRandomEqList[3] = dataList[race][idx]
            end 
        end
        ArenaManager:SendRandomMsg()
    end
    for i = 1, #mRandomEqList do
        print("eq "..mRandomEqList[i].id)
    end
    mHeadId = math.random(1, 36)--这里顺便把头像也随机一个

    ArenaManager:initPool()
    ArenaManager:getCardsFromPool()
end

--生成随机卡池
function ArenaManager:initPool()
    mRandomPoolList = {}
    local dataList = DataManager.DataArenaCardList
    for i = 1, 4 do
        if mRandomPoolList[i] == nil then mRandomPoolList[i] = {} end
        local cardList = dataList[i]
        for j = 1, #cardList do
            if CollectionManager:checkCardRace(cardList[j], mRandomEqList) == true then--根据圣物判断传入的普通卡牌阵营是否符合要求 
                table.insert(mRandomPoolList[i], cardList[j])
            end
        end
    end
end

----发送当前的随机参数信息
--function ArenaManager:ssss() 
--    local prlist = {} 
--    local gl = {1, 2, 3, 4, 5}
--    local nl = {12, 32, 3, 8, 5}
--    local num = 0
--    local list = {}
--    for i = 1, #gl do
--        num = num + nl[i]
--        list[i] = {g = gl[i], n = nl[i]}        
--    end

--    math.randomseed(tostring(socket.gettime()):reverse():sub(1, 6) )
--    for i = 1, 10000 do
--        local tempNum = math.random(1,num)
--        for j = 1, #list do
--            tempNum = tempNum - list[j].n
--            if tempNum <= 0 then
--                if prlist[list[j].g] == nil then
--                    prlist[list[j].g] = 1
--                else 
--                    prlist[list[j].g] = prlist[list[j].g]  + 1
--                end
--                break
--            end     
--        end
--    end

--    for k, v in pairs(prlist) do
--        print( k.." has ".. v)
--    end

--    local prlist2 = {}
--    local dd = mRandomPoolList[1]
--    local idx = 0
--    for i = 1, 10000 do 
--        idx = ArenaManager:getIdxByWeight( mRandomPoolList[1] )  
--        if prlist2[idx] == nil then
--            prlist2[idx] = 1
--        else 
--            prlist2[idx] = prlist2[idx]  + 1
--        end
--    end
--    for k, v in pairs(prlist2) do
--        print( k.." has2 ".. v)
--    end
--end

--通过权重(全牌表arena值)获取卡牌，值越大出现概率越高
function ArenaManager:getIdxByWeight( tempList )  
    local weightNum = 0
    for i = 1, #tempList do
        weightNum = weightNum + tempList[i].arena
    end

    local tempNum = math.random(1, weightNum)
    for i = 1, #tempList do
        tempNum = tempNum - tempList[i].arena
        if tempNum <= 0 then
            return i
        end     
    end
    return nil
end
    
--发送当前的随机参数信息
function ArenaManager:SendRandomMsg()  
    local str = mCurRound  
    if mCurRound < 4 then
        for i = 1, 3 do
            str = str..","..mRandomEqList[i].id
        end
    else
        for i = 1, 4 do
            str = str..","..mRandomCardList[i].id
        end
    end
    ServMsgTransponder:SMTAreaSuiji( str )
end


--读取发给后台保存的数据
function ArenaManager:setDataByMsg(str)
    local msgArr = string.split(str, ",")
    if msgArr[1] == "" then msgArr[1] = 1 end
    mCurRound = tonumber(msgArr[1])
    if mCurRound < 4 then
        for i = 2, #msgArr do
            mRandomEqList[i-1] = DataManager:getEq( tonumber(msgArr[i]) )
        end
        self:initPool()
    else        
        for i = 2, #msgArr do
            mRandomCardList[i-1] = DataManager:getCardObjByID( tonumber(msgArr[i]) )
        end
    end    
end

--是否获取了后台保存的竞技场信息
function ArenaManager:getIsGetMsg()   
    return mIsGetMsg
end

function ArenaManager:setIsGetMsg(bol)   
    mIsGetMsg = bol
end

--是否发送打开竞技场请求 如果为true则获取到2800信息可能会打开竞技场界面
function ArenaManager:getIsSendOpen()   
    return mIsSendOpen
end

function ArenaManager:setIsSendOpen(bol)   
    mIsSendOpen = bol
end


--发送当前的卡组信息
function ArenaManager:SendGroupMsg()       
    local EqStr = ""
    local DinaryStr = ""

    for i = 1, #mRandomEqList do
        EqStr = EqStr..mRandomEqList[i].id..","
    end

    for i = 1, #mSelectedCardList do
        for j = 1, mSelectedCardList[i].num do
            DinaryStr = DinaryStr..mSelectedCardList[i].data.id..","
        end
    end
--    if DinaryStr == "" then DinaryStr = "1,2" end
    --compose_card decks 牌组编号 牌组名称 圣物卡牌数据 普通卡牌数据牌

--    EqStr = "20001,20001,20001"
--    DinaryStr = "81,363" 
    if DinaryStr == "" then DinaryStr = "999999" end
    ServMsgTransponder:SMTDecks2( mCurDeckId, "arena", mHeadId, EqStr, DinaryStr)
end

--从随机卡池生成两组待选的卡牌  bolInit为true则重新随机4张候选卡牌,否则用当前的mRandomCardList
function ArenaManager:getCardsFromPool( bolInit )
    
    if mCurRound < 4 or mCurRound > 23 then 
        return 
    end
    if bolInit ~= true and mRandomCardList ~= nil and #mRandomCardList == 4 then 
        return 
    end

    local dataList = mRandomQltList[mCurRound - 3]  --1前三轮是圣物选择,所以要减去3
    local qlt = 1
    
    local idx
    for i = 1, 4 do
        math.randomseed(tostring(socket.gettime()):reverse():sub(1, 6) * i)
        local num = math.random(1,100)
        local tempNum = 0
        for j = 1, 4 do
            if num < dataList[j] + tempNum then
                qlt = j
                break--直接结束循环
            end
            tempNum = dataList[j] + tempNum
        end


        math.randomseed(tostring(socket.gettime()):reverse():sub(1, 6) * i)
--        idx = math.random(1, #mRandomPoolList[qlt])
        idx = ArenaManager:getIdxByWeight( mRandomPoolList[qlt] )  
        cardData = mRandomPoolList[qlt][idx]
        
        while table.indexof(mRandomCardList, cardData) ~= false do  --如果跟第一张相同的话继续随机
            math.randomseed(tostring(socket.gettime()):reverse():sub(1, 6) * i)
--            idx = math.random(1, #mRandomPoolList[qlt])
            idx = ArenaManager:getIdxByWeight( mRandomPoolList[qlt] )  
            cardData = mRandomPoolList[qlt][idx]
        end
        mRandomCardList[i] = cardData
--        print(" cards "..cardData.id.." "..qlt)

--        str = ""
--        for z =1, #mRandomPoolList[qlt] do
--            str = str..","..mRandomPoolList[qlt][z].id
--        end
--        print(str)
    end

    if mCurRound == 4 then  --第4轮,则表示是第一次随机4张卡牌,要发去后台保存数据
        ArenaManager:SendRandomMsg()
    end

end

--组牌最大数量
function ArenaManager:getMaxDeckNum()
    return mMaxDeckNum
end

--现在进行到第几轮选牌 总共23轮 1~3轮选择圣物,4~23轮选择普通卡牌
function ArenaManager:setCurRound(num)
	mCurRound = num
end

function ArenaManager:getCurRound()
	return mCurRound
end


--当前阶段  0没报名 1选牌阶段 2已选牌阶段
function ArenaManager:setCurState(num)
	mCurState = num
end

function ArenaManager:getCurState()
	return mCurState
end


function ArenaManager:setWinList(list)
	mWinList = list
end

function ArenaManager:getWinList()
	return mWinList
end

function ArenaManager:setWinList(list)
	mWinList = list
end

--3张圣物牌随机候选数组
function ArenaManager:getRandomEqList()
	return mRandomEqList
end

--4张卡牌候选列表
function ArenaManager:getRandomCardList()
	return mRandomCardList
end

--头像ID
function ArenaManager:getHeadId()
	return mHeadId
end


function ArenaManager:getSelectedCardList()
	return mSelectedCardList
end

function ArenaManager:AddToSelectedCardList( obj )
    local bolIn = false
     for i = 1, #mSelectedCardList do
        if mSelectedCardList[i].data == obj then
            bolIn = true
            mSelectedCardList[i].num = mSelectedCardList[i].num + 1
            break
        end
    end
    if bolIn == false then
        table.insert(mSelectedCardList, {data = obj, num = 1})
    end	
end

function ArenaManager:sortDeckList()
    table.sort( mSelectedCardList, CardGroupSort )--排序
end


return ArenaManager