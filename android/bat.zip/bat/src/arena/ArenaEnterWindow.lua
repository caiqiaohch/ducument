require "tagMap.Tag_arena"
local DataManager = require("data.DataManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local ArenaManager = require("arena.ArenaManager"):instance()

local __instance = nil

local mBtnClose
local mBtnGold
local mBtnStone

--介绍文本
local mTxtDesc

local mTxtGold 
local mTxtStone

local mNeedGold = 300
local mNeedStone = 130

local window

--要预加载的资源列表
local resArr = { PLIST_ARENA_URL }


ArenaEnterWindow = class("ArenaEnterWindow",function()
	return TuiBase:create()
end)

ArenaEnterWindow.isShow = false

function ArenaEnterWindow:create()
	local ret = ArenaEnterWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
--    ret:setOnEnterSceneScriptHandler(function() ret:onEnterScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)

	return ret
end

function ArenaEnterWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function ArenaEnterWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

function ArenaEnterWindow:updateMsg()
    
end

--点击关闭事件
local function BtnCloseClick(p_sender)
    print("close")
    PopScene(__instance)
end

local function BtnGoldClick(p_sender)
    ArenaManager:setIsSendOpen(true)   
    ServMsgTransponder:SMTAreaRegist(1)
--    ArenaEnterWindow:gotoArena()
end

local function BtnStoneClick(p_sender)
--    local str = "6,447,446,403,447"
--    ArenaManager:setDataByMsg(str)
    ArenaManager:setIsSendOpen(true)  
    ServMsgTransponder:SMTAreaRegist(2)
end


--更新商店卡包选中效果
local function updateShopBtn()    
    local char = CharacterManager:getMainPlayer()

    if char.gold < mNeedGold then
        EffectManager:setBtnGrayFilter(mBtnGold, true)
    else
        EffectManager:setBtnGrayFilter(mBtnGold, false)
    end

    if char.stone < mNeedStone then
        EffectManager:setBtnGrayFilter(mBtnStone, true)
    else
        EffectManager:setBtnGrayFilter(mBtnStone, false)
    end
end

function ArenaEnterWindow:closeWindow()
    PopScene(__instance)
end

--初始化界面
function ArenaEnterWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end

function ArenaEnterWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_arena_enter",PATH_ARENA)
    window = self:getChildByTag(Tag_arena.PANEL_ARENA_ENTER)

    mBtnGold = window:getChildByTag(Tag_arena.BTN_GOLD)
    mBtnGold:setOnClickScriptHandler( BtnGoldClick )   
   
    mBtnStone = window:getChildByTag(Tag_arena.BTN_STONE)
    mBtnStone:setOnClickScriptHandler( BtnStoneClick ) 
      
    mBtnClose = window:getChildByTag(Tag_arena.BTN_MASK)
    mBtnClose:setOnClickScriptHandler( BtnCloseClick )
    
    mTxtGold = window:getChildByTag(Tag_arena.LABBMF_GOLD)
    mTxtGold:setString(DataManager:getStringDataTxt(24, true)..mNeedGold)
    mTxtStone = window:getChildByTag(Tag_arena.LABBMF_STONE)
    mTxtStone:setString(DataManager:getStringDataTxt(24, true)..mNeedStone)

    mTxtDesc = window:getChildByTag(Tag_arena.LABEL_ENTER_DESC)
    mTxtDesc:setString(DataManager:getStringDataTxt(98, true))

    updateShopBtn()

    ArenaEnterWindow.isShow = true
end
 
  
function ArenaEnterWindow:onExitScene()
    ArenaEnterWindow.isShow = false
    UILoadManager:delResByArr( resArr )
end

