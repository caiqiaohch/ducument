require "tagMap.Tag_arena"
local DataManager = require("data.DataManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local ArenaManager = require("arena.ArenaManager"):instance()

local __instance = nil

local mImgMask
--关闭按钮
local mBtnClose
--play按钮
local mBtnPlay
--领奖励按钮
local mBtnReward
--弃权按钮
local SMTAreaGiveUp

--更换圣物按钮
local mBtnReplace
--确定选择圣物按钮
local mBtnKeep

--选择卡牌按钮1
local mBtnSelect1
--选择卡牌按钮2
local mBtnSelect2

--右侧区域
local mLayoutRight
--中间区域
local mLayoutMain
--选择牌区域
local mLayoutSelect
--花费百分比图
local mLayoutSpends = nil

--牌组数量文本
local mTxtNum

--头像图片
local mImgHead
--胜负状态按钮列表
local mImgWinList = {}
--圣物UI列表
local mCardGroupImgList = {}
--右侧已选卡牌列表
local mCardCellList = {}
--右侧已选卡牌列表组件
local mGpvList

--候选3张圣物列表
local mRandomEqList = {}
--候选4张卡片列表
local mRandomCardList = {}

--花费框元件列表
local mCardSpendsArr = {}
local mCardTypesArr = {}

local mImgSelect1
local mImgSelect2
local mImgKeep
local mImgReplace

local window

--要预加载的资源列表
local resArr = { PLIST_ARENA_URL, PLIST_XIANGXI_URL, PLIST_CARDUI_URL, PLIST_WAR2CARDSG_URL,
    PLIST_CARDMIDDLEUI_URL, PLIST_CARDBIGUI1_URL, PLIST_CARDBIGUI2_URL, PLIST_CARDBIGUI3_URL, PLIST_CARDBIGUI4_URL, PLIST_CARDBIGUI5_URL  }


ArenaWindow = class("ArenaWindow",function()
	return TuiBase:create()
end)

ArenaWindow.isShow = false
ArenaWindow.isWaiting = false

function ArenaWindow:create()
	local ret = ArenaWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
--    ret:setOnEnterSceneScriptHandler(function() ret:onEnterScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)

	return ret
end

function ArenaWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function ArenaWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end


--圣物卡牌查看事件
local function showCardClick( p_sender )
    print("showCardClick")
    if CardXiangXi.isShow == false then 
        RunScene( "CardXiangXi" )
        CardXiangXi:setAndShowCardXiangXi( p_sender.mCardID, 1, nil , nil, 0.9 )
    end
end

local function tempCardUIClick( p_sender )
    print("tempCardUIClick")
    if p_sender.id == nil then
        return
    end 
    mImgMask:setVisible(true)
    mCardUI:setCard(p_sender.id)
    for k, tempSp in pairs(mCardCellList) do
        if tempSp.img_CardBoxLight == p_sender then
            tempSp.img_CardBoxLight:setOpacity(255)    
        else
            tempSp.img_CardBoxLight:setOpacity(0)
        end
    end
end

--取消选中的卡牌大图显示
local function cardUIMaskClick( p_sender )
    for k, tempSp in pairs(mCardCellList) do
        if curGroupCardId == k then
            tempSp.img_CardBoxLight:setOpacity(0)
            break
        end    
    end
    mImgMask:setVisible(false)
end

--随机卡牌查看事件
local function showCardClick2( p_sender )
    print("showCardClick2")
    local list = ArenaManager:getRandomCardList()
    local data1 
    local data2
    if p_sender.index < 3 then
        data1 = require("war2.war2Card").new()
        data1:init(list[2].id)
        data2 = require("war2.war2Card").new()
        data2:init(list[1].id)
    else
        data1 = require("war2.war2Card").new()
        data1:init(list[3].id)
        data2 = require("war2.war2Card").new()
        data2:init(list[4].id)
    end
    CardXiangXi:setAndShowCardXiangXi(0, 3, data1, data2, 0.9)
end

--点击关闭事件
local function BtnCloseClick(p_sender)
    if ArenaWindow.isPopAll == true then
        if MainWindow.isCanShow == true then
            PopScene(__instance)
        else
            MainWindow.isCanShow = true
            replaceScene("MainWindow")
        end
    else
        PopScene(__instance)
    end
end

local function BtnPlayClick(p_sender)
    print("BtnPlayClick")
    ServMsgTransponder:SMTComposeCardFight2( ArenaManager:getCurDeckId() )    
end

local function BtnRewardClick(p_sender)
    print("BtnRewardClick")
    if ArenaManager:getCurState() ~= 2 then
         return
    end
    ServMsgTransponder:SMTAreaGiveUp() 
end

local function BtnGiveUpClick(p_sender)
    if ArenaManager:getCurState() ~= 2 then
         return
    end
    require("prompt.PromptManager"):instance():SetPromptMsg( 4069, nil, function () ServMsgTransponder:SMTAreaGiveUp() end )
end

local function BtnReplaceClick(p_sender)
    print("BtnReplaceClick")
    if ArenaManager:getCurRound() < 3 then
        ArenaManager:setCurRound( ArenaManager:getCurRound() + 1)
    else
        return
    end
    ArenaManager:initEquip(true)
    ArenaWindow:updateMsgByRounds()
    ArenaManager:SendRandomMsg()   
end

local function BtnKeepClick(p_sender)
    print("BtnKeepClick")
    ArenaManager:setCurRound( 4 )
    ArenaManager:getCardsFromPool(true)
    ArenaWindow:updateMsgByRounds()

    ArenaWindow:updateEqMsg()
    ArenaManager:SendRandomMsg()   
    ArenaManager:SendGroupMsg()
--    ArenaManager:initEquip()
end

local function BtnSelectClick(p_sender)
    if ArenaManager:getCurState() ~= 1 then 
        return 
    end
    if ArenaManager:getCurRound() > 23 then  
        ServMsgTransponder:SMTAreaDeck()
        return 
    end
    local list = ArenaManager:getRandomCardList()
    if p_sender == mBtnSelect1 then
        for i = 1, 2 do
            ArenaManager:AddToSelectedCardList( list[i] )
        end
    else
        for i = 3, 4 do
            ArenaManager:AddToSelectedCardList( list[i] )
        end
    end
    ArenaManager:sortDeckList()
    ArenaManager:setCurRound( ArenaManager:getCurRound() + 1)
    ArenaManager:getCardsFromPool(true)
    ArenaWindow:updateMsgByRounds()
    ArenaWindow:updateGpvCardList()
    ArenaManager:SendRandomMsg() 
    ArenaManager:SendGroupMsg()
    if ArenaManager:getCurRound() > 23 then 
--        ArenaManager:setCurState(2)        
--        ArenaWindow:updateMsg()
        ServMsgTransponder:SMTAreaDeck()
        return 
    end
end

--套牌费用按钮点击事件
local function EditorClick(p_sender)
--    local MovMove = require("Mov.MovMove").new()
    if mLayoutSpends:isVisible() == false then
        ArenaWindow:CardSpendMsg()
        mLayoutSpends:setVisible(true)
--        MovMove:init(mLayoutSpends, false, -40, mLayoutSpends:getPositionY(), 100, 1)  
--        MovManager:pushMov( MovMove )
    else
        mLayoutSpends:setVisible(false)
--        MovMove:init(mLayoutSpends, false, 500, mLayoutSpends:getPositionY(), 100, -1)
--        MovMove.callBackFucFinished = function () mLayoutSpends:setVisible(false) end
--        MovManager:pushMov( MovMove )
    end
end
    
--开始匹配
function ArenaWindow:StartLink()    
    ArenaWindow.isWaiting = true
    RunScene("FightWaitWindow")
end

    

--套牌花费情况与各种类数量
function ArenaWindow:CardSpendMsg()
    local list = ArenaManager:getSelectedCardList()
    local tempArr = {}
    for i = 1, #list do
        tempArr[list[i].data.id] = list[i].num
    end
    local arr = CollectionManager:getCurGroupCostArr( tempArr )
    if arr == nil then return end
    local prog_Percent = nil
    local num = 0
    local char = CharacterManager:getMainPlayer()
    local AllCardNum = 0
    for i = 0, 10 do
        if mCardSpendsArr[i] ~= nil then
            prog_Percent = mCardSpendsArr[i].pro
            prog_Percent:setValue( arr[i] )
            mCardSpendsArr[i].txt:setString( arr[i] )
        end
    end


    local tArr = CollectionManager:getCurGroupTypeArr( tempArr )
    for i = 1, 4 do
        mCardTypesArr[i]:setHorizontalAlignment(cc.ui.TEXT_ALIGN_RIGHT)
        mCardTypesArr[i]:setString("X"..tArr[i])
    end
end

function ArenaWindow:closeWindow()
    if ArenaWindow.isPopAll == true then
        if MainWindow.isCanShow == true then
            PopScene(__instance)
        else
            MainWindow.isCanShow = true
            replaceScene("MainWindow")
        end
    else
        PopScene(__instance)
    end
end


function ArenaWindow:updateMsg()
    if ArenaManager:getCurState() == 1 then --选牌阶段
        mLayoutSelect:setVisible(true)
        mLayoutMain:setVisible(false)
        ArenaWindow:updateMsgByRounds()
    elseif ArenaManager:getCurState() == 2 then --已经选好牌了
        mLayoutSelect:setVisible(false)
        mLayoutMain:setVisible(true)
        local bolReward = true
        --胜负状态更新
        for i = 1, 5 do
            if ArenaManager:getWinList()[i] == 0 then
                mImgWinList[i]:setSpriteFrame("Arena/".."img_Level"..i.."_disable.png")
                bolReward = false
            elseif ArenaManager:getWinList()[i] == 1 then
                mImgWinList[i]:setSpriteFrame("Arena/img_Level"..i.."_normal.png")
            elseif ArenaManager:getWinList()[i] == 2 then
                mImgWinList[i]:setSpriteFrame("Arena/img_Level_lost.png")
            end 
        end
        if bolReward == true then
            mBtnPlay:setVisible(false)
            mBtnReward:setVisible(true)
        else
            mBtnPlay:setVisible(true)
            mBtnReward:setVisible(false)
        end        
    end
end

--更新牌组里的圣物信息
function ArenaWindow:updateEqMsg()
    if ArenaManager:getCurRound() < 4 then 
        return 
    end
    local list = ArenaManager:getRandomEqList()
    for i = 1, 3 do
        mCardGroupImgList[i]:setTexture( "war2/warEqIcon/"..list[i].id..".png" )
        mCardGroupImgList[i].mCardID = list[i].id
    end
    mImgHead:setTexture("war2/head/HeadPic"..ArenaManager:getHeadId()..".png")
end

    

--根据第几轮更新界面信息
function ArenaWindow:updateMsgByRounds()
    local round = ArenaManager:getCurRound()
    if round < 4 then
        mBtnReplace:setVisible(true)
        mBtnKeep:setVisible(true)
        mImgReplace:setVisible(true)
        mImgKeep:setVisible(true)
        mBtnSelect1:setVisible(false)
        mBtnSelect2:setVisible(false)
        mImgSelect1:setVisible(false)
        mImgSelect2:setVisible(false)
        local list = ArenaManager:getRandomEqList()
        for i = 1, 3 do
            mRandomCardList[i]:setVisible(true)
            mRandomEqList[i]:init(list[i].id)
        end
        for i = 1, 4 do
            mRandomCardList[i]:setVisible(false)
        end
        if round == 1 then
            mImgReplace:setTexture("langImg/img_Font+Replace2_"..LANGUAGE..".png")
        elseif round == 2 then
            mImgReplace:setTexture("langImg/img_Font+Replace1_"..LANGUAGE..".png")
        elseif round == 3 then
            mBtnReplace:setVisible(false)
            mImgReplace:setVisible(false)
            mBtnKeep:setPositionX(460)
            mImgKeep:setPositionX(460)
        end
    else
        mBtnReplace:setVisible(false)
        mBtnKeep:setVisible(false)
        mImgReplace:setVisible(false)
        mImgKeep:setVisible(false)
        mBtnSelect1:setVisible(true)
        mBtnSelect2:setVisible(true)
        mImgSelect1:setVisible(true)
        mImgSelect2:setVisible(true)
        local list = ArenaManager:getRandomCardList()
        for i = 1, 3 do
            mRandomEqList[i]:setVisible(false)
        end
        for i = 1, 4 do
            mRandomCardList[i]:setVisible(true)
            mRandomCardList[i]:setCard(list[i].id)
        end
    end
end



--更新预组套牌右边列表
function ArenaWindow:updateGpvCardList()
    --移除右边显示所有节点
    mGpvList:removeAllNodes()
    local dataList = ArenaManager:getSelectedCardList()
    mCardCellList = {}
    local allNum = 0
    for i = 1, #dataList do
         ArenaWindow.insertItemToList( i, dataList[i] )
         allNum = allNum + dataList[i].num
    end
    mGpvList:reloadData()
    mTxtNum:setString( allNum.."/"..ArenaManager:getMaxDeckNum() )
end

--更新套牌数据
function ArenaWindow.insertItemToList( idx, obj )
    local pCell = mCardCellList[idx]  --因为用pCell属性的方式VS很容易报错退出，只好改成pCell[]这个方式
    if pCell == nil then
		pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell( pCell, "cell_card", PATH_ARENA )
        mCardCellList[idx] = pCell

        pCell["TxtCardCountRace"] = pCell:getChildByTag(Tag_arena.LABBMF_CARDCOUNTRACE)
        pCell["TxtCardCountNum"] = pCell:getChildByTag(Tag_arena.LABBMF_CARDCOUNTNUM)
        pCell["TxtCardName"] = pCell:getChildByTag( Tag_arena.LABEL_CARDCOUNTNAME )
        pCell["TxtCardName"]:enableOutline(cc.c4b(0,0,0,245),2)  --对文本进行描边
        pCell["TxtCardName"]:setLineBreakWithoutSpace(true)

        pCell["img_CardBoxLight"] = pCell:getChildByTag( Tag_arena.IMG_CARDBOXLIGHT )
        pCell["img_CardBoxLight"]:setTouchEnabled(true)
        pCell["img_CardBoxLight"]:setOnClickScriptHandler( tempCardUIClick )    
        pCell["img_CardBoxLight"]:setOpacity(0)

        pCell["img_CardBoxCell2"] = pCell:getChildByTag( Tag_arena.IMG_CARDBOXCELL2 )        
	end
    pCell:setName( "" )

    local data = obj.data

    pCell["TxtCardCountRace"]:setString( data.cost )
    pCell["TxtCardCountNum"]:setString(obj.num)
    pCell["TxtCardName"]:setString(data["name_text_"..LANGUAGE])
    pCell["img_CardBoxLight"].id = data.id

    pCell["img_CardBoxCell2"]:setTexture( "collectionwnd/cardImg/"..data.shape..".png" )
    pCell:setContentSize( cc.size( 340, 70 ) )
    mGpvList:insertNodeAtLast( pCell )
end


--初始化界面
function ArenaWindow:onLoadScene()
    ServMsgTransponder:SMTShow( ArenaManager:getCurDeckId() )
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end

function ArenaWindow:onEnterScene()
    local char = CharacterManager:getMainPlayer()    
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_ARENA)
    window = self:getChildByTag(Tag_arena.PANEL_MAIN)


    mLayoutMain = self:getControl(Tag_arena.PANEL_MAIN, Tag_arena.LAYOUT_MAIN)   
    mLayoutRight = self:getControl(Tag_arena.PANEL_MAIN, Tag_arena.LAYOUT_RIGHT_TP)
    mLayoutSelect = self:getControl(Tag_arena.PANEL_MAIN, Tag_arena.LAYOUT_SELECT)
    mLayoutSpends = self:getControl(Tag_arena.PANEL_MAIN, Tag_arena.LAYOUT_SPEEDS)

    mLayoutSelect:setContentSize(1280,720)
    mLayoutSpends:setVisible(false)

    mImgMask = window:getChildByTag(Tag_arena.IMG9_MASK)
    mImgMask:setContentSize( {width = 1280, height = 720} )
    mImgMask:setTouchEnabled(true)
    mImgMask:setOpacity(200)
    mImgMask:setOnClickScriptHandler( cardUIMaskClick )
    mImgMask:setVisible(false)

    mCardUI = require("war2.cardBig").new()
    mCardUI:init( 0 )
    mCardUI:setCardIsFront(true)
    mImgMask:addChild( mCardUI ) 
    mCardUI:setPosition( 680, 400 )

    mBtnPlay = mLayoutMain:getChildByTag(Tag_arena.BTN_PLAY)
    mBtnPlay:setOnClickScriptHandler( BtnPlayClick )  
    mBtnReward = mLayoutMain:getChildByTag(Tag_arena.BTN_REWARD)
    mBtnReward:setOnClickScriptHandler( BtnRewardClick )  
    mBtnGiveUp = mLayoutMain:getChildByTag(Tag_arena.BTN_SURRENDER)
    mBtnGiveUp:setOnClickScriptHandler( BtnGiveUpClick )  

    mBtnClose = mLayoutRight:getChildByTag(Tag_arena.BTN_CLOSE)
    mBtnClose:setOnClickScriptHandler( BtnCloseClick )   
    local btnCost = mLayoutRight:getChildByTag( Tag_arena.BTN_COST ) 
    btnCost:setOnClickScriptHandler( EditorClick )

    mTxtNum = mLayoutRight:getChildByTag(Tag_arena.LABBMF_ALLCARDNUM)
    mTxtNum:setString("0/40")

    local img_head = mLayoutMain:getChildByTag(Tag_arena.IMG_HEAD)
    mImgHead = display.newSprite()
    mImgHead:setTexture("war2/head/HeadPic101"..".png")
    img_head:addChild(mImgHead, -1)
    mImgHead:setPosition(img_head:getContentSize().width * 0.5, 115)    


    for i = 1, 5 do
        mImgWinList[i] = mLayoutMain:getChildByTag(Tag_arena["IMG_LEVEL"..i])
    end

    ArenaManager:initData()

    for i = 1, 3 do
        local img = mLayoutRight:getChildByTag( Tag_arena["IMG_EQUIP_"..i] )  
        img:setTouchEnabled(true)
        img:setOnClickScriptHandler( showCardClick )
        mCardGroupImgList[i] = img
    end

    local cardUI
    for i = 1, 3 do
        cardUI = require("war2.cardBig").new()
        cardUI:setScale(0.7)
        mLayoutSelect:addChild( cardUI )
        local width = 300--cardUI:getContentSize().width * 0.7
        cardUI:setPosition( (580 - width * 3) * 0.5 + width * i, 315 )
--        cardUI:setPosition( (640 - width * 3) * 0.5 + width * i - 640, 120 )
        cardUI:setTouchEnabled(true)
        cardUI:setOnClickScriptHandler( showCardClick )
--        cardUI:setPosition(720,0)
        mRandomEqList[i] = cardUI
    end

    for i = 1, 4 do
        cardUI = require("war2.cardBig").new()
        cardUI:setScale(0.7)
        mLayoutSelect:addChild( cardUI )
        cardUI:init()
        cardUI.index = i
        cardUI:setTouchEnabled(true)
        cardUI:setOnClickScriptHandler( showCardClick2 )
--        cardUI:init(3)
        mRandomCardList[i] = cardUI
    end
    mRandomCardList[1]:setPosition(170, 405)
    mRandomCardList[2]:setPosition(260, 320)
    mRandomCardList[3]:setPosition(705, 405)
    mRandomCardList[4]:setPosition(625, 320)

    mBtnReplace = mLayoutSelect:getChildByTag(Tag_arena.BTN_REPLACE)
    mBtnReplace:setOnClickScriptHandler( BtnReplaceClick ) 
    mBtnKeep = mLayoutSelect:getChildByTag(Tag_arena.BTN_KEEP)
    mBtnKeep:setOnClickScriptHandler( BtnKeepClick ) 
    mBtnSelect1 = mLayoutSelect:getChildByTag(Tag_arena.BTN_SELECT1)
    mBtnSelect1:setOnClickScriptHandler( BtnSelectClick ) 
    mBtnSelect2 = mLayoutSelect:getChildByTag(Tag_arena.BTN_SELECT2)
    mBtnSelect2:setOnClickScriptHandler( BtnSelectClick ) 

    mImgReplace = mLayoutSelect:getChildByTag(Tag_arena.IMG_REPLACE)
    mImgKeep = mLayoutSelect:getChildByTag(Tag_arena.IMG_KEEP)
    mImgSelect1 = mLayoutSelect:getChildByTag(Tag_arena.IMG_SELECT1)
    mImgSelect2 = mLayoutSelect:getChildByTag(Tag_arena.IMG_SELECT2)

    ---------------------花费框------------------------------------------------
    local SpendsBg = mLayoutSpends:getChildByTag( Tag_arena.IMG_PROFILEBOX )
    SpendsBg:setTouchEnabled( true )
    --左上费用1-2-3-4。。。。9
    local prog_Percent = nil
    local font = nil
    for i = 0, 10 do
        prog_Percent = mLayoutSpends:getChildByTag( Tag_arena["PROG_PERCENT"..i] )
        prog_Percent:setDirection( 2 )
        prog_Percent:setValue( 0 )
        prog_Percent:setMaxValue( 40 )
        font = mLayoutSpends:getChildByTag( Tag_arena["LABBMF_PERCENT"..i] )
        font:setString( 0 )
        mCardSpendsArr[i] = {pro = prog_Percent, txt = font}
    end
    mCardTypesArr[1] = mLayoutSpends:getChildByTag( Tag_arena["LABBMF_CREATURENUM"] ) --1生物, 2领域, 3法术, 4闪咒
    mCardTypesArr[2] = mLayoutSpends:getChildByTag( Tag_arena["LABBMF_FLASHNUM"] )
    mCardTypesArr[3] = mLayoutSpends:getChildByTag( Tag_arena["LABBMF_DOMAINNUM"] )
    mCardTypesArr[4] = mLayoutSpends:getChildByTag( Tag_arena["LABBMF_SPELLNUM"] )

    
    mGpvList = mLayoutRight:getChildByTag( Tag_arena.LIST_CARDTEMPCARDS )
    mGpvList:removeAllNodes()
--    mGpvList:reloadData()
    self:updateEqMsg()
    self:updateMsg()

    self:updateGpvCardList()
    ArenaWindow.isShow = true

    if BattleWindow.isShow == true then
        BattleWindow:closeWindow()
    end
end
 
  
function ArenaWindow:onExitScene()
    ArenaWindow.isShow = false
    ArenaWindow.isPopAll = false
    ArenaWindow.isWaiting = false
    UILoadManager:delResByArr( resArr )
end

