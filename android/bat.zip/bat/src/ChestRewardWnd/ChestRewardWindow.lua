ChestRewardWindow = class("ChestRewardWindow", function() 
    return CLayout:create()
end)

local ServMsgTransponder = require("net.ServMsgTransponder")
local TextManager = require("ui.TextManager"):instance()

local mBoxArr
-- 道具资源数组
local mItemResArr = {}
--当前显示Item容器
local mCurShowVec
--当前显示步骤
local mType = 0  --0初始，1初始道具 2换位置道具 3选择宝箱道具 4钻石选择宝箱道具 5显示视频 6显示选中道具

local btn_Click
--按钮文本
local txt_btn

local function onPlayVideoSpClick(p_sender)
    print("onPlayVideoSpClick")
end

--按钮点击事件
local function onClick(p_sender)
    print(111)
end

--随机调换了位置后选择宝箱
local function RandomOpenBox()
    local btn_Box = nil
    local btn_PlayVideo = nil
    local RewardItem = nil
    local txt = nil
    for i = 1, 6 do
        btn_Box = CButton:create()
        btn_Box:setNormalSpriteFrameName( "mainwnd/btn_Box_normal.png" )
        btn_Box:setPosition(-200 + 350 * (i%3),-250 + 300 * math.ceil(i/3))
        btn_Box:setScale(1.5)
        mCurShowVec:addChild(btn_Box)

        if mType == 3 then
            btn_PlayVideo = CButton:create("other/btn_PlayVideo_normal.png")
            btn_PlayVideo:setPosition(-190 + 350 * (i%3),-250 + 300 * math.ceil(i/3))
            mCurShowVec:addChild(btn_PlayVideo)
            btn_PlayVideo:setOnClickScriptHandler(onPlayVideoSpClick)
            btn_Box:setOnClickScriptHandler(onPlayVideoSpClick)
        end

        if mType == 4 then
            RewardItem = display.newSprite()
            RewardItem:setTexture("other/img_BigSpar.png")
            RewardItem:setPosition(-160 + 350 * (i%3),-310 + 300 * math.ceil(i/3))
            RewardItem:setScale(0.3)
            mCurShowVec:addChild(RewardItem)

            txt = TextManager:createTxt( "99", 35, TXTFONTNAME )
            txt:enableOutline(cc.c4b(0,0,0,255),2)
            txt:setTextColor(cc.c4b(255,255,255,255))
            txt:setAlignment( 1, 0 )
            txt:setDimensions(800, 20)
            txt:setPosition(RewardItem:getPositionX() - 40,RewardItem:getPositionY() + 10)
            mCurShowVec:addChild(txt)
        end
    end

    if mType == 4 then
        txt_btn:setString(DataManager:getStringDataTxt(88, true))
        txt_btn:setVisible(true)
        btn_Click:setVisible(true)
    else
        txt = TextManager:createTxt( "", 45, TXTFONTNAME )
        txt:enableOutline(cc.c4b(0,0,0,255),2)
        txt:setTextColor(cc.c4b(255,255,255,255))
        txt:setAlignment( 1, 0 )
        txt:setDimensions(800, 20)
        mCurShowVec:addChild(txt)
        if mType == 2 then
            txt:setString(DataManager:getStringDataTxt(3020, true))
            txt:setPosition( 100, -90 )
            local CharacterManager = require("characters.CharacterManager"):instance()
            local ImgKey = CImageView:createWithSpriteFrameName( "mainwnd/btn_TopButton2+N_normal.png" )
            mCurShowVec:addChild(ImgKey)
            ImgKey:setPosition(450,-100)

            local char = CharacterManager:getMainPlayer()
            txt = TextManager:createTxt( "x"..char.CharKey, 34, TXTFONTNAME )
            txt:enableOutline(cc.c4b(0,0,0,255),2)
            txt:setTextColor(cc.c4b(255,255,255,255))
            txt:setPosition( ImgKey:getPositionX() + 10, ImgKey:getPositionY() + 10 )
            txt:setAlignment( 1, 0 )
            txt:setDimensions(500, 20)
            mCurShowVec:addChild(txt)
            txt:setPosition( 455, -90 )
        else
            txt:setString(DataManager:getStringDataTxt(3021, true))
            txt:setPosition( 100, -90 )
        end
    end
end

--后台初始随机选出的道具
local function InitRandomItem()
    local sprite = nil
    local hId = 1
    
    for i = 1, 6 do
        sprite = display.newSprite()
        hId = math.random(1,4)
        sprite:setTexture("other/"..mItemResArr[hId]..".png")
        sprite:setPosition(-200 + 300 * (i%3),-250 + 300 * math.ceil(i/3))
        mCurShowVec:addChild(sprite)
    end
    txt_btn:setString(DataManager:getStringDataTxt(43, true))
    txt_btn:setVisible(true)
    btn_Click:setVisible(true)
end

--更新当前显示界面
function ChestRewardWindow:updataShow()
    if mCurShowVec == nil then
        mCurShowVec = CLayout:create()
        mCurShowVec:setPosition(640,360)
        window:addChild(mCurShowVec)
    else
        mCurShowVec:removeFromParent()
    end
    if mType == 1 then
        InitRandomItem()
    elseif mType == 5 then
        local sprite = display.newSprite()
        local hId = math.random(1,4)
        sprite:setTexture("other/"..mItemResArr[hId]..".png")
        sprite:setPosition(150, 150)
        mCurShowVec:addChild(sprite)

        local txt = TextManager:createTxt( "x999", 45, TXTFONTNAME )
        txt:enableOutline(cc.c4b(0,0,0,255),2)
        txt:setTextColor(cc.c4b(255,255,255,255))
        txt:setPosition( 150, 100 )
        txt:setAlignment( 1, 0 )
        txt:setDimensions(500, 20)
        mCurShowVec:addChild(txt)
    else
        RandomOpenBox()
    end
end

function ChestRewardWindow:init(num)
    local DataManager = require("data.DataManager"):instance()
    local CharacterManager = require("characters.CharacterManager"):instance()
    self:setContentSize(cc.size(1280,720))  
    window = self
    mBoxArr = {}

    local btn_WindowBack = CButton:create("other/btn_Mask_normal.png")
    btn_WindowBack:setPosition(640,360)
    self:addChild(btn_WindowBack)

    btn_Click = CButton:create("other/btn_QuestButton+N_normal.png")
    btn_Click:setPosition(640,60)
    btn_Click:setOnClickScriptHandler(onClick)
    self:addChild(btn_Click)
    btn_Click:setVisible(false)

    txt_btn = TextManager:createTxt( "", 34, TXTFONTNAME )
    txt_btn:enableOutline(cc.c4b(0,0,0,255),2)
    txt_btn:setTextColor(cc.c4b(255,255,255,255))
    txt_btn:setPosition( 640, 70 )
    txt_btn:setAlignment( 1, 0 )
    txt_btn:setDimensions(260, 20)
    self:addChild(txt_btn)
    txt_btn:setVisible(false)
    
    mType = 3
    mItemResArr = {"img_FewGold","img_MoreGold", "img_Store+AddGoldItem+GoldBox1", "img_BigSpar"}
    self:updataShow()
end

--清空、删除
function ChestRewardWindow:clear() 
    for i = 1, #mBoxArr do
        mBoxArr[i]:clear()
    end

end


--计时器开启或关闭
function ChestRewardWindow:setBattleTimer(bol)
    --计时器开启 
    if bol == true and self.BattleTimer == nil then
        local fuc = function () self:updateBattleTimer() end
        self.BattleTimer = require("framework.scheduler").scheduleGlobal( fuc, battleDelayTimes )
    elseif bol == false then
        require("framework.scheduler").unscheduleGlobal( self.BattleTimer )--清理计时器
        self.BattleTimer = nil
    end
end

--计时器
function ChestRewardWindow:updateBattleTimer()
    battleTimes = battleTimes - battleDelayTimes
    if battleTimes > 0 then return end
    local obj = self.BattlePhaseList[1]
    if obj == nil then 
        if self.isPlaying == false then
            self:setBattleTimer(false)
        end
        return 
    end
    
    local data = obj.data
    local fun = obj.fun
    local dtime = obj.dtime
    self.bda = data
    fun()
    battleTimes = dtime 
    self.bda = nil
    table.remove( self.BattlePhaseList, 1 )
end

return ChestRewardWindow