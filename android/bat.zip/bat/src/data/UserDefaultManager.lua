local UserDefaultManager = class()-- 定义一个类 test 继承于 base_type


--用户本地信息管理
function UserDefaultManager:ctor()

	print("UserDefaultManager:ctor --------------------------")
	
end

--是否可以发送log
local mBolSendLog = true

function UserDefaultManager:instance()
    local o = _G.UserDefaultManager
    if o then
    	return o
	end
 
    o = UserDefaultManager:new()
	_G.UserDefaultManager = o
    UserDefaultManager:init()
    return o
end


--初始化, isExisted表示是否已经在本地有保存数据, 没有的话则把当前语言版本等信息保存到本地
function UserDefaultManager:init()
    if UserDefaultManager:getBoolForKey( "isExisted" ) == true then
        --语言版本
        LANGUAGE = self:getStringForKey( "LANGUAGE" )
        --是否可以播放音乐
        IS_OPEN_MUSIC = self:getBoolForKey( "IS_OPEN_MUSIC" )
        --是否可以播放音效
        IS_OPEN_SOUND = self:getBoolForKey( "IS_OPEN_SOUND" )
        --是否可以播放音效
        IS_OPEN_WATCH = self:getBoolForKey( "IS_OPEN_WATCH" )
        --是否可以播放音效
        IS_OPEN_CHALLER = self:getBoolForKey( "IS_OPEN_CHALLER" )
        --是否开启全屏模式 需要重启游戏
        IS_OPEN_FULLSCREENMODE = self:getBoolForKey( "FullScreenMode" )
--        --是否开启写入Log打印信息
--        DEBUG_ISOPENWRITEMSG = self:getBoolForKey( "ISOPENWRITEMSG" )
        --是否使用备用线路
        IS_OPEN_FONTALINE = self:getBoolForKey( "IS_OPEN_FONTALINE" )

    else
--        --语言版本
        self:setStringForKey( "LANGUAGE", LANGUAGE )
        --是否可以播放音乐
        self:setBoolForKey( "IS_OPEN_MUSIC", IS_OPEN_MUSIC )
        --是否可以播放音效
        self:setBoolForKey( "IS_OPEN_SOUND", IS_OPEN_SOUND )
        --是否可以播放音效
        self:setBoolForKey( "IS_OPEN_WATCH", IS_OPEN_WATCH )
        --是否可以播放音效
        self:setBoolForKey( "IS_OPEN_CHALLER", IS_OPEN_CHALLER )
        --是否开启全屏模式 需要重启游戏
        self:setBoolForKey( "FullScreenMode", IS_OPEN_FULLSCREENMODE )
        --是否开启写入Log打印信息
        self:setBoolForKey( "ISOPENWRITEMSG", DEBUG_ISOPENWRITEMSG )
        --是否使用备用线路
        self:setBoolForKey( "IS_OPEN_FONTALINE", IS_OPEN_FONTALINE )
    end

    self:setBoolForKey( "isExisted", true )
end


--key 关键词,没有保存相关的值的话默认返回""
function UserDefaultManager:getStringForKey( key )
    key = tostring(key)
    return cc.UserDefault:getInstance():getStringForKey( key )
end

function UserDefaultManager:setBolSendLog( bol )
    mBolSendLog = bol
end

function UserDefaultManager:setStringForKey( key, value )
    key = tostring(key)
    value = tostring(value)
    cc.UserDefault:getInstance():setStringForKey( key, value )  
end

--key 关键词,没有保存相关的值的话默认返回false
function UserDefaultManager:getBoolForKey( key )
    key = tostring(key)
    local str = cc.UserDefault:getInstance():getStringForKey( key )
    if str == "true" then
        return true 
    else
        return false
    end
--    return cc.UserDefault:getInstance():getBoolForKey( key )
end

function UserDefaultManager:setBoolForKey( key, value )
    key = tostring(key)
    local str 
    if value then
        str = "true" 
    else
        str = "false"  
    end
    cc.UserDefault:getInstance():setStringForKey( key, str )  
--    cc.UserDefault:getInstance():setBoolForKey( key, value )  
end



local uploadPhp = "http://106.12.128.7/mhhz/mobile/update_build/upload.php"
function UserDefaultManager:uploadLog( bolEx )
    if mBolSendLog == false then return end
    local accounts = LoginSer.accounts  --$_FILES["filepath"];上传的文件参数可以在php这里获取

    if bolEx == true then
        uploadPhp = "http://106.12.128.7/mhhz/mobile/update_build/uploadEX.php"

        network.uploadFile(function(evt)
--        print("evet "..evt.name)
	    if evt.name == "completed" then
		    local request = evt.request
		    printf("REQUEST getResponseStatusCode() = %d", request:getResponseStatusCode())
		    printf("REQUEST getResponseHeadersString() =\n%s", request:getResponseHeadersString())
 		    printf("REQUEST getResponseDataLength() = %d", request:getResponseDataLength())
            printf("REQUEST getResponseString() =\n%s", request:getResponseString())
	    end
    end,
    --	"http://127.0.0.1/upload.php",
        uploadPhp,
	    {
		    fileFieldName="filepath",
		    filePath = DEBUG_WRITEMSGURL2,
    --		contentType="Image/jpeg",
		    extra={
			    {"act", "upload"},
			    {"submit", "upload"},
                {"accounts", require("net.LoginSer"):instance().accounts}, --这里extra的参数在$_POST中能找到，如这里$_POST["act"]的值是upload
		        }
	        }
        )
    end
    network.uploadFile(function(evt)
--        print("evet "..evt.name)
		if evt.name == "completed" then
			local request = evt.request
			printf("REQUEST getResponseStatusCode() = %d", request:getResponseStatusCode())
			printf("REQUEST getResponseHeadersString() =\n%s", request:getResponseHeadersString())
 			printf("REQUEST getResponseDataLength() = %d", request:getResponseDataLength())
            printf("REQUEST getResponseString() =\n%s", request:getResponseString())
		end
	end,
--	"http://127.0.0.1/upload.php",
    uploadPhp,
	{
		fileFieldName="filepath",
		filePath = DEBUG_WRITEMSGURL,
--		contentType="Image/jpeg",
		extra={
			{"act", "upload"},
			{"submit", "upload"},
            {"accounts", require("net.LoginSer"):instance().accounts}, --这里extra的参数在$_POST中能找到，如这里$_POST["act"]的值是upload
		    }
	    }
    )
end

return UserDefaultManager