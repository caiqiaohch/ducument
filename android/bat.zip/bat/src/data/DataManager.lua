local DataManager = class()-- 定义一个类 test 继承于 base_type

local ShopManager = require("Shop.ShopManager"):instance()
local ItemManager = require("Shop.ItemManager"):instance()

function DataManager:ctor()

	print("DataManager:ctor --------------------------")
	
end


--在DataManager里面读取的文本,在更改语言的时候需要重新处理
local mTextLanguageList = {}

function DataManager:instance()
    local o = _G.DataManager
    if o then
    	return o
	end
 
    o = DataManager:new()
	_G.DataManager = o
    DataManager:init()
    return o
end

function DataManager:init()
    --角色基本属性表数据
    self.DataCharAttArr = {}
    --角色起始套牌表数据
    self.DataInitCardArr = {}
    --经验表数据
    self.DataCharExpArr = {}
    --文字卡牌表数据
    self.DataTxtCardArr = {}
    --文字其他表数据
    self.DataTxtArr = {}
    --文字表关键字图片
    self.DataTxtKeyImage = {}
    --技能表数据
    self.DatakillArr = {}
    --全牌圣物表数据
    self.DataEqArr = {}
    --全牌卡牌表数据
    self.DataCardArr = {}
    --全牌兵种地形表数据
    self.DataTroopArr = {}
    --全牌关键字技能表数据
    self.DataKeySkillArr = {}
    --模型控制表数据
    self.DataModelArr = {}
    --任务表数据
    self.DataTask = {}
    --成就表数据
    self.DataAchieve = {}
    --成就表数据 按分类划分
    self.DataAchieveClass = {}
    --STEAM成就表数据
    self.DataAchieveSteam = {}
    --排行榜奖励表数据
    self.DataRank = {}
    --奖励表
    self.DataReward = {}
    --音效表数据
    self.DataMusic = {}
    --音效对应特效ID表数据
    self.DataEffectMusic = {}
    --地图怪物配置
    self.DataMapNpc = {}
    --地图怪物配置 用npc_camp分组
    self.DataMapCampNpc = {}

    --预组套牌
    self.DataYzTp = {}
    --电脑套牌
    self.DataNpcTp = {}
    self.DataNpcTpNum = {}
    self.DataPlayerTp ={}
    self.DataPlayerTpNum = {}

    --竞技场圣物卡池表 根据派系race分组
    self.DataArenaEquipList = {}
    --竞技场卡池表 根据稀有度qlt分组
    self.DataArenaCardList = {}

    --经验表数据 获取各个经验段的数据列表{70,92,162,286,470...}
    self.DataLvExpArr = {}
    --排行榜奖励表数据 获取各个段的数据列表{99,199,349,499...}
    self.DataLvRankArr = {}
end

local function read_config_line(nLine,fLine,tLine,count,i)
    local size,j,m,iType,id, id0, flag
    local nTmp,cTmp,tag, type, file
    local mpConfigTmp, mpTmp
    mpTmp = {};
	for j=1,count,1 do
	   --去掉为0项
	    if nLine[j] ~= "0" then
		   tag = string.format("%s", fLine[j])
		   --去掉标签名中的空格
		   tag = string.trim(tag)
		   type = string.format("%s", tLine[j])
		   --去掉类型名中的空格
		   type = string.trim(type)
		   --字符串
		   if type == "string" then
			   mpTmp[tag] = nLine[j]
		   --浮点型
		   elseif type == "float" then
			   mpTmp[tag] = tonumber(nLine[j])
		   --int型
		   elseif type == "int" then
			   mpTmp[tag] = tonumber(nLine[j])
		   else
			--   logstat.log_day("read_config.txt",string.format("read_config_line j[%d] type:%s |\n",j,type))
		   end
		end
		
	 end --for j=0,count,1
	 
	return mpTmp
end


--读取配置文件
--函数：读取配置文件，适用于配置表中 一对一 或 一对多 的读取
--注意：多对一方式读取出来的数据，同一编号对应一个mapping，此mapping为每条数据为一个数组的集合
--传参格式：config : ({ file, flag(0 一对一/ 1 一对多/ 2 两层mapping) })
--返回值格式：
--      1.一对一：([ key : ([ value ]) ])
--      2.一对多：([ key : ({ ([value1]), ([value2]),  }) ])
--      3.两层mapping：([ key1 : ([key11 : ([value11]), ]),
--                           ([key12: ([value12]), ]) ])
function DataManager:analysisData2( fileName ,flag)

    local saveDataArr ,i,temp,txt,isCard,cLine
    local mpConfigTmp = {}
    local str = cc.FileUtils:getInstance():getStringFromFile("data/"..fileName..".tcg")
    str = DataManager:JieMi(str)
    local arr = string.split( str, "\n" )
    local nTmp = {}
    for i = 2, #arr - 1 do
        nTmp[i-1] = string.split( arr[i], "(-]" )
    end

    size=table.getn(nTmp)

    for i=1,#nTmp do
        nLine = nTmp[i]     
--        if cLine~=nil then 
--            nLine = explode(cLine,"\t")
--        end
        if i == 1 then--首行标签行不能变       
            count = table.getn(nLine)
            fLine = clone(nLine)
        elseif i == 2 then--字段数据类型行
            count = table.getn(nLine)
            tLine = clone(nLine)
        else 
            --用首行的标签行属性列数来确定数据项是否正确
            if  table.getn(nLine) ~= count then
            elseif  nLine~=nil then          
                mpTmp = read_config_line(nLine,fLine,tLine,count,i)
				--nLine[0] ID列不能变
				id = tonumber(nLine[1])
			    
				if flag==1 then --一对多		   
					if mpConfigTmp[id]==nil then
						mpConfigTmp[id] = {};
					end
					table.insert(mpConfigTmp[id],clone(mpTmp))
				elseif flag==2 then --两层mapping
					id0 = tonumber(nLine[2]); --默认第二列为mapping的第二层key
					if mpConfigTmp[id]==nil then
						mpConfigTmp[id] = {};
					end
					mpConfigTmp[id][id0] = {};
					mpConfigTmp[id][id0] = clone(mpTmp);				
				else --一对一
					mpConfigTmp[id] = {};
					mpConfigTmp[id] = clone(mpTmp);
				end
				
              end

		end

    end--for i=0,size,1
    mpConfigTmp[0] = nil
    return clone(mpConfigTmp)  

end
function DataManager:addTextLanguageList( txtData, date, key, langKey )    
    if langKey == nil then
        langKey = "text_"
    end
    if txtData == nil then
        date[key] = ""
    else
        date[key] = txtData[langKey..LANGUAGE]
    end

    local obj = {txtData = txtData, date = date, key = key ,langKey = langKey}
    table.insert(mTextLanguageList, obj)
end

function DataManager:setTextByLanguage()
    local obj
    for i = 1, #mTextLanguageList do
        obj = mTextLanguageList[i]
        if obj.txtData == nil then
            obj.date[obj.key] = ""
        else
            obj.date[obj.key] = obj.txtData[obj.langKey..LANGUAGE]
        end
    end
end

--解析表
function DataManager:analysisData( saveDataArr, fileName )
    local str = cc.FileUtils:getInstance():getStringFromFile("data/"..fileName..".tcg")
    str = DataManager:JieMi(str)
    local arr = string.split( str, "\n" )
    local dataArr = {}
    for i = 2, #arr - 1 do
        dataArr[i] = string.split( arr[i], "(-]" )
    end

    local temp = nil
    local txt = nil
    local isCard = (fileName == "dataCard") or (fileName == "dataEquip")
    for i = 4, #dataArr do   
        temp = {}
        saveDataArr[ tonumber(dataArr[i][1]) ] = temp
        for j = 1, #dataArr[2] - 1 do
            if dataArr[2][j] ~= nil then
                if dataArr[3][j] == "int" then
                   temp[dataArr[2][j]] = tonumber(dataArr[i][j])
                else
                   local str = tostring(dataArr[i][j])
                   if str == nil then str = "" end          
                   temp[dataArr[2][j]] = string.gsub(str, "\\n", "\n")
                end
            end
        end

        --全牌表卡牌处理
        if isCard == true then
            txt = DataManager.DataTxtCardArr[temp.text]
            if txt == nil then print(temp.text.." txt is nil") end
            for j, v in pairs(txt) do
                temp[j] = v
            end

            --根据3个阵营设置显示阵营索引
            --圣物
            if temp.race1 == nil then
                temp.showRace = temp.race
            --部队
            else

                temp.showRace = {temp.race1, temp.race2, temp.race3}
            end
            
            --设置血量上限
            if temp.health ~= nil then
                temp.curHealth = temp.health
                temp.maxHealth = temp.health
            end

            --设置当前攻击力
            if temp.atk ~= nil then
                temp.curAtk = temp.atk
            end

            --设置技能列表
            if temp.skill_id ~= nil then
                temp.skillList = string.split(temp.skill_id, ",")
                for ii = 1, #temp.skillList do
                    temp.skillList[ii] = tonumber(temp.skillList[ii])
                end
            end

             --设置条件优先级
            if temp.state_PRI ~= nil then
                temp.state_PRI = string.split(temp.state_PRI, "#")
                for ii = 1, #temp.state_PRI do
                    temp.state_PRI[ii] = string.split(temp.state_PRI[ii], ",")
                    for jj = 1, #temp.state_PRI[ii] do
                        temp.state_PRI[ii][jj] = tonumber(temp.state_PRI[ii][jj])
                    end
                end
            end

            if fileName == "dataEquip" then
                temp.cost = 0

                if temp.arena > 0 then --如果是竞技场的卡牌
                    if self.DataArenaEquipList[ temp.race ] == nil then
                        self.DataArenaEquipList[ temp.race ] = {}
                    end
                    table.insert( self.DataArenaEquipList[ temp.race ], temp )
                end
            else
                if temp.arena > 0 then --如果是竞技场的卡牌
                    if self.DataArenaCardList[ temp.qlt ] == nil then
                        self.DataArenaCardList[ temp.qlt ] = {}
                    end
                    table.insert( self.DataArenaCardList[ temp.qlt ], temp )
                end
            end

            

        --关键字技能
        elseif fileName == "dataKeySkill" then
            local txtData = self:getStringDataTxt(temp.name_text)
            DataManager:addTextLanguageList( txtData, temp, "name_text" )
            txtData = self:getStringDataTxt(temp.desc_text)
            DataManager:addTextLanguageList( txtData, temp, "desc_text" )
        elseif fileName == "dataTask" or fileName == "dataAchieve" then
            local txtData = self:getStringDataTxt(temp.quest_name)
            DataManager:addTextLanguageList( txtData, temp, "quest_name" )
            txtData = self:getStringDataTxt(temp.quest_require)
            DataManager:addTextLanguageList( txtData, temp, "quest_require" )
            if fileName == "dataAchieve" then
                if temp.class ~= 0  then
                    if self.DataAchieveClass[temp.class] == nil then self.DataAchieveClass[temp.class] = {} end
                    table.insert( self.DataAchieveClass[temp.class], temp )
                end
                if temp.Steam_updata == 1 then
                    self.DataAchieveSteam[temp.quest_id] = 0
                end
            end
        elseif fileName == "dataRank" then
            local txtData = self:getStringDataTxt(temp.quest_name)
            DataManager:addTextLanguageList( txtData, temp, "quest_name" )
            txtData = self:getStringDataTxt(temp.quest_require)
            DataManager:addTextLanguageList( txtData, temp, "quest_require" )
        elseif fileName == "dataYzTp" then
            local txtData = self:getStringDataTxt(temp.quest_name)
            DataManager:addTextLanguageList( txtData, temp, "quest_name" )
            txtData = self:getStringDataTxt(temp.quest_require)
            DataManager:addTextLanguageList( txtData, temp, "quest_require" )
        elseif fileName == "dataReward" then
            local txtData = self:getStringDataTxt(temp.quest_name)
            DataManager:addTextLanguageList( txtData, temp, "quest_name" )            
            txtData = self:getStringDataTxt(temp.quest_require)
            DataManager:addTextLanguageList( txtData, temp, "quest_require" )
        elseif fileName == "dataMapNpc" then
            local txtData = self:getStringDataTxt(temp.npc_name)
            DataManager:addTextLanguageList( txtData, temp, "npc_name" )
            txtData = self:getStringDataTxt(temp.npc_desc)
            DataManager:addTextLanguageList( txtData, temp, "npc_desc" )
            if temp.npc_camp ~= 0 then
                if self.DataMapCampNpc[ temp.npc_camp ] == nil then
                    self.DataMapCampNpc[ temp.npc_camp ] = {}
                end
                table.insert( self.DataMapCampNpc[ temp.npc_camp ], temp )
            end
        end
        temp = nil
    end

    if fileName == "dataMusic" then
        local btn = CButton:create()
        btn:setTag(707)
		btn:setName( self:getMusic(100).DubbingMusic )--设置按键音效
        btn:setText( " " )
        btn:removeFromParent()

        local musicArr
        for k, v in pairs(self.DataMusic) do
            musicArr = string.split( v.EffectMusic_desc, "#" )
            for i = 1, #musicArr do
                if tonumber(musicArr[i]) then
                    self.DataEffectMusic[ tonumber(musicArr[i]) ] = v.EffectMusic_ID
                end
            end         
        end    
    end

end

function DataManager:JieMi(dataStr)
    local crypto = require("loader.crypto")
    k = "xiangyuTcgHy401"           --密匙, 同样写在导表工具的pyjiami.py里面
    d = crypto.decodeBase64(dataStr)
    local str = crypto.decryptXXTEA(d, k)
    if str then
--        print(str)
    else print("str is nil") end
    return str
end

--加载所有表数据
function DataManager:loadAll()

    self:analysisData(  self.DataCharAttArr, "dataCharAtt" )
    self:analysisData(  self.DataInitCardArr, "dataInitCard" )
    self:analysisData(  self.DataCharExpArr, "dataCharExp" )
    self:analysisData(  self.DataTxtCardArr, "dataTxtCard" )
    self:analysisData(  self.DataTxtArr, "dataTxt" )
    self:analysisData(  self.DataTxtKeyImage, "dataTxtKeyImage" )
    self:analysisData(  self.DatakillArr, "dataSkill" )
    self:analysisData(  self.DataEqArr, "dataEquip" )
    self:analysisData(  self.DataCardArr, "dataCard" )
    self:analysisData(  self.DataTroopArr, "dataTroop" )
    self:analysisData(  self.DataKeySkillArr, "dataKeySkill" )
    self:analysisData(  self.DataModelArr, "dataModel" )
    self:analysisData(  self.DataTask, "dataTask" )
    self:analysisData(  self.DataAchieve, "dataAchieve" )
    self:analysisData(  self.DataReward, "dataReward" )
    self:analysisData(  self.DataRank, "dataRank" )
    self:analysisData(  self.DataMusic, "dataMusic" )
    self:analysisData(  self.DataMapNpc, "dataMapNpc" )

    self.DataYzTp = self:analysisData2(  "dataYzTp" )
    self.DataNpcTp = self:analysisData2(  "dataNpcTp" ,2)
    self.DataPlayerTp = self:analysisData2(  "dataPlayerTp" ,2)
    --初始化技能表数据
    local SkillManager = require("skill.SkillManager"):instance()
    SkillManager:init()

    ShopManager:loadAll()
    ItemManager:loadAll()
end

function DataManager:AnaliseDataPlayerTp(id)
    local dataMap = {}
    local data
    local mDataPlayerTp = self.DataPlayerTp[id]

    for i = 4, #mDataPlayerTp do
         data = mDataPlayerTp[i]
         if dataMap[data.card_id] == nil then 
            dataMap[data.card_id] = 0
         end
         dataMap[data.card_id] = dataMap[data.card_id]+1
    end
    self.DataPlayerTpNum[id] = dataMap

end

--玩家预组套牌
function DataManager:getDataPlayerTpNum(id)
    if self.DataPlayerTpNum[id] == nil then 
        self:AnaliseDataPlayerTp(id)
    end
    return self.DataPlayerTpNum[id]
end

function DataManager:getDataPlayerTp(id)
    return self.DataPlayerTp[id]
end

function DataManager:analyseDataNpcTp(id)
    local dataMap = {}
    local data
    local mDataNpcTp = self.DataNpcTp[id]
    if mDataNpcTp == nil then return end
    for i = 4, #mDataNpcTp do
         data = mDataNpcTp[i]
         if dataMap[data.card_id] == nil then 
            dataMap[data.card_id] = 0
         end
         dataMap[data.card_id] = dataMap[data.card_id]+1
    end
    self.DataNpcTpNum[id] = dataMap

end


--电脑预组套牌
function DataManager:getDataNpcTpNum(id)
    if self.DataNpcTpNum[id] == nil then 
        self:analyseDataNpcTp(id)
    end
    return self.DataNpcTpNum[id]
end


function DataManager:getDataNpcTp(id)
    return self.DataNpcTp[id]
end

function DataManager:getYzTp()
    return self.DataYzTp
end

function DataManager:getYzTpData(id)
    id = tonumber(id)
    return self.DataYzTp[id]
end

--根据卡牌ID获取全牌表指定牌对象
function DataManager:getCardObjByID( id, isClone )
    isClone = isClone or false
    id = tonumber(id)
    if isClone == true then
        local data = self.DataCardArr[id]
        local obj = {}
        for i, v in pairs(data) do
            obj[i] = v
        end
        return obj
    end
    return self.DataCardArr[id]
end

--根据ID获取将军信息对象
function DataManager:getEq( id )
    id = tonumber(id)
    return self.DataEqArr[id]
end

--根据ID获取任务信息
function DataManager:getTask(id)
    id = tonumber(id)
    return self.DataTask[id]
end

--根据ID获取成就信息
function DataManager:getAchieve(id)
    id = tonumber(id)
    return self.DataAchieve[id]
end

function DataManager:getDataRank()
    return self.DataRank
end

--排行榜积分数据 获取各个段的数据列表{99,199,349,499...}
function DataManager:getDataLvRankArr()
    if self.DataLvRankArr == nil or #self.DataLvRankArr == 0 then
        self.DataLvRankArr = {}
        for k, v in pairs(self.DataRank) do
            table.insert( self.DataLvRankArr, v.integral )
        end

        function comps(a,b)
            return a < b
        end
        table.sort(self.DataLvRankArr,comps)
    end
    return self.DataLvRankArr
end

function  DataManager:getDataReward(id)
    id = tonumber(id)
    return self.DataReward[id]
end


--根据ID获取音效信息
function DataManager:getMusic(id)
    id = tonumber(id)
    return self.DataMusic[id]
end

--根据特效ID获取震屏信息
function DataManager:getEffectVibrating(effId)
    effId = tonumber(effId)
    local musicId = self.DataEffectMusic[ effId ]
    if musicId == nil then return nil end
    if self.DataMusic[musicId] then
        local scrArr = string.split( self.DataMusic[musicId].Vibrating , "," )
        if #scrArr > 5 then
            if scrArr[7] == nil or scrArr[7] == 0 then
                scrArr[7] = false
            end
            for i = 1, 6 do
                scrArr[i] = tonumber(scrArr[i])
            end    
            return scrArr
        end    
    end
    return nil
end

--根据粒子ID获取对应的音效信息
function DataManager:getEffectMusicId(effId)
    local musicId = self.DataEffectMusic[ effId ]
    if musicId == nil then musicId = 0 end
    return musicId
end

--地图怪物配置
function DataManager:getDataMapNpcbyDi(id)
    id = tonumber(id)
    return self.DataMapNpc[id]
end

function DataManager:getDataMapNpc()
    return self.DataMapNpc
end

--获得各大关的列表
function DataManager:getDataMapCampNpc()
    return self.DataMapCampNpc
end

--获得某一个大关的NPC数据列表
function DataManager:getDataMapCampList( camp )
    return self.DataMapCampNpc[camp]
end



--根据国家ID获取初始表起始套牌
function DataManager:getInitHandCardList( id )
    local index = 1
    local list = {}
    local CountryID = id*100 + 1

    local temp = nil
    while true do
        temp = self.DataInitCardArr[CountryID]
        if temp == nil then break end
        list[index] = temp.card_id
        index = index + 1
        CountryID = CountryID + 1
    end

    return list
end

--根据ID获取文字表其他分页数据
function DataManager:getStringDataTxt( id, bol )
    id = tonumber(id)
    local str
    if bol == true then
        local data = DataManager:getStringDataTxt(id)
        if data ~= nil then
            str = data["text_"..LANGUAGE]
        else
            str = ""
        end
    else
        str = self.DataTxtArr[id]
    end    
    if bol == true then
        local CharacterManager = require("characters.CharacterManager"):instance()
        if CharacterManager:getMainPlayer() then
            str = string.gsub(str, "$999",  CharacterManager:getMainPlayer().Name)
        end   
    end

    return str
end

--根据ID获取关键技能表数据
function DataManager:getKeySkilltData( id )
    id = tonumber(id)
    return self.DataKeySkillArr[id]
end

--根据ID获取模型控制表数据
function DataManager:getModelData( id )
    id = tonumber(id)
    return self.DataModelArr[id]
end

--根据ID获取文本表关键字对应图片
function DataManager:getTxtKeyImage( id )
    id = tonumber(id)
    return self.DataTxtKeyImage[id]
end

--根据等级获取需求经验
function DataManager:getExp( lv )
    lv = tonumber(lv)
    if self.DataCharExpArr[lv] == nil then
        return 1
    else
        return self.DataCharExpArr[lv].exp
    end
end

--经验表数据 获取各个经验段的数据列表{70,92,162,286,470...}
function DataManager:getDataLvExpArr()
    if self.DataLvExpArr == nil or #self.DataLvExpArr == 0 then
        self.DataLvExpArr = {}
        for k, v in pairs(self.DataCharExpArr) do
            table.insert( self.DataLvExpArr, v.exp )
        end

        function comps(a,b)
            return a < b
        end
        table.sort(self.DataLvExpArr,comps)
        for i = 2, #self.DataLvExpArr do
            self.DataLvExpArr[i] = self.DataLvExpArr[i - 1] + self.DataLvExpArr[i]
        end
    end   
    return self.DataLvExpArr
end


function changeImgXML( ret, nodeXml )
    if ret == nil or nodeXml == nil then return end
    if nodeXml["@type"] == "image" and nodeXml["@image"] ~= nil then --== "collectionwnd/img_CardBoxHead+Front.png" then
        if string.find( nodeXml["@image"] , "_en.png" ) ~= nil then
            local str = string.gsub( nodeXml["@image"], "_en.png", "_"..LANGUAGE..".png")
            ret:getChildByTag( nodeXml["@tag"] ):setTexture( str )
            nodeXml["@image"] = str
        end        
        print( nodeXml["@image"] )
    elseif nodeXml.control ~= nil and #nodeXml.control > 0 then
        if nodeXml["@tag"] ~= nil then
            ret = ret:getChildByTag( nodeXml["@tag"] )
        end
        for i = 1, #nodeXml.control do
            changeImgXML( ret, nodeXml.control[i] )
        end
    end 

end

--解析XML 使用的是Lua-Simple-XML-Parser
function DataManager:ParsingXML( ret, xmlFilename )
    local xml = require("data.xmlSimple").newParser()
    local node = xml:loadFile("res/"..xmlFilename)
--    for i = 1, #nodeXml.userDefaultRoot.___children do
--        print(nodeXml.userDefaultRoot.___children[i].___value)
--    end
    changeImgXML(ret, node)
    print(#node.control)
end

return DataManager