local FriendManager = class()-- 定义一个类 test 继承于 base_type
--所在列表类型 1：好友 2：仇敌 3：相识 4：黑名单
FriendManager.TYPE_HAO_YOU	= 1			--1：好友
FriendManager.TYPE_LING_SHI	= 2			--2：申请人
FriendManager.TYPE_XIANG_SHI= 3			--3：相识
FriendManager.TYPE_BLACK	= 4			--4：黑名单
function FriendManager:ctor()

	print("DataManager:ctor --------------------------")
	
end


function FriendManager:instance()
    local o = _G.FriendManager
    if o then
    	return o
	end
 
    o = FriendManager:new()
	_G.FriendManager = o
    FriendManager:init()
    return o
end

--排序的算法
local function comps_f(a,b)
    return a.friend < b.friend
end

function comps_friend(b, a)
    if a.friend == b.friend then
        return a.online < b.online
    else
        return a.friend < b.friend
    end
end


function FriendManager:init()
    --角色基本属性表数据
    self.list = {}

end

--[好友ID %d][好友是否在线 %c][好友是否战斗 %w][好友名字 %s]
function FriendManager:add(friend,id,online,onbattle,name)
    local m_list = self.list
    for k,v in pairs(m_list) do
        if v.id == id and friend == v.friend then
            v.online = online
            v.onbattle = onbattle
            v.name = name
            v.friend = friend
            return
        end
    end

    table.insert(m_list,{id = id,online = online,onbattle= onbattle,name = name,friend = friend})
    table.sort(m_list,comps_friend)

end

function FriendManager:del(friend,id)
    local list = self.list
    local len = #list
    local i = 1
    for i=1,len do
        if list[i].id == id and list[i].friend == friend then
            table.remove(list,i)
            return
        end
    end
end 

function FriendManager:isFriend(friend,name)
    local list = self.list
    local len = #list
    local i = 1
    for i=1,len do
        if list[i].name == name and list[i].friend == friend then
            return true
        end
    end
    return false
end 

function FriendManager:update_online(id,online)
    local list = self.list
    local len = #list
    local i = 1
    local flag = 0
    for i=1,len do
        if list[i].id == id then
            list[i].online = online
            list[i].onbattle = onbattle
            flag = 1
        end
    end
    table.sort(list,comps_friend)
    return flag
end 


function FriendManager:update_onbattle(id,onbattle)
    local list = self.list
    local len = #list
    local i = 1
    local flag = 0
    for i=1,len do
        if list[i].id == id then
            list[i].onbattle = onbattle
            flag = 1
        end
    end
    return flag
end 

function FriendManager:getlist()
    return  self.list
end

function FriendManager.StringToTable(s)
    local tb = {}
    --[[
    UTF8的编码规则： 
    1. 字符的第一个字节范围： 0x00—0x7F(0-127),或者 0xC2—0xF4(194-244); UTF8 是兼容 ascii 的，所以 0~127 就和 ascii 完全一致    
    2. 0xC0, 0xC1,0xF5—0xFF(192, 193 和 245-255)不会出现在UTF8编码中     
    3. 0x80—0xBF(128-191)只会出现在第二个及随后的编码中(针对多字节编码，如汉字)    
     ]]
	for utfChar in string.gmatch(s, "[%z\1-\127\194-\244][\128-\191]*") do
		table.insert(tb, utfChar)
	end
	return tb
 end

function FriendManager.GetUTFLen(s)
    local sTable = FriendManager.StringToTable(s)
    local len = 0
    local charLen = 0
    for i=1,#sTable do
        local utfCharLen = string.len(sTable[i])
            if utfCharLen > 1 then -- 长度大于1的就认为是中文
                charLen = 2
            else
                charLen = 1
            end
            len = len + charLen
        end
    return len
end

function FriendManager.GetUTFLenWithCount(s, count)
    local sTable =  FriendManager.StringToTable(s)
 
    local len = 0
    local charLen = 0
    local isLimited = (count >= 0)
 
    for i=1,#sTable do
        local utfCharLen = string.len(sTable[i])
        if utfCharLen > 1 then -- 长度大于1的就认为是中文
            charLen = 2
        else
            charLen = 1
        end
 
        len = len + utfCharLen
 
        if isLimited then
            count = count - charLen
            if count <= 0 then
                break
            end
        end
    end
 
    return len
end

function FriendManager.GetMaxLenString(s, maxLen)
    local len = FriendManager.GetUTFLen(s)
    
    local dstString = s
    -- 超长，裁剪，加...
    if len > maxLen then
        dstString = string.sub(s, 1,  FriendManager.GetUTFLenWithCount(s, maxLen))
        dstString = dstString
    end
 
    return dstString
end

return FriendManager