require "tagMap.Tag_battlewnd"
local war2CardManager = require("war2.war2CardManager")
local scheduler = require("framework.scheduler")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local UserDefaultManager = require("data.UserDefaultManager"):instance()
local socket = require "socket"

StoryBattleWindow = class("StoryBattleWindow",function()
	return TuiBase:create()
end)


StoryBattleWindow.isShow = false

local __instance = nil
--总容器
local window = nil


local mBtnStory
local mBtnPuzzle

local mLayoutBtnPuzzle
local mLayoutBtnPuzzle


--要加载的资源列表
local resArr = { PLIST_BATTLEWND_URL }

function StoryBattleWindow:create()
	local ret = StoryBattleWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end


function StoryBattleWindow:getPanel(tagPanel)
	local ret = nil
	ret = self:getChildByTag(tagPanel)
	return ret
end

function StoryBattleWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

-----------------------------点击触发事件--------------------------//
local function BtnCloseClick(p_sender)
    PopScene(__instance)
end

local function BtnPuzzleClick(p_sender)
    require("Music.MusicManager"):instance():PlaySound( 107 )
    RunScene("PuzzleWindow") 
end

local function BtnStoryClick(p_sender)
    require("Music.MusicManager"):instance():PlaySound( 107 )
    RunScene("StoryWindow") 
end

function StoryBattleWindow:closeWindow()
    PopScene(__instance)
end


function StoryBattleWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () 
        self:onEnterScene() 
    end )
end

function StoryBattleWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_story",PATH_BATTLEWND)
    window = self:getChildByTag(Tag_battlewnd.PANEL_STORY)
    mLayoutBtnStory = window:getChildByTag(Tag_battlewnd.LAYOUT_BTN_STORY)
    mLayoutBtnPuzzle = window:getChildByTag(Tag_battlewnd.LAYOUT_BTN_PUZZLE)

    local btn = self:getControl(Tag_battlewnd.PANEL_STORY, Tag_battlewnd.BTN_CLOSE2)
    btn:setOnClickScriptHandler( BtnCloseClick )
    btn = self:getControl(Tag_battlewnd.PANEL_STORY, Tag_battlewnd.BTN_WINDOWBACK2)
    btn:setOnClickScriptHandler( BtnCloseClick )
    btn:setOpacity(255*0.9)
    
    mBtnStory = mLayoutBtnStory:getChildByTag(Tag_battlewnd.BTN_STORY)
    mBtnStory:setOnClickScriptHandler( BtnStoryClick )

    mBtnPuzzle = mLayoutBtnPuzzle:getChildByTag(Tag_battlewnd.BTN_PUZZLE)
    mBtnPuzzle:setOnClickScriptHandler( BtnPuzzleClick )

    StoryBattleWindow.isShow = true
end


function StoryBattleWindow:onExitScene()
    window = nil
    StoryBattleWindow.isShow = false
 
    UILoadManager:delResByArr( resArr )
end