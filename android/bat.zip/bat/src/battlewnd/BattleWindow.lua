require "tagMap.Tag_battlewnd"
local war2CardManager = require("war2.war2CardManager")
local scheduler = require("framework.scheduler")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager"):instance()
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local UserDefaultManager = require("data.UserDefaultManager"):instance()
local socket = require "socket"

BattleWindow = class("BattleWindow",function()
	return TuiBase:create()
end)


BattleWindow.isShow = false

local __instance = nil
--总容器
local window = nil


local mBtnRank
local mBtnArena

local mLayoutArena
local mLayoutBtnArena
local mLayoutBtnRank

---------竞技场-----------
local mBtnPoint
local mBtnStone

--介绍文本
local mTxtDesc

local mTxtPoint 
local mTxtUsePoint 
local mTxtStone
local mTxtUseStone

local mNeedPoint = 300
local mNeedStone = 150
---------竞技场-----------


--要加载的资源列表
local resArr = { PLIST_BATTLEWND_URL }

function BattleWindow:create()
	local ret = BattleWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end


function BattleWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function BattleWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--更新竞技场按钮
local function updateShopBtn()    
    local char = CharacterManager:getMainPlayer()

    mTxtPoint:setString(char.arenaPoints)
    mTxtStone:setString(char.stone)

    if char.arenaPoints < mNeedPoint then
        EffectManager:setBtnGrayFilter(mBtnPoint, true)
    else
        EffectManager:setBtnGrayFilter(mBtnPoint, false)
    end

    if char.stone < mNeedStone then
        EffectManager:setBtnGrayFilter(mBtnStone, true)
    else
        EffectManager:setBtnGrayFilter(mBtnStone, false)
    end
end


--打开竞技场
local function closeArena()
    mLayoutArena:setVisible(false)
    mLayoutBtnRank:setVisible(true)
    mLayoutBtnArena:setPositionX(183)
end
-----------------------------点击触发事件--------------------------//
local function BtnCloseClick(p_sender)
    if mLayoutArena:isVisible() == true then
        closeArena()
        return
    end
    PopScene(__instance)
end

local function BtnRankClick(p_sender)
    require("Music.MusicManager"):instance():PlaySound( 107 )
    FightWnd:setAndShowType( WAR2_TYPE_RANK )
end

local function BtnArenaClick(p_sender)
--    if CharacterManager:checkNpcWin( 30 ) == 1 then --没打赢这关的不开放
    if CharacterManager:getMainPlayer().CharLevel < 17 then --没达到等级17的不开放
        require("prompt.PromptManager"):instance():SetNotice( 4092 )    
        return 
    end
    ArenaManager:setIsSendOpen(true)   
    if ArenaManager:getIsGetMsg() == false then
        ServMsgTransponder:SMTAreaOpen()
    elseif ArenaManager:getCurState() == 0 then
--        RunScene("ArenaEnterWindow")
        BattleWindow:OpenArena()
    elseif ArenaManager:getCurState() == 1 or ArenaManager:getCurState() == 2 then
        RunScene("ArenaWindow")
    end
end


local function BtnPointClick(p_sender)
    ArenaManager:setIsSendOpen(true)   
    ServMsgTransponder:SMTAreaRegist(1)
end

local function BtnStoneClick(p_sender)
    ArenaManager:setIsSendOpen(true)  
    ServMsgTransponder:SMTAreaRegist(2)
end

--打开竞技场
function BattleWindow:OpenArena()
    mLayoutArena:setVisible(true)
    mLayoutBtnRank:setVisible(false)
    mLayoutBtnArena:setPositionX(258)
end


function BattleWindow:closeWindow()
    PopScene(__instance)
end


function BattleWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () 
        self:onEnterScene() 
    end )
end

function BattleWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_BATTLEWND)
    window = self:getChildByTag(Tag_battlewnd.PANEL_MAIN)
    mLayoutArena = window:getChildByTag(Tag_battlewnd.LAYOUT_ARENA)
    mLayoutBtnRank = window:getChildByTag(Tag_battlewnd.LAYOUT_BTN_RANK)
    mLayoutBtnArena = window:getChildByTag(Tag_battlewnd.LAYOUT_BTN_ARENA)

    local btn = self:getControl(Tag_battlewnd.PANEL_MAIN, Tag_battlewnd.BTN_CLOSE)
    btn:setOnClickScriptHandler( BtnCloseClick )
    btn = self:getControl(Tag_battlewnd.PANEL_MAIN, Tag_battlewnd.BTN_WINDOWBACK)
    btn:setOnClickScriptHandler( BtnCloseClick )
    btn:setOpacity(255*0.9)
    
    -----------------------竞技场---------------------
    mBtnRank = mLayoutBtnRank:getChildByTag(Tag_battlewnd.BTN_RANK)
    mBtnRank:setOnClickScriptHandler( BtnRankClick )

    mBtnArena = mLayoutBtnArena:getChildByTag(Tag_battlewnd.BTN_ARENA)
    mBtnArena:setOnClickScriptHandler( BtnArenaClick )


    mBtnPoint = mLayoutArena:getChildByTag(Tag_battlewnd.BTN_POINT)
    mBtnPoint:setOnClickScriptHandler( BtnPointClick )   
   
    mBtnStone = mLayoutArena:getChildByTag(Tag_battlewnd.BTN_STONE)
    mBtnStone:setOnClickScriptHandler( BtnStoneClick ) 
          
    mTxtPoint = mLayoutArena:getChildByTag(Tag_battlewnd.LABBMF_POINT)
    mTxtPoint:setString("")
    mTxtUsePoint = mLayoutArena:getChildByTag(Tag_battlewnd.LABBMF_USE_POINT)
    mTxtUsePoint:setString(mNeedPoint)
    mTxtStone = mLayoutArena:getChildByTag(Tag_battlewnd.LABBMF_STONE)
    mTxtStone:setString("")
    mTxtUseStone = mLayoutArena:getChildByTag(Tag_battlewnd.LABBMF_USE_STONE)
    mTxtUseStone:setString(mNeedStone)

    mTxtDesc = mLayoutArena:getChildByTag(Tag_battlewnd.LABEL_ENTER_DESC)
    mTxtDesc:setString(DataManager:getStringDataTxt(98, true))
    mLayoutArena:setVisible(false)
    updateShopBtn()
    -----------------------竞技场---------------------

    BattleWindow.isShow = true
end


function BattleWindow:onExitScene()
    window = nil
    BattleWindow.isShow = false
 
    UILoadManager:delResByArr( resArr )

end