require "tagMap.Tag_fightwait"
FightWaitWindow = class("FightWaitWindow",function()
	return TuiBase:create()
end)

local DataManager = require("data.DataManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local scheduler = require("framework.scheduler")

local __instance = nil
--总容器
local window = nil
--等待匹配层
local mLayoutWait

local mBolPlaying = false

FightWaitWindow.isShow = false

function FightWaitWindow:create()
	local ret = FightWaitWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function FightWaitWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end


local function setTxtWai()
    if FightWaitWindow.isShow == false then return end
    local txtId = math.random( 7000, 7094 )
    while( DataManager:getStringDataTxt( txtId ) == nil ) do
        txtId = math.random( 7000, 7094 )
    end   
    mTxtWait:setOpacity(0)
    mTxtWait:runAction(cc.FadeTo:create(1, 255))    
    mTxtWait:setString( DataManager:getStringDataTxt( txtId, true) )

    scheduler.performWithDelayGlobal( setTxtWai, 20 )  
end

--对战匹配打开动态效果
local function playWaitOpenEffect()
    print("playWaitOpenEffect")
    if mBolPlaying == true then return end
    mBolPlaying = true

    local sprite = cc.Sprite:create()
    sprite:setTexture("other/img_Mask_halo.png")
    sprite:setOpacity(0)
    window:addChild(sprite, -1)

    mWaitUpEffect = EffectManager:createHnyEffect( 100799 , {x = 0, y = 360} ) 
    window:addChild(mWaitUpEffect, -1)
    EffectManager:startHnyEffect( mWaitUpEffect )

    mWaitDownEffect = EffectManager:createHnyEffect( 100800 , {x = 0, y = -360} ) 
    window:addChild(mWaitDownEffect, -1)
    EffectManager:startHnyEffect( mWaitDownEffect )

    local effect = EffectManager:createHnyEffect( 100804 , {x = 0, y = -149} ) 
    window:addChild(effect, -1)
    EffectManager:startHnyEffect( effect )

    mLayoutWait:setVisible(true)    
    mLayoutWait:setOpacity(0)
    mWaitMoveAlpha = require("Mov.MovAlpha").new()
    mWaitMoveAlpha:init( mLayoutWait, 255,  25, 15 )
    mWaitMoveAlpha.callBackFucFinished =
         function () 
            if mLayoutWait and tolua.isnull(mLayoutWait) == false then
                mLayoutWait:setOpacity(255)
            end
            mBolPlaying = false mWaitMoveAlpha = nil 

            if FightWnd.isWaiting == true then
                ServMsgTransponder:SMTWarApply(1) --天梯匹配请求
            elseif ArenaWindow.isWaiting == true then
                ServMsgTransponder:SMTAreaApply() --竞技场匹配请求
            end  
        end
    require("Mov.MovManager"):instance():pushMov( mWaitMoveAlpha )
end


--对战匹配取消动态效果
local function playWaitCloseEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true

    local effect = EffectManager:createHnyEffect( 100802 , {x = 0, y = 360} ) 
    window:addChild(effect, 9)
    EffectManager:startHnyEffect( effect, {time = 0.3, fun = function() 
        if mWaitUpEffect ~= nil then mWaitUpEffect:removeFromParent() end
        end } )

    effect = EffectManager:createHnyEffect( 100803 , {x = 0, y = -360} ) 
    window:addChild(effect, 9)
    EffectManager:startHnyEffect( effect, {time = 0.3, fun = function() 
    if mWaitDownEffect ~= nil then mWaitDownEffect:removeFromParent() end
        end, 
    close =  function()
                if war2FightScene.TempSelf then --战场进入回调
                    war2FightScene.TempSelf:onEnterScene()
                    war2FightScene.TempSelf = nil
                end 
            end } )
    if mLayoutWait then
        mWaitMoveAlpha = require("Mov.MovAlpha").new()
        mWaitMoveAlpha:init( mLayoutWait, 0,  25 )
        mWaitMoveAlpha.callBackFucFinished =
            function () 
                mBolPlaying = false mWaitMoveAlpha = nil 
                PopScene(__instance)         
            end
        require("Mov.MovManager"):instance():pushMov( mWaitMoveAlpha )    
    end
end


--取消战斗点击事件
local function onCanCelClick(p_sender)
--    mLayoutWait:setVisible(false)    
    if FightWnd.isWaiting == true then
        FightWnd.isWaiting = false
        ServMsgTransponder:SMTWarWithDraw(1)
    elseif ArenaWindow.isWaiting == true then
        ArenaWindow.isWaiting = false
        ServMsgTransponder:SMTAreaWithDraw(1)
    elseif FightWnd.fight_friend_isWaiting == true then
        if FightWnd:get_battlefriend()~=nil then
            ServMsgTransponder:SMTRefuseApplyWar( FightWnd:get_battlefriend() )
            FightWnd:set_battlefriend(nil) 
        end
        FightWnd.fight_friend_isWaiting = false
        require("framework.scheduler").performWithDelayGlobal( function () FightWnd:closeWindow() end, 0.2 )
    end         
    playWaitCloseEffect()
end


function FightWaitWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

function FightWaitWindow:onLoadScene()
    self:onEnterScene()
end


function FightWaitWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_FIGHTWAIT)
    window = self:getChildByTag(Tag_fightwait.PANEL_MAIN)
    
    mLayoutWait = self:getControl( Tag_fightwait.PANEL_MAIN, Tag_fightwait.LAYOUT_WAIT)
    mLayoutWait:setVisible(false)    

    btn = mLayoutWait:getChildByTag(Tag_fightwait.BTN_CANCLE)
    btn:setOnClickScriptHandler(onCanCelClick)

    mTxtWait = mLayoutWait:getChildByTag(Tag_fightwait.LABEL_WAIT)
    mTxtWait:setAlignment( 0, 1 )

    mEffect = EffectManager:createHnyEffect( 100635, {x = 640, y = 212} )
    mLayoutWait:addChild( mEffect )    
    EffectManager:startHnyEffect( mEffect )

--    mScroll:setOnScrollingScriptHandler(onScroll)   --滚动事件 
--    mScroll:setDragable(false)  --设置不能拖动
    playWaitOpenEffect()
    FightWaitWindow.isShow = true
    setTxtWai()

    if FightWnd.fight_friend_isWaiting == true then
        local m_cell = mLayoutWait:getChildByTag(Tag_fightwait.IMG_FONTMATCH)
        m_cell:setVisible(false)
        local m_cell = mLayoutWait:getChildByTag(Tag_fightwait.IMG_FONTMATCH_FRIEND)
        m_cell:setVisible(true)
    else
        local m_cell = mLayoutWait:getChildByTag(Tag_fightwait.IMG_FONTMATCH)
        m_cell:setVisible(true)
        local m_cell = mLayoutWait:getChildByTag(Tag_fightwait.IMG_FONTMATCH_FRIEND)
        m_cell:setVisible(false)
    end
end

function FightWaitWindow:closeWindow()
    FightWnd.fight_friend_isWaiting =nil
    PopScene(__instance)
end

function FightWaitWindow:onExitScene()
    window = nil
    FightWaitWindow.isShow = false
    FightWnd.isWaiting = false
    mBolPlaying = false
    mWaitUpEffect = nil
    mWaitDownEffect = nil
    mLayoutWait = nil
    if mTimer then
        require("framework.scheduler").unscheduleGlobal(mTimer)
        mTimer = nil
    end
    if mWaitMoveAlpha then
        require("Mov.MovManager"):instance():delMov( mWaitMoveAlpha )
        mWaitMoveAlpha = nil
    end
end