require "tagMap.Tag_fightwnd"
local war2CardManager = require("war2.war2CardManager")
local scheduler = require("framework.scheduler")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager"):instance()
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()
local UserDefaultManager = require("data.UserDefaultManager"):instance()
local socket = require "socket"

FightWnd = class("FightWnd",function()
	return TuiBase:create()
end)
--是否退出所有场景
FightWnd.isPopAll = false

FightWnd.isShow = false
FightWnd.isWaiting = false

local __instance = nil
--总容器
local window = nil

--选择对战的NPC
local battleNpc = nil
local battlefriend = nil
local battlefriend2 = nil

--界面窗口层
local mLayoutFightWnd
--是否选择匹配AI层
local mLayoutAI

local mBtnWindowBack

local mGroupCellList = {}
local mTxtWait

local mImgX

local mBolPlaying = false

local mWaitMoveAlpha

local mWaitUpEffect
local mWaitDownEffect

local mImgPage1
local mImgPage2
local mCurPage = 1

--当前选择的卡组id
local mCurCardTempIndex = 0

--当前选择的卡组id
local mCurCardId = 0

--上一次使用的套牌会置于最前面
local mFirstCardId = 0

--- 战斗类型 1天梯 obj = nil，2剧情故事模式 obj = npc，3竞技场，4好友对战，6休闲模式
local mFightType = 0

--是否已经请求了第一个卡组信息
local mBolSMTShow = false


--要加载的资源列表
local resArr = { PLIST_FIGHTWND_URL }

function FightWnd:create()
	local ret = FightWnd.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function FightWnd:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end


function FightWnd:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end


--验证卡组合法性
local function checkGroup()
    print(mCurCardId)
    local group = CollectionManager:getCardGroupData( mCurCardId )
    if mCurCardId == 0 or group == nil then return false end    
    local mCardArr = group.GroupCardArr
    local equipArr = group.GroupEquipArr
    local num = 0
    for i, obj in pairs(mCardArr) do
        num = num + obj.num
    end 
    if num < 50 or #equipArr < 3 then
        return false
    end
    for i = 1, #mCardArr do
        if CollectionManager:checkCardRace( mCardArr[i].data, equipArr) == false then
            return false
        end
    end
    return true
end


--播放界面打开动态效果
local function playOpenEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true
    local sp = TextureManager:getSprite( mLayoutFightWnd )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100699 , tx2d)
    local effect = EffectManager:createHnyEffect( 100699 , {x = mLayoutFightWnd:getPositionX(), y = mLayoutFightWnd:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    mLayoutFightWnd:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = 
        function ()     
            mLayoutFightWnd:setVisible(true) 
            mBolPlaying = false 
            end } )

    local img = mLayoutFightWnd:getChildByTag(Tag_fightwnd.IMG_PVPBOX)
    img:setTouchEnabled(true)

    mImgPage1:setTouchEnabled(true)
    mImgPage2:setTouchEnabled(true)
end

--播放界面关闭动态效果
local function playCloseEffect()
    print("playCloseEffect")
    if mBolPlaying == true then return end
    mBolPlaying = true
    local sp = TextureManager:getSprite( mLayoutFightWnd )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100701 , tx2d)
    local effect = EffectManager:createHnyEffect( 100701 , {x = mLayoutFightWnd:getPositionX(), y = mLayoutFightWnd:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    mLayoutFightWnd:setVisible(false)
    EffectManager:startHnyEffect( effect, { close = function () mBolPlaying = false FightWnd:closeWindow() end } )
end



-----------------------------点击触发事件--------------------------

--离开按钮点击事件
local function onLeaveClick(p_sender)  
--    if FightWnd.isPopAll == true then
--        if MainWindow.isCanShow == true then
--            PopScene(__instance)
--        else
--            MainWindow.isCanShow = true
--            replaceScene("MainWindow")
--        end
--    else
--        PopScene(__instance)
--    end
    playCloseEffect()
    if battlefriend~=nil then
        ServMsgTransponder:SMTRefuseApplyWar( battlefriend )
        battlefriend = nil
    end
end

--上一次点击开始战斗按钮的时间
local mClickTime = 0
--开始战斗按钮点击事件
local function onStartClick(p_sender)
    if FightWnd.needHide ==true then
        return
    end
    if mBolPlaying == true then return end
    if checkGroup() == false then
        require("prompt.PromptManager"):instance():SetNotice( 3004 )
        return
    end
    local curTime = socket.gettime()   
    if curTime - mClickTime < 2 then
        return 
    end
    mClickTime = curTime
    ServMsgTransponder:SMTComposeCardFight( mCurCardId )
    mFirstCardId = mCurCardId
    UserDefaultManager:setStringForKey("FirstCardId", mFirstCardId)
end

local function btnCardGroup(p_sender)
    local group = mGroupCellList[p_sender.idx]
    mCurCardId = group.id

    local groupList = CollectionManager:getCardGroupList()
    for i = 1, #groupList do
        if mGroupCellList[i].id == mCurCardId  then
            mGroupCellList[i].img_light:setVisible(true)
        else
            mGroupCellList[i].img_light:setVisible(false)
        end
    end
    if #CollectionManager:getCardGroupData( mCurCardId ).GroupCardArr == 0 then --没收到数据的向后台请求数据
        ServMsgTransponder:SMTShow( mCurCardId )
    end    
end

--分页点击事件
local function onPageClick(p_sender)  
    if p_sender == mImgPage2 and mCurPage == 1 then
        mCurPage = 2
        mImgPage1:setSpriteFrame("fightwnd/img_page1_normal.png")
        mImgPage2:setSpriteFrame("fightwnd/img_page2_select.png")
    elseif p_sender == mImgPage1 and mCurPage == 2 then
        mCurPage = 1
        mImgPage1:setSpriteFrame("fightwnd/img_page1_select.png")
        mImgPage2:setSpriteFrame("fightwnd/img_page2_normal.png")
    end

    FightWnd:updateGroup()
end

local function onImgXClick(p_sender)  
    local char = CharacterManager:getMainPlayer()
    if char.AllowAI == 0 then
        ServMsgTransponder:SMTWarAI(1)
    else
        ServMsgTransponder:SMTWarAI(0)
    end
end


-----------------------------点击触发事件--------------------------//


--创建一个卡套元件
local function createCardTemp()
    local pCell = CGridPageViewCell:new()
    TuiManager:getInstance():parseCell( pCell, "cell_CardTemp", PATH_FIGHTWND )

    pCell.head = pCell:getChildByTag( Tag_fightwnd.IMG_CARDTEMPCELLHEAD )
--    pCell.head:setTexture("war2/head/HeadPic102.png")

    pCell.btn = pCell:getChildByTag( Tag_fightwnd.BTN_CLICK )
    pCell.btn:setOnClickScriptHandler( btnCardGroup )
    pCell.btn.idx = #mGroupCellList + 1
    pCell.img_light = pCell:getChildByTag(Tag_fightwnd.IMG_CARDGROUPLIGHT)
    pCell.img_light:setVisible(false)
    return pCell
end


--更新卡套列表
local function updateCardTemp(obj, mCell)  
    local mTxtName = mCell:getChildByTag( Tag_fightwnd.LABEL_CARDTEMPCELLNAME ) 
    mTxtName:setString( obj.name )

    mCell.head:setTexture("war2/head/HeadPic"..obj.headId..".png")
    local iconList = {}
    for i = 1, 3 do
        iconList[i] = mCell:getChildByTag( Tag_fightwnd["IMG_CARDTEMPCELLICON"..i] )
        if obj.GroupEquipArr[i] ~= nil then
            iconList[i]:setTexture( "war2/warEqIcon/"..obj.GroupEquipArr[i].shape..".png" )
            iconList[i]:setVisible(true)
        else    
            iconList[i]:setVisible(false)
        end
    end
    mCell:setVisible( true )
    if mCell.id == mCurCardId  then
        mCell.img_light:setVisible(true)
    else
        mCell.img_light:setVisible(false)
    end
end


function FightWnd:closeWindow()
    FightWnd.needHide = false

    if battlefriend~=nil then
        ServMsgTransponder:SMTRefuseApplyWar( battlefriend )
        battlefriend = nil
    end
    if FightWnd:get_battlefriend2()~=nil then
        ServMsgTransponder:SMTRefuseApplyWar( FightWnd:get_battlefriend2() )
        FightWnd:set_battlefriend2(nil) 
    end

    if FightWnd.isPopAll == true then
        if MainWindow.isCanShow == true then
            PopScene(__instance)
        else
            MainWindow.isCanShow = true
            replaceScene("MainWindow")
        end
    else
        PopScene(__instance)
    end

end

--更新卡组信息
function FightWnd:updateGroup()
    local groupList = CollectionManager:getCardGroupList()
    local tempList = {}
    local idx = 1
    if mCurPage == 1 then
        idx = 1
    else
        idx = 9
    end
    local tempList2 = {}
    for i = 1, #groupList do
        if mFirstCardId == groupList[i].id then
            table.insert(tempList2, 1, groupList[i])
        else
            table.insert(tempList2, groupList[i])
        end
    end

    local num = 1
    for i = idx, #tempList2 do
        if mFirstCardId == tempList2[i].id then
            table.insert(tempList, 1, tempList2[i])
        else
            table.insert(tempList, tempList2[i])
        end
        num = num + 1
        if num > 8 then break end
    end
    
    for i = 1, #mGroupCellList do
        if tempList[i] then
            mGroupCellList[i].id = tempList[i].id
            updateCardTemp(tempList[i], mGroupCellList[i])  
        else
            mGroupCellList[i]:setVisible(false)
        end
    end
    if mFirstCardId == mGroupCellList[1].id and mGroupCellList[1]:isVisible() == true and mBolSMTShow == false then
        btnCardGroup( mGroupCellList[1]:getChildByTag( Tag_fightwnd.BTN_CLICK ) )
        mBolSMTShow = true
    end
end

--开始匹配
function FightWnd:StartLink()
    if mFightType == WAR2_TYPE_RANK then  
        FightWnd.isWaiting = true
        RunScene("FightWaitWindow")      
    elseif mFightType == WAR2_TYPE_STORY or mFightType == WAR2_TYPE_PUZZLE then
        ServMsgTransponder:SMTWarNPC(battleNpc, CharacterManager:checkNpcWin(battleNpc))
        battleNpc = nil
    elseif mFightType == WAR2_TYPE_FRIEND then
        if battlefriend ~= nil then
            print("battlefriend")
            ServMsgTransponder:SMTApplyWar(battlefriend )
            --battlefriend = nil
            FightWnd.fight_friend_isWaiting = true
            RunScene("FightWaitWindow")
            return
        end
        if battlefriend2 ~= nil then
                ServMsgTransponder:SMTApplyWar2(battlefriend2 )
                battlefriend2 = nil
                return
        end
    elseif mFightType == WAR2_TYPE_XIUXIAN then
        ServMsgTransponder:SMTWarApply(2)
    end
end

--设置对战NPC
function FightWnd:set_battleNpc(value)
    battleNpc = value
end

function FightWnd:set_battlefriend(value)
    battlefriend = value
end

function FightWnd:set_battlefriend2(value)
    battlefriend2 = value
end

function FightWnd:get_battlefriend()
    return battlefriend
end 

function FightWnd:get_battlefriend2()
    return battlefriend2
end 

function FightWnd:getFightType()
    return mFightType
end 

function FightWnd:setFightType(ntype)
    mFightType = ntype
end 


--- 战斗类型 1天梯 obj = nil，2剧情故事模式 obj = npc，3竞技场，4好友对战，6休闲模式
function FightWnd:setAndShowType( ntype, obj )
    mFightType = ntype

    battleNpc = nil 
    battlefriend = nil
    battlefriend2 = nil
    if mFightType == WAR2_TYPE_RANK then        
    elseif mFightType == WAR2_TYPE_STORY or mFightType == WAR2_TYPE_PUZZLE then
        battleNpc = obj
    elseif mFightType == WAR2_TYPE_FRIEND then
        battlefriend = obj.friend1
        battlefriend2 = obj.friend2
    elseif mFightType == WAR2_TYPE_XIUXIAN then
    end
    RunScene("FightWnd")
end

function FightWnd:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () 
        self:onEnterScene() 
--        CollectionManager:SendOpenInfo()
    end )
    if CollectionManager.Bol0x1504 == false then ServMsgTransponder:SMTOpenDeck_info() end    
end

function FightWnd:updateAllowAI()
    if mFightType == WAR2_TYPE_RANK then
        mLayoutAI:setVisible(true)
    else   
        mLayoutAI:setVisible(false) 
        return
    end
    local char = CharacterManager:getMainPlayer()
    if char.AllowAI == 0 then
        mImgX:setOpacity(255)
    else
        mImgX:setOpacity(0)
    end
end

function FightWnd:onEnterScene()
    if FightWnd.isPopAll == true then
        --临时 退出之前所有场景
        popAllScene()
    end
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_FIGHTWND)
    mCardGpvCurPage = 0
    window = self:getPanel(Tag_fightwnd.PANEL_MAIN)

    mBtnWindowBack = window:getChildByTag(Tag_fightwnd.BTN_WINDOWBACK)

    mLayoutFightWnd = self:getControl( Tag_fightwnd.PANEL_MAIN, Tag_fightwnd.LAYOUT_FIGHTWND)
    mLayoutAI = self:getControl( Tag_fightwnd.PANEL_MAIN, Tag_fightwnd.LAYOUT_ALLOWAI)

    local txt = mLayoutAI:getChildByTag(Tag_fightwnd.LABEL_ALLOWAI)
    txt:setString(DataManager:getStringDataTxt(4112, true))

    local img = mLayoutAI:getChildByTag(Tag_fightwnd.IMG_DISAIBACK)
    img:setTouchEnabled(true)
    img:setOnClickScriptHandler(onImgXClick)
   
    mImgX = mLayoutAI:getChildByTag(Tag_fightwnd.IMG_X)

    local btn = self:getControl( Tag_fightwnd.PANEL_MAIN, Tag_fightwnd.BTN_WINDOWBACK)
    btn:setOnClickScriptHandler(onLeaveClick)

    local img = mLayoutFightWnd:getChildByTag(Tag_fightwnd.IMG_PVPBOX)

    btn = mLayoutFightWnd:getChildByTag(Tag_fightwnd.BTN_START)
    btn:setOnClickScriptHandler(onStartClick)

    btn = mLayoutFightWnd:getChildByTag(Tag_fightwnd.BTN_BACKBUTTON)
    btn:setOnClickScriptHandler(onLeaveClick)

    mImgPage1 = mLayoutFightWnd:getChildByTag(Tag_fightwnd.IMG_PAGE1)
    mImgPage1:setSpriteFrame("fightwnd/img_page1_select.png")
    mImgPage2 = mLayoutFightWnd:getChildByTag(Tag_fightwnd.IMG_PAGE2)
    mImgPage1:setOnClickScriptHandler(onPageClick) 
    mImgPage2:setOnClickScriptHandler(onPageClick) 
    mCurPage = 1

    mGroupCellList = {}
    local mCell
    local addX = 0
    local addY = 140
    for i = 1, CollectionManager.DECK_NUM do
        mCell = createCardTemp()
        mLayoutFightWnd:addChild(mCell)
        if i % 2 == 0 then 
            addX = 370            
        else
            addX = 0
            addY = addY - 110 
        end
        mCell:setPosition( mLayoutFightWnd:getContentSize().width * 0.5 -360 + addX, mLayoutFightWnd:getContentSize().height * 0.5 + addY + 130 )
        mCell:setVisible(false)
        mGroupCellList[i] = mCell
    end

    mFirstCardId = tonumber(UserDefaultManager:getStringForKey("FirstCardId"))

    self:updateGroup()
    self:updateAllowAI()
    playOpenEffect()
    FightWnd.isShow = true
    if TaskWindow.isShow == true then
        TaskWindow:close()
    end
    if #TaskManager.RewardDataList > 0 then
        RunScene("RewardWindow")
    end

end

function FightWnd:closeWaiting()
    if mLayoutFightWnd == nil then return false end
    if FightWnd:get_battlefriend()~=nil then
        ServMsgTransponder:SMTRefuseApplyWar( FightWnd:get_battlefriend() )
        FightWnd:set_battlefriend(nil) 
    end
    if FightWnd:get_battlefriend2()~=nil then
        ServMsgTransponder:SMTRefuseApplyWar( FightWnd:get_battlefriend2() )
        FightWnd:set_battlefriend2(nil) 
    end
    mLayoutFightWnd:setVisible(false)
    mBtnWindowBack:setVisible(false)
    playWaitCloseEffect()
    return true
end

function FightWnd:onExitScene()
    FightWnd.needHide = false
    if mWaitMoveAlpha then
        mWaitMoveAlpha.Sp = nil
    end
    window = nil
    mGroupCellList = {}
    FightWnd.isPopAll = false
    FightWnd.isShow = false
    mBolPlaying = false
    mCurCardId = 0
    mLayoutFightWnd = nil
    battleNpc = nil
    battlefriend = nil
    battlefriend2 = nil

    mBolSMTShow = false

    UILoadManager:delResByArr( resArr )

end