
local ItemManager = class()

function ItemManager:ctor()
    print(" ItemManager:ctor----=-=-=-=-=-")
end


function ItemManager:instance()
     local o = _G.ItemManager
    if o then
    	return o
	end
 
    o = ItemManager:new()
	_G.ItemManager = o
    ItemManager:init()
    return o
end

function ItemManager:init()
    --道具配置表数据
    self.DataItemArr = {}
    --self:loadAll()
end

--解析表
local function analysisData( tempSelf, saveDataArr, fileName )
    local str = cc.FileUtils:getInstance():getStringFromFile("data/"..fileName..".tcg")
    str = DataManager:JieMi(str)
    local arr = string.split( str, "\n" )
    local dataArr = {}
    for i = 2, #arr - 1 do
        dataArr[i] = string.split( arr[i], "(-]" )
    end

    local temp = nil
    local txt = nil
    local isCard = fileName == "dataShop"
    for i = 4, #dataArr do   
        temp = {}
        saveDataArr[ tonumber(dataArr[i][1]) ] = temp
        for j = 1, #dataArr[2] - 1 do
            if dataArr[2][j] ~= nil then
                if dataArr[2][j] == "item_name_id" or dataArr[2][j] == "item_desc1_id"  then
                    
                    local txtData = DataManager:getStringDataTxt(tonumber(dataArr[i][j]))
                    DataManager:addTextLanguageList( txtData, temp, dataArr[2][j] )
--                    temp[dataArr[2][j]] = DataManager:getStringDataTxt(tonumber(dataArr[i][j]), true)
                elseif dataArr[3][j] == "int" then
                   temp[dataArr[2][j]] = tonumber(dataArr[i][j])
                else
                   local str = tostring(dataArr[i][j])
                   if str == nil then str = "" end          
                   temp[dataArr[2][j]] = string.gsub(str, "\\n", "\n")
                end
            end
        end            
        temp = nil
    end
end

--加载所有表数据
function ItemManager:loadAll()
    analysisData( self, self.DataItemArr, "dataItem" )
end


--根据ID获取购买item表数据
function ItemManager:getItemData( id )
    id = tonumber(id)
    return self.DataItemArr[id]
end

return ItemManager