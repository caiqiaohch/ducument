local ShopManager = class()

function ShopManager:ctor()
    print(" ShopManager:ctor----=-=-=-=-=-")
end


function ShopManager:instance()
     local o = _G.ShopManager
    if o then
    	return o
	end
 
    o = ShopManager:new()
	_G.ShopManager = o
    ShopManager:init()
    return o
end

function ShopManager:init()
    --商城表数据
    self.DataShopArr = {}
    --商城表购买金币数据
    self.DataShopGoldArr = {}
    --商城表购买宝石数据
    self.DataShopStoneArr = {}

    --卡牌市场
    self.DataCardShopArr = {}

    --自动出售的卡牌列表
    self.SellCardList = {}
    --当前商城列表显示的商品种类 1:金币, 2:宝石
    self.CurGoodsType = 1

    --已向后台发送请求的ID列表
    self.SendedCardIdList = {}
    --卡牌市场的信息 obj:cardId卡牌id, num商城数量, buyPrice金币购买价格, sellPrice贩卖价格;
    self.ShopCardList = {}

    --想后台发送批量卖卡的时间
    self.sellTime = 0


    --玩家当前卡包卡牌信息数组
    self.CurCardPackArr = {}
    --开的包的物品ID
    self.CurCardPackId = 0

    --购买的卡包或者物品id
    self.CurBuyId = 0
end

--解析表
local function analysisData( tempSelf, saveDataArr, fileName )
    local str = cc.FileUtils:getInstance():getStringFromFile("data/"..fileName..".tcg")
    str = DataManager:JieMi(str)
    local arr = string.split( str, "\n" )
    local dataArr = {}
    for i = 2, #arr - 1 do
        dataArr[i] = string.split( arr[i], "(-]" )
    end

    local temp = nil
    local txt = nil
    local isCard = fileName == "dataShop"
    for i = 4, #dataArr do   
        temp = {}
        if fileName == "dataShop" then
            if saveDataArr[ tonumber(dataArr[i][1]) ] == nil then
                saveDataArr[ tonumber(dataArr[i][1]) ] = {}
            end
            saveDataArr[ tonumber(dataArr[i][1]) ][#saveDataArr[ tonumber(dataArr[i][1]) ] + 1] = temp --[ tonumber(dataArr[i][2])] = temp
        else
            saveDataArr[ tonumber(dataArr[i][1]) ] = temp
        end
        for j = 1, #dataArr[2] - 1 do
            if dataArr[2][j] ~= nil then
                if dataArr[3][j] == "int" then
                   temp[dataArr[2][j]] = tonumber(dataArr[i][j])
                else
                   local str = tostring(dataArr[i][j])
                   if str == nil then str = "" end          
                   temp[dataArr[2][j]] = string.gsub(str, "\\n", "\n")
                end
            end
        end            
        temp = nil
    end
end

--加载所有表数据
function ShopManager:loadAll()
    analysisData( self, self.DataShopArr, "dataShop" )
    analysisData( self, self.DataShopGoldArr, "dataShopGold" )
    analysisData( self, self.DataShopStoneArr, "dataShopGem" )
    analysisData( self, self.DataCardShopArr, "dataCardShop" )
end

--根据分类与ID获取商城表商品数据表1 卡包 2 卡背 3 玩家市场
function ShopManager:getShopDataListByType( options )
    options = tonumber(options)
    return self.DataShopArr[options]
end

--根据分类与ID获取商城表数据
function ShopManager:getShopData( options, id )
    options = tonumber(options)
    id = tonumber(id)
    for i = 1, #self.DataShopArr[options] do
        if id == self.DataShopArr[options][i].ItemsID then
            return self.DataShopArr[options][i]
        end
    end
    return nil
end

--根据ID获取卡牌市场表数据
function ShopManager:getShopCardData( id )
    id = tonumber(id)
    return self.DataCardShopArr[id]
end

--购买的卡牌id
function ShopManager:getCurBuyId()    
    return self.CurBuyId
end

function ShopManager:setCurBuyId( id )    
    self.CurBuyId = id
end
    
--预减的金币数量
function ShopManager:getCurBuyGold()    
    return self.CurBuyGold
end

function ShopManager:setCurBuyGold( value )    
    self.CurBuyGold = value
end

--预减的宝石数量
function ShopManager:getCurBuyStone()    
    return self.CurBuyStone
end

function ShopManager:setCurBuyStone( value )    
    self.CurBuyStone = value
end


--根据ID获取购买金币表数据
function ShopManager:getShopGoldData( id )
    id = tonumber(id)
    return self.DataShopGoldArr[id]
end

--根据ID获取购买宝石表数据
function ShopManager:getShopGemData( id )
    id = tonumber(id)
    return self.DataShopStoneArr[id]
end

return ShopManager