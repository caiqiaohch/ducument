require "tagMap.Tag_mainwnd"
local ShopManager = require("Shop.ShopManager"):instance()
local DataManager = require("data.DataManager"):instance()
local ItemManager = require("Shop.ItemManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()

local __instance = nil

--点击空白处关闭按钮
local btnBlackBack

--贩卖的数据列表
local itemList = {}

local resArr = { PLIST_MAIN_URL }

--
local mCellList = {}
local window

--是否在播放特效
local mBolPlaying = false


ShopGoodsWindow = class("ShopGoodsWindow",function()
	return TuiBase:create()
end)

ShopGoodsWindow.isShow = false
function ShopGoodsWindow:create()
	local ret = ShopGoodsWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function ShopGoodsWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function ShopGoodsWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--清除
 function ShopGoodsWindow:clear( tempSelf )
end

--播放界面打开动态效果
local function playOpenEffect()    
    local sp
    local tx2d 
    local diy
    local effect
    for i = 1, #mCellList do
        sp = TextureManager:getSprite( mCellList[i] )
        mCellList[i].sprite = sp  --保存effect需要的sprite
        mCellList[i].sprite:retain()
        tx2d = sp:getTexture()
        diy = TextureManager:getDiyEffect(100696 , tx2d)
        effect = EffectManager:createHnyEffect( 100696 , {x = mCellList[i]:getPositionX() + mCellList[i]:getContentSize().width * 0.5, y = mCellList[i]:getPositionY() + mCellList[i]:getContentSize().height * 0.5}, 
            {x = 1280 + 472, y = 360 + 130}, diy ) 
        window:addChild(effect)
        mCellList[i]:setVisible(false)
        EffectManager:startHnyEffect( effect, {time = 0.1 * math.pow(2, i - 2), key = function () mCellList[i]:setVisible(true) end} )
    end
    mBolPlaying = true
    require("framework.scheduler").performWithDelayGlobal( function () mBolPlaying = false end, 1.5 )
end

local function playCloseEffect()    
    if mBolPlaying == true then return end   
    local sp
    local tx2d 
    local diy
    local effect
    local tt = {0.8, 0.4, 0.2, 0.1, 0.01}
    for i = 1, #mCellList do
        sp = mCellList[i].sprite
        tx2d = sp:getTexture()
        diy = TextureManager:getDiyEffect(100697 , tx2d)
        effect = EffectManager:createHnyEffect( 100697 , {x = mCellList[i]:getPositionX() + pCell:getContentSize().width * 0.5, y = mCellList[i]:getPositionY() + pCell:getContentSize().height * 0.5}, 
            {x = 1280 + 472, y = 360 + 130}, diy ) 
        window:addChild(effect)
        EffectManager:startHnyEffect( effect, {time = tt[i], fun = function() mCellList[i]:setVisible(false) end} )
        mCellList[i].sprite:release()
    end
    local fun = function()
        for i = 1, #mCellList do
            mCellList[i]:setVisible(true)
        end
    end
    mBolPlaying = true
    require("framework.scheduler").performWithDelayGlobal( function () mBolPlaying = false PopScene(__instance) end, 1.5 )
end


--界面外点击关闭事件
local function BtnCloseClick(p_sender)
    print("close")
    if mBolPlaying == true then return end
    playCloseEffect()
--    PopScene(__instance)
end

--点击购买事件
local function BtnBuyClick(p_sender)
    print("BtnBuyClick")
    local data = itemList[p_sender.idx]
    if data == nil then return end
    if ShopManager.CurGoodsType == 1 then  --购买金币
        
    else                             --购买宝石
        if IS_STEAM_INIT == true then
             if SteamManager:getBolWaiting() == true then
                return
            end
            SteamManager:requestPhpForSteamBuy( data )
        end    
        
        if IS_GOOGLE_LOGIN == true then
            local char = CharacterManager:getMainPlayer()
            local orderId = math.ceil(socket.gettime())

            local itemPId = data.PID
            local params = "item_id="..data.Options1.."&coin="..data.USD.."&coin_type=1"
            require("app.GoogleManager"):instance():callJavaPay(orderId, itemPId, char.CharID , char.Name, char.CharLevel, params)
        end      
    end
end


--初始化界面
function ShopGoodsWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

--更新显示卡牌
function ShopGoodsWindow:UpDataCardMsg()
    for i = 1, 5 do
        if itemList[i] == nil then
            mCellList[i]:setVisible(false)
            break
        end
        pCell = mCellList[i]
        pCell:setVisible(true)
        img_stoneBox = pCell:getChildByTag(Tag_mainwnd.IMG_STONEBOX)
        img_goldBox = pCell:getChildByTag(Tag_mainwnd.IMG_GOLDBOX)
        img_stoneIcon = pCell:getChildByTag(Tag_mainwnd.IMG_STONEICON)
        img_goldIcon = pCell:getChildByTag(Tag_mainwnd.IMG_GOLDICON)        
        labBmf_cellMoney = pCell:getChildByTag(Tag_mainwnd.LABBMF_CELLMONEY)
        labBmf_cellCoin = pCell:getChildByTag(Tag_mainwnd.LABBMF_CELLCOIN)
        img_currency = pCell:getChildByTag(Tag_mainwnd.IMG_CURRENCY)
        
        local data = itemList[i]
        if ShopManager.CurGoodsType == 1 then  --购买金币
            img_stoneBox:setVisible(false) 
            img_stoneIcon:setVisible(false)
            img_goldBox:setVisible(true)
            img_goldIcon:setVisible(true)

            labBmf_cellMoney:setString( "+"..data.Gold )
            labBmf_cellCoin:setString( data[MONEYTYPE.."_unit"]..data[MONEYTYPE]*0.01 )
            img_currency:setTexture("other/currency/img_"..data[MONEYTYPE]..".png")
        else                             --购买宝石
            img_stoneBox:setVisible(true)
            img_stoneBox:setSpriteFrame("mainwnd/img_Store+AddGoldItem+GoldBox"..i..".png")
            img_stoneIcon:setVisible(true)
            img_goldBox:setVisible(false)
            img_goldIcon:setVisible(false)

            labBmf_cellMoney:setString( "+"..data.Gem )
            labBmf_cellCoin:setString( data[MONEYTYPE]*0.01 )
            img_currency:setTexture("other/currency/img_"..MONEYTYPE..".png")
        end
    end    
end


function ShopGoodsWindow:onEnterScene()
    window = self
     --覆盖战场关闭按钮
    local btn_WindowBack = CButton:create("other/btn_Mask_normal.png")
    btn_WindowBack:setPosition(640,360)
    self:addChild(btn_WindowBack)
    btn_WindowBack:setOnClickScriptHandler( BtnCloseClick )
    
    mCellList = {}
    local pCell
    local btn_goldBuy

    for i = 1, 5 do
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell(pCell, "cell_gridGold", PATH_MAINWND)
        self:addChild( pCell)
        pCell:setPosition(33 + i * 238 - 223, 180)
        btn_goldBuy = pCell:getChildByTag(Tag_mainwnd.BTN_GOLDBUY)
        btn_goldBuy.idx = i
        btn_goldBuy:setOnClickScriptHandler( BtnBuyClick )
        table.insert(mCellList, pCell)
    end
    local tempList
    if ShopManager.CurGoodsType == 1 then
        tempList = ShopManager.DataShopGoldArr
    elseif ShopManager.CurGoodsType == 2 then
        tempList = ShopManager.DataShopStoneArr
    end
    for k, v in pairs(tempList) do
        if ShopManager.CurGoodsType == 2 then
            if v.Gem > 10 then  --宝石小于10不在这里贩卖
                table.insert(itemList, v)
            end
        else
            table.insert(itemList, v)
        end        
    end

    local sortFun = 
    function(a, b)
        if a.Options1 ~= b.Options1 then
            return a.Options1 < b.Options1
        else
            return true
        end        
    end
    table.sort(itemList, sortFun)

    self:UpDataCardMsg()
    playOpenEffect()
    ShopGoodsWindow.isShow = true
end


function ShopGoodsWindow:onExitScene()
    itemList = {}
    mCellList = {}
    UILoadManager:delResByArr( resArr )
    ShopGoodsWindow.isShow = false
end

