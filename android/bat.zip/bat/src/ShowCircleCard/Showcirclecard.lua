Showcirclecard = class("Showcirclecard", function() 
    return CLayout:create()
end)

local ServMsgTransponder = require("net.ServMsgTransponder")
local TextManager = require("ui.TextManager"):instance()

local mCardArr
local mCircle
local window
local btn_next
local txt_next


--������ʾ
local mCardUI

local function onNextClick(p_sender)
    window:setVisible(false)
    ServMsgTransponder:SMTItemUse( ShopManager.CurCardPackId, 1 )--����ID,����
end

local function onCloseClick(p_sender)
    window:setVisible(false)
end

--�Ž����Ƶ����
function Showcirclecard:updataCard(arr)
    local ShopManager = require("Shop.ShopManager"):instance()
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()

    local len = #arr    
    if #arr == 1 then  --ֻ��һ�ſ���ʱ��ֻ��ʾ����
        mCardUI:setVisible(true)
        mCardUI:setCard(arr[1])
        mCircle:setVisible(false)  
    else
        mCardUI:setVisible(false)       
        mCircle:setVisible(true)   
    end
    if len < #mCardArr then len = #mCardArr end
    for i = 1, len do
        if arr[i] == nil or #arr == 1 then
            if mCardArr[i] ~= nil then
                mCardArr[i]:clear()
                mCardArr[i]:removeFromParent()
                mCardArr[i] = nil
            end
        else
            if mCardArr[i] == nil then
                local ImgCardUI = require("war2.cardBig").new()
                ImgCardUI:init( arr[i] )
                ImgCardUI:setName(i)
                mCircle:addChild(ImgCardUI)
                table.insert(mCardArr, ImgCardUI)
            else
                mCardArr[i]:setCard(arr[i])
            end
        end
    end

    local num = #arr
    btn_next:setVisible(num ~= nil and num > 0)
    txt_next:setVisible(num ~= nil and num > 0)

    mCircle:reloadData()
end

function Showcirclecard:init()
    local DataManager = require("data.DataManager"):instance()
    local CharacterManager = require("characters.CharacterManager"):instance()
    self:setContentSize(cc.size(1280,720))  
    window = self
    mCardArr = {}

    local btn_WindowBack = CButton:create("other/btn_Mask_normal.png")
    btn_WindowBack:setPosition(640,360)
    self:addChild(btn_WindowBack)

    
    btn_next = CButton:create("other/btn_QuestButton+N_normal.png")
    btn_next:setPosition(990,60)
    btn_next:setOnClickScriptHandler(onNextClick)
    self:addChild(btn_next)

    txt_next = TextManager:createTxt( DataManager:getStringDataTxt(71, true), 34, TXTFONTNAME )
    txt_next:enableOutline(cc.c4b(0,0,0,255),2)
    txt_next:setTextColor(cc.c4b(255,255,255,255))
    txt_next:setPosition( 990, 70 )
    txt_next:setAlignment( 1, 0 )
    txt_next:setDimensions(1280, 20)
    self:addChild(txt_next)

    local ShopManager = require("Shop.ShopManager"):instance()
    local char = CharacterManager:getMainPlayer()

    local btn_close = CButton:create("other/btn_QuestButton+N_normal.png")
    btn_close:setPosition(1180,60)
    btn_close:setOnClickScriptHandler(onCloseClick)
    self:addChild(btn_close)

    local fontext = TextManager:createTxt( DataManager:getStringDataTxt(53, true), 34, TXTFONTNAME )
    fontext:enableOutline(cc.c4b(0,0,0,255),2)
    fontext:setTextColor(cc.c4b(255,255,255,255))
    fontext:setPosition( 1180, 70 )
    fontext:setAlignment( 1, 0 )
    fontext:setDimensions(260, 20)
    self:addChild(fontext)

    local ImgCardUI = nil
    local arr = {0,0,0,0 }
    for i = 1, #arr do
        ImgCardUI = require("war2.cardBig").new()
        ImgCardUI:init( arr[i], 1 )
        ImgCardUI:setTag( 99 )
        ImgCardUI:setName(i)
        table.insert(mCardArr, ImgCardUI)
    end

    mCircle = CircleMenu:create(mCardArr, cc.size(1300,600))
    self:addChild(mCircle)
    mCircle:setScale(0.6)
    mCircle:setPosition(640,360)

    
    mCardUI =  require("war2.cardBig").new()
    mCardUI:init( 0 )
    mCardUI:setVisible(false)
    self:addChild( mCardUI ) 
    mCardUI:setPosition(640,360)
end

--��ա�ɾ��
function Showcirclecard:clear() 
    for i = 1, #mCardArr do
        mCardArr[i]:clear()
    end
    mCircle = nil
end

return Showcirclecard