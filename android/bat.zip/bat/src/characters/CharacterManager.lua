character = require("characters.character")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = class()-- 定义一个类 test 继承于 base_type

function CharacterManager:ctor()

	print("CharacterManager:ctor --------------------------")
	
end

function CharacterManager:instance()
    local o = _G.CharacterManager
    if o then
    	return o
	end
 
    o = CharacterManager:new()
	_G.CharacterManager = o
    CharacterManager:init()
    return o
end

function CharacterManager:init()
    --主角
    self.mainPlayer = nil
    --玩家列表
    self.playerList = {}
     --各关卡已开的NPCId列表  结构:{关卡ID:npc数据}
    self.stageNpcList = {}
    --保存已经开启的npc_camp为0的npc列表
    self.WinNpcList = {}
end


--发送解锁的NPC列表给后台
function CharacterManager:sendNpcMsg()
    local str = ""
    if self.stageIdList == nil or #self.stageIdList == 0 then return end  --未成功初始化则返回
    for i = 1, #self.stageIdList do
        if self.stageNpcList[ self.stageIdList[i] ] ~= nil then
            str = str..self.stageNpcList[ self.stageIdList[i] ]..","
        end
    end

    if str == "" then
        return
    end

    for i = 1, #self.WinNpcList do
        str = str..self.WinNpcList[i]..","
    end
    if str ~= "" then
        str = string.sub( str, 1, -2 )--返回除了最后的","的字符串
        ServMsgTransponder:SMTWarMapNpc(str)
        --print( "savenpc "..str)
    end

    if StoryWindow.isShow == true then
        StoryWindow:UpDataMsg()
    end
end

function CharacterManager:callbackNpcWin( npcId )
    local npcList = DataManager:getDataMapNpc()
    for key, npcObj in pairs(npcList) do  --遍历npc数据表,看看这次打败的NPC能激活哪些新的NPC
        if npcId == npcObj.Death_trigger then  --如果是触发的NPCId了
            if npcObj.npc_camp == 0 or self.stageNpcList[npcObj.npc_camp] == nil or (self.stageNpcList[npcObj.npc_camp] and self.stageNpcList[npcObj.npc_camp] < npcObj.npc_id) then
                self.stageNpcList[npcObj.npc_camp] = npcObj.npc_id  
                if npcObj.npc_camp == 0 and table.indexof(self.WinNpcList, npcObj.npc_id) == false then --npcObj.npc_camp = 0时的特殊处理
                    table.insert(self.WinNpcList, npcObj.npc_id)
                end

            end
        end
    end      

    self:sendNpcMsg()
end

--判断该npc之前是否已经打赢了,是则返回2,否则返回1
--npc不属于故事模式类型的(npc_camp == 0)也要返回2
function CharacterManager:checkNpcWin( npcId )
    local npcObj = DataManager:getDataMapNpcbyDi(npcId)
    if npcObj and npcObj.npc_camp == 0 then
        return 2
    end
    local npcList = DataManager:getDataMapNpc()
    for key, npcObj in pairs(npcList) do  --遍历npc数据表,看看这次打败的NPC能激活哪些新的NPC
        if npcId == npcObj.Death_trigger then  --如果是触发的NPCId了            
            if npcObj.npc_camp == 0 then--npcObj.npc_camp = 0时的特殊处理
                if table.indexof(self.WinNpcList, npcObj.npc_id) == false then
                    return 1  --还没有打赢
                end
            elseif self.stageNpcList[npcObj.npc_camp] == nil or (self.stageNpcList[npcObj.npc_camp] and self.stageNpcList[npcObj.npc_camp] < npcObj.npc_id) then
                return 1  --如果可以触发的NPC还没激活,这表示该NPC之前这是第一次被打败,返回1
            end
        end
    end    
    return 2 
end

--npcIdList 当前保存的NPCID列表
function CharacterManager:updateMapNpcMsg( npcIdList )    
    --各关卡已开的NPCId列表  结构:{关卡ID:npc数据}
    self.stageNpcList = {}
    for key, value in pairs( npcIdList ) do  
        npcObj = DataManager:getDataMapNpcbyDi( tonumber(value) )
        if npcObj then
            if self.stageNpcList[npcObj.npc_camp] == nil then
                self.stageNpcList[npcObj.npc_camp] = 0
            end
            if self.stageNpcList[npcObj.npc_camp] < npcObj.npc_id then
                self.stageNpcList[npcObj.npc_camp] = npcObj.npc_id
            end
            if npcObj.npc_camp == 0 and table.indexof(self.WinNpcList, npcObj.npc_id) == false then --npcObj.npc_camp = 0时的特殊处理
                table.insert(self.WinNpcList, npcObj.npc_id)
            end
        end
    end 

    --当前关卡列表 结构:{关卡ID1, 关卡ID2}
    if self.stageIdList == nil then
        self.stageIdList = {}
        for key, value in pairs(DataManager:getDataMapCampNpc()) do
            if table.indexof(self.stageIdList, key) == false then
                table.insert( self.stageIdList, key )
            end
        end
        table.sort(self.stageIdList, function(a,b)
            return a < b
        end)
    end    

    if self.stageNpcList[100] == nil then --未解锁解密关卡先解开
        self.stageNpcList[100] = 300
        self.stageNpcList[101] = 320
        self.stageNpcList[102] = 340
        self.stageNpcList[103] = 360

        self:sendNpcMsg()
    end
end

--创建玩家信息
function CharacterManager:createPlayer( charID, isMainPlayer )
    local char = self.playerList[charID]
    if char ~= nil then return char end
    if isMainPlayer == true then
        if self.mainPlayer == nil then
            self.mainPlayer = character.new()
            self.mainPlayer:init()
            self.mainPlayer.IsMainChar = true
        end
        char = self.mainPlayer
    else
        char = self.playerList[charID]
        if char == nil then
             char = character.new()
             char:init()
        end
    end
    
    char.CharID = charID
    self.playerList[charID] = char
    return char
end

--获取主角信息
function CharacterManager:getMainPlayer()
    return self.mainPlayer
end

--根据角色ID获取玩家信息
function CharacterManager:getPlayerByCharID( charID )
    return self.playerList[tonumber(charID)]
end

local mVipTimer
local mRemainTimes
local mRemainDays

function CharacterManager:getVipDays()
    return mRemainDays
end

local function updateVipTimer()
    mRemainTimes = mRemainTimes - 60  --由于不需要太精确,60s更新一次就可以了
    mRemainDays =  math.ceil( mRemainTimes / 86400 ) --- 1
--    local hour = math.ceil( mRemainTimes % 86400 / 3600 )
    if MainWindow.isShow == true then
        MainWindow:updatamsg()
    end
--    if mRemainTimes < 0 then
--       LadderManager:setSeasonTime()
--    end
end

--设置月卡结束时间及计时
function CharacterManager:setVipTime( reTime, reDay )    
    if reTime == nil then
        local char = self:getMainPlayer()
        reTime = char.VipTime
        reDay = char.VipGetDay
    end
--    print( "setVipTime "..reTime.." "..os.date("%Y-%m-%d-%H",reTime))
--    print( "setVipTime "..reTime.." "..os.date("%Y-%m-%d-%H",SERVER_TIME))
--    print( "setVipTime "..reTime.." "..os.date("*t",SERVER_TIME).yday)

--    local day = os.date("*t",SERVER_TIME).yday
--    local min = os.date("%M", SERVER_TIME )
--    local sec = os.date("%S", SERVER_TIME )
--    local min2 = os.date("%M", reTime )
--    local sec2 = os.date("%S", reTime )
--    print(" setVipTime "..day..","..min..","..sec..","..min2..","..sec2)
--    if min > min2 or (min == min2  and sec > sec2) then
--        day = day - 1
--    end 
--    if day > reDay then
--        TaskManager:setRewardData( 6, 100 ) --新手礼包领取提示
--    end

    mRemainTimes = reTime - SERVER_TIME
    
    if mVipTimer == nil then
        local fuc = function () updateVipTimer() end
        mVipTimer = require("framework.scheduler").scheduleGlobal( fuc, 5 ) --由于不需要太精确,60s更新一次就可以了
        mRemainTimes = mRemainTimes + 60 --下面执行一次所以先加上60
        updateVipTimer()
    end  
end

function CharacterManager:endSeasonTime()
    if mVipTimer then
        require("framework.scheduler").unscheduleGlobal( mVipTimer )--清理计时器
        mVipTimer = nil
    end
end

function CharacterManager:endSeasonTime()
    if mVipTimer then
        require("framework.scheduler").unscheduleGlobal( mVipTimer )--清理计时器
        mVipTimer = nil
    end
end

return CharacterManager