local character = class("character")

function character:init()
    --是否为主角
    self.IsMainChar = false
     --玩家角色ID
    self.CharID = 0
    --玩家账号名
    self.accounts = ""
    --玩家姓名
    self.Name = "iiiiiii"
    --玩家金币
    self.gold = 0
    --玩家钻石
    self.stone = 0
    --玩家竞技场点券
    self.arenaPoints = 0
    --玩家用于合成卡牌的尘
    self.dust = 0
    --玩家拥有的卡背的数组
    self.AllCardBgArr = {}
    --玩家正在使用的卡背
    self.UsingCarBg = 0
    --玩家拥有的头像的数组
    self.AllHeadIdArr = {}
    --玩家开启的卡组位数量
    self.deckNum = 8
    --玩家头像编号
    self.headId = 1
    --玩家当前等级
    self.CharLevel = 0
    --玩家之前等级
    self.OldCharLevel = 0
    --玩家当前经验
    self.CharExp = 0
    --玩家之前经验
    self.OldCharExp = 0
    --玩家钥匙数量
    self.boxkey = 0
    --玩家荣誉值
    self.CharHonour = 0
    --玩家之前荣誉值
    self.OldCharHonour = 0
    --玩家获得的最大荣誉值
    self.CharMaxHonour = 0
    --玩家任务信息
    self.CharTaskArr = {}
    --玩家战斗胜利场数
    self.Wins = 0
    --玩家战斗失败场数
    self.Lose = 0

    --玩家NPCID(不是NPC则为0)
    self.NPCID = 0

    --玩家是否开启了天梯AI选项0关闭1开启
    self.AllowAI = 0
    --玩家是否禁止观战0关闭1开启
    self.ForbidWatch = 0

    --玩家是否已经购买了新手礼包 -1:还没收到协议 0:没买 1:已经买过了
    self.BuyNewGift = -1
    --玩家月卡vip到期时间
    self.VipTime = -1
    --玩家上次领取月卡奖励时间
    self.VipGetDay = -1
end

return character