local LadderManager = class()



function LadderManager:ctor()
    print(" LadderManager:ctor----=-=-=-=-=-")
end

--��������ʣ��ʱ��
local mRemainTimes = 0
--ʱ�������
local mSeasonTimer

local socket = require "socket"

function LadderManager:instance()
    local o = _G.LadderManager
    if o then
    	return o
	end
 
    o = LadderManager:new()
	_G.LadderManager = o
    LadderManager:init()
    return o
end

function LadderManager:init()
    self.CurPage = 1
    self.NextPage = 1
    self.CurRank = 0
    self.CurCapNum = 0

    self.LadderDataArr = {}
    self.BolGetMsg = false
end

local function updateEndTurnTimer()
    mRemainTimes = mRemainTimes - 60  --���ڲ���Ҫ̫��ȷ,60s����һ�ξͿ�����
    local day = math.ceil( mRemainTimes / 86400 ) - 1
    local hour = math.ceil( mRemainTimes % 86400 / 3600 )
    if LadderRankWindow.isShow == true then
        LadderRankWindow:updateSeasonTime( day, hour )
    end
    if mRemainTimes < 0 then
       LadderManager:setSeasonTime()
    end
end

--������������ʱ�估��ʱ
function LadderManager:setSeasonTime()
    local year = os.date("%Y", SERVER_TIME )
    local month = os.date("%m", SERVER_TIME  ) + 1
    if month > 12 then
        year = year + 1
        month = 1
    end
    local day = os.date("%d", SERVER_TIME )
    local endTime = os.time({day  = 1, month = month, year = year, hour=0, min=0, sec=0})-- ָ��ʱ���ʱ���
    ------------------------------��ӡ����-------------------------
	local dd = os.date("%Y-%m-%d-%H",endTime)
    print(dd)
    mRemainTimes = socket.gettime() - SERVER_GET_TIME + SERVER_TIME
     dd = os.date("%Y-%m-%d-%H", mRemainTimes )
     print(dd)
    print(socket.gettime() - SERVER_GET_TIME)
     ------------------------------��ӡ����-------------------------
    mRemainTimes = math.ceil( endTime - (socket.gettime() - SERVER_GET_TIME + SERVER_TIME ) )

    if mSeasonTimer == nil then
        local fuc = function () updateEndTurnTimer() end
        mSeasonTimer = require("framework.scheduler").scheduleGlobal( fuc, 60 ) --���ڲ���Ҫ̫��ȷ,60s����һ�ξͿ�����
        mRemainTimes = mRemainTimes + 60 --����ִ��һ�������ȼ���60
        updateEndTurnTimer()
    end  
end

function LadderManager:endSeasonTime()
    if mSeasonTimer then
        require("framework.scheduler").unscheduleGlobal( mSeasonTimer )--������ʱ��
        mSeasonTimer = nil
    end
end



return LadderManager