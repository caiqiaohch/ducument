require "tagMap.Tag_ladder"
require "framework.display"
require "framework.cc.ui.UIListView"
require "tagMap.Tag_mclib"


local __instance = nil

local LadderManager = require("Ladder.LadderManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local scheduler = require("framework.scheduler")

local window

--赛季结束时间文本
local mLabelSeasonTime

--点击空白处关闭按钮
local btnBlackBack

--排行榜奖励按钮
local btnOpenReward

--排行榜列表
local mListRood
--排行榜奖励预览列表
local mListReward

--排行榜分页
local mImgTabLadder
--排行榜奖励预览分页
local mImgTabReward

--玩家当前的奖励
local mCharHonour = 1

local mLayoutLadder

local mBolPlaying = false

local mSendTimer

--要预加载的资源列表
local resArr = { PLIST_LADDER_URL, PLIST_WAR2_URL, PLIST_XIANGXI_URL, PLIST_CARDMIDDLEUI_URL, PLIST_CARDUI_URL }

LadderRankWindow = class("LadderRankWindow",function()
	return TuiBase:create()
end)

LadderRankWindow.isShow = false

function LadderRankWindow:create()
	local ret = LadderRankWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
--    ret:setOnEnterSceneScriptHandler(function() ret:onEnterScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function LadderRankWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function LadderRankWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--播放界面打开动态效果
local function playOpenEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true

    local effect = EffectManager:createHnyEffect( 100713 , {x = 0,y = 0} ) 
    window:addChild(effect)
    EffectManager:startHnyEffect( effect, {time = 0.5, fun = function() mListRood:setVisible(true) end , close = function () mBolPlaying = false end } )
    mListRood:setVisible(false)

    local sp = TextureManager:getSprite( mLayoutLadder )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100712, tx2d)
    effect = EffectManager:createHnyEffect( 100712 , {x = mLayoutLadder:getPositionX(), y = mLayoutLadder:getPositionY() - mLayoutLadder:getContentSize().height*0.5}, nil, diy ) 
    window:addChild(effect)
    mLayoutLadder:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () mLayoutLadder:setVisible(true) end } )

    mImgTabLadder:setTouchEnabled(true)
    mImgTabReward:setTouchEnabled(true)
end

--播放界面关闭动态效果
local function playCloseEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true

    local effect = EffectManager:createHnyEffect( 100715 , {x = 0,y = 0} ) 
    window:addChild(effect)
    EffectManager:startHnyEffect( effect )

    local sp = TextureManager:getSprite( mLayoutLadder )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100714, tx2d)
    effect = EffectManager:createHnyEffect( 100714 , {x = mLayoutLadder:getPositionX(), y = mLayoutLadder:getPositionY() - mLayoutLadder:getContentSize().height*0.5}, nil, diy ) 
    window:addChild(effect)
    mLayoutLadder:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () mBolPlaying = false PopScene(__instance) end } )
end


--界面外点击关闭事件
local function BtnCloseClick(p_sender)
    print("close")
    playCloseEffect()
--    PopScene(__instance)
end

--分页点击事件
local function onTabLadderClick(p_sender)
    mListRood:setVisible(true)
    mListReward:setVisible(false)
    mImgTabLadder:setOpacity(255)
    mImgTabReward:setOpacity(1)
end

--分页点击事件
local function onTabRewardClick(p_sender)
    mListRood:setVisible(false)
    mListReward:setVisible(true)
    mImgTabLadder:setOpacity(1)
    mImgTabReward:setOpacity(255)
end


--列表滚动事件
local function onScroll(p_sender)
--    print("mListRood "..mListRood:getContainer():getPositionY())
    if mListRood:getContainer():getPositionY() > 0 and LadderManager.BolGetMsg == false then
        LadderManager.BolGetMsg = true
        ServMsgTransponder:SMTRankCnt(LadderManager.CurPage) --后台从0开始算,直接发当前页码,不用加一
    end
end


--列表cell点击事件
local function BtnCellClick(p_sender)
    RunScene("CharacterWindow")
end

--卡牌查看事件
local function showCardClick( p_sender )
    if CardXiangXi.isShow == false then 
        RunScene( "CardXiangXi" )
        CardXiangXi:setAndShowCardXiangXi( p_sender.mCardID, 1 )
    end
end

--清除
 function LadderRankWindow:clear( tempSelf )
    for i in pairs(tempSelf.mData) do
        tempSelf.mData[i] = nil
    end
    tempSelf.mData = nil
end

local function sendSMTOpen()
    if #LadderManager.LadderDataArr == 0 then
        ServMsgTransponder:SMTRankOpen()
    else
        scheduler.unscheduleGlobal( mSendTimer )
        mSendTimer = nil
    end
end


--初始化界面
function LadderRankWindow:onLoadScene()
    ServMsgTransponder:SMTRankOpen()
    if mSendTimer == nil then
        local fun = function () sendSMTOpen() end
        mSendTimer = scheduler.scheduleGlobal( fun, 0.5 )
    end    
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end

function LadderRankWindow:updateList()
    local itemList = {}
    local arr
    local dataList = LadderManager.LadderDataArr
    local len = #dataList
    local len2
    local ii = 1
--    把所有分页的数据放到一个列表中    
    for i=1, len do
        arr = dataList[i]
         len2 = #arr
         for j=1, len2 do
            itemList[ii] = arr[j]
            ii = ii + 1
         end
         
    end
    len = #itemList
    for i=1, len do
        if mListRood:getNodeCount() == 0 then
            LadderRankWindow:insertItemToList(itemList[i])
        elseif mListRood:getNodeAtIndex(mListRood:getNodeCount()-1).rank < itemList[i].rank then
            LadderRankWindow:insertItemToList(itemList[i])
        end
    end

    mListRood:reloadData()
end

function LadderRankWindow:insertItemToList(data)
    data = data
    local rankCell = CGridPageViewCell:new()
    TuiManager:getInstance():parseCell( rankCell, "cell_rankCell", PATH_LADDER )

    local fontRank = rankCell:getChildByTag(Tag_ladder.LABBMF_RANK)
    local fontCapnum = rankCell:getChildByTag(Tag_ladder.LABBMF_CAPNUM)
    local txtName = rankCell:getChildByTag(Tag_ladder.LABEL_NAME)
    local imgBg = rankCell:getChildByTag(Tag_ladder.IMG_LEGENDARYITEMBG)
    local imgFlag = rankCell:getChildByTag(Tag_ladder.IMG_LADDERFLAG)
    local img_ladder_me = rankCell:getChildByTag(Tag_ladder.IMG_LADDER_ME)

    rankCell.rank = tonumber(data.rank)
    txtName:setString(data.name)

    fontRank:setString(data.rank)
    fontCapnum:setString(data.capnum)

    if mListRood:getNodeCount() % 2 == 0 then
        imgBg:setVisible(true)
    else
        imgBg:setVisible(false)
    end

    if mListRood:getNodeCount() < 3 then
        imgFlag:setVisible(true)
    else
        imgFlag:setVisible(false)
    end    

    local rankList = DataManager:getDataRank()
    local rankData
    for i=1, #rankList do        
        if rankList[i] and rankList[i].integral >= data.capnum then
            rankData = rankList[i]
            break
        end      
    end
    if rankData then
        img_ladder_me:setTexture("other/rankIcon/"..rankData.icon..".png")
    end

    rankCell:setContentSize( cc.size( 1007, 65 ) )
    mListRood:insertNodeAtLast(rankCell)
end


function LadderRankWindow:updateRewardList()
    local rankList = DataManager:getDataRank()
    local char = CharacterManager:getMainPlayer()
    local rankData
    for i=1, #rankList do 
        if rankList[i] then 
            if rankList[i].rank_rewardshow ~= 0 then
                mCharHonour = rankList[i].rank_id
            end       
            if rankList[i].integral >= char.CharMaxHonour then
                rankData = rankList[i]
                break
            end      
        end
    end

    local len = #rankList     
    for i=1, len do
        if rankList[i] and rankList[i].rank_rewardshow ~= 0 then
            LadderRankWindow:insertItemToRewardList(rankList[i])
        end
    end

    mListReward:reloadData()
end

function LadderRankWindow:insertItemToRewardList(data)
    local rankCell = CGridPageViewCell:new()
	TuiManager:getInstance():parseCell( rankCell, "cell_rankreward", PATH_LADDER )

------------------------------------------------------------------------------------------------------------------
    local img_rank_flag = rankCell:getChildByTag(Tag_ladder.IMG_LADDER_REWARD)
    local imgBg = rankCell:getChildByTag(Tag_ladder.IMG_RANKLIST3)
    local img_gold = rankCell:getChildByTag(Tag_ladder.IMG_GOLD_REWARD)
    local lab_gold = rankCell:getChildByTag(Tag_ladder.LABBMF_GOLD_REWARD)
     
    img_rank_flag:setTexture("other/rankIcon/"..data.icon..".png") 
    if data.gold_reward == 0 then
        img_gold:setVisible(false)
        lab_gold:setString("")
    else
        img_gold:setVisible(true)
        lab_gold:setString("x"..data.gold_reward)
    end
    
    
    local pack_reward =  string.split(data.pack__reward, ",")

    local img_Pack1 = rankCell:getChildByTag(Tag_ladder.IMG_PACK_REWARD1)
    local lab_pack1 = rankCell:getChildByTag(Tag_ladder.LABBMF_PACK_REWARD1)
    if pack_reward[1]~=nil and pack_reward[1]~="" then
        local packData = string.split(pack_reward[1], "#")
        img_Pack1:setTexture("other/img_Pack_"..packData[1]..".png")
        lab_pack1:setString("x"..packData[2])
    else
        img_Pack1:setVisible(false)
        lab_pack1:setVisible(false)
    end

    local img_Pack2 = rankCell:getChildByTag(Tag_ladder.IMG_PACK_REWARD2)
    local lab_pack2 = rankCell:getChildByTag(Tag_ladder.LABBMF_PACK_REWARD2)
    if pack_reward[2]~=nil and pack_reward[2]~="" then
        local packData = string.split(pack_reward[2], "#")
        img_Pack2:setTexture("other/img_Pack_"..packData[1]..".png")
        lab_pack2:setString("x"..packData[2])
    else
        img_Pack2:setVisible(false)
        lab_pack2:setVisible(false)
    end

    local img_Pack3 = rankCell:getChildByTag(Tag_ladder.IMG_PACK_REWARD3)
    local lab_pack3 = rankCell:getChildByTag(Tag_ladder.LABBMF_PACK_REWARD3)
    if pack_reward[3]~=nil and pack_reward[3]~="" then
        local packData = string.split(pack_reward[3], "#")
        img_Pack3:setTexture("other/img_Pack_"..packData[1]..".png")
        lab_pack3:setString("x"..packData[2])
    else
        img_Pack3:setVisible(false)
        lab_pack3:setVisible(false)
    end
       
    local img_ladder_me = rankCell:getChildByTag(Tag_ladder.IMG_LADDER_REWARDME)
    img_ladder_me:setVisible(false)
    if mCharHonour == data.rank_id then 
        img_ladder_me:setVisible(true)
    end

    local card_reward =  string.split(data.card__reward, ",")
    if card_reward[1]~=nil and card_reward[1]~="" then
        local cardDataStr = string.split(card_reward[1], "#")
        local cardUI = require("war2.cardMiddle").new()
        rankCell:addChild( cardUI )        
        cardUI:setScale(0.3)
        cardUI:init( tonumber(cardDataStr[1]) )
        cardUI:setTouchEnabled(true)
        cardUI:setOnClickScriptHandler( showCardClick )

        local posX = 445 + #pack_reward * 112
        cardUI:setPosition( posX, 48 )

        if img_ladder_me:isVisible() == true then
            img_ladder_me:setPositionX(posX + 100)
        end
    end

    if mListReward:getNodeCount() % 2 == 0 then
        imgBg:setVisible(true)
    else
        imgBg:setVisible(false)
    end

    rankCell:setContentSize( cc.size( 1007, 100 ) )
    mListReward:insertNodeAtLast(rankCell)
end

function LadderRankWindow:updateSeasonTime( day, hour )
    local str = DataManager:getStringDataTxt( 1, true )
    str = string.gsub(str,"$1", day)
    str = string.gsub(str,"$2", hour)
    mLabelSeasonTime:setString(str)
end

function LadderRankWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_rank",PATH_LADDER)
    window = self:getChildByTag(Tag_ladder.PANEL_RANK)
    mLayoutLadder = self:getControl(Tag_ladder.PANEL_RANK, Tag_ladder.LAYOUT_LADDER)
           --覆盖战场按钮
    btnClose = mLayoutLadder:getChildByTag(Tag_ladder.BTN_CLOSE)
    btnClose:setOnClickScriptHandler( BtnCloseClick )

    mImgTabLadder = mLayoutLadder:getChildByTag(Tag_ladder.IMG_TAB_LADDER)
    mImgTabLadder:setOnClickScriptHandler( onTabLadderClick )
    
    mImgTabReward = mLayoutLadder:getChildByTag(Tag_ladder.IMG_TAB_REWARD)
    mImgTabReward:setOnClickScriptHandler( onTabRewardClick )

    mLabelSeasonTime = mLayoutLadder:getChildByTag(Tag_ladder.LABEL_SEASONTIME)
    mLabelSeasonTime:setString( "" )
    --------------------------排行榜列表-------------------------------------
    mListRood = self:getControl(Tag_ladder.PANEL_RANK,Tag_ladder.LIST_RANK)
   
    mListRood:removeAllNodes()
    mListRood:initWithSize( cc.size(1007, 600) )
    mListRood:setPosition(0, 50)

    mListRood:setOnScrollingScriptHandler(onScroll)
    --------------------------排行榜奖励列表-------------------------------------
    mListReward = self:getControl(Tag_ladder.PANEL_RANK,Tag_ladder.LIST_GOOD_REWARD)
   
    mListReward:removeAllNodes()
    mListReward:initWithSize( cc.size(1007, 600) )
    mListReward:setPosition(0, 50)
    
    self:updateList()
    self:updateRewardList()
    onTabLadderClick(mImgTabLadder)

    ------------------------更新玩家自己的排行信息---------------------------------//
    local mRankIcon = mLayoutLadder:getChildByTag(Tag_ladder.IMG_LADDERICON)
    local mLabCurRank = mLayoutLadder:getChildByTag(Tag_ladder.LABBMF_CURRANK)
    local mLabScore = mLayoutLadder:getChildByTag(Tag_ladder.LABBMF_SCORE)

    local rankList = DataManager:getDataRank()
    local char = CharacterManager:getMainPlayer()
    local rankData
    for i=1, #rankList do        
        if rankList[i] and rankList[i].integral >= char.CharHonour then
            rankData = rankList[i]
            break
        end      
    end
    if rankData then
        mRankIcon:setTexture("other/rankIcon/"..rankData.icon..".png")
    end
    if char.Rank == 0 then 
        mLabCurRank:setString( "" )
    else
        mLabCurRank:setString( char.Rank )
    end
    mLabScore:setString( char.CharHonour )

    LadderRankWindow.isShow = true
    LadderManager:setSeasonTime()    
    playOpenEffect()
end

  
function LadderRankWindow:onExitScene()
    LadderManager.BolGetMsg = false   
--    LadderManager.LadderDataArr = {}
    LadderManager.NextPage = 1
    LadderManager:endSeasonTime()

    UILoadManager:delResByArr( resArr )
    if mSendTimer ~= nil then
        scheduler.unscheduleGlobal( mSendTimer )
        mSendTimer = nil
    end
    mBolPlaying = false
    MainWindow:playOpenEffect()
    LadderRankWindow.isShow = false
end
