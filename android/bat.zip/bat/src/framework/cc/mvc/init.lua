
-- init MVC
local mvc = {}

mvc.AppBase = import(".AppBase")
mvc.ModelBase = import(".ModelBase")

return mvc
