
local errors = {}

errors.SERVICE    = "SERVICE"
errors.NETWORK    = "NETWORK"
errors.NO_MORE_AD = "NO_MORE_AD"
errors.VERSION    = "VERSION"
errors.UNKNOWN    = "UNKNOWN"

return errors
