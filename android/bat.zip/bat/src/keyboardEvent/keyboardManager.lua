local warAi = require("war2.warAi"):instance()

local keyboardManager = class()-- 定义一个类 test 继承于 base_type
local LoginSer = require("net.LoginSer"):instance()

local mGmList = {}

local mBolFocus = true

function keyboardManager:ctor()

	print("keyboardManager:ctor --------------------------")
	
end

function keyboardManager:instance()
    local o = _G.keyboardManager
    if o then
    	return o
	end
 
    o = keyboardManager:new()
	_G.keyboardManager = o
    keyboardManager:init()
    return o
end

function keyboardManager:init()
    self.testTxt = ccui.EditBox:create(cc.size(900,40),"main/edit_login.png",0)
    --self.testTxt:setPosition( 640, 360 )
    self.testTxt:retain()
    self.testTxtIndex = 0
    self.testTxtHistroy = {}

    self.tempPrint = print
    self.isOpenPrintFirst = true
    self.isOpenPrintFirst2 = true
    self:openOrCloseWrite()

    mGmList = {}
    for i = 1, 9 do
        table.insert(mGmList, "test"..i)
    end
    table.insert(mGmList, "meng")    
        table.insert(mGmList, "dyh1")   
end

local bolLogErr = false
local function logInsert(str, tempSelf)
    local arr = DEBUG_WRITELOGTABLE
    if #arr > 100 then
        table.remove(arr, 10)
    end
    table.insert(arr, str)
end


local function logDbgPrint(str)
    local arr = str.split(str, " ")
    if arr[2] == "print" then --dbg print war2.war2CardManager State
        pcall( function ()
            print( require( arr[3] ):instance()[arr[4]]  )
            end)
    end
    
end

--GM指令,前台执行的
local function dbgCmd(str)
    local arr = str.split(str, " ")
    local log
    if arr[2] == "count" then --dbg print war2.war2CardManager State
        log = collectgarbage("count")
        print( "log clean before: "..log.. " K" )
        log = collectgarbage("collect")
        log = collectgarbage("count")
        print( "log clean end: "..log.." K" )  
    elseif arr[2] == "npc" then
        local npcId = tonumber(arr[3])
        local npcObj = DataManager:getDataMapNpcbyDi(npcId)
        if npcId == 0 or npcObj == nil then return end
        if npcObj.my_deck > 0 then --不需要选卡组的
            ServMsgTransponder:SMTWarNPC( npcId, CharacterManager:checkNpcWin(npcId) )
        else
            ServMsgTransponder:SMTComposeCardFight( 1 )
            require("framework.scheduler").performWithDelayGlobal( function ()  ServMsgTransponder:SMTWarNPC( npcId, CharacterManager:checkNpcWin(npcId) ) end, 0.5 )       
        end   
    elseif arr[2] == "DEBUG_FPS" then
        local bol = tonumber(arr[3])
        local sharedDirector = cc.Director:getInstance()
        if bol > 0  then
            DEBUG_FPS = true
            sharedDirector:setDisplayStats(true)
        else
            DEBUG_FPS = false
            sharedDirector:setDisplayStats(false)
        end
    elseif arr[2] == "DEBUG_MEM_LOG" then
        local bol = tonumber(arr[3])
        if bol > 0 then
            DEBUG_MEM_LOG = true
            cc.Texture2D:calen_SetTextureLogOpen(true)
        else
            DEBUG_MEM_LOG = false
            cc.Texture2D:calen_SetTextureLogOpen(false)
        end
    elseif arr[2] == "pwd" then
        local bol = tonumber(arr[3])
        if bol > 0 then
            IS_PASSWORD_LOGIN = true
        else
            IS_PASSWORD_LOGIN = false
        end        
    elseif arr[2] == "buytest" then
        local bol = tonumber(arr[3])
        if bol > 0 then
            MainWindow.buyTest = true
        else
            MainWindow.buyTest = false
        end
    elseif arr[2] == "box" then
        RunScene("OpenBoxWindow")
    elseif arr[2] == "newbie" then  --跳过新手
        ServMsgTransponder:SMTWarMapNpc("3,7,13,30,37")
    elseif arr[2] == "story" then --开启全部剧情
        ServMsgTransponder:SMTWarMapNpc("3,18,24,30,42,49,54,314,325,345,365")
    end
   

end


--键盘事件处理 键盘序号取自Cocos2dConstants.lua的cc.KeyCode
function keyboardManager:delKeyboardEvent( event )
    print( "event.key "..event.key )
--    local li  = cc.KeyCode
--    for k, v in pairs(cc.KeyCode) do
--        if v == tonumber(event.key) then
--            print("k "..k)end
--        print("k "..k.."  v "..v)
--    end
    if mBolFocus == false then 
        print("mBolFocus is false")
        return 
    end
    --退出键(PC esc) 手机后退键盘
    if event.key == "back" then          
--        game_ui.exit()
        RunScene("MainSetWindow")
    --菜单键(Menu键)
    elseif event.key == "18" or event.key == "7" then --7是退格键
--        if LogWindow.isOpen == false and IS_STEAM_LOGIN == false then
--            LogWindow.isOpen = true
--            RunScene("LogWindow")
--        end        
    --回车键(PC)
    elseif event.key == "35" then
        local name
        if LoginWindow.isShow == true then
            name = LoginWindow:getCharName()
        else
            if LoginSer.accounts == nil then return end
            name = LoginSer.accounts
        end
        if table.indexof(mGmList, name) == false and BOL_GM_CMD == true then
            return --不是GM则直接返回
        end
        if self.testTxt:getParent() ~= nil then
            local str = self.testTxt:getText()
            if str == "" then
                self.testTxt:removeFromParent()
            elseif string.find( str, "dbg") then
                logDbgPrint(str)
                dbgCmd(str)
            else
                require("net.ServMsgTransponder"):SMTDbg( str )
                local len = #self.testTxtHistroy
                if self.testTxtHistroy[len] == str then
                    return
                end
                self.testTxtHistroy[len+1] = str
                if len > 50 then
                    table.remove( self.testTxtHistroy, 1 )
                end
                self.testTxtIndex = #self.testTxtHistroy
            end
        else
            if CurScene:getChildren() and CurScene:getChildren()[1] then
                CurScene:getChildren()[1]:addChild(self.testTxt,999)  --这里的 CurScene:getChildren()[1] 是界面的panel_main之类的
            end
        end
    --退格键(PC)
    elseif event.key == "7" then
--        self:openOrCloseWrite( DEBUG_ISOPENWRITEMSG == false )
    --方向上(PC)
    elseif event.key == "28" then
        local len = #self.testTxtHistroy
        if len == 0 then return end
        local index = self.testTxtIndex - 1
        if index <= 0 then 
            index = 1
            self.testTxtIndex = 1
        else
            self.testTxtIndex = index
        end
        self.testTxt:setText( self.testTxtHistroy[index] )
    --方向下(PC)
    elseif event.key == "29" then
        local len = #self.testTxtHistroy
        if len == 0 then return end
        local index = self.testTxtIndex + 1
        if index > len then 
            index = len
            self.testTxtIndex = len - 1
            if self.testTxtIndex <= 0 then self.testTxtIndex = len end
        else
            self.testTxtIndex = index
        end
        self.testTxt:setText( self.testTxtHistroy[index] )
    elseif event.key == "26" then--右箭头
        if LoginSer.accounts == nil then return end
        local name = LoginSer.accounts
        if table.indexof(mGmList, name) == false and BOL_GM_CMD == true then
            return --不是GM则直接返回
        end
        warAi:doNpcAi()
    elseif event.key == "27" then--右箭头
        if LoginSer.accounts == nil then return end
        local name = LoginSer.accounts
        if table.indexof(mGmList, name) == false and BOL_GM_CMD == true then
            return --不是GM则直接返回
        end
        if MusicWnd.isShow == false then
            RunScene( "MusicWnd" )
        else
            MusicWnd:closeWindow()
        end
    elseif event.key == "47" then--F1
        DEBUG_ISOPENWRITEMSG = not DEBUG_ISOPENWRITEMSG
        UserDefaultManager:setBoolForKey( "ISOPENWRITEMSG", DEBUG_ISOPENWRITEMSG )
        if DEBUG_ISOPENWRITEMSG == true then
            require("prompt.PromptManager"):instance():SetNotice( 4088 )    --开启了log打印
        else
            require("prompt.PromptManager"):instance():SetNotice( 4089 )    --关闭了log打印
        end
    elseif event.key == "48" then--F2
        if io.exists(DEBUG_WRITEMSGURL) == true then
            UserDefaultManager:uploadLog(true)  --上传log
            require("prompt.PromptManager"):instance():SetNotice( 4095 )  
        end        
    end
end

--开启或关闭打印信息
function keyboardManager:openOrCloseWrite()
    
    local bool = DEBUG_ISOPENWRITEMSG or DEBUG_ISOPENWRITELOG
    if bool == true then
        print = function (tempStr) 
            if DEBUG_ISOPENWRITEMSG then
                self.tempPrint(tempStr) 
                if io.writefile ~= nil then 
                    local CurrentDateTime = os.date("*t",os.time())
                    str = CurrentDateTime.hour..":"..CurrentDateTime.min..":"..CurrentDateTime.sec..":"..tempStr
                    --开启后第一次记录信息
                    if self.isOpenPrintFirst == true then
                        self.isOpenPrintFirst = false
                        if DEBUG_WRITENEWMSGEVERYTIMES == true then
                            if io.exists(DEBUG_WRITEMSGURL) == true then
                                io.common_copy(DEBUG_WRITEMSGURL, DEBUG_WRITEMSGURL2)
                            end

                            io.writefile( DEBUG_WRITEMSGURL, "", "w+b" )
                        else
                            io.writefile( DEBUG_WRITEMSGURL, "\n\n\n", "a+b" ) 
                        end
                    end
                    io.writefile( DEBUG_WRITEMSGURL, str.."\n", "a+b" ) 
                end 
            end

            if DEBUG_ISOPENWRITELOG then
                if DEBUG_ISOPENWRITEMSG == false then
                    self.tempPrint(tempStr)
                end
                if io.writefile ~= nil then 
                    local CurrentDateTime = os.date("*t",os.time())
                    str = CurrentDateTime.hour..":"..CurrentDateTime.min..":"..CurrentDateTime.sec..":"..tempStr
--                    --开启后第一次记录信息
--                    if self.isOpenPrintFirst2 == true then
--                        self.isOpenPrintFirst2 = false
--                        if DEBUG_WRITENEWMSGEVERYTIMES == true then
--                            io.writefile( DEBUG_WRITELOGURL, "", "w+b" )
--                        else
--                            io.writefile( DEBUG_WRITELOGURL, "\n\n\n", "a+b" ) 
--                        end
--                    end
--                    io.writefile( DEBUG_WRITELOGURL, str.."\n", "a+b" ) 
                    logInsert(str, self)
                end 
            end
        end
    else
        print = self.tempPrint
    end 
end

function keyboardManager:setBolFocus(bol)
    mBolFocus = bol
end

function keyboardManager:getBolFocus()
    return mBolFocus
end

return keyboardManager