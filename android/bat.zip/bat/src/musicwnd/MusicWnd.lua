require "tagMap.Tag_mclib"
require "tagMap.Tag_music"
require"lfs"
local DataManager = require("data.DataManager"):instance()
local EffectManaget = require("ui.EffectManager"):instance()

local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local utils = require("loader.utils")
-------------------------------------------------------------------------------
MusicWnd = class("MusicWnd",function()
	return TuiBase:create()
end)
-------------------------------------------------------------------------------

--�����ļ�
local btn_gengxinwenjian = nil
--���β���
local btn_dancibofang = nil
--ѭ������
local btn_xunhuanbofang = nil
--�����б�
local mListRood1 = nil
--��Ч�б�
local mListRood2 = nil

local selectListRood1 = nil
local selectListRood2 = nil

local label_txt_1 = nil
local label_txt_2 = nil
--������
local window = nil

--
local mImgBg = nil

local edit_effect_Search = nil

local edit_VibScreen

local mUseHandEff 

local mModel1
local mModel2

-------------�ұ����------------//
local resArr = { PLIST_WAR2_URL }
local music_table = {}
local particle_table = {}

local __instance = nil

MusicWnd.isShow = false

local function tempCardUIClick(p_sender)
    local parentMe = p_sender:getParent():getParent():getParent()
    if parentMe.selectTxt ~=nil then
        parentMe.selectTxt:setColor(cc.c3b(255,255,255))
    end
    p_sender:setColor(cc.c3b(255,255,0))
    parentMe.selectTxt = p_sender
end

local function findindir (path, wefind, r_table, intofolder)  
    for file in lfs.dir(path) do  
        if file ~= "." and file ~= ".." then  
            local f = path..'/'..file  
            --print ("/t "..f)  
            if string.find(f, wefind) ~= nil then  
                --print("/t "..f)  
                table.insert(r_table, f)  
            end  
            local attr = lfs.attributes (f)  
            assert (type(attr) == "table")  
            if attr.mode == "directory" and intofolder then  
                findindir (f, wefind, r_table, intofolder)  
            else  
                --for name, value in pairs(attr) do  
                --    print (name, value)  
                --end  
            end  
        end  
    end  
end

----��Ч�б�
--local music_table
----�����б�
--local particle_table
function MusicWnd:updateList()

    local len = #music_table
    for i=1, len do
        MusicWnd:insertItemToList(mListRood1,music_table[i])
    end

--    local len = #particle_table
--    for i=1, len do
--        MusicWnd:insertItemToList(mListRood2,particle_table[i])
--    end

    mListRood1:reloadData()
    mListRood1:setPosition(-450, 100)

--    mListRood2:reloadData()
--    mListRood2:setPosition(-450, -200)
end


function MusicWnd:closeWindow()
    PopScene(__instance)
end

function MusicWnd:insertItemToList(mListRood,data)
    local rankCell = CGridPageViewCell:new()
	TuiManager:getInstance():parseCell( rankCell, "cell_achCell", PATH_MUSIC )
------------------------------------------------------------------------------------------------------------------
    local label_celldesc = rankCell:getChildByTag(Tag_music.LABEL_CELLDESC)
    label_celldesc:setString(data)
    rankCell:setContentSize( cc.size( 450, 30 ) )
    mListRood:insertNodeAtLast(rankCell)
    label_celldesc:setTouchEnabled(true)
    label_celldesc:setOnClickScriptHandler( tempCardUIClick )  

end

--�����ļ�
local function event_btn_gengxinwenjian(p_sender)
    local input_table = {}
    findindir(DEBUG_MUSICURL, "%.mp3", music_table, true)--�ݹ����C���е�mp3�ļ�
    findindir(DEBUG_MUSICURL, "%.wav", music_table, true)--�ݹ����C���е�wav�ļ�
 --   findindir(DEBUG_PARTICLE_URL, "%.xml", particle_table, true)--�ݹ����C���е�txt�ļ�
    MusicWnd:updateList()
    if mUseHandEff~=nil then
        fontTxt:removeFromParent()
    end
end

local musicDelayTimes = 0.01
local musicTimes = 0
local bolAddTimes = true --�Ƿ��ʱ
--��ʱ��������ر�
function MusicWnd:setMusicTimer(bol)
    --��ʱ������ 
    if bol == true and self.MusicTimer == nil then
        local fuc = function () self:updateBattleTimer() end
        self.MusicTimer = require("framework.scheduler").scheduleGlobal( fuc, musicDelayTimes )
    elseif bol == false then
        require("framework.scheduler").unscheduleGlobal( self.MusicTimer )--������ʱ��
        self.MusicTimer = nil
    end
end

--��ʱ��
function MusicWnd:updateBattleTimer()
    if bolAddTimes == false then return end
    musicTimes = musicTimes + musicDelayTimes
    label_txt_1:setString(musicTimes)
    label_txt_2:setString(musicTimes)

    if musicTimes>100 then
        musicTimes = 100
    end
end


local function event_btn_dancibofang(p_sender)
    if mListRood1~=nil and mListRood1.selectTxt~=nil then
        mu = mListRood1.selectTxt:getString()
    end
    cc.SimpleAudioEngine:getInstance():stopAllEffects()
    cc.SimpleAudioEngine:getInstance():playEffect(mu,false)

    if mListRood2~=nil and mListRood2.selectTxt~=nil then
        mu = mListRood2.selectTxt:getString()
    end

--    local path_mu = io.pathinfo(mu)
    local path_mu = edit_effect_Search:getText() 

    if mUseHandEff~=nil then
        window:removeChild(mUseHandEff)
    end

    bolAddTimes = true
    musicTimes = 0
    if utils.exists(DEBUG_PARTICLE_URL.."/"..path_mu..".xml") then
--        local hyNo = Hny.HnyNode:createWithXY( 0, 0 )
--        local hyNo2 = Hny.HnyNode:createWithXY( 0, 0 )
--        mUseHandEff = Hny.HnyParticleEffect:createUseDiy(path_mu, hyNo, hyNo2)
--        window:addChild( mUseHandEff,0 )
--        mUseHandEff:close( function() bolAddTimes = false end )
--        mUseHandEff:start()


--        mUseHandEff = EffectManager:createHnyEffect( path_mu, { hyParent = mModel1 } , { hyParent = mModel2 })
        mUseHandEff = EffectManager:createHnyEffect( path_mu, { x = mModel1:getPositionX(), y = mModel1:getPositionY() } , { x = mModel2:getPositionX(), y = mModel2:getPositionY() })

        mImgBg:addChild( mUseHandEff, 0 )            
        EffectManager:startHnyEffect( mUseHandEff, { close = function() bolAddTimes = false end })
    end

     
    local scrArr = string.split( edit_VibScreen:getText() , "," )
    if #scrArr > 5 then
        if scrArr[7] == nil or scrArr[7] == 0 then
            scrArr[7] = false
        end
        for i = 1, 6 do
            scrArr[i] = tonumber(scrArr[i])
        end    
        EffectManager:VibratingScreen(mImgBg, nil, scrArr[1], scrArr[2], scrArr[3], scrArr[4], scrArr[5], scrArr[6], scrArr[7])
    end    

--    local screenStr = edit_VibScreen:getText() 
--    EffectManager:VibratingScreen(mLayFight, 6, 10, 0.2, 2, 6, false)
end

local mUseHandEff = nil
local function event_btn_xunhuanbofang(p_sender)
    if mListRood1~=nil and mListRood1.selectTxt~=nil then
        mu = mListRood1.selectTxt:getString()
    end
    cc.SimpleAudioEngine:getInstance():stopAllEffects()
    cc.SimpleAudioEngine:getInstance():playEffect(mu,true)

    if mListRood2~=nil and mListRood2.selectTxt~=nil then
        mu = mListRood2.selectTxt:getString()
    end

 --   local path_mu = io.pathinfo(mu)
    local path_mu = edit_effect_Search:getText() 
    local hyNo = Hny.HnyNode:createWithXY( 0, 0 )
    local hyNo2 = Hny.HnyNode:createWithXY( 0, 0 )

    if mUseHandEff~=nil then
         window:removeChild(mUseHandEff)
    end

    if utils.exists(DEBUG_PARTICLE_URL.."/"..path_mu..".xml") then
        mUseHandEff = Hny.HnyParticleEffect:createUseDiy(path_mu, hyNo, hyNo2)
        window:addChild( mUseHandEff )
        mUseHandEff:start()
        musicTimes = 0
    end
end

function MusicWnd:create()
	local ret = MusicWnd.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
    MusicWnd.__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end


--Tag_music = {
--PANEL_MAIN = 1 ,
--IMG_AUTOSELLBOX = 2 ,
--GPV_LZ = 3 ,
--BTN_XUNHUANBOFANG = 4 ,
--BTN_DANCIBOFANG = 5 ,
--GPV_YX = 6 ,
--BTN_GENGXINWENJIAN = 7 ,
--LABEL_TXT_2 = 8 ,
--LABEL_TXT_1 = 9 }
---------------------------------�������---------------------------------//
function MusicWnd:onEnterScene()
    MusicWnd.mCardVec = {}
    TuiManager:getInstance():parseScene( self, "panel_main", PATH_MUSIC )
    window = self:getChildByTag(Tag_music.PANEL_MAIN)
    mImgBg = window:getChildByTag(Tag_music.IMG_AUTOSELLBOX)
    mImgBg:setTexture("war2/fightMap/101.png")
    mImgBg:setScale(0.8)

 	btn_xunhuanbofang = window:getChildByTag(Tag_music.BTN_XUNHUANBOFANG)
 	btn_xunhuanbofang:setOnClickScriptHandler(event_btn_xunhuanbofang)
    btn_xunhuanbofang:setText("LoopPlay")

 	btn_dancibofang = window:getChildByTag(Tag_music.BTN_DANCIBOFANG)
 	btn_dancibofang:setOnClickScriptHandler(event_btn_dancibofang)
    btn_dancibofang:setText("oncePlay")

 	btn_gengxinwenjian = window:getChildByTag(Tag_music.BTN_GENGXINWENJIAN)
 	btn_gengxinwenjian:setOnClickScriptHandler(event_btn_gengxinwenjian)
    btn_gengxinwenjian:setText("Update")
    --------------------------���а��б�-------------------------------------
    mListRood1 = window:getChildByTag(Tag_music.LIST_GOOD1)
    mListRood1:removeAllNodes()
    mListRood1:initWithSize( cc.size(450, 500) )
--    mListRood1:setPosition(682, 341)
--    mListRood1:setOnScrollingScriptHandler(onScroll)
    ------------------------��ť-------------------------------------//
    --------------------------���а��б�-------------------------------------
--    mListRood2 = window:getChildByTag(Tag_music.LIST_GOOD2)
--    mListRood2:removeAllNodes()
--    mListRood2:initWithSize( cc.size(450, 350) )
--    mListRood2:setPosition(0, 35)
--    mListRood2:setOnScrollingScriptHandler(onScroll)
    ------------------------��ť-------------------------------------//

    edit_effect_Search = window:getChildByTag(  Tag_music.EDIT_EFFECT_SEARCH )
    edit_effect_Search:setPlaceHolder( DataManager:getStringDataTxt( 22, true ) )
    edit_effect_Search:setVisible( true )

    edit_VibScreen = window:getChildByTag(  Tag_music.EDIT_VIBSCREEN )
    edit_VibScreen:setPlaceHolder( "����" )


    event_btn_gengxinwenjian(nil)

 	btn_gengxinwenjian = window:getChildByTag(Tag_music.BTN_GENGXINWENJIAN)
 	btn_gengxinwenjian:setOnClickScriptHandler(event_btn_gengxinwenjian)
    btn_gengxinwenjian:setText("Update")

    label_txt_1 =  window:getChildByTag(Tag_music.LABEL_TXT_1)
    label_txt_2 =  window:getChildByTag(Tag_music.LABEL_TXT_2)

    mIsOpenWindow = true
    MusicWnd.isShow = true
    self:setMusicTimer(true)

    --------------���ΰ�ť��Ч-----------  ���ײ���ͨ�������������޸ĵ�....
    local btn = CButton:create()
    btn:setTag(707)
	btn:setName( "" )--���ð�����Ч
    btn:setText( " " )
    --------------���ΰ�ť��Ч-----------

    --ģ��
    mModel1 = require("model.CharModelOld").new()
    mModel1:init() 
    mModel1:setShowParent(1)
    mModel1:resPos( mModel1 )
    mImgBg:addChild(mModel1)
    mModel1:setPosition(1200,360)
    mModel1:setModel( 50009 )
    mModel1:setDir(3)
    mModel1:setChassis(59003)
    mModel1:update()

    mModel2 = require("model.CharModelOld").new()
    mModel2:init() 
    mModel2:setShowParent(1)
    mModel2:resPos( mModel2 )
    mImgBg:addChild(mModel2)
    mModel2:setPosition(700,600)
    mModel2:setModel( 50012 )
    mModel2:setDir(7)
    mModel2:setChassis(59002)
    mModel2:update()
end


----------------------------------------��ʾ��������----------------------------------
--�������Ƽ�ͼ��
function MusicWnd:updateGpvCardList(isUpdataShow, isToLeft)
    print(debug.getinfo(1).name)
end

function MusicWnd:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

---------------------------------�������---------------------------------

function MusicWnd:onExitScene()
    MusicManager:PlayLastSound()
    window = nil
    UILoadManager:delResByArr( resArr )
    MusicWnd.isShow = false
    require("framework.scheduler").unscheduleGlobal( self.MusicTimer )--������ʱ��
    self.MusicTimer = nil
end

function MusicWnd:showPage(value) 

    window:setVisible(true)

end

