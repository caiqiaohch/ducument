require "tagMap.Tag_charwnd"
local DataManager = require("data.DataManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()

local __instance = nil

--点击空白处关闭按钮
local btnBlackBack

local mcBg

--人物信息层
local mLayoutChar
--人物改名层
local mLayoutCharName
--下侧区域
local mLayoutCharDown
--成就区域
local mLayoutCharGpv


--对战总次数
local mTxtMatch
--胜利场数
local mTxtWins
--拥有圣物的卡牌数
local mTxtHoly
--总共拥有的卡牌种类总数
local mTxtOwen
--普通牌的种类总数
local mTxtCommon
--非普通牌的种类总数
local mTxtUncommon
--稀有牌的种类总数
local mTxtRare
--史诗牌的种类总数
local mTxtEpic
--起源版本牌的种类总数
local mTxtOriginate
--联盟版本牌的种类总数
local mTxtAlliance
--特殊版本牌的种类总数
local mTxtOther

--总共拥有的卡牌总数
local mTxtFullOwen
--普通牌的总数
local mTxtFullCommon
--非普通牌的总数
local mTxtFullUncommon
--稀有牌的总数
local mTxtFullRare
--史诗牌的总数
local mTxtFullEpic
--起源版本牌的种类总数
local mTxtFullOriginate
--联盟版本牌的种类总数
local mTxtFullAlliance
--特殊版本牌的种类总数
local mTxtFullOther

--头像
local btnHead
--成就列表
local mAchieveList = {}
--成就列表
local gpvHead
--荣誉值
local mHonour
--最大荣誉值
local mMaxHonour
--玩家等级
local mLevel
--玩家经验值
local mExpTxt

local mBtnNameOk
local mBtnNameClose
local mLabBmfGem
local mLabBmfName
local mEditName
local mBtnName

--玩家信息分页
local mImgTabChar
--成就分页
local mImgTabAchieve

local mMoveAlpha 

local mBolPlaying = false

--是否已经初始化输入文本框
local mBolInitCursor = false

local window

--要预加载的资源列表
local resArr = { PLIST_CHARWND_URL, PLIST_CARDMIDDLEUI_URL, PLIST_CARDUI_URL }

CharacterWindow = class("CharacterWindow",function()
	return TuiBase:create()
end)

CharacterWindow.isShow = false

function CharacterWindow:create()
	local ret = CharacterWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
--    ret:setOnEnterSceneScriptHandler(function() ret:onEnterScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)

	return ret
end

function CharacterWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function CharacterWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--播放界面打开动态效果
local function playOpenEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true

    mLayoutChar:setOpacity(0)
    mMoveAlpha = require("Mov.MovAlpha").new()
    mMoveAlpha:init( mLayoutChar, 255,  25 )
    require("Mov.MovManager"):instance():pushMov( mMoveAlpha )

    local sp = TextureManager:getSprite( mLayoutCharDown )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100712, tx2d)
    effect = EffectManager:createHnyEffect( 100712 , {x = mLayoutCharDown:getPositionX(), y = mLayoutCharDown:getPositionY() - mLayoutCharDown:getContentSize().height*0.5}, nil, diy ) 
    window:addChild(effect)
    mLayoutCharDown:setVisible(false)

    EffectManager:startHnyEffect( effect, {key = function () 
    mBolPlaying = false 
    mLayoutCharDown:setVisible(true) 
    end} )
--    effect:KeyFramesCallback(function () mBolPlaying = false mLayoutCharDown:setVisible(true) end)

    mImgTabChar:setTouchEnabled(true)
    mImgTabAchieve:setTouchEnabled(true)
end

--播放界面关闭动态效果
local function playCloseEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true

    local effect = EffectManager:createHnyEffect( 100715 , {x = 0,y = 0} ) 
    window:addChild(effect)
    EffectManager:startHnyEffect( effect )

    local sp = TextureManager:getSprite( mLayoutCharDown )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100714, tx2d)
    effect = EffectManager:createHnyEffect( 100714 , {x = mLayoutCharDown:getPositionX(), y = mLayoutCharDown:getPositionY() - mLayoutCharDown:getContentSize().height*0.5}, nil, diy ) 
    window:addChild(effect)
    mLayoutCharDown:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () mBolPlaying = false PopScene(__instance) end } )
end



function CharacterWindow:updateMsg()
    local char = CharacterManager:getMainPlayer()
    mTxtMatch:setString(char.Wins + char.Lose)
    mTxtWins:setString(char.Wins.."/"..char.Lose)
    local holyNum = 0
    local allHasNum = 0
    local allFullHasNum = 0 
    local arr = {}
    local fullCardArr = {}
    local verCardArr = {0, 0, 0}
    local fullVerCardArr = {0, 0, 0}
    local obj = nil
    for id, num in pairs(CollectionManager:getAllHasCardList()) do
        if id > 9999 then
            obj = DataManager:getEq(id)
        else
            obj = DataManager:getCardObjByID(id)
        end
        if obj and table.indexof(CARD_VERSION_LIST, obj.version) ~= false and num > 0 then
            
            if id > 9999 then
                holyNum = holyNum + 1
            else
                allHasNum = allHasNum + 1
                if arr[obj.qlt] == nil then arr[obj.qlt] = 0 end
                arr[obj.qlt] = arr[obj.qlt] + 1                   
                
                if num > 4 then num = 4 end
                allFullHasNum = allFullHasNum + num
                if fullCardArr[obj.qlt] == nil then fullCardArr[obj.qlt] = 0 end
                fullCardArr[obj.qlt] = fullCardArr[obj.qlt] + num

                if obj.version == 1 then
                    verCardArr[1] = verCardArr[1] + 1
                    fullVerCardArr[1] = fullVerCardArr[1] + num
                elseif obj.version > 20 and obj.version < 28 then
                    verCardArr[2] = verCardArr[2] + 1
                    fullVerCardArr[2] = fullVerCardArr[2] + num
                elseif obj.version == 100 then
                    verCardArr[3] = verCardArr[3] + 1
                    fullVerCardArr[3] = fullVerCardArr[3] + num
                end
            end
        end
    end
   
    local _dataEq = table.values( DataManager.DataEqArr )  
    local _dataCard = table.values( DataManager.DataCardArr )
    local mAllCardArr = {}
    table.insertto( mAllCardArr,_dataEq )
    table.insertto( mAllCardArr,_dataCard )

    local allHolyNum = 0
    local allCardNum = 0
    local mAllQltArr = {}
    local mAllVerArr = {0, 0, 0}
    for i = 1, #mAllCardArr do
        if mAllQltArr[mAllCardArr[i].qlt] == nil then mAllQltArr[mAllCardArr[i].qlt] = 0 end
        if table.indexof(CARD_VERSION_LIST, mAllCardArr[i].version) ~= false then
            if mAllCardArr[i].id > 9999 then
                allHolyNum = allHolyNum + 1
            else
                allCardNum = allCardNum + 1
                mAllQltArr[mAllCardArr[i].qlt] = mAllQltArr[mAllCardArr[i].qlt] + 1

                if mAllCardArr[i].version == 1 then
                    mAllVerArr[1] = mAllVerArr[1] + 1
                elseif mAllCardArr[i].version > 20 and mAllCardArr[i].version <= 28 then
                    mAllVerArr[2] = mAllVerArr[2] + 1
                elseif mAllCardArr[i].version == 100 then
                    mAllVerArr[3] = mAllVerArr[3] + 1
                end
            end
        end
    end
    local TxtArr = {mTxtCommon, mTxtUncommon, mTxtRare, mTxtEpic}
    local TxtFullArr = {mTxtFullCommon, mTxtFullUncommon, mTxtFullRare, mTxtFullEpic}
    for i = 1, 4 do 
        if arr[i] ~= nil and arr[i] ~= 0 and mAllQltArr[i] ~= nil then
            TxtArr[i]:setString(arr[i].."/".. mAllQltArr[i])
            TxtFullArr[i]:setString(fullCardArr[i].."/".. (mAllQltArr[i] * 4))    --卡牌总数是每张卡的数量乘以4        
        else
            TxtArr[i]:setString("0/".. mAllQltArr[i])
            TxtFullArr[i]:setString("0/".. (mAllQltArr[i] * 4))
        end
    end

    local TxtVerArr = {mTxtOriginate, mTxtAlliance, mTxtOther}
    local TxtFullVerArr = {mTxtFullOriginate, mTxtFullAlliance, mTxtFullOther}

    for i = 1, 3 do 
        if verCardArr[i] ~= nil and verCardArr[i] ~= 0 and mAllVerArr[i] ~= nil then
            TxtVerArr[i]:setString(verCardArr[i].."/".. mAllVerArr[i])
            TxtFullVerArr[i]:setString(fullVerCardArr[i].."/".. (mAllVerArr[i] * 4))    --卡牌总数是每张卡的数量乘以4        
        else
            TxtVerArr[i]:setString("0/".. mAllVerArr[i])
            TxtFullVerArr[i]:setString("0/"..(mAllVerArr[i] * 4))
        end
    end

    mTxtHoly:setString(holyNum.."/"..allHolyNum)
    mTxtOwen:setString(allHasNum.."/"..allCardNum)
    mTxtFullOwen:setString(allFullHasNum.."/"..(allCardNum * 4)) --卡牌总数是每张卡的数量乘以4       

    mExpTxt:setString( char.CharExp.."/"..DataManager:getExp( char.CharLevel ) )

    mHonour:setString( char.CharHonour)
    mMaxHonour:setString( char.CharMaxHonour)
    mLevel:setString( char.CharLevel)
end

--点击关闭事件
local function BtnCloseClick(p_sender)
    print("close")
--    PopScene(__instance)
    playCloseEffect()
end

--分页点击事件
local function onTabCharClick(p_sender)
    mScrollChar:setVisible(true)
    mLayoutCharGpv:setVisible(false)
    mImgTabChar:setOpacity(255)
    mImgTabAchieve:setOpacity(1)
end

--分页点击事件
local function onTabAchieveClick(p_sender)
    mScrollChar:setVisible(false)
    mLayoutCharGpv:setVisible(true)
    mImgTabChar:setOpacity(1)
    mImgTabAchieve:setOpacity(255)
end

--卡牌查看事件
local function showCardClick( p_sender )
    if CardXiangXi.isShow == false then 
        RunScene( "CardXiangXi" )
        CardXiangXi:setAndShowCardXiangXi( p_sender.mCardID, 1 )
    end
end

function CharacterWindow:updateStone()
    local char = CharacterManager:getMainPlayer()
    mLabBmfGem:setString(char.stone)
        
    if char.stone < 1000 and mBtnNameOk.isGrey == false then
        EffectManager:setBtnGrayFilter(mBtnNameOk, true)
        mBtnNameOk.isGrey = true
    elseif char.stone >= 1000 and mBtnNameOk.isGrey == true then
        EffectManager:setBtnGrayFilter(mBtnNameOk, false)
        mBtnNameOk.isGrey = false
    end
end

--播放减金币/宝石效果
function CharacterWindow:addBuyEffect( value )    
    local str = "-"..value--mLabBmfBuyMoney:getString()

    local addGEffect = cc.Sprite:create()
    local G_font = cc.LabelBMFont:create( str, "fonts/labBmf_BitFont+01.fnt" )
    local G_icon--
    local pos
    G_icon = cc.Sprite:create("other/img_Spar.png")
    pos = { x = mLabBmfGem:getPositionX() + mLabBmfGem:getContentSize().width * 0.5, y = mLabBmfGem:getPositionY() }

    addGEffect:addChild(G_font)
    addGEffect:addChild(G_icon)
    G_icon:setPosition(40, 0)
    G_icon:setScale(0.6)
    mLayoutCharName:addChild(addGEffect, 1)
    addGEffect:setPosition( pos.x, pos.y )

    local age_MB = cc.EaseCubicActionOut:create(cc.MoveBy:create(0.5, cc.p(0, 100)))
    local age_DT = cc.DelayTime:create(0.5)
    local age_RS = cc.RemoveSelf:create()
    local age_SQ = cc.Sequence:create(age_MB, age_DT, age_RS)
    addGEffect:runAction(age_SQ)
    
    
    local gf_FO = cc.FadeOut:create(0.5)
    local gf_SQ = cc.Sequence:create(age_DT:clone(), gf_FO)
    G_font:runAction(gf_SQ)
    G_icon:runAction(gf_SQ:clone())   
    
    require("Music.MusicManager"):instance():PlaySound( 114 ) 
end

local function BtnNameClick(p_sender)
    local char = CharacterManager:getMainPlayer()
    mLayoutCharName:setVisible(true)
    mLabBmfGem:setString(char.stone)

    if BOL_CURSOR == true and mBolInitCursor == false then 
        mEditName:setVisible(false)
        local oldPos = {x = mEditName:getPositionX(), y = mEditName:getPositionY()}
        mEditName = CursorTextField.new()
        mEditName:init( {width = 360, height = 30}, TXTFONTNAME, 28, 25)
        mEditName:setEditCallBack( CursorTextListener )
        mLayoutCharName:addChild(mEditName, 9)
        mEditName:setPosition(oldPos.x, oldPos.y)
        mBolInitCursor = true
    end
    mEditName:setText(char.Name)    
end

--检查姓名是否符合要求 返回结果:0合法 1超出长度 2不合法字符 3名称不符合要求
local function checkNameStr(nameStr)
    nameStr = string.lower(nameStr)
    local len = string.len(nameStr)
    if len < 4 or len > 15 then 
        print(len.." 超出长度")
        return 1
    end    
    return 0
end


local function BtnNameOkClick(p_sender)
    if BOL_CURSOR == true then
        CursorTextField:closeAllIME() 
    end
    local char = CharacterManager:getMainPlayer()
    if char.stone < 1000 or mEditName:getText() == char.Name then
        return
    end

    local result = checkNameStr( mEditName:getText() ) --检查名字合法性
    if result == 1 or result == 2 then 
        require("prompt.PromptManager"):instance():SetNotice(3042)--账号名称至少4 ~ 15个字母或数字组成。
        return 
    elseif result == 3 then 
        require("prompt.PromptManager"):instance():SetNotice(3048)
        return 
    end
    ServMsgTransponder:SMTReName( mEditName:getText() )   

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAME1_TEXT)
    fontTxt:setString( mEditName:getText() )
--    mLayoutCharName:setVisible(false)
    CharacterWindow:addBuyEffect( 1000 )    
end


local function BtnNameCloseClick(p_sender)
    if BOL_CURSOR == true then
        CursorTextField:closeAllIME() 
    end
    mLayoutCharName:setVisible(false)
end

--初始化界面
function CharacterWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end

--获取文字
local function getStr( str ,num )
    if num ~= nil then
        local mStr = str
        str = string.gsub(mStr,"$1", num)
    end
    return str
end

 --成就拖动设置
local function gpvHeadClick(p_convertview, idx)
	local pCell = p_convertview
    local ImgCardUI = nil
    local progHp = nil
	if pCell == nil then
        pCell = CGridPageViewCell:new()
        pCell.cardUI = require("war2.cardMiddle").new()
        pCell.cardUI:setScale(0.3)
        pCell:addChild( pCell.cardUI )
        pCell.cardUI:setPosition( 40, 50 )
        pCell.cardUI:setOnClickScriptHandler( showCardClick )
        TuiManager:getInstance():parseCell(pCell, "cell_achCell", PATH_CHARWND)
	end

    local data =  mAchieveList[idx + 1]
    if data ~= nil then 
        data = DataManager:getAchieve( mAchieveList[idx + 1].id )
    end
    if idx == -1 or data == nil then 
        pCell:setVisible(false)
        return pCell
    else
        pCell:setVisible(true)
    end
    local fontTxt = pCell:getChildByTag(Tag_charwnd.LABEL_CELLDESC)
    progHp = pCell:getChildByTag(Tag_charwnd.PROG_EXPPROGRESS)
    local mName = pCell:getChildByTag(Tag_charwnd.LABEL_CELLNAME)

    fontTxt:setString( getStr(data.quest_require, data.amount ) )
    mName:setString( data.quest_name )

    fontTxt = pCell:getChildByTag(Tag_charwnd.LABBMF_CELLNUM)
    --进度条
    progHp:setValue( mAchieveList[idx + 1].num / data.amount * 100 )
    progHp:setShowValueLabel(false)
    fontTxt:setString( mAchieveList[idx + 1].num.."/"..data.amount )
--    local sprite = display.newSprite()
--    sprite:setTexture("other/achIcon/"..data.icon..".png")
--    pCell:addChild(sprite, 0)
--    sprite:setPosition(60, 72)

    local txtNum = pCell:getChildByTag(Tag_charwnd.LABEL_REWARDNUM)
    local mImgPrizeIcon = pCell:getChildByTag(Tag_charwnd.IMG_CELLREWARD)
    local mImgPack = pCell:getChildByTag(Tag_charwnd.IMG_PACK)
    local cardUI = pCell.cardUI

    local img_FinishAchievement = pCell:getChildByTag(Tag_charwnd.IMG_FINISHACHIEVEMENT)
    if mAchieveList[idx + 1].num == data.amount then
        img_FinishAchievement:setVisible(true)

        txtNum:setString("")
        mImgPrizeIcon:setVisible(false)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
        return  pCell--直接返回,不用执行下面的奖励显示
    else
        img_FinishAchievement:setVisible(false)
    end

    if data.card__reward ~= "" then --卡牌
        local cardStr = string.split( data.card__reward, "#" )
        local cardData = DataManager:getCardObjByID( cardStr[1] )
        if cardData == nil then cardData = DataManager:getEq( cardStr[1] ) end
        mImgPrizeIcon:setVisible(false)
        mImgPack:setVisible(false)
        cardUI:setVisible(true)
        cardUI:init(cardData.id)
        txtNum:setString( "×"..cardStr[2] )
    elseif data.pack__reward ~= "" then --卡包
        local packReward = string.split( data.pack__reward, "," )
        for i = 1, #packReward do
            local packStr = string.split( packReward[i], "#" )
            local item = ItemManager:getItemData( packStr[1] )
            local imgUrl
            imgUrl = "other/img_Pack_"..item.item_id..".png"
            mImgPrizeIcon:setVisible(false)
            mImgPack:setVisible(true)
            cardUI:setVisible(false)
            mImgPack:setTexture( imgUrl )
            txtNum:setString( "×"..packStr[2] )
        end         
    elseif data.gold_reward > 0 then --金币
        mImgPrizeIcon:setVisible(true)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
    	mImgPrizeIcon:setTexture( "other/img_Gold.png" )
        txtNum:setString( "×"..data.gold_reward )
	elseif data.gem_reward > 0 then --宝石
        mImgPrizeIcon:setVisible(true)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
        mImgPrizeIcon:setTexture( "other/img_Spar.png" )
        txtNum:setString( "×"..data.gem_reward )
		--require("Music.MusicManager"):instance():PlaySound( 102 )       
    end    

	return pCell
end

function CharacterWindow:onEnterScene()
    local char = CharacterManager:getMainPlayer()    
    TuiManager:getInstance():parseScene(self,"panel_charwnd",PATH_CHARWND)
    window = self:getChildByTag(Tag_charwnd.PANEL_CHARWND)

    mcBg = self:getControl(Tag_charwnd.PANEL_CHARWND, Tag_charwnd.IMG_BG)
    mcBg:setTouchEnabled(true)

    mLayoutChar = self:getControl(Tag_charwnd.PANEL_CHARWND, Tag_charwnd.LAYOUT_CHAR)
    mLayoutCharName = self:getControl(Tag_charwnd.PANEL_CHARWND, Tag_charwnd.LAYOUT_CHARNAME)
    mLayoutCharDown = self:getControl(Tag_charwnd.PANEL_CHARWND, Tag_charwnd.LAYOUT_CHARDOWN)
    mLayoutCharGpv = self:getControl(Tag_charwnd.PANEL_CHARWND, Tag_charwnd.LAYOUT_CHARGPV)

    btnClose = mLayoutCharDown:getChildByTag(Tag_charwnd.BTN_CLOSE)
    btnClose:setOnClickScriptHandler( BtnCloseClick )

    mImgTabChar = mLayoutCharDown:getChildByTag(Tag_charwnd.IMG_TAB_CHAR)    
    mImgTabChar:setOnClickScriptHandler( onTabCharClick )
    
    mImgTabAchieve = mLayoutCharDown:getChildByTag(Tag_charwnd.IMG_TAB_ACHIEVE)
    mImgTabAchieve:setOnClickScriptHandler( onTabAchieveClick )
    ---------------------------文字---------------------
    mExpTxt = mLayoutChar:getChildByTag(Tag_charwnd.LAB_EXPNUM)
    mExpTxt:setString(999)    

    mHonour = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_VESUSNUM)
    mHonour:setString(999)    
    
    mMaxHonour = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_HIGHVESUSNUM)

    mLevel = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_LEVEL)
    mLevel:setString( char.CharLevel )

    local fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_BASICINFO)
    fontTxt:setString( DataManager:getStringDataTxt(49, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAME1)
    fontTxt:setString( DataManager:getStringDataTxt(39, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAME1_TEXT)
    fontTxt:setString( char.Name )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAME)
    fontTxt:setString( DataManager:getStringDataTxt(42, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAME_TEXT)
    fontTxt:setString( char.accounts )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAMEID)
    fontTxt:setString( DataManager:getStringDataTxt(44, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CHARNAMEIDNUM)
    fontTxt:setString( char.CharID )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_MYLEVEL)
    fontTxt:setString( DataManager:getStringDataTxt(75, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_EXP)
    fontTxt:setString( DataManager:getStringDataTxt(5001, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_MATCH)
    fontTxt:setString( DataManager:getStringDataTxt(28, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_WINS)
    fontTxt:setString( DataManager:getStringDataTxt(29, true) )
   
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_RANK)
    fontTxt:setString( DataManager:getStringDataTxt(5, true) )


    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_VESUS)
    fontTxt:setString( DataManager:getStringDataTxt(76, true) )
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_HIGHVESUS)
    fontTxt:setString( DataManager:getStringDataTxt(65, true) )
--    fontTxt:setVisible(false)
--    mMaxHonour:setVisible(false)


    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_MYCOLLECTION)
    fontTxt:setString( DataManager:getStringDataTxt(60, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_HOLY)
    fontTxt:setString( DataManager:getStringDataTxt(1002, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_CARD)
    fontTxt:setString( DataManager:getStringDataTxt(30, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_COMMON)
    fontTxt:setString( DataManager:getStringDataTxt(31, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_UNCOMMON)
    fontTxt:setString( DataManager:getStringDataTxt(32, true) )
  
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_RARE)
    fontTxt:setString( DataManager:getStringDataTxt(34, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_EPIC)
    fontTxt:setString( DataManager:getStringDataTxt(33, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_MYCOLLECTIONFULL)
    fontTxt:setString( DataManager:getStringDataTxt(82, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLCARD)
    fontTxt:setString( DataManager:getStringDataTxt(30, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLCOMMON)
    fontTxt:setString( DataManager:getStringDataTxt(31, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLUNCOMMON)
    fontTxt:setString( DataManager:getStringDataTxt(32, true) )
  
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLRARE)
    fontTxt:setString( DataManager:getStringDataTxt(34, true) )
    
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLEPIC)
    fontTxt:setString( DataManager:getStringDataTxt(33, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_ORIGINATE)
    fontTxt:setString( DataManager:getStringDataTxt(21, true) )
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_ALLIANCE)
    fontTxt:setString( DataManager:getStringDataTxt(26, true) )
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_OTHER)
    fontTxt:setString( DataManager:getStringDataTxt(4122, true) )

    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLORIGINATE)
    fontTxt:setString( DataManager:getStringDataTxt(21, true) )
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLALLIANCE)
    fontTxt:setString( DataManager:getStringDataTxt(26, true) )
    fontTxt = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLOTHER)
    fontTxt:setString( DataManager:getStringDataTxt(4122, true) )

    mTxtMatch = mLayoutChar:getChildByTag(Tag_charwnd.LAB_MATCHNUM)
    mTxtWins = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_WINSNUM)
    mTxtHoly = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_HOLYNUM)

    mTxtOwen = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_OWNERNUM)
    mTxtCommon = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_COMMONNUM)
    mTxtUncommon = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_UNCOMMONNUM)
    mTxtRare = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_RARENUM)
    mTxtEpic = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_EPICNUM)

    mTxtFullOwen = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLOWNERNUM)
    mTxtFullCommon = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLCOMMONNUM)
    mTxtFullUncommon = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLUNCOMMONNUM)
    mTxtFullRare = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLRARENUM)
    mTxtFullEpic = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLEPICNUM)

    mTxtOriginate = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_ORIGINATENUM)
    mTxtAlliance = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_ALLIANCENUM)
    mTxtOther = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_OTHERNUM)

    mTxtFullOriginate = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLORIGINATENUM)
    mTxtFullAlliance = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLALLIANCENUM)
    mTxtFullOther = mLayoutChar:getChildByTag(Tag_charwnd.LABEL_FULLOTHERNUM)

    mBtnName = mLayoutChar:getChildByTag(Tag_charwnd.BTN_NAME)
    mBtnName:setOnClickScriptHandler(BtnNameClick)
    
    self:updateMsg()
    CharacterWindow.isShow = true
    gpvHead = mLayoutCharGpv:getChildByTag(Tag_charwnd.GPV_ACHIVE)
    	-- ccs中 0:none 1:vertical 2:horizontal 3:vertical and horizontal
	-- quick 0:both 1:vertical 2:horizontal
    gpvHead:setDirection(1)
    mLayoutCharGpv:setVisible(false)
    gpvHead:setDataSourceAdapterScriptHandler(gpvHeadClick)

    mLayoutChar:retain()
    mLayoutChar:removeFromParent()

    local arrival = mLayoutCharName:getOrderOfArrival()--获取层级

    mScrollChar = CScrollView:create( cc.size(666, 590) )    --创建可拖动界面，并设置可视区域大小
    mScrollChar:setDirection(1)
    mScrollChar:setPosition( 60, 50 )
    window:addChild( mScrollChar ) 
    mScrollChar:setOrderOfArrival(arrival - 1)

    local consize =  mLayoutChar:getContentSize()
    mScrollChar:setContainerSize( cc.size( consize.width, consize.height) )
    mScrollChar:getContainer():addChild(mLayoutChar)
    mLayoutChar:setPosition( consize.width * 0.5, consize.height * 0.5 )
--    mScrollChar:setOnScrollingScriptHandler(onScroll)
    mScrollChar:setContentOffsetToTop()
    mLayoutChar:release()

    self:UpDataAchMsg()
    onTabCharClick(mImgTabChar)
        
    require("framework.scheduler").performWithDelayGlobal( function() ServMsgTransponder:SMTRankOpen() end, 3 )
    require("framework.scheduler").performWithDelayGlobal( function() ServMsgTransponder:SMTDailyCJOpen() end, 4 )
    CollectionManager:SendOpenInfo()

    mLayoutCharName:setVisible(false)
    mTxtNameTips = mLayoutCharName:getChildByTag(Tag_charwnd.LABEL_NAME_TIPS)
    mTxtNameTips:setString( DataManager:getStringDataTxt(3048, true) )
    mTxtNameDesc = mLayoutCharName:getChildByTag(Tag_charwnd.LABEL_NAME_DESC)
    mTxtNameDesc:setString( DataManager:getStringDataTxt(4130, true) )

    mBtnNameOk = mLayoutCharName:getChildByTag(Tag_charwnd.BTN_NAME_OK)
    mBtnNameOk:setOnClickScriptHandler( BtnNameOkClick )
    mBtnNameOk.isGrey = false
    mBtnNameClose = mLayoutCharName:getChildByTag(Tag_charwnd.BTN_NAME_CLOSE)
    mBtnNameClose:setOnClickScriptHandler( BtnNameCloseClick )
    mLabBmfGem = mLayoutCharName:getChildByTag(Tag_charwnd.LABBMF_CHARGEM)
    mLabBmfGem:setString(DataManager:getStringDataTxt(24, true)..1000)
    mLabBmfName = mLayoutCharName:getChildByTag(Tag_charwnd.LABBMF_NAME)
    mLabBmfName:setString(DataManager:getStringDataTxt(24, true)..1000)
    mEditName = mLayoutCharName:getChildByTag(Tag_charwnd.EDIT_NAME)
    self:updateStone()

    playOpenEffect()
end
  
--更新显示成就
function CharacterWindow:UpDataAchMsg()
    mAchieveList = {}--TaskManager:getFinishedAchList()
    table.merge(mAchieveList, TaskManager.AchieveDataArr)
    table.insertto(mAchieveList, TaskManager:getFinishedAchList())
    gpvHead:setCountOfCell(#mAchieveList)    
    gpvHead:reloadData()
    gpvHead:setBounceable(false) --取消反弹
    gpvHead:setContentOffsetToTop()
end
  
function CharacterWindow:onExitScene()
    CharacterWindow.isShow = false
    UILoadManager:delResByArr( resArr )
    mBolPlaying = false
    mImgTabChar:setTouchEnabled(false)
    mImgTabAchieve:setTouchEnabled(false)
    mcBg:setTouchEnabled(false)
    MainWindow:playOpenEffect()
    mBolInitCursor = false
end

