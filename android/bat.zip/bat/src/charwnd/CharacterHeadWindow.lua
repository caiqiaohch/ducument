require "tagMap.Tag_charwnd"
local DataManager = require("data.DataManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager"):instance()

local __instance = nil

--点击空白处关闭按钮
local btnBlackBack

--确定按钮
local btnOk
--取消按钮
local btnCancel

--拖动图鉴
local gpvHead = nil
local cellList = {}
local mCurHeadId = 0


CharacterHeadWindow = class("CharacterHeadWindow",function()
	return TuiBase:create()
end)

local mCircle
local mHeadImgArr = {}
--放进头像到组件
function CharacterHeadWindow:updataCard()
--    local CharacterManager = require("characters.CharacterManager"):instance()
--    local char = CharacterManager:getMainPlayer()
--    local arr = char.AllHeadIdArr

--    for i = 1, #arr do
--        mHeadImgArr
--    local num = 5--#arr

--    mCircle = CircleMenu:create(arr, cc.size(1300,600))
--    self:addChild(mCircle)
--    mCircle:setScale(0.6)
--    mCircle:setPosition(640,360)

--    for i = 1, num do
--        if arr[i] == nil then
--            local sprite = display.newSprite()
--            sprite:setSpriteFrame("war2/head/HeadPic"..101 + i..".png")
--            mCircle:addChild(sprite)
--            table.insert(mHeadImgArr, sprite)
--        end
--    end
--    mCircle:reloadData()
end

function funcname(args) 
--    local arr = CharacterManager:getMainPlayer().CurCardPackArr
--    CircleCard:setVisible(true)
--    CircleCard:updataCard(arr)
end    

function CharacterHeadWindow:create()
	local ret = CharacterHeadWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function CharacterHeadWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function CharacterHeadWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--清除
 function CharacterHeadWindow:clear( tempSelf )
    for i in pairs(tempSelf.mData) do
        tempSelf.mData[i] = nil
    end
    tempSelf.mData = nil
end

--创建文本框 显示内容、大小、字体、宽度、高度、水平对位(0左1中2右)、垂直对位(0顶1中2底)
local function createTxt( str, size, font, _w, _h, _ha, _va )
    str = str or "" size = size or 16 font = font or "FRABK" _w = _w or 200 _h = _h or 30
    _ha = _ha or 0 _va = _va or 0

    local txt = CLabel:createWithTTF( str, font, size )
    txt:setTextColor(cc.c4b(0,0,0,255))
    txt:setDimensions( _w , _h )
    txt:setAlignment( _ha, _va )
    return txt
end

--界面外点击关闭事件
local function BtnCloseClick(p_sender)
    print("close")
    PopScene(__instance)
end

--确定按钮事件
local function BtnOKClick(p_sender)
    if mCurHeadId ~= 0 then
        ServMsgTransponder:SMTUserinfoHead( mCurHeadId )
    end
    PopScene(__instance)
end

--点击头像事件
local function BtnHeadClick(p_sender)
    local headId = p_sender.headId

    local imgBgLight
    for i = 1, #cellList do
        imgBgLight = cellList[i]:getChildByTag(Tag_charwnd.IMG_CELLLIGHT)
        if i == headId then
            imgBgLight:setVisible(true)
        else
            imgBgLight:setVisible(false)
        end
    end
    mCurHeadId = tonumber(p_sender:getName())
end

--初始化界面
function CharacterHeadWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end



 --卡包拖动设置
local function gpvHeadClick(p_convertview, idx)

	local pCell = p_convertview
    local ImgCardUI = nil
	if pCell == nil then
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell(pCell, "cell_head", PATH_CHARWND)
	end

    if idx == -1 then 
        pCell:setVisible(false)
        return pCell
    else
        pCell:setVisible(true)
    end

    local sprite = display.newSprite()
    sprite:setTexture("war2/head/HeadPic"..101 + idx..".png")
    pCell:addChild(sprite, 0)
    sprite:setPosition(115, 115)

    local imgBgLight = pCell:getChildByTag(Tag_charwnd.IMG_CELLLIGHT)
    imgBgLight:setVisible(false)

    cellList[#cellList + 1] = pCell

    local btn_click = pCell:getChildByTag(Tag_charwnd.BTN_CLICK)
    btn_click.headId = #cellList
    btn_click:setName(idx + 1)
    btn_click:setOnClickScriptHandler( BtnHeadClick )
	return pCell
end

function CharacterHeadWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_headwnd",PATH_CHARWND)

     --覆盖战场关闭按钮
    btnBlackBack = self:getControl(Tag_charwnd.PANEL_HEADWND, Tag_charwnd.BTN_HEADWINDOWBACK)
    btnBlackBack:setOnClickScriptHandler( BtnCloseClick )

    btnOk = self:getControl(Tag_charwnd.PANEL_HEADWND, Tag_charwnd.BTN_HEADOK)
    btnOk:setOnClickScriptHandler( BtnOKClick )
    btnCancel = self:getControl(Tag_charwnd.PANEL_HEADWND, Tag_charwnd.BTN_HEADCANCLE)
    btnCancel:setOnClickScriptHandler( BtnCloseClick )

    local fontTxt = self:getControl(Tag_charwnd.PANEL_HEADWND, Tag_charwnd.LABBMF_OK)
    local btnX = 0
    local btnY = 0
    local parent = fontTxt:getParent()
    if LANGUAGE == "cn" then
        btnX, btnY = fontTxt:getPosition()
        fontTxt:removeFromParent()
        fontTxt = createTxt( DataManager:getStringDataTxt(53, true), 34, TXTFONTNAME )
        fontTxt:setTextColor(cc.c4b(255,255,255,255))
        fontTxt:setPosition( btnX + 90, btnY - 10 )
        fontTxt:setAlignment( 1, 0 )
        fontTxt:setDimensions(260, 20)
        parent:addChild(fontTxt)
    else
        fontTxt:setString( DataManager:getStringDataTxt(53, true) )
    end

    fontTxt = self:getControl(Tag_charwnd.PANEL_HEADWND, Tag_charwnd.LABBMF_CANCLE)
    if LANGUAGE == "cn" then
        btnX, btnY = fontTxt:getPosition()
        fontTxt:removeFromParent()
        fontTxt = createTxt( DataManager:getStringDataTxt(40, true), 34, TXTFONTNAME )
        fontTxt:setTextColor(cc.c4b(255,255,255,255))
        fontTxt:setPosition( btnX + 90, btnY - 10 )
        fontTxt:setAlignment( 1, 0 )
        fontTxt:setDimensions(260, 20)
        parent:addChild(fontTxt)
    else
        fontTxt:setString( DataManager:getStringDataTxt(40, true) )
    end

    gpvHead = self:getControl(Tag_charwnd.PANEL_HEADWND,Tag_charwnd.GPV_HEAD)
    gpvHead:setDataSourceAdapterScriptHandler(gpvHeadClick)
    gpvHead:setCountOfCell(9)
    gpvHead:setContentOffsetToRight()
    gpvHead:setContentOffsetToLeft()
    gpvHead:reloadData()
    gpvHead:setBounceable(false) --取消反弹

   -- self:updataCard()
end

function CharacterHeadWindow:onExitScene()
    cellList = {}
    mCurHeadId = 0

end

