
-- 0 - disable debug info, 1 - less debug info, 2 - verbose debug info
DEBUG = 1

-- display FPS stats on screen
DEBUG_FPS = false

-- dump memory info every 10 seconds
DEBUG_MEM = false

--是否打开calen添加的log打印
DEBUG_MEM_LOG = false

-- load deprecated API
LOAD_DEPRECATED_API = false

-- load shortcodes API
LOAD_SHORTCODES_API = true

-- screen orientation
CONFIG_SCREEN_ORIENTATION = "landscape"

-- design resolution
CONFIG_SCREEN_WIDTH  = 1280
CONFIG_SCREEN_HEIGHT = 720

-- auto scale mode
CONFIG_SCREEN_AUTOSCALE = "SHOW_ALL"

--是否加密
UseEcrypt = true

HEART_BEAT_SECONDS = 5 -- 心跳时间间隔

CHECK_NETWORK = true  -- 是否开启强制网络检测
if DEBUG < 1 then  -- 正式环境必须要开断网检测
    CHECK_NETWORK = true
end

--服务器时间  虽然不算是config预设的值但是没什么其他地方好放那就放这里吧
SERVER_TIME = 0
--接收到服务器的时间戳  虽然不算是config预设的值但是没什么其他地方好放那就放这里吧
SERVER_GET_TIME = 0

--[[
....
...
继续写一些全局配置
]]

--***************************************************************************************
----服务器地址字符串 IP+端口 有铨端
--LOGIN_SERVER_POLICY = "192.168.1.151:8012"
----服务器地址字符串 IP
--LOGIN_SERVER_DOMAIN = "192.168.1.151"
----服务器地址端口
--LOGIN_SERVER_PORT = 8012

----------服务器地址字符串 IP+端口  月辉
--LOGIN_SERVER_POLICY = "192.168.1.181:8012"
----------服务器地址字符串 IP
--LOGIN_SERVER_DOMAIN = "192.168.1.181"
----------服务器地址端口
--LOGIN_SERVER_PORT = 8012

--------服务器地址字符串 IP+端口  宁夏
LOGIN_SERVER_POLICY = "52.82.98.237:8992"
--------服务器地址字符串 IP
LOGIN_SERVER_DOMAIN = "52.82.98.237"
--------服务器地址端口
LOGIN_SERVER_PORT = 8992

--------服务器地址字符串 IP+端口  vpn
--LOGIN_SERVER_POLICY = "144.34.181.158:8991"
----服务器地址字符串 IP
--LOGIN_SERVER_DOMAIN = "144.34.181.158"
----服务器地址端口
--LOGIN_SERVER_PORT = 8991

---- --服务器地址字符串 IP+端口
---- LOGIN_SERVER_POLICY = "192.168.1.161:8886"
---- --服务器地址字符串 IP
---- LOGIN_SERVER_DOMAIN = "192.168.1.161"
---- --服务器地址端口
---- LOGIN_SERVER_PORT = 8886


-- --服务器地址字符串 IP+端口  外服地址
--LOGIN_SERVER_POLICY = "www.andorworld.com:8992"
---- --服务器地址字符串 IP
--LOGIN_SERVER_DOMAIN = "www.andorworld.com"
---- --服务器地址端口
--LOGIN_SERVER_PORT = 8992

-- 服务器地址字符串 IP+端口  外服地址
--LOGIN_SERVER_POLICY = "18.217.242.44:8992"
----服务器地址字符串 IP
--LOGIN_SERVER_DOMAIN = "18.217.242.44"
----服务器地址端口
--LOGIN_SERVER_PORT = 8992

--------备用服务器地址字符串 IP+端口  vpn
LOGIN_SERVER_POLICY_2 = "144.34.181.158:8991"
--服务器地址字符串 IP
LOGIN_SERVER_DOMAIN_2 = "144.34.181.158"
--服务器地址端口
LOGIN_SERVER_PORT_2 = 8991

--游戏服务器最大人数上限
C_DENY_LIMIT = 600

--语言版本
LANGUAGE = "en"
--是否可以播放音乐
IS_OPEN_MUSIC = true
--是否可以播放音效
IS_OPEN_SOUND = true
--是否可以播放音效
IS_OPEN_WATCH = false
--是否可以观看对手
IS_OPEN_CHALLER = false
--是否使用备用线路
IS_OPEN_FONTALINE = false

--是否开启全屏模式 需要重启游戏 默认不全屏,pc端有效
IS_OPEN_FULLSCREENMODE = false


--币种 货币类型 USD	CNY	EUR	JPY
MONEYTYPE = "CNY"
--是否开启写入打印信息
DEBUG_ISOPENWRITEMSG = true
--打印信息保存路径
DEBUG_WRITEMSGURL = cc.FileUtils:getInstance():getWritablePath().."/phoneDebug.txt"--"E:/phoneDebug.txt"
DEBUG_WRITEMSGURL2 = cc.FileUtils:getInstance():getWritablePath().."/phoneDebug2.txt" --上一次的打印信息
DEBUG_MUSICURL = "D:/QuickGame2/QuickGame/res/music"--"F:/phone2/QuickGame/res/music"
DEBUG_PARTICLE_URL  = "D:/QuickGame2/QuickGame/res/effect/Particle"--"F:/phone2/QuickGame/res/effect/Particle"
--每次开启是否重新写入打印信息文件
DEBUG_WRITENEWMSGEVERYTIMES = true

--是否开启写入Log打印信息 记录错误的信息
DEBUG_ISOPENWRITELOG = false
--打印信息保存路径
DEBUG_WRITELOGURL = cc.FileUtils:getInstance():getWritablePath().."/logg.txt"
--打印信息保存table
DEBUG_WRITELOGTABLE = {}

--文本字体
if LANGUAGE == "cn" then
    TXTFONTNAME = "fonts/msyh.ttf"
else
    TXTFONTNAME = "fonts/msyh.ttf"
end

--文本字体加粗
if LANGUAGE == "cn" then
    TXTFONTNAMEB = "fonts/msyh.ttf"
else
    TXTFONTNAMEB = "fonts/msyh.ttf"
end

--文本字体斜体
if LANGUAGE == "cn" then
    TXTFONTNAMEL = "fonts/FZWBJW.ttf"
else
    TXTFONTNAMEL = "fonts/Ariali.ttf"
end


--存放php地址
PHP_URL = "http://52.82.98.237/"
--PHP_URL = "http://192.168.1.181/"

--存放php地址2
PHP_URL2 = "http://52.82.98.237/php-login/"--"http://192.168.1.181/"
--PHP_URL = "http://18.217.242.44/"
--PHP_URL2 = "http://192.168.1.181/php-login-minimal-master/"
--steam相关的php地址
STEAM_PHP_URL = PHP_URL.."steam_sdk/"

--登录是否需要输入正确密码,走注册流程
IS_PASSWORD_LOGIN = false
--登录通用密码
--PASS_KEY = "401haoyou"

--是否启用特殊的输入框
BOL_CURSOR = false

--当前卡牌版本
CARD_VERSION_LIST = {1, 100, 21, 22, 23, 24, 25, 26, 27, 28}

--是否是测试模式 测试模式下不会自动登录，可以在登录界面点击标题切换服务器等正式版屏蔽了的操作
BOL_TEST_MODE = true

--是否只能GM才能打开命令行
BOL_GM_CMD = false

---正式服打包要设置的参数,放在这里方便打包的时候直接修改
if false then
    --------服务器地址字符串 IP+端口  宁夏
    LOGIN_SERVER_POLICY = "52.82.98.237:8992"
    --------服务器地址字符串 IP
    LOGIN_SERVER_DOMAIN = "52.82.98.237"
    --------服务器地址端口
    LOGIN_SERVER_PORT = 8992

    BOL_TEST_MODE = false
    IS_PASSWORD_LOGIN = true
    BOL_GM_CMD = true
end

if IS_GOOGLE_LOGIN == true then
    LANGUAGE = "tw" --谷歌版本默认繁体
    --------服务器地址字符串 IP+端口  谷歌测试
    LOGIN_SERVER_POLICY = "47.75.189.91:8012"
    --------服务器地址字符串 IP
    LOGIN_SERVER_DOMAIN = "47.75.189.91"
    --------服务器地址端口
    LOGIN_SERVER_PORT = 8012

    BOL_TEST_MODE = false
    IS_PASSWORD_LOGIN = true
    BOL_GM_CMD = true
    
    --币种 货币类型 USD	CNY	EUR	JPY
    MONEYTYPE = "USD"
end

--测试版本才会用到，登录的服务器列表
SERVER_LIST = 
{
-- { policy =  "18.217.242.44:8992", domain =  "18.217.242.44", port =  "8992"},  --正式服地址
 { policy =  LOGIN_SERVER_POLICY, domain =  LOGIN_SERVER_DOMAIN, port =  LOGIN_SERVER_PORT},  --默认服地址
 { policy =  "106.12.128.7:8992", domain =  "106.12.128.7", port =  "8992"},  --外服测试服地址
 { policy =  "192.168.1.181:8012", domain =  "192.168.1.181", port =  "8012"},  --默认服地址
}