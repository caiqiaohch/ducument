--例子1
MC_LIB_URL_EXAMPLE1 = { {PLIST_WAR2_URL, PLIST_XIANGXI_URL}, "tui/tui_mclib.xml", "cell_example1" }

--例子2
MC_LIB_URL_EXAMPLE2 = { {PLIST_WAR2_URL}, "tui/tui_mclib.xml", "cell_example1" }

--天梯排行榜Cell
MC_LIB_URL_RANKCELL = { {PLIST_LADDER_URL}, "tui/tui_mclib.xml", "cell_rankCell" }