require("app.gameconfig")
require("app.game_const")
require("app.plistUrl")
require("app.mclibUrl")
require("framework.init")
require("tui.extern")
require("tui.Cocos2d")
require("tui.Cocos2dConstants")
require("data.DataManager")
require ("ui.LoginWindow")
require("war2.war2Constants")
require("war2.war2FightScene")
require ("war2.war2FightReadyWnd")
require ("MainWnd.MainWindow")
require ("MainWnd.LogWindow")
require ("MainWnd.StoryWindow")
require ("MainWnd.PuzzleWindow")
require ("collectionWnd.CollectionWnd")
require ("collectionWnd.CollectionSellWnd")
require ("collectionWnd.CollectionYzWnd")
require ("collectionWnd.HeadWindow")

require ("xiangxi.CardXiangXi")
require ("Ladder.LadderRankWindow")
require ("fightWnd.FightWnd")
require ("fightWnd.FightWaitWindow")
require ("TaskWnd.TaskWindow")
require ("ui.FriendWnd")
require ("Shop.ShopGoodsWindow")
require ("charwnd.CharacterWindow")
require ("charwnd.CharacterHeadWindow")
require ("cocos.cocosdenshion.AudioEngine")
require ("EndGameWnd.EndGameWindow")
require ("setwnd.SetWindow")
require ("setwnd.MainSetWindow")
require ("setwnd.StaffWindow")
require ("openbox.OpenBoxWindow")
require ("openpack.OpenPackWindow")
require ("prompt.NewbieWindow")
require ("prompt.PromptWindow")
require ("TaskWnd.RewardWindow")
require ("TaskWnd.LadderRewardWindow")
require ("musicwnd.MusicWnd")
require ("arena.ArenaWindow")
require ("arena.ArenaEnterWindow")
require("net.ServMsgTransponder")
require("battlewnd.BattleWindow")
require("battlewnd.StoryBattleWindow")

require("app.fun")
require("app.SteamManager")
local socket = require "socket"

-- define global module
game_ui = {}
CurScene = nil
CurSceneList = {}

--Ҫpop�Ľ����б�
local mPopSceneList = {}
--�ϴ�pop�����ʱ�� �������С��λ
local mLastPopTimes = 0

function game_ui.startup()
    --������������
    collectgarbage("setpause", 100) 
    collectgarbage("setstepmul", 5000)
    --��������
    TuiManager:getInstance():setLanguage( LANGUAGE )
    --���볡��
    game_ui.enterMainScene()
end

function game_ui.exit()
    --cc.Director:getInstance():endToLua()
    device.showAlert("Confirm Exit", "Are you sure exit game ?", {"YES", "NO"}, function (event)  
        if event.buttonIndex == 1 then    
--            cc.Director:getInstance():endToLua() 
            if IS_STEAM_LOGIN == true then
                cc.Director:getInstance():endToLua() 
            else
                game_ui.openLog()
            end
        else
            device.cancelAlert()  --ȡ���Ի���
        end
    end)
end

function game_ui.openLog()
    --cc.Director:getInstance():endToLua()
    device.showAlert("Confirm Exit", "Are you sure exit game or open log?", {"exit", "log"}, function (event)  
        if event.buttonIndex == 1 then    
            cc.Director:getInstance():endToLua() 
        else
            if LogWindow.isOpen == false then --��log����
                LogWindow.isOpen = true
                RunScene("LogWindow")
            end     
        end
    end)
end

REGISTER_SCENE_FUNC = function(sceneName,constructFunc)
    CSceneManager:getInstance():registerSceneClassScriptFunc(sceneName,constructFunc)
end

--���س���
LoadScene = function(sceneName)
    return CSceneManager:getInstance():loadScene(sceneName)
end

--�л�����
replaceScene = function(sceneName)
    print("replaceScene   "..sceneName)
    require("framework.scheduler"):clearAllDelay()
    require ("Mov.MovManager"):instance():clearAll()
    local scene
    for i = 1, #CurSceneList do
        scene = CurSceneList[#CurSceneList]
        if scene ~= nil then
            scene:removeNodeEventListenersByEvent(cc.KEYPAD_EVENT)
            scene:setKeypadEnabled(false)
        end
    end
    CurSceneList = {}
    scene = LoadScene(sceneName)
    CSceneManager:getInstance():replaceScene(scene)
    scene:addNodeEventListener( cc.KEYPAD_EVENT, function (event)
        require ("keyboardEvent.keyboardManager"):instance():delKeyboardEvent(event)
    end )  
    scene:setKeypadEnabled(true)
    table.insert(CurSceneList, scene) 
    CurScene = scene
end

--���ӳ���
RunScene = function (sceneName)
    print("RunScene   "..sceneName)
    
    local scene = CurSceneList[#CurSceneList] --��ǰ���
    if scene ~= nil then
        local bol = false
        pcall(  function ()
                if sceneName == scene:getClassName() then
                    print( " scene is the same " )--��ͬһ�������Ͳ���runscene��
                    bol = true
                end
            end )
        if bol == true then return end
        scene:removeNodeEventListenersByEvent(cc.KEYPAD_EVENT)
        scene:setKeypadEnabled(false)
    end
    scene = LoadScene(sceneName)
    CSceneManager:getInstance():runUIScene(scene)

    scene:addNodeEventListener( cc.KEYPAD_EVENT, function (event)
        require ("keyboardEvent.keyboardManager"):instance():delKeyboardEvent(event)
    end )
    scene:setKeypadEnabled(true) 
    table.insert( CurSceneList, scene )
    CurScene = scene 
end

--�˳�����
PopScene2 = function(scene)
    print("PopScene   ")
    local tempScene = CurSceneList[#CurSceneList]
    if tempScene ~= nil and tempScene == scene then
        tempScene:removeNodeEventListenersByEvent(cc.KEYPAD_EVENT)
        tempScene:setKeypadEnabled(false)
        CurSceneList[#CurSceneList] = nil
    end
    CSceneManager:getInstance():popUIScene(scene)

    tempScene = CurSceneList[#CurSceneList]
    tempScene:addNodeEventListener( cc.KEYPAD_EVENT, function (event)
        require ("keyboardEvent.keyboardManager"):instance():delKeyboardEvent(event)
    end ) 
    tempScene:setKeypadEnabled(true) 
    CurScene = tempScene
end

--�Ƿ�ǰ���
IsTopScene = function(scene)
    return scene == CurSceneList[#CurSceneList]  
end

PopScene = function(scene)
    print("PopScene   ")    
    local curTime = socket.gettime()   
--    print(mLastPopTimes.." "..curTime)
    if curTime - mLastPopTimes > 0.1 then  --��Ϊ��ͬһ֡pop�������ײ�������⣨�ײ��m_lUISceneSwitchQueue������֡�ص�����CSceneManager::mainLoop�����ȥ��Ҫpop�Ľ��棩�����Ըĳɼ��0.1��popһ��
        if #mPopSceneList > 0 then
            table.insert(mPopSceneList, scene)
            scene = table.remove(mPopSceneList, 1)
            require("framework.scheduler").performWithDelayGlobal( function() PopScene(nil) end, 0.1 )
        end
    else
        table.insert(mPopSceneList, scene)
        require("framework.scheduler").performWithDelayGlobal( function() PopScene(nil) end, 0.1 )
        return
    end
    mLastPopTimes = curTime
    if scene == nil or tolua.isnull(scene) == true then return end

    local bolTop = false --�رյ��Ƿ񶥲�
    for i = 1, #CurSceneList do
        tempScene = CurSceneList[i]
        if tempScene ~= nil and tempScene == scene then
            if CurScene == tempScene then
                bolTop = true
            end
            tempScene:removeNodeEventListenersByEvent(cc.KEYPAD_EVENT)
            tempScene:setKeypadEnabled(false)
            table.remove( CurSceneList, i)
            break
        end
    end

    CSceneManager:getInstance():popUIScene(scene)
    if bolTop == true then
        tempScene = CurSceneList[#CurSceneList]  --��ǰ���
        tempScene:addNodeEventListener( cc.KEYPAD_EVENT, function (event)
            require ("keyboardEvent.keyboardManager"):instance():delKeyboardEvent(event)
        end ) 
        tempScene:setKeypadEnabled(true) 
        CurScene = tempScene
    end

--    display.removeUnusedTextures()
end

--�˳����г���
popAllScene = function ()
    CSceneManager:getInstance():popAllUIScene()
end

_G._scaleResolutionX = TuiManager:getInstance():getScaleResolutionX()
_G._scaleResolutionY = TuiManager:getInstance():getScaleResolutionY()
-- Arp
Arp = function(p)
    p.x = p.x * _G._scaleResolutionX
    p.y = p.y * _G._scaleResolutionY
    return p
end

function game_ui.enterMainScene()

    local DataManager = require("data.DataManager"):instance()
    DataManager:loadAll()
    require ("war2.war2CardManager"):instance():initEq()
    --��ʼ��
    require ("keyboardEvent.keyboardManager"):instance()

	REGISTER_SCENE_FUNC("LoginWindow",LoginWindow.create)
    REGISTER_SCENE_FUNC("war2FightScene",war2FightScene.create)
    REGISTER_SCENE_FUNC("war2FightReadyWnd",war2FightReadyWnd.create)
    REGISTER_SCENE_FUNC("MainWindow",MainWindow.create)
    REGISTER_SCENE_FUNC("StoryWindow",StoryWindow.create)
    REGISTER_SCENE_FUNC("PuzzleWindow",PuzzleWindow.create)
    REGISTER_SCENE_FUNC("CollectionWnd",CollectionWnd.create)
    REGISTER_SCENE_FUNC("CollectionYzWnd",CollectionYzWnd.create)
    REGISTER_SCENE_FUNC("CollectionSellWnd",CollectionSellWnd.create)
    REGISTER_SCENE_FUNC("HeadWindow",HeadWindow.create)
    REGISTER_SCENE_FUNC("CardXiangXi",CardXiangXi.create)
    REGISTER_SCENE_FUNC("LadderRankWindow",LadderRankWindow.create)
    REGISTER_SCENE_FUNC("FightWnd",FightWnd.create)
    REGISTER_SCENE_FUNC("PromptWindow",PromptWindow.create)

    REGISTER_SCENE_FUNC("FightWaitWindow",FightWaitWindow.create)
    REGISTER_SCENE_FUNC("TaskWindow",TaskWindow.create)
    REGISTER_SCENE_FUNC("EndGameWindow",EndGameWindow.create)
    REGISTER_SCENE_FUNC("SetWindow",SetWindow.create)
    REGISTER_SCENE_FUNC("MainSetWindow",MainSetWindow.create)
    REGISTER_SCENE_FUNC("StaffWindow",StaffWindow.create)

    REGISTER_SCENE_FUNC("ShopGoodsWindow",ShopGoodsWindow.create)
    REGISTER_SCENE_FUNC("CharacterWindow",CharacterWindow.create)    
    REGISTER_SCENE_FUNC("CharacterHeadWindow",CharacterHeadWindow.create)  
    REGISTER_SCENE_FUNC("OpenBoxWindow",OpenBoxWindow.create)
    REGISTER_SCENE_FUNC("OpenPackWindow",OpenPackWindow.create)
    REGISTER_SCENE_FUNC("LogWindow",LogWindow.create)
    REGISTER_SCENE_FUNC("NewbieWindow",NewbieWindow.create)
    REGISTER_SCENE_FUNC("RewardWindow",RewardWindow.create)
    REGISTER_SCENE_FUNC("LadderRewardWindow",LadderRewardWindow.create)    
    REGISTER_SCENE_FUNC("MusicWnd",MusicWnd.create)
    REGISTER_SCENE_FUNC("ArenaWindow",ArenaWindow.create)    
    REGISTER_SCENE_FUNC("ArenaEnterWindow",ArenaEnterWindow.create)    

    REGISTER_SCENE_FUNC("FriendWnd",FriendWnd.create)
    REGISTER_SCENE_FUNC("BattleWindow",BattleWindow.create)
    REGISTER_SCENE_FUNC("StoryBattleWindow",StoryBattleWindow.create)

    local scene = LoadScene("LoginWindow")
    CSceneManager:getInstance():runWithScene(scene)
    scene:setKeypadEnabled(true) 
    scene:addNodeEventListener( cc.KEYPAD_EVENT, function (event)
        require ("keyboardEvent.keyboardManager"):instance():delKeyboardEvent(event)
    end )  
    CurSceneList[1] = scene
    CurScene = scene


end




