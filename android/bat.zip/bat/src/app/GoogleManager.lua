local GoogleManager = class()-- 定义一个类 test 继承于 base_type

local luaj = require "cocos.cocos2d.luaj"
local socket = require "socket"

local mBolJava = false

local mLoginUserId

local mObbFilePath

function GoogleManager:ctor()

	print("GoogleManager:ctor --------------------------")
	
end

function GoogleManager:instance()
    local o = _G.GoogleManager
    if o then
    	return o
	end
 
    o = GoogleManager:new()
	_G.GoogleManager = o
    GoogleManager:init()
    return o
end


--登录成功回调
local function onCallBackLogin(msg)
    print(" onCallBackLogin "..msg)
    mLoginUserId = msg-- tonumber(msg)
    --回调处理
    if msg == "success" then
    end

    require("framework.scheduler").performWithDelayGlobal( 
    function() 
        LoginWindow:setTextName(mLoginUserId, "666666")
        LoginWindow:onLogin( 1 )
    end, 
    1 )

   
end

--支付回调
local function onCallBackPay(msg)
    print(" onCallBackPay "..msg)
--    mLoginUserId = tonumber(msg)
end

local mBolStar = false
--获取obb路径参数回调
local function onCallObbPath(pathStr)
    mObbFilePath = pathStr
    print(" onCallObbPath "..mObbFilePath.."  "..DEBUG_WRITEMSGURL)

--    GoogleManager:unObbFile() 

--        local t = Zip.ZipUtils:uncompressDir(mObbFilePath, cc.FileUtils:getInstance():getWritablePath().."dsf/")
--       if t == true then
--            print("uncompressDir success")
--        else
--           print("uncompressDir fail")  
--       end

--    local t = Zip.ZipUtils:uncompressDir("fightwnd.obb", DEBUG_WRITEMSGURL.."dsf/")
--    local t2 = Zip.ZipUtils:uncompressDir("D:/QuickGame2/QuickGame/res/fightwnd.obb", "D:/QuickGame2/QuickGame/res/dsf/")
--    mLoginUserId = tonumber(msg)
end

--解压obb文件
function GoogleManager:unObbFile()
    if io.exists(mObbFilePath) == true then
       print("obbFile is exists start uncompress")        
       print( cc.FileUtils:getInstance():getWritablePath() .. "dotdata/dotloader/"..SCRIPT_VERSION_ID.."/" )
       local t = Zip.ZipUtils:uncompressDir(mObbFilePath, cc.FileUtils:getInstance():getWritablePath() .. "dotdata/dotloader/"..SCRIPT_VERSION_ID.."/")
       if t == true then
            print("uncompressDir success")
            return true
        else
           print("uncompressDir fail")  
       end

    else
       print("obbFile is not exists")  
    end    
    return false
end

function GoogleManager:init()
    self:callJavaCallBackLua()
end

--定义java里面回调lua的函数
function GoogleManager:callJavaCallBackLua()
    if mBolJava == true then return end
    mBolJava = true
    local className = "org/cocos2dx/lua/AppActivity"
    local args = { "login", onCallBackLogin }
    local sigs = "(Ljava/lang/String;I)V"
    local ok = luaj.callStaticMethod(className,"callLoginMethod",args, sigs)


    className = "org/cocos2dx/lua/AppActivity"
    args = { "pay", onCallBackPay }
    sigs = "(Ljava/lang/String;I)V"
    ok = luaj.callStaticMethod(className,"callPayMethod",args)

    className = "org/cocos2dx/lua/AppActivity"
    args = { "obbPath", onCallObbPath }
    sigs = "(Ljava/lang/String;I)V"
    ok = luaj.callStaticMethod(className,"callObbPathMethod",args)    
end

--调用java函数,获取obb文件路径
function GoogleManager:getObbFilepath()
    print("getObbFileFullpath")
    local pathStr = ""
    local javaClassName = "org/cocos2dx/lua/AppActivity"
    local javaMethodName = "getObbFileFullpath"
    local javaParams = {}
    local javaMethodSig = "()Ljava/lang/String;"

    local ok = luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end


--调用java函数,登录平台
function GoogleManager:callJavaLogin()
    local javaClassName = "org/cocos2dx/lua/AppActivity"
    local javaMethodName = "googleLuaLogin"
    local javaParams = {}
    local javaMethodSig = "()V"

    luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

--调用java函数,购买
--googlePay(String orderId, String itemPId, String serverId, String userId, String userName, int userLv, string Extraparams) 
--Extraparams格式:物品ID加物品货币价格加物品货币类型(默认美元为1)item_id=300000&coin=100&coin_type=1
function GoogleManager:callJavaPay(orderId, itemPId, charId, userName, userLv, params)
    local javaClassName = "org/cocos2dx/lua/AppActivity"
    local javaMethodName = "googleLuaPay"
    local javaParams = {orderId, itemPId, "1", charId, userName, userLv, params}    
    print(orderId..","..itemPId..","..charId..","..userName..","..userLv..","..params)
    local javaMethodSig = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V"

    luaj.callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

--------------------java调用--------

return GoogleManager