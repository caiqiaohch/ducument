local SteamManager = class("SteamManager")
local socket = require "socket"

function SteamManager:ctor()

end

function SteamManager:instance()
     local o = _G.SteamManager
    if o then
    	return o
	end
 
    o = SteamManager:new()
	_G.SteamManager = o
    SteamManager:init()
    return o
end

function  SteamManager:init()

end

--支持的币种
local mSupCurrencyList = {"USD", "CNY", "RUB", "ARS"}

local steamParam = {}

--国家/地区
local mSteamCountry = "USA"
--币种
local mSteamCurrency = "USD" 

--是否在等待请求信息返回
local mBolWaiting = false
--上次请求信息发送的时间
local mLastSendTimes = 0
--最大等待请求信息时间(s)
local mMaxWaitingTimes = 30

function SteamManager:getBolWaiting()
    local curTime = math.ceil(socket.gettime())
    if curTime - mLastSendTimes > mMaxWaitingTimes then
        mBolWaiting = false
    end
    print(" mcurt "..curTime.. " "..mLastSendTimes)
    return mBolWaiting
end

function SteamManager:setBolWaiting(bol)
    mBolWaiting = bol
    mLastSendTimes = math.ceil(socket.gettime())
end

--接收PHP返回数据回调
function onSteamLoginRequestFinished(event)
    local ok = (event.name == "completed")
    local request = event.request 
    if not ok then
        -- 请求失败，显示错误代码和错误消息
        if request:getErrorMessage() ~= "" then
            print("request failed "..request:getErrorCode().." "..request:getErrorMessage())
            SteamManager:setBolWaiting(false)
        end
        return
    end
 
    local code = request:getResponseStatusCode()
    if code ~= 200 then
        -- 请求结束，但没有返回 200 响应代码
        print("code = "..code.." response"..request:getResponseString())    
        SteamManager:setBolWaiting(false)
        return
    end
 
    -- 请求成功，显示服务端返回的内容
    local response = request:getResponseString()
    local s = json.decode(response).response
    if s.params and tostring(s.params.steamid) == steam_GetPersonaID64() then  --收到的steamId与玩家的64位id一致
        print("connect finished")
--        text_name:setText("steam"..steam_GetAccountID())
        LoginWindow:checnkLogin()
    else
        require("prompt.PromptManager"):instance():SetNotice("Steam Log in error")
    end
    print("response "..response)
    
    SteamManager:setBolWaiting(false)
end



function SteamManager:steam_login()    
    if IS_STEAM_INIT == false then 
        local value  = steam_initSteamApp() 
        IS_STEAM_INIT = (value ~= nil and value ~= 0) --初始化未成功就提示并退出
    end
    if IS_STEAM_INIT == false then
        require("prompt.PromptManager"):instance():SetNotice("Steam must be running to play this game")
        return
    end
    print("SteamManager:steam_login()    ")
    local str = "?appid="..steam_GeSteamAppID().."&ticket="..steam_GetAuthTicket().."&steamMethod=AuthenticateUserTicket"
    local url = STEAM_PHP_URL.."getRequest.php"..str 
    local request = network.createHTTPRequest(onSteamLoginRequestFinished, url, "GET")
--    SteamManager:setBolWaiting(true)
    request:start()  
end



--接收PHP返回数据回调
local function onSteamBuyRequestFinished(event)
    local ok = (event.name == "completed")
    local request = event.request 
    if not ok then
        -- 请求失败，显示错误代码和错误消息
        if request:getErrorMessage() ~= "" then
            print("request failed "..request:getErrorCode().." "..request:getErrorMessage())  --getErrorCode 参考curl.h,28为请求超时
            SteamManager:setBolWaiting(false)
        end        
        return
    end
 
    local code = request:getResponseStatusCode()
    if code ~= 200 then
        -- 请求结束，但没有返回 200 响应代码
        print("code = "..code.." "..request:getResponseString())
        SteamManager:setBolWaiting(false)
        return
    end
 
    -- 请求成功，显示服务端返回的内容
    local response = request:getResponseString()
    print("onSteamBuyRequestFinished response "..response)
    SteamManager:setBolWaiting(false)
end

  
--购买steam物品 itemId, amount:物品的价格
function SteamManager:requestPhpForSteamBuy( itemData )
    local char = CharacterManager:getMainPlayer()

    local itemId 
    local description  --物品标题
    if itemData.ItemsID == nil or itemData.ItemsID == 0 then
        itemId = itemData.Gem
        description = itemId.." "..DataManager:getStringDataTxt(5003,true)
    else
        local item = ItemManager:getItemData( itemData.ItemsID  )
        itemId = itemData.ItemsID 
        description = item.item_name_id
    end
    local amount = itemData[mSteamCurrency] --物品的价格

    local url
    local fun
    local steamId = steam_GetPersonaID64()
    local str = ""

--    local url = "https://partner.steam-api.com/ISteamMicroTxnSandbox/InitTxn/v3/"
--    url = "https://partner.steam-api.com/ISteamMicroTxn/InitTxn/v3/"
    url = STEAM_PHP_URL.."InitTxn.php"
    local request = network.createHTTPRequest(onSteamBuyRequestFinished, url, "POST")
    request:addRequestHeader("Content-Type: application/x-www-form-urlencoded")
    request:addRequestHeader("Accept: application/json")
    request:addRequestHeader("Accept-Language: en_US")
    local orderid = math.ceil(socket.gettime())--math.random() * 100000	
    print("steamId "..steamId.." "..tostring(steamId).." orderid "..orderid)
    request:addPOSTValue("username", char.accounts)
    request:addPOSTValue("role_id", char.CharID)
    request:addPOSTValue("ipaddress", "82.163.143.176")
    
    request:addPOSTValue("orderid", orderid)
    request:addPOSTValue("steamid", steamId)
    request:addPOSTValue("appid", steam_GeSteamAppID())
    request:addPOSTValue("itemcount", "1")
    request:addPOSTValue("language", "en_US")--steam_GetSteamUILanguage())
    request:addPOSTValue("currency", mSteamCurrency)
    request:addPOSTValue("itemid[0]", itemId)
    request:addPOSTValue("qty[0]", "1")
    request:addPOSTValue("amount[0]", amount)
    request:addPOSTValue("description[0]", description)

    SteamManager:setBolWaiting(true)
    steamParam.orderid = orderid
    steamParam.itemId = itemId
    request:start()  
end


--接收PHP返回数据回调
local function onSteamBuyFinal(event)
    local ok = (event.name == "completed")
    local request = event.request 
    if not ok then
        -- 请求失败，显示错误代码和错误消息
        if request:getErrorMessage() ~= "" then
            print("request failed "..request:getErrorCode().." "..request:getErrorMessage())
            SteamManager:setBolWaiting(false)
        end
        return
    end
 
    local code = request:getResponseStatusCode()
    if code ~= 200 then
        -- 请求结束，但没有返回 200 响应代码
        print("code = "..code)
        SteamManager:setBolWaiting(false)
        return
    end
 
    -- 请求成功，显示服务端返回的内容
    local response = request:getResponseString()
    print("onSteamBuyFinal response "..response)
    SteamManager:setBolWaiting(false)

    ServMsgTransponder:SMTShopBuy2( steamParam.orderid, steamParam.itemId, 1 )
    steamParam = {}
end


function steam_sendBuyMsg(bolOk)
--    print("response "..buyMsg)
    if bolOk == true then
        local char = CharacterManager:getMainPlayer()
        local url = STEAM_PHP_URL.."FinalizeTxn.php"
        local request = network.createHTTPRequest(onSteamBuyFinal, url, "POST")
        request:addRequestHeader("Content-Type: application/x-www-form-urlencoded")
        request:addRequestHeader("Accept: application/json")
        request:addRequestHeader("Accept-Language: en_US")

        request:addPOSTValue("username", char.accounts)
    
        request:addPOSTValue("appid", steam_GeSteamAppID())
        request:addPOSTValue("orderid", steamParam.orderid)
        request:addPOSTValue("role_id", char.CharID)
        request:addPOSTValue("itemid[0]", steamParam.itemId)
        SteamManager:setBolWaiting(true)
        request:start()  
    else
--        require("prompt.PromptManager"):instance():SetNotice("cancle")
        print("steam_sendBuyMsg cancle")
        steamParam = {}
    end
--    steamParam = {}
    if true then return end
--    local s = json.decode(buyMsg).response
--    if s.params and s.result and s.result == "OK" then --tonumber(s.params.steamid) == steam_GetPersonaID64() then  --收到的steamId与玩家的64位id一致
--        print("steam_sendBuyMsg "..tostring(s.params.orderid).." , "..tostring(s.params.transid))

--        local char = CharacterManager:getMainPlayer()

--    local url
--    local fun
--    local orderid
--    local steamId = steam_GetPersonaID64()
--    local str = ""-- "?key=6E3F99905CA1D9DF9BF1E7099BE8884C&orderid="..orderid.."&steamid="..steamId.."&appid=867420&itemcount=1&language=en_US&currency=USD&itemid[0]=200&qty[0]=1&amount[0]=1&description[0]=Hat decoration description"

--    local url = STEAM_PHP_URL.."FinalizeTxn.php"
--    local request = network.createHTTPRequest(onSteamBuyFinal, url, "POST")
--    request:addRequestHeader("Content-Type: application/x-www-form-urlencoded")
--    request:addRequestHeader("Accept: application/json")
--    request:addRequestHeader("Accept-Language: en_US")

--    request:addPOSTValue("username", char.Name)

--    request:addPOSTValue("orderid", s.params.orderid)
--    request:addPOSTValue("role_id", char.CharID)
--    request:addPOSTValue("itemid[0]", "200")
----    request:addPOSTValue("appid", steam_GeSteamAppID())

--    request:start()  
--    else
--        require("prompt.PromptManager"):instance():SetNotice("Steam net in error")
--    end
--    print("response "..response)
end



----向后台发送登录HTTP请求 ptype:1:登录 2:注册
--local function requestPhp( ptype, name, password)
--    local url = "https://partner.steam-api.com/ISteamMicroTxn/GetUserInfo/v2/?";..str  --反正只有182.61.31.95有,先写死吧...
--    local request = network.createHTTPRequest(fun, url, "GET")
--    request:start()  
--end


local function onSteamUserInfoRequestFinished(event)
    local ok = (event.name == "completed")
    local request = event.request 
    if not ok then
        -- 请求失败，显示错误代码和错误消息
        if request:getErrorMessage() ~= "" then
            print("request failed "..request:getErrorCode().." "..request:getErrorMessage())
--            SteamManager:setBolWaiting(false)
        end
        return
    end
 
    local code = request:getResponseStatusCode()
    if code ~= 200 then
        -- 请求结束，但没有返回 200 响应代码
        print("code = "..code.." response"..request:getResponseString())    
--        SteamManager:setBolWaiting(false)
        return
    end
 
    -- 请求成功，显示服务端返回的内容
    local response = request:getResponseString()
    local s = json.decode(response).response
    if s.params then
        if s.params.country then 
            mSteamCountry = s.params.country
        end
        if s.params.currency then 
            mSteamCurrency = s.params.currency  --币种
        end
    end
    if table.indexof(mSupCurrencyList, mSteamCurrency) == false then
        mSteamCurrency = "USD"
    end
    MONEYTYPE = mSteamCurrency  --重新设置货币
    print("response "..response)
    print("steam_GetSteamUILanguage() "..steam_GetSteamUILanguage())
--    SteamManager:setBolWaiting(false)
end

function SteamManager:requsetUserInfo()
    local str = "?steamid="..steam_GetPersonaID64().."&steamMethod=GetUserInfo"
    local url = STEAM_PHP_URL.."getRequest.php"..str 
    local request = network.createHTTPRequest(onSteamUserInfoRequestFinished, url, "GET")
--    SteamManager:setBolWaiting(true)
    request:start()  
end

--获取已完成成就ID列表
function SteamManager:setAchievement()
    local list = {}
    for k, v in pairs(DataManager.DataAchieveSteam) do
        if TaskManager:getAchFinished( tonumber(k) ) == true then
            if v == 0 then
                steam_RunSetAchievement("ACHIEVEMENT"..k)
                print("ACHIEVEMENT"..k)
            end
            DataManager.DataAchieveSteam[k] = 1
        end
    end
end

--是否是在steam测试版本客户端
function SteamManager:getBolBeta()
    local bol  = steam_GetCurrentBetaName()
    return bol
end

function testLua()
    print("testlua")
end

function testLua2(a, b)
    print("testlua aa  "..a..","..b)
end

function SteamManager.testLua3()
    print("testlua3 abbbba ")
end

function SteamManager:testLua4(a, b)
    print("testlua aa  "..a..","..b)
end
return SteamManager