------------战场相关
PLIST_WAR2_URL = "war2/war2.plist"

------------卡牌相关
--卡牌通用配件
PLIST_CARDUI_URL = "war2/CardUI.plist"
--卡牌标记
PLIST_WAR2CARDSG_URL = "war2/war2CardSign.plist"
--大卡牌配件1
PLIST_CARDBIGUI1_URL = "war2/CardBig1.plist"
--大卡牌配件2
PLIST_CARDBIGUI2_URL = "war2/CardBig2.plist"
--大卡牌配件3
PLIST_CARDBIGUI3_URL = "war2/CardBig3.plist"
--大卡牌配件4
PLIST_CARDBIGUI4_URL = "war2/CardBig4.plist"
--大卡牌配件5
PLIST_CARDBIGUI5_URL = "war2/CardBig5.plist"
--中卡牌配件
PLIST_CARDMIDDLEUI_URL = "war2/CardMiddle.plist"

------------圣物相关
PLIST_WAR2EQ_URL = "war2/war2Eq.plist"

------------主界面相关
PLIST_MAIN_URL = "mainwnd/mainwnd.plist"

------------登录界面相关
PLIST_LOGIN = "login/Login.plist"

------------卡牌详细界面相关
PLIST_XIANGXI_URL = "xiangxi/xiangxi.plist"

------------收藏界面相关
PLIST_COLLECT_URL = "collectionwnd/collectionwnd.plist"

------------天梯界面相关
PLIST_LADDER_URL = "ladder/ladder.plist"

------------玩家信息界面相关
PLIST_CHARWND_URL = "charwnd/charwnd.plist"

------------任务界面相关
PLIST_TASK_URL = "taskwnd/taskwnd.plist"

------------战斗结束界面相关
PLIST_ENDGAME_URL = "endgamewnd/endgamewnd.plist"

------------开包界面相关
PLIST_OPENPACK_URL = "openpack/openpack.plist"

-------新手教程相关
PLIST_NEWBIE_URL = "newbie/newbie.plist"

-------剧情界面相关
PLIST_STORY_URL = "story/story.plist"

-------解密界面相关
PLIST_PUZZLE_URL = "puzzle/puzzle.plist"

------------任务界面相关
PLIST_FIGHTWND_URL = "fightwnd/fightwnd.plist"

------------任务界面相关
PLIST_FRIEND_URL = "friend/friend.plist"

------------竞技场界面相关
PLIST_ARENA_URL = "Arena/arena.plist"

------------对战界面相关
PLIST_BATTLEWND_URL = "battlewnd/battlewnd.plist"