require "tagMap.Tag_endgamewnd"
--主角头像
local mImgMainHead = nil
local mProgress = nil
--经验值文本
local mTxtExpNum = nil
--经验值图片
local mImgExpNum = nil
--等级文本
local mTxtLVNum
--天梯积分上限
local mTarHonorNum = 0

--天梯图标
local mImgRankIcon = nil 

--
local mLayoutEndturn
local mLayoutEndturnPos 

--显示状态 0:界面打开, 1:显示经验值 2:显示经验值进度完毕 3:显示天梯积分 4:显示天梯积分完毕,可以关闭
local mShowState = 0


--计时器
local mGolalTimer
--计时器运行的秒数 为nil这计时器不执行回调
local mGolalTimes = 0

--胜利或失败结果背景特效
local mResultEffect
--胜利或失败背景图
local victoryBackground

--天梯图标效果
local mRankIconEffect

--进度条为满时执行的回调函数,经验值执行的是updataUserExp, 天梯积分执行的是updataUserLadder
local updataUserExp_V

--当前进度条的进度等级
local userLV = 0
--当前天梯数值
local userEXP = 0
--天梯数值增加的值
local userADDEXP = 0
--天梯各阶段最大值数组
local userLVEXPArray = nil


--进度条
local expProgressBar
--进度条每次回调的数值列表
local expTTFString = {}
--进度条回调的当前执行次数
local expTTFStringIndex = 1
--进度条的总需要执行的回调次数
local expAnimationTime = 10
--进度条开始数值(百分比)
local expProgressStart = 0
--进度条最终数值(百分比)
local expProgressStop = 100

--保存的action列表
local mActionList = {}

--是否已经点击了关闭
local bolClose = false

local mBolPlaying = false

local ServMsgTransponder = require("net.ServMsgTransponder")
local OpenBoxManager = require("openbox.OpenBoxManager"):instance()
local DataManager = require("data.DataManager"):instance()
local war2CardManager = require("war2.war2CardManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()

EndGameWindow = class("EndGameWindow",function()
	return TuiBase:create()
end)

EndGameWindow.mWin = false

EndGameWindow.isShow = false

local __instance = nil

--要预加载的资源列表
local resArr = { PLIST_ENDGAME_URL }

function EndGameWindow:create()
	local ret = EndGameWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function EndGameWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function EndGameWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end



--node运行runAction,把相关action保存到mActionList中
local function runNodeAction( node, act, list )
    if list == nil then list = mActionList end
    table.insert(list, act)
    node:runAction(act)
end

local function closeVictoryUI()
    if tolua.isnull(victoryBackground) == true then return end
    local vbFT = cc.FadeOut:create(0.5)
    local vbST = cc.ScaleTo:create(0.5, 1.5)
    local vbCO = cc.Spawn:create(vbFT, vbST)
    local vbRM = cc.RemoveSelf:create()
    local vbQU = cc.Sequence:create(vbCO, vbRM)
    runNodeAction(victoryBackground, vbQU)
--    initReward()
--    local bgFlower = dialogueUISprite:getChildByName("bgFlower")
--    local bgFT = vbFT:clone()
--    local bgRM = vbRM:clone()
--    local bgQU = cc.Sequence:create(bgFT, bgRM)
--    bgFlower:runAction(bgQU)
end

--根据荣耀值获取天梯积分信息
local function getRankValue( honour ) 
    local rankList = DataManager:getDataRank()
    local rankData1
    local rankData2
    for i=1, #rankList do        
        if rankList[i] then
            if rankList[i].integral >= honour then
                rankData2 = rankList[i]
                break
            else
                rankData1 = rankList[i]
            end
        end      
    end

    local minValue = 0
    if rankData1 then
        minValue = rankData1.integral
    end
    local maxValue = rankData2.integral

    local rankValue = (honour - minValue) / (maxValue - minValue) * 100     
    return {rankData = rankData2, rankValue = rankValue}
end

local function initUserExp()--计算经验与天梯数值
    print("initUserExp")
    local i = 1
    while userEXP >= userLVEXPArray[i] do
        userLV = i
        i = i + 1
    end 
    expProgressStart = (userEXP - userLVEXPArray[userLV]) / (userLVEXPArray[i] - userLVEXPArray[userLV]) * 100
    
    local maxTTFString = userEXP + userADDEXP
    if userADDEXP > 0 then
        if maxTTFString > userLVEXPArray[i] then
            maxTTFString = userLVEXPArray[i]
            expProgressStop = 100
        else
            expProgressStop = (maxTTFString - userLVEXPArray[userLV]) / (userLVEXPArray[i] - userLVEXPArray[userLV]) * 100
        end
    else
        if maxTTFString < userLVEXPArray[userLV] then
            maxTTFString = userLVEXPArray[userLV]
            expProgressStop = 0
        else
            expProgressStop = (maxTTFString - userLVEXPArray[userLV]) / (userLVEXPArray[i] - userLVEXPArray[userLV]) * 100
        end
    end
    
    
    local testAT = math.abs(maxTTFString - userEXP)
    local perADD = 0
    local per = 0
    if testAT < expAnimationTime then
        expAnimationTime = testAT
        perADD = 1
    else
        perADD, per = math.modf(testAT / expAnimationTime)--testAT / expAnimationTime
    end
    if userADDEXP < 0 then
        perADD = perADD * -1
    end
    
    for j = 1 , (expAnimationTime - 1), 1 do
        expTTFString[j] = userEXP + perADD * j
        print(expTTFString[j])
    end 
    if expAnimationTime == 0 then expAnimationTime = 1 end
    expTTFString[expAnimationTime] = maxTTFString
    expTTFStringIndex = 1
end

local function playProgressLeaveEffect()
    local exDT = cc.DelayTime:create(1)
    local exMT = cc.EaseCubicActionInOut:create(cc.MoveBy:create(0.5, cc.p(-1005, 0)))
    local exCB = cc.CallFunc:create( EndGameWindow.updateState )
--        local exRO = cc.RemoveSelf:create()
    local exAnimationQuence = cc.Sequence:create(exDT, exMT, exCB)--, exRO)
    runNodeAction(mLayoutEndturn, exAnimationQuence)   
end

-----------------------------------------------天梯积分处理 start-------------------------------------------

local function showLadderIcon()--天梯升级图标显示
    print("showLadderIcon "..iconHonour)
    local char = CharacterManager:getMainPlayer()
    local rankObj 
    if mShowState == 4   then
        rankObj = getRankValue( char.CharHonour )
    else
        rankObj = getRankValue( iconHonour )
    end
--    rankObj = getRankValue( iconHonour )
    mImgRankIcon:setTexture("other/rankIcon/"..rankObj.rankData.icon..".png")
--    runNodeAction(mImgRankIcon, cc.Show:create())
    mImgRankIcon:runAction(cc.Show:create())
    mBolPlaying = false
--    ladderEnd()
end
local function playIconEffect(lvMOD)--天梯升级动画播放
    mBolPlaying = true
    lvMOD = lvMOD + 1
    local rankList = DataManager:getDataRank()
    local char = CharacterManager:getMainPlayer()
    local effId 
    local oldRankObj = getRankValue( char.OldCharHonour )
    local rankObj = getRankValue( char.CharHonour )
       

--    local oldValue = mTxtLVNum:setString(tostring(userEXP).." / "..tostring(userLVEXPArray[(userLV + 1)]))
--    userLVEXPArray[userLV]
    local curuserLv
    if userADDEXP > 0 then
        effectID = {100879, 100872, 100875, 100878 }
    else
        effectID = {100874, 100882, 100881, 100880 } 
    end

    local oldRankObj = getRankValue( iconHonour )
    local rankObj = getRankValue( expTTFString[expAnimationTime] )
    iconHonour = expTTFString[expAnimationTime]
    effId = effectID[lvMOD]
    print(effectID[lvMOD])
    local img = cc.Sprite:create("other/rankIcon/"..oldRankObj.rankData.icon..".png")
    local tx2d = img:getTexture()

    img = cc.Sprite:create("other/rankIcon/"..rankObj.rankData.icon..".png")
    local tx2d2 = img:getTexture()

    local diy
--    if rankObj.rankData.rank_id < oldRankObj.rankData.rank_id and rankObj.rankData.rank_lv2 < oldRankObj.rankData.rank_lv2 then --天梯星数降级的特效两个texture的顺序不一样
--        diy = TextureManager:getDiyEffect(effId, {tx2d2, tx2d})
--    else
--        diy = TextureManager:getDiyEffect(effId, {tx2d, tx2d2})
--    end
    diy = TextureManager:getDiyEffect(effId, {tx2d, tx2d2})
    local pos = {}
    pos.x = mImgRankIcon:getPositionX() + mLayoutEndturn:getPositionX() - mLayoutEndturn:getContentSize().width * 0.5
    pos.y = mImgRankIcon:getPositionY() + mLayoutEndturn:getPositionY() - mLayoutEndturn:getContentSize().height * 0.5
    mRankIconEffect = EffectManager:createHnyEffect( effId , pos, nil, diy ) 
    window:addChild(mRankIconEffect, 999)
    EffectManager:startHnyEffect( mRankIconEffect,{key = showLadderIcon} )
end


local function updataLadderIcon()--天梯升级界面更新
    --print("updataLadderIcon")
    
    local perTime = 1 / expAnimationTime
    local updataTime = expAnimationTime * perTime
    expProgressBar:setPercentage(expProgressStart)
    
    mTxtLVNum:setString(tostring(userEXP).." / "..tostring(userLVEXPArray[(userLV + 1)]))
    
    local epDT = cc.DelayTime:create(0.5)
    local epPT = cc.ProgressTo:create(updataTime, expProgressStop)
    local epAnimationQuence = cc.Sequence:create(epDT, epPT)
    runNodeAction(expProgressBar, epAnimationQuence)

    local eiDT = epDT:clone()
    local eiDT2 = cc.DelayTime:create(perTime * 0.5)
    local eiCF = cc.CallFunc:create(updataUserExp_V)
    local eiDT3 = cc.DelayTime:create(perTime * 0.5)
    local reAQ = cc.Sequence:create(eiDT2, eiCF, eiDT3)
    local eiRE = cc.Repeat:create(reAQ, expAnimationTime)
    local eiAnimationQuence = cc.Sequence:create(eiDT, eiRE)
    runNodeAction(mTxtLVNum, eiAnimationQuence)

    mImgRankIcon:setScale(0.45)
    runNodeAction(mImgRankIcon, cc.Hide:create())

    if userLV > 3 then
        local lvM = userLV % 4
        playIconEffect(lvM, userEXP)
    else
        playIconEffect(userLV, userEXP)
    end 
end

local function updataUserLadder()--更新天梯数值，检查是否升级和动效完成经验界面飞出
    --print("updataUserLadder")
    mTxtLVNum:setString(tostring(expTTFString[expTTFStringIndex]).." / "..tostring(userLVEXPArray[(userLV + 1)]))
    expTTFStringIndex = expTTFStringIndex + 1
    
    if expTTFStringIndex > expAnimationTime then
        if (userEXP + userADDEXP) ~= expTTFString[expAnimationTime] then
            userADDEXP = userADDEXP - (expTTFString[expAnimationTime] - userEXP)
            userEXP = expTTFString[expAnimationTime]
            if userADDEXP < 0 then
                userEXP = userEXP - 1
            end
            initUserExp()
            local exDT = cc.DelayTime:create(0.5)
            local exCF = cc.CallFunc:create(updataLadderIcon)
            local exAnimationQuence = cc.Sequence:create(exDT, exCF)
            runNodeAction(mLayoutEndturn, exAnimationQuence)
        else
--            ladderEnd()
--            showLadderIcon()
            EndGameWindow:updateState()
        end
    end
end

local function startLadderUI()--天梯进度进入
    --print("fromExpToLadder")
    mShowState = 3
    local char = CharacterManager:getMainPlayer()
    userEXP = char.OldCharHonour
    userADDEXP = char.CharHonour - char.OldCharHonour

--    userEXP = 1100
--    userADDEXP = 100
    userLVEXPArray = DataManager:getDataLvRankArr()--{0,99,199,349,499,599,699,849,999,1199,1399,1699,1999,2249,2499,2749,2999,3249,3499,3749,3999,4249,4499,4749,4999,5249,5499,5749}
    expTTFStringIndex = 1
    expAnimationTime = 10
    expTTFString = {}
    initUserExp()

    local rankObj = getRankValue( char.CharHonour )
    mTarHonorNum = rankObj.rankData.integral
    
    mTxtExpNum:setVisible(false)
    mImgExpNum:setVisible(false)

--    mImgRankIcon:setScale(0.45)
--    runNodeAction(mImgRankIcon, cc.Hide:create())

    local rankObj = getRankValue( char.OldCharHonour )
    iconHonour = char.OldCharHonour
    mImgRankIcon:setTexture("other/rankIcon/"..rankObj.rankData.icon..".png")

    mLayoutEndturn:setPositionX(mLayoutEndturnPos.x + 1200)
    local exDT = cc.DelayTime:create(0.1)
    local exMT = cc.EaseCubicActionInOut:create(cc.MoveTo:create(0.5, mLayoutEndturnPos))
    local exAnimationQuence = cc.Sequence:create(exDT, exMT)
    runNodeAction(mLayoutEndturn, exAnimationQuence)

    updataUserExp_V = updataUserLadder

    expProgressBar:setPercentage(expProgressStart)
    local perTime = 1 / expAnimationTime
    local updataTime = expAnimationTime * perTime
    
    local epDT = cc.DelayTime:create(1)
    local epPT = cc.ProgressTo:create(updataTime, expProgressStop)
    local epAnimationQuence = cc.Sequence:create(epDT, epPT)
    runNodeAction(expProgressBar, epAnimationQuence)
    
    local eiDT = epDT:clone()
    local eiDT2 = cc.DelayTime:create(perTime * 0.5)
    local eiCF = cc.CallFunc:create(updataUserLadder)
    local eiDT3 = cc.DelayTime:create(perTime * 0.5)
    local reAQ = cc.Sequence:create(eiDT2, eiCF, eiDT3)
    local eiRE = cc.Repeat:create(reAQ, expAnimationTime)
    local eiAnimationQuence = cc.Sequence:create(eiDT, eiRE)
    runNodeAction(mTxtLVNum, eiAnimationQuence)
--    mTxtLVNum:setString(tostring(expTTFString[expTTFStringIndex]).." / "..tostring(userLVEXPArray[(userLV + 1)]))
    mTxtLVNum:setString(char.OldCharHonour.." / "..tostring(userLVEXPArray[(userLV + 1)]))
    
    local lvUPADD = expTTFString[expAnimationTime] - userEXP
    local addString = "+"
    if userADDEXP < 0 then
        addString = ""
    end
    local expLVUP = cc.LabelBMFont:create(addString..tostring(userADDEXP), "fonts/labBmf_BitFont+06.fnt")
    expLVUP:setPosition(mTxtLVNum:getPositionX() + mTxtLVNum:getContentSize().width * 0.5, mTxtLVNum:getPositionY())
    expLVUP:setOpacity(0)
    mTxtLVNum:getParent():addChild(expLVUP, 1)
    
    local elDT = epDT:clone()
    local elMB = cc.EaseQuadraticActionOut:create(cc.MoveBy:create(1, cc.p(0, 40)))
    local elFI = cc.FadeIn:create(0.5)
    local elFO = cc.FadeOut:create(0.5)
    local elFQuence = cc.Sequence:create(elFI, elFO)
    local elSP = cc.Spawn:create(elMB, elFQuence)
    local elRE = cc.RemoveSelf:create()
    local elAnimationQuence = cc.Sequence:create(elDT, elSP, elRE)
--    runNodeAction(expLVUP, elAnimationQuence)
    expLVUP:runAction(elAnimationQuence)
end

-----------------------------------------------天梯积分处理 end-------------------------------------------


-----------------------------------------------经验值处理 start-------------------------------------------
local function updataExpLV()--升级和更新进度条
    print("updataExpP")   
    local updataTime = expAnimationTime * 0.1
    expProgressBar:setPercentage(expProgressStart)
    
    local expLV = cc.LabelBMFont:create("Lv."..tostring(userLV), "fonts/labBmf_BitFont+06.fnt")
    expLV:setPosition(mTxtLVNum:getPositionX() + mTxtLVNum:getContentSize().width * 0.5, mTxtLVNum:getPositionY())
    expLV:setName("expLV")
    mTxtLVNum:getParent():addChild(expLV, 1)

    mTxtLVNum:setString("Lv."..tostring(userLV))
    
    local elMB = cc.MoveBy:create(0.5, cc.p(0, 40))
    local elFO = cc.FadeOut:create(0.5)
    local elSP = cc.Spawn:create(elMB, elFO)
    local elRE = cc.RemoveSelf:create()
    local elAnimationQuence = cc.Sequence:create(elSP, elRE)
--    runNodeAction(expLV, elAnimationQuence)
    expLV:runAction(elAnimationQuence)

    local epDT = cc.DelayTime:create(0.5)
    local epPT = cc.ProgressTo:create(updataTime, expProgressStop)
    local epAnimationQuence = cc.Sequence:create(epDT, epPT)
    runNodeAction(expProgressBar, epAnimationQuence)

    local eiDT = epDT:clone()
    local eiDT2 = cc.ScaleTo:create(0.05, 1.1)
    local eiCF = cc.CallFunc:create(updataUserExp_V)
    local eiDT3 = cc.ScaleTo:create(0.05, 1)
    local reAQ = cc.Sequence:create(eiDT2, eiCF, eiDT3)
    local eiRE = cc.Repeat:create(reAQ, expAnimationTime)
    local eiAnimationQuence = cc.Sequence:create(eiDT, eiRE)
    runNodeAction(mTxtExpNum, eiAnimationQuence)
end

local function updataUserExp()--更新经验数值，检查是否升级和动效完成经验界面飞出
    --print("updataUserExp")
    mTxtExpNum:setString(tostring(expTTFString[expTTFStringIndex]))
    expTTFStringIndex = expTTFStringIndex + 1
    
    if expTTFStringIndex > expAnimationTime then
        if (userEXP + userADDEXP) > expTTFString[expAnimationTime] then
            userADDEXP = userADDEXP - (expTTFString[expAnimationTime] - userEXP)
            userEXP = expTTFString[expAnimationTime]
            initUserExp()
            local exDT = cc.DelayTime:create(0.5)
            local exCF = cc.CallFunc:create(updataExpLV)
            local exAnimationQuence = cc.Sequence:create(exDT, exCF)
            runNodeAction(mLayoutEndturn, exAnimationQuence)
        else
--            local exDT = cc.DelayTime:create(1)
--            local exMT = cc.EaseCubicActionInOut:create(cc.MoveBy:create(0.5, cc.p(-1005, 0)))
--            local exCB = cc.CallFunc:create( EndGameWindow.updateState )  --进入天梯积分进度计算
--            local exRO = cc.RemoveSelf:create()
--            local exAnimationQuence = cc.Sequence:create(exDT, exMT, exCB)--, exRO)
--            mLayoutEndturn:runAction(exAnimationQuence)
            mShowState = 2
            playProgressLeaveEffect()
        end
    end
end


local function initExpProgress()--经验界面进入
    mShowState = 1
    userLVEXPArray = DataManager:getDataLvExpArr()--{100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000}
    
    local char = CharacterManager:getMainPlayer()
--    char.OldCharExp = 5056 
--    char.CharExp = 2100
--    char.OldCharLevel = 12
    local oexp = DataManager.DataLvExpArr[ char.OldCharLevel ]
    local nexp = DataManager.DataLvExpArr[ char.CharLevel ] 
    userEXP = char.OldCharExp
    userADDEXP = char.CharExp  - char.OldCharExp + DataManager:getExp( char.CharLevel ) - DataManager:getExp( char.OldCharLevel )
    userEXP = char.OldCharExp + oexp
    userADDEXP = char.CharExp + nexp - userEXP
--        userEXP = 355
--    userADDEXP = 120
    expTTFStringIndex = 0
    expAnimationTime = 10
    initUserExp()

    mProgress:setVisible(false)
    
    local expBG = cc.Sprite:create()
    expBG:setSpriteFrame("endgamewnd/prog_EX+progress_bg.png")
    expBG:setPosition(285, 32)
    expBG:setName("expBG")
    mLayoutEndturn:addChild(expBG, -2)

    local proSP = cc.Sprite:create("effect/Particle/Par00327.png")
    expProgressBar = cc.ProgressTimer:create(proSP)
    expProgressBar:setType(cc.PROGRESS_TIMER_TYPE_BAR)
    expProgressBar:setMidpoint(cc.p(0, 0.5))
    expProgressBar:setBarChangeRate(cc.p(1, 0))
    expProgressBar:setPercentage(expProgressStart)
    expProgressBar:setPosition(283, 32)
    mLayoutEndturn:addChild(expProgressBar, -1)

    mLayoutEndturnPos = { x = mLayoutEndturn:getPositionX(), y =  mLayoutEndturn:getPositionY() }
    mLayoutEndturn:setPositionX(mLayoutEndturnPos.x + 1200)
    local exDT = cc.DelayTime:create(0.1)
    local exMT = cc.EaseCubicActionInOut:create(cc.MoveTo:create(0.5, mLayoutEndturnPos))
    local exAnimationQuence = cc.Sequence:create(exDT, exMT)
    runNodeAction(mLayoutEndturn, exAnimationQuence)

    updataUserExp_V = updataUserExp
    local updataTime = expAnimationTime * (1 / expAnimationTime)
    
    local epDT = cc.DelayTime:create(1)
    local epPT = cc.ProgressTo:create(updataTime, expProgressStop)
    local epAnimationQuence = cc.Sequence:create(epDT, epPT)
    runNodeAction(expProgressBar, epAnimationQuence)

    local addString = "+"
    if userADDEXP < 0 then
        addString = ""
    end
    local expLVUP = cc.LabelBMFont:create(addString..tostring(userADDEXP), "fonts/labBmf_BitFont+01.fnt")
    expLVUP:setPosition(mTxtExpNum:getPositionX() + mTxtExpNum:getContentSize().width * 0.5, mTxtExpNum:getPositionY())
    expLVUP:setOpacity(0)
    mTxtExpNum:getParent():addChild(expLVUP, 1)
    local elDT = epDT:clone()
    local elMB = cc.EaseQuadraticActionOut:create(cc.MoveBy:create(1, cc.p(0, 40)))
    local elFI = cc.FadeIn:create(0.5)
    local elFO = cc.FadeOut:create(0.5)
    local elFQuence = cc.Sequence:create(elFI, elFO)
    local elSP = cc.Spawn:create(elMB, elFQuence)
    local elRE = cc.RemoveSelf:create()
    local elAnimationQuence = cc.Sequence:create(elDT, elSP, elRE)
--    runNodeAction(expLVUP, elAnimationQuence)
    expLVUP:runAction(elAnimationQuence)

    local eiDT = epDT:clone()
    local eiDT2 = cc.ScaleTo:create(0.05, 1.1)
    local eiCF = cc.CallFunc:create(updataUserExp)
    local eiDT3 = cc.ScaleTo:create(0.05, 1)
    local reAQ = cc.Sequence:create(eiDT2, eiCF, eiDT3)
    local eiRE = cc.Repeat:create(reAQ, expAnimationTime)
    local eiAnimationQuence = cc.Sequence:create(eiDT, eiRE)
    runNodeAction(mTxtExpNum, eiAnimationQuence)
    mTxtExpNum:setString(tostring(expTTFString[expTTFStringIndex]))

    mTxtLVNum:setString("Lv."..tostring(userLV))
end
-----------------------------------------------经验值处理 start-------------------------------------------



--播放界面打开动态效果
local function playOpenEffect()
    if EndGameWindow.mWin == true then
        victoryBackground = cc.Sprite:create("effect/Particle/Par00298.png")
        MusicManager:PlaySound( 7 ) 
        mResultEffect = EffectManager:createHnyEffect( 100824 , {x = 6,y = 40} ) 
        window:addChild(mResultEffect)
        EffectManager:startHnyEffect( mResultEffect )
    else
        victoryBackground = cc.Sprite:create("effect/Particle/Par00306.png")
        MusicManager:PlaySound( 8 ) 
    end   

--    local victoryBackground = cc.Sprite:create("effect/Particle/Par00306.png")

    victoryBackground:setScale(0.1)
    victoryBackground:setOpacity(0)
    victoryBackground:setPosition(0, 85)
    
    window:addChild(victoryBackground)
    
--    EndGameWindow:updateState()
    if war2CardManager:isWatching() == true then --如果是观战方
        mLayoutEndturn:setVisible(false)
        mShowState = 4
    else
        initExpProgress()
    end
    
    local vbgFI = cc.FadeIn:create(0.3)
    local vbgSC = cc.EaseBackOut:create(cc.ScaleTo:create(0.5, 1))
    local vbgASP = cc.Spawn:create(vbgFI, vbgSC)
    runNodeAction(victoryBackground, vbgASP)
end



local function endRunTimer()  
    if mBolPlaying == true then return end
    print("endRunTimer")
--    cc.Director:getInstance():getActionManager():removeAction("action对象")
    for i = 1, #mActionList do
        cc.Director:getInstance():getActionManager():removeAction(mActionList[i])
    end
    mLayoutEndturn:setVisible(true) 
    EndGameWindow:updateState()
end

--关闭界面
local function onCloseClick(p_sender)
    print("onCloseClick")
    if mShowState < 4 then 
        endRunTimer()
        return
    end
    if bolClose == true or mBolPlaying == true then return end --如果还在计时则不能退出
    bolClose = true
--    PopScene(__instance)
--    if true then return end
    local str
    if #OpenBoxManager.BoxRewardList > 0 == true then
--        RunScene("OpenBoxWindow")
        playProgressLeaveEffect()
    else
        --- 战斗类型 1天梯，2剧情故事模式，3竞技场，4好友对战，6休闲模式
        if war2CardManager.WarType == WAR2_TYPE_RANK then
            FightWnd.isPopAll = true
            require("framework.scheduler").performWithDelayGlobal( function () replaceScene("FightWnd") end, 0.5 )
        elseif war2CardManager.WarType == WAR2_TYPE_STORY then
            StoryWindow.isPopAll = true
            require("framework.scheduler").performWithDelayGlobal( function () replaceScene("StoryWindow") end, 0.5 )
        elseif war2CardManager.WarType == WAR2_TYPE_ARENA then
            ArenaWindow.isPopAll = true
            require("framework.scheduler").performWithDelayGlobal( function () replaceScene("ArenaWindow") end, 0.5 )
        elseif war2CardManager.WarType == WAR2_TYPE_XIUXIAN then
            FightWnd.isPopAll = true
            FightWnd:setFightType(WAR2_TYPE_XIUXIAN)
            require("framework.scheduler").performWithDelayGlobal( function () replaceScene("FightWnd") end, 0.5 )
        elseif war2CardManager.WarType == WAR2_TYPE_PUZZLE then
            PuzzleWindow.isPopAll = true
            require("framework.scheduler").performWithDelayGlobal( function () replaceScene("PuzzleWindow") end, 0.5 )            
        else
            MainWindow.isCanShow = true
            require("framework.scheduler").performWithDelayGlobal( function () replaceScene("MainWindow") end, 0.5 )            
        end
        war2CardManager.mOtherNpcId = 0
        popAllScene()
    end
end

--清除
 function EndGameWindow:clear( tempSelf )
    for i in pairs(tempSelf.mData) do
        tempSelf.mData[i] = nil
    end
    tempSelf.mData = nil
end


local function updateGolbalTimer()
    if mGolalTimes == nil then return end
    mGolalTimes = mGolalTimes + 1
    if mGolalTimes > 3 then
        if mShowState == 4 then
            onCloseClick()
            mGolalTimes = nil
        else
            EndGameWindow:updateState()
            mGolalTimer = nil    
        end            
    end
end


--mShowState显示状态 0:界面打开, 1:显示经验值 2:显示经验值进度完毕 3:显示天梯积分 4:显示天梯积分完毕,可以关闭
function EndGameWindow:endProgress()
    local char = CharacterManager:getMainPlayer()  
    
    mLayoutEndturn:setPositionX(mLayoutEndturnPos.x)
    if mShowState == 2 then
        mTxtLVNum:setString("Lv."..char.CharLevel)

        userEXP = (char.CharExp + DataManager.DataLvExpArr[ char.CharLevel ] )
        mTxtExpNum:setString(userEXP)
    elseif mShowState == 4 then
        mTxtLVNum:setString( char.CharHonour.."/"..mTarHonorNum ) 
        userEXP = char.CharHonour
    end
    initUserExp()
    expProgressBar:setPercentage(expProgressStart)
end

--mShowState显示状态 0:界面打开, 1:显示经验值 2:显示经验值进度完毕 3:显示天梯积分 4:显示天梯积分完毕,可以关闭
function EndGameWindow:updateState()
    print(" EndGameWindow:updateState() "..mShowState)
    if mShowState == 0 then 
        mShowState = 1 
        
    elseif mShowState == 1 then        
        mShowState = 2
        mGolalTimes = 0
        mLayoutEndturn:setVisible(true) 
        mBolPlaying = false
        EndGameWindow:endProgress() 
    elseif mShowState == 2 then
        if war2CardManager.WarType == WAR2_TYPE_RANK then  --如果是天梯战,那么需要显示天梯积分进度条,否则直接可以点击退出界面
            mShowState = 3
            mGolalTimes = nil
            startLadderUI()
        else
            mShowState = 4
            mGolalTimes = nil
            closeVictoryUI()           
            if #TaskManager.RewardDataList > 0 then
                RunScene("RewardWindow")
            elseif #OpenBoxManager.BoxRewardList > 0 == true then
                RunScene("OpenBoxWindow")
            else
                onCloseClick() 
            end   
            bolClose = false
        end        
    elseif mShowState == 3 then        
        mShowState = 4        
        showLadderIcon() 
        EndGameWindow:endProgress()
        mGolalTimes = 0         
    elseif mShowState == 4 then     
        mGolalTimes = nil        
        closeVictoryUI()           
        if #TaskManager.RewardDataList > 0 then
            RunScene("RewardWindow")
        elseif #OpenBoxManager.BoxRewardList > 0 == true then
            RunScene("OpenBoxWindow")
        else
            onCloseClick() 
        end   
        bolClose = false
    end
end


--初始化界面
function EndGameWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

function EndGameWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_ENDGAMEWND)
    window = self:getChildByTag(Tag_endgamewnd.PANEL_MAIN)
    mLayoutEndturn = self:getControl(Tag_endgamewnd.PANEL_MAIN, Tag_endgamewnd.LAYOUT_ENDTURN)
    mLayoutEndturn:setLocalZOrder(10)

    mTxtExpNum = mLayoutEndturn:getChildByTag(Tag_endgamewnd.LABBMF_EXPNUM)
    mImgExpNum = mLayoutEndturn:getChildByTag(Tag_endgamewnd.IMG_EXPNUM)

    mTxtLVNum = mLayoutEndturn:getChildByTag(Tag_endgamewnd.LABBMF_LVNUM)

    mImgRankIcon = mLayoutEndturn:getChildByTag(Tag_endgamewnd.IMG_RANKICON)

    local char = CharacterManager:getMainPlayer()

    local Mask = self:getControl(Tag_endgamewnd.PANEL_MAIN, Tag_endgamewnd.BTN_WINDOWBACK)
    Mask:setOnClickScriptHandler( onCloseClick )
    
    mProgress = mLayoutEndturn:getChildByTag(Tag_endgamewnd.PROG_EXPPROGRESS)
--    mProgress:setOnValueChangedScriptHandler(event_prog_hp)
    local maxExp = DataManager:getExp( char.CharLevel )
    mProgress:setValue( char.CharExp / maxExp * 100 )
    print( char.CharExp.." exp "..maxExp )

    local expAnimationTime = 10
    local expProgressStop = 100
    local perTime = 1 / expAnimationTime
    local updataTime = expAnimationTime * perTime
    
    local epDT = cc.DelayTime:create(1)
    local epPT = cc.ProgressTo:create(updataTime, expProgressStop)
    local epAnimationQuence = cc.Sequence:create(epDT, epPT)
    runNodeAction(mProgress, epAnimationQuence)

    ServMsgTransponder:SMTDailyOpen() 

    mGolalTimes = nil

    if mGolalTimer == nil then
        local fuc = function () updateGolbalTimer() end
        mGolalTimer = require("framework.scheduler").scheduleGlobal( fuc, 1 ) 
    end

    if SetWindow.isShow == true then
        SetWindow:closeWindow()
    end
    playOpenEffect()
    EndGameWindow.isShow = true
end

function EndGameWindow:onExitScene()
    MusicManager:StopMusic( 5 )
    EndGameWindow.mWin = false
    UILoadManager:delResByArr( resArr )
    bolClose = false

    mBolPlaying = false
    mShowState = 0
    EndGameWindow.isShow = false
    if mResultEffect and tolua.isnull(mResultEffect) == false then
        mResultEffect:removeFromParent()
        mResultEffect = nil
    end

    if mRankIconEffect and tolua.isnull(mRankIconEffect) == false then
        mRankIconEffect:removeFromParent()
        mRankIconEffect = nil
    end 

    if mGolalTimer then
        require("framework.scheduler").unscheduleGlobal( mGolalTimer )--清理计时器
        mGolalTimer = nil
    end
    mGolalTimes = nil

    for i = 1, #mActionList do
        cc.Director:getInstance():getActionManager():removeAction(mActionList[i])
    end

    TextureManager:clearTx2dList()--清理贴图
end