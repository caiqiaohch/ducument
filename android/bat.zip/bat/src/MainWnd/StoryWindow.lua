require "tagMap.Tag_story"
local DataManager = require("data.DataManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local TaskManager = require("TaskWnd.TaskManager"):instance()

local __instance = nil
local window

--背景底图
local mImgBg

--退出按钮
local mBtnExit
--Play按钮
local mBtnPlay

--关卡列表左按钮
local mBtnLeft
--关卡列表右按钮
local mBtnRight

local mImgBgLeft

--右标签
local mImgStoryTxt
local mImgStoryReward
--右标签按钮
local mBtnStoryTxt
local mBtnStoryReward

--右侧描述文本
local mTxtDesc

--上侧头像列表
local mGpvHead
--左侧大关分页列表
local mGpvStage

--当前时候显示奖励
local mBolShowReward = false

--当前选中的头像的NPCID
local mCurHeadNpcId = 1
--头像Cell列表
local mStageHeadList = {}

--选中的头像特效
local mHeadEffect

--当前选中的关卡
local mCurStageId = 1
--头像Cell列表
local mStageCellList = {}

--奖励预览Cell列表
local mRewardCellList = {}

--要预加载的资源列表
local resArr = { PLIST_STORY_URL, PLIST_CARDMIDDLEUI_URL, PLIST_CARDUI_URL }

StoryWindow = class("StoryWindow",function()
	return TuiBase:create()
end)

--是否之前已经退出所有场景,一般从战场退出的时候为true
StoryWindow.isPopAll = false

StoryWindow.isShow = false

function StoryWindow:create()
	local ret = StoryWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)

	return ret
end

function StoryWindow:getPanel(tagPanel)
	return self:getChildByTag(tagPanel)
end

function StoryWindow:getControl(tagPanel,tagControl)
	return self:getPanel(tagPanel):getChildByTag(tagControl)
end

--卡牌查看事件
local function showCardClick( p_sender )
    if CardXiangXi.isShow == false then 
        RunScene( "CardXiangXi" )
        CardXiangXi:setAndShowCardXiangXi( p_sender.mCardID, 1 )
    end
end

--是否还是锁定状态
local function bolNpcLock( npcId, stageId )
    local curNpcId = CharacterManager.stageNpcList[stageId]  --当前关卡已经解锁的NPCID,npcId比它大的表示还没解锁
    if curNpcId == nil then curNpcId = 0 end  --未解锁关卡会为nil
    if curNpcId < npcId then
        return true
    else
        return false
    end
    return false
end

--更新显示奖励预览信息
local function upDataRewardMsg( reward )
    local showNum = 0 --显示数量
    local pCell
    for i = 1, #mRewardCellList do
        mRewardCellList[i]:setVisible(false)
    end
    if mBolShowReward == false then return end
    if reward.g_cash > 0 then --金币
        showNum = showNum + 1
        pCell = mRewardCellList[showNum]
        pCell.img_reward_prizeIcon:setVisible(true)
        pCell.img_reward_pack:setVisible(false)
        pCell.cardUI:setVisible(false)
    	pCell.img_reward_prizeIcon:setTexture( "other/img_PrizeIcon+3.png" )
        pCell.labBmf_reward_num:setString( "X"..reward.g_cash )                
    end

	if reward.g_gem > 0 then --宝石
        showNum = showNum + 1
        pCell = mRewardCellList[showNum]
        pCell.img_reward_prizeIcon:setVisible(false)
        pCell.img_reward_pack:setVisible(true)
        pCell.cardUI:setVisible(false)
    	pCell.img_reward_prizeIcon:setTexture( "other/img_PrizeIcon+2.png" )
        pCell.labBmf_reward_num:setString( "X"..reward.g_gem )     
    end

    if reward.g_card ~= "" then --卡牌

        local cardReward = string.split( reward.g_card,  "," )
        for i = 1, #cardReward do
            obj = {}
            obj.Icon = 4
            local cardStr = string.split( cardReward[i], "#" )
            local cardData = DataManager:getCardObjByID( cardStr[1] )
            if cardData == nil then cardData = DataManager:getEq( cardStr[1] ) end
            showNum = showNum + 1

            pCell = mRewardCellList[showNum]
            pCell.img_reward_prizeIcon:setVisible(false)
            pCell.img_reward_pack:setVisible(false)
            pCell.cardUI:setVisible(true)
            pCell.cardUI:init(cardData.id)
            pCell.cardUI:setTouchEnabled(true)
            pCell.cardUI:setOnClickScriptHandler( showCardClick )
            pCell.labBmf_reward_num:setString( "X"..cardStr[2] )
        end     

    end

    if reward.g_pack ~= "" then --卡包
        local packReward = string.split( reward.g_pack, "," )


        local packData = string.split(packReward[1], "#")

        showNum = showNum + 1
        pCell = mRewardCellList[showNum]
        pCell.img_reward_prizeIcon:setVisible(false)
        pCell.img_reward_pack:setVisible(true)
        pCell.cardUI:setVisible(false)
        pCell.img_reward_pack:setTexture( "other/img_Pack_"..packData[1]..".png" )
        pCell.labBmf_reward_num:setString( "X"..packData[2] )
    end    
    --排版
    for i = 1, showNum do
        mRewardCellList[i]:setVisible(true)
        mRewardCellList[i]:setPositionX( -214 + (350 - 214 * showNum) * 0.5 + 214 * i )
    end
end

--local mMapEffect
--更新NPC介绍
local function updateNpcDesc()
    local npcObj = DataManager:getDataMapNpcbyDi(mCurHeadNpcId)
    if npcObj == nil then 
        mTxtDesc:setString("")
        return
    end
    mTxtDesc:setString( npcObj.npc_desc )
    upDataRewardMsg( npcObj )
    mImgBg:setTexture( "story/storyplant/"..npcObj.story_back..".png")
--    if npcObj.story_back == 10 and mMapEffect == nil then
--        mMapEffect = EffectManager:createHnyEffect( 100968, {x = 650, y = 0} )    
--        window:addChild(mMapEffect, 99)
--        EffectManager:startHnyEffect( mMapEffect )
--    end
end

--更新NPC头像
local function updateHeadIcon( pCell )
    if pCell:isVisible() == false then return end

    if bolNpcLock( pCell.npcObj.npc_id, mCurStageId ) == true then  --如果是锁定状态
        pCell.imgHeadIcon:setScale(0.45)
        pCell.imgLock:setVisible(true)
        pCell.imgLittle:setVisible(true)
        pCell.imgLight:setVisible(false)
        return
    end

    pCell.imgLock:setVisible(false)
    if pCell.npcObj.npc_id == mCurHeadNpcId then  --如果是当前选中的NPC
        pCell.imgLight:setVisible(true)
        pCell.imgLittle:setVisible(false)
        pCell.imgHeadIcon:setScale(0.56)
        mHeadEffect:removeFromParent()
        pCell:addChild(mHeadEffect, -1)
    else
        pCell.imgLight:setVisible(false)
        pCell.imgLittle:setVisible(true)
        pCell.imgHeadIcon:setScale(0.45)
    end
end

--更新左侧关卡列表
local function updateStageCell( pCell )
    if pCell:isVisible() == false then return end
    local npcObj = DataManager:getDataMapCampList( pCell.stageId )[1]  --当前关卡列表的第一个NPC
    local imgName = npcObj.story_name
    pCell.img_normal:setTexture( "story/storyname/"..imgName.."_normal_"..LANGUAGE..".png")
    pCell.img_select:setTexture( "story/storyname/"..imgName.."_select_"..LANGUAGE..".png")
    pCell.img_disable:setTexture( "story/storyname/"..imgName.."_disable_"..LANGUAGE..".png")
        
    if mCurStageId == pCell.stageId then
        pCell.img_normal:setVisible(false)
        pCell.img_select:setVisible(true)
        pCell.img_disable:setVisible(false)
        pCell.img_cellLock:setVisible(false)
    elseif CharacterManager.stageNpcList[pCell.stageId] == nil then --如果是未解锁的
        pCell.img_normal:setVisible(false)
        pCell.img_select:setVisible(false)
        pCell.img_disable:setVisible(true)
        pCell.img_cellLock:setVisible(true)
    else
        pCell.img_normal:setVisible(true)
        pCell.img_select:setVisible(false)
        pCell.img_disable:setVisible(false)
        pCell.img_cellLock:setVisible(false)
    end

end

--跳到解锁关卡的那一页并选中
local function gotoTheNpc(stageId)
    print(stageId)
    local curNpcId = CharacterManager.stageNpcList[stageId]  --当前关卡已经解锁的NPCID
    local idx = 1
    local dataList = DataManager:getDataMapCampList( mCurStageId )
    local npcObj
    for i = 1, #dataList do
        npcObj =  dataList[i]
        if curNpcId == npcObj.npc_id then
            idx = math.ceil( i/5 ) - 1
            break
        end
    end

    mCurHeadNpcId = curNpcId
    for i = 1, #mStageHeadList do
       updateHeadIcon( mStageHeadList[i] )
    end

    local sIdx = math.ceil( stageId/7 ) - 1
    local _y = mGpvStage:getContentOffset().y
    local _h = mGpvStage:getContentSize().height * sIdx
    mGpvStage:setContentOffsetInDuration( cc.p( 0, _y + _h), 0 )

    

    if idx > 0 then
        print(idx)
        local _x = mGpvHead:getContentOffset().x
        local _w = mGpvHead:getContentSize().width * idx
        local num = _x - _w 
        if num > 0 then num = 0 end
        mGpvHead:setContentOffsetInDuration( cc.p( num, 0 ), 0 )
    else
        mGpvHead:setContentOffsetInDuration( cc.p( 0, 0 ), 0 )
    end

    updateNpcDesc()
end

--点击关闭事件
local function BtnCloseClick(p_sender)
    if StoryWindow.isPopAll == true then
        if MainWindow.isCanShow == true then
            PopScene(__instance)
        else
            MainWindow.isCanShow = true
            replaceScene("MainWindow")
        end
    else
        PopScene(__instance)
        MusicManager:PlaySound( 1 )
    end
end

--左点击事件
local function BtnLeftClick(p_sender)
    local _x = mGpvHead:getContentOffset().x
    local _w = mGpvHead:getContentSize().width
    if _x % _w ~= 0 or _x == 0 then return end
    mGpvHead:setContentOffsetInDuration( cc.p( _x + _w, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )  
end

--右点击事件
local function BtnRightClick(p_sender)
    print( mGpvHead:getContentSize().width..","..mGpvHead:getContentSize().height)
    local _x = mGpvHead:getContentOffset().x
    local _w = mGpvHead:getContentSize().width
--    if _x % _w ~= 0 or _x <= -( mCardGpvPage - 1 ) * _w then return end
    mGpvHead:setContentOffsetInDuration( cc.p( _x - _w, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )  
end

--右按钮事件
local function onBtnStory( p_sender )
    if p_sender == mBtnStoryTxt then 
        mBolShowReward = false
        mImgStoryTxt:setSpriteFrame("story/img_StoryTxt+N_normal.png")
        mImgStoryReward:setSpriteFrame("story/img_StoryReward+N_select.png")
    else
        mBolShowReward = true
        mImgStoryTxt:setSpriteFrame("story/img_StoryTxt+N_select.png")
        mImgStoryReward:setSpriteFrame("story/img_StoryReward+N_normal.png")
    end

    local npcObj = DataManager:getDataMapNpcbyDi(mCurHeadNpcId)
    if npcObj == nil then 
        return
    end
    mTxtDesc:setVisible(not mBolShowReward)
    upDataRewardMsg( npcObj )
end

--play按钮点击事件
local function BtnPlayClick(p_sender)
    print("npcplay "..mCurHeadNpcId)
    local npcObj = DataManager:getDataMapNpcbyDi(mCurHeadNpcId)
    if mCurHeadNpcId == 0 or npcObj == nil then return end
    if npcObj.my_deck > 0 then --不需要选卡组的
        ServMsgTransponder:SMTWarNPC( mCurHeadNpcId, CharacterManager:checkNpcWin(mCurHeadNpcId) )
        return
    end
    FightWnd:setAndShowType( WAR2_TYPE_STORY, mCurHeadNpcId )
end

--点击上侧头像按钮事件
local function BtnHeadIconClick(p_sender)
    print("HeadIcon")
    if bolNpcLock( p_sender.npcId, mCurStageId ) == true then
        return
    end
    mCurHeadNpcId = p_sender.npcId
    for i = 1, #mStageHeadList do
       updateHeadIcon( mStageHeadList[i] )
    end
    updateNpcDesc()
end

--点击左侧关卡列表按钮事件
local function BtnStageClick(p_sender)
    print("BtnStage")
    if bolNpcLock( 1, p_sender.stageId ) == true then
        return
    end
    mCurStageId = p_sender.stageId
    for i = 1, #mStageCellList do
       updateStageCell( mStageCellList[i] )
    end
    local npcObj = DataManager:getDataMapCampList( mCurStageId )[1]
    if bolNpcLock( npcObj.npc_id, mCurStageId ) == true then
        mCurHeadNpcId = 0
    else
        mCurHeadNpcId = npcObj.npc_id
    end
    StoryWindow:UpDataHeadMsg()
    gotoTheNpc(mCurStageId)    
    updateNpcDesc()
end


--初始化界面
function StoryWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end

 --关卡分页拖动设置
local function gpvStageClick(p_convertview, idx)
    local pCell = p_convertview
    idx = idx + 1
    local dataList = DataManager:getDataMapCampList( mCurStageId )
    local stageId =  CharacterManager.stageIdList[idx]
	if pCell == nil then
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell(pCell, "cell_stage", PATH_STORY)
        pCell.img_normal = pCell:getChildByTag( Tag_story.IMG_STAGE_NORMAL )
        pCell.img_select = pCell:getChildByTag( Tag_story.IMG_STAGE_SELECT )
        pCell.img_disable = pCell:getChildByTag( Tag_story.IMG_STAGE_DISABLE )
        pCell.btn =  pCell:getChildByTag( Tag_story.BTN_CELL_STAGE )     
        pCell.img_cellLock = pCell:getChildByTag( Tag_story.IMG_CELLLOCK )
        pCell.btn:setOnClickScriptHandler( BtnStageClick )
        table.insert(mStageCellList, pCell)
	end
    if stageId == nil then
        pCell:setVisible(false)
        return pCell
    end
    local npcObj = DataManager:getDataMapCampList( stageId )[1]  --当前关卡列表的第一个NPC
    if npcObj == nil or npcObj.map == 0 then
        pCell:setVisible(false)
        return pCell
    end
    pCell:setVisible(true)    
    pCell.stageId = stageId
    pCell.btn.stageId = stageId
    updateStageCell(pCell)    
	return pCell
end



 --头像拖动设置
local function gpvHeadClick(p_convertview, idx)
	local pCell = p_convertview
    idx = idx + 1
    local dataList = DataManager:getDataMapCampList( mCurStageId )
    local npcObj =  dataList[idx]
	if pCell == nil then
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell(pCell, "cell_head", PATH_STORY)
        pCell.imgHeadIcon = pCell:getChildByTag( Tag_story.IMG_HEADICON )
        pCell.imgLight = pCell:getChildByTag( Tag_story.IMG_CELLLIGHT )
        pCell.imgLittle = pCell:getChildByTag( Tag_story.IMG_CELL_LITTLE )
        pCell.imgLock = pCell:getChildByTag( Tag_story.IMG_CELL_LOCK )     
        pCell.btn =  pCell:getChildByTag( Tag_story.BTN_CELL_HEAD )     
        pCell.btn:setOnClickScriptHandler( BtnHeadIconClick )
        table.insert(mStageHeadList, pCell)
	end
    if npcObj == nil or npcObj.npc_icon == 0 then
        pCell:setVisible(false)
        return pCell
    end
    pCell.imgHeadIcon:setTexture("war2/head/HeadPic"..npcObj.npc_icon..".png")
    pCell:setVisible(true)    
    pCell.npcObj = npcObj
    pCell.btn.npcId = npcObj.npc_id
    updateHeadIcon(pCell)    
	return pCell
end

function StoryWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_story",PATH_STORY)

    window = self:getChildByTag(Tag_story.PANEL_STORY)

    mImgBgLeft = self:getControl(Tag_story.PANEL_STORY, Tag_story.IMG_BG_LEFT)

    mImgBg = self:getControl(Tag_story.PANEL_STORY, Tag_story.IMG_BG)
    mImgBg:setTouchEnabled(true)

    mBtnExit = self:getControl(Tag_story.PANEL_STORY, Tag_story.BTN_EXIT)
    mBtnExit:setOnClickScriptHandler( BtnCloseClick )

    mBtnPlay = self:getControl(Tag_story.PANEL_STORY, Tag_story.BTN_PLAY)
    mBtnPlay:setOnClickScriptHandler( BtnPlayClick )

    mBtnLeft = self:getControl(Tag_story.PANEL_STORY, Tag_story.BTN_LEFT)
    mBtnLeft:setOnClickScriptHandler( BtnLeftClick )

    mBtnRight = self:getControl(Tag_story.PANEL_STORY, Tag_story.BTN_RIGHT)
    mBtnRight:setOnClickScriptHandler( BtnRightClick )

    mImgStoryTxt = self:getControl(Tag_story.PANEL_STORY, Tag_story.IMG_STORYTXT)
    mImgStoryReward = self:getControl(Tag_story.PANEL_STORY, Tag_story.IMG_STORYREWARD)

    mBtnStoryTxt = self:getControl(Tag_story.PANEL_STORY, Tag_story.BTN_STORYTXT)
    mBtnStoryTxt:setOnClickScriptHandler( onBtnStory )

    mBtnStoryReward = self:getControl(Tag_story.PANEL_STORY, Tag_story.BTN_STORYREWARD)
    mBtnStoryReward:setOnClickScriptHandler( onBtnStory )

    mTxtDesc = self:getControl(Tag_story.PANEL_STORY, Tag_story.LABEL_DESC)
	mTxtDesc:setAdditionalKerning(-0.5)
	mTxtDesc:setLineHeight(28)

    mGpvHead = self:getControl(Tag_story.PANEL_STORY,Tag_story.GPV_HEAD)    
    mGpvHead:setDataSourceAdapterScriptHandler(gpvHeadClick)
--    mGpvHead:setDirection(1) --quick 0:both 1:vertical 2:horizontal
    mGpvStage = self:getControl(Tag_story.PANEL_STORY,Tag_story.GPV_STAGE)    
    mGpvStage:setDataSourceAdapterScriptHandler(gpvStageClick)
    
    local pCell
    for i = 1, 3 do
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell(pCell, "cell_reward", PATH_STORY)
        pCell.img_reward_pack = pCell:getChildByTag( Tag_story.IMG_REWARD_PACK )
        pCell.img_reward_prizeIcon = pCell:getChildByTag( Tag_story.IMG_REWARD_PRIZEICON )
        pCell.labBmf_reward_num = pCell:getChildByTag( Tag_story.LABBMF_REWARD_NUM )
--        pCell.labBmf_reward_num:setHorizontalAlignment(cc.ui.TEXT_ALIGN_LEFT)

        pCell.cardUI = require("war2.cardMiddle").new()
        pCell:addChild( pCell.cardUI )
        pCell.cardUI:setPosition( 105, 150 )
--        pCell.cardUI:setScale(0.4)

        window:addChild(pCell)
        pCell:setPositionY(-160)
        table.insert(mRewardCellList, pCell)        
    end

    mHeadEffect = EffectManager:createHnyEffect( 100650, {x = 66.5, y = 66.5} )    
    mHeadEffect:retain()
    EffectManager:startHnyEffect( mHeadEffect )

    mImgStoryTxt:setSpriteFrame("story/img_StoryTxt+N_normal.png")
    mImgStoryReward:setSpriteFrame("story/img_StoryReward+N_select.png")
    mBolShowReward = false

    StoryWindow.isShow = true

    self:UpDataHeadMsg()
    self:UpDataStageMsg()
    self:UpDataMsg()

    for i = 1, #CharacterManager.stageIdList do
        if CharacterManager.stageNpcList[ CharacterManager.stageIdList[i] ] then
            local npcObj = DataManager:getDataMapCampList( CharacterManager.stageIdList[i] )[1] --当前关卡列表的第一个NPC
            if npcObj ~= nil and npcObj.map ~= 0 and (npcObj.npc_camp < 100 or npcObj.npc_camp > 199) then
                mCurStageId = CharacterManager.stageIdList[i]
            end            
        end
    end

    for i = 1, #mStageCellList do
        if mStageCellList[i].stageId == mCurStageId then
            BtnStageClick( mStageCellList[i] )
            break
        end
    end

    gotoTheNpc(mCurStageId)

    if #TaskManager.RewardDataList > 0 then
        RunScene("RewardWindow")
    end

    if NewbieManager:getBolEndStory() == true and NewbieManager.UseData.CollectionPre == false then
        NewbieWindow:setAndShowType("CollectionPre")
    end

    MusicManager:PlaySound( 6 )
end
  
--更新显示上侧头像列表
function StoryWindow:UpDataHeadMsg()
    local len = #DataManager:getDataMapCampList( mCurStageId )
    mGpvHead:setCountOfCell( len )
    mGpvHead:reloadData()
    mGpvStage:setContentOffsetToLeft()
    mGpvHead:setBounceable(false) --取消反弹
end
  
--更新显示上侧头像列表
function StoryWindow:UpDataStageMsg()
    if bolNpcLock( 3, 1 ) == true then  --如果新手第三关还是锁定状态
        mGpvStage:setVisible(false)
        mImgBgLeft:setVisible(false)
    else
        mGpvStage:setVisible(true)
        mImgBgLeft:setVisible(true)
    end
    if CharacterManager.stageIdList == nil then  CharacterManager:updateMapNpcMsg( {} ) end
    local len = 0
    for i = 1, #CharacterManager.stageIdList do
        if CharacterManager.stageIdList[i] < 100 or CharacterManager.stageIdList[i] > 199 then
            len = len + 1
        end 
    end
    mGpvStage:setCountOfCell( len )    
    mGpvStage:reloadData()
    mGpvStage:setContentOffsetToTop()
    mGpvStage:setBounceable(false) --取消反弹  
end

--更新显示 不更改当前选中npc
function StoryWindow:UpDataMsg()
    for i = 1, #mStageCellList do
       updateStageCell( mStageCellList[i] )
    end
    for i = 1, #mStageHeadList do
       updateHeadIcon( mStageHeadList[i] )
    end
    updateNpcDesc()
    if NewbieManager:getBolNewbie() == true then --新手流程
        if CharacterManager.stageNpcList[1] == 1 then
            NewbieManager.CurState = 1
            NewbieWindow:setAndShowType("NewLogin")    
            self:reorderImgBgChild(100)        
        end
        mBtnExit:setVisible(false)
    else --已经结束了新手流程
        if mBtnExit:isVisible() == false then mBtnExit:setVisible(true) end
    end  
end

function StoryWindow:reorderImgBgChild( idx )
    mImgBg:getParent():reorderChild( mImgBg, idx )
end


--关闭界面
function StoryWindow:closeWindow()
    BtnCloseClick(nil)
end

  
function StoryWindow:onExitScene()
    mHeadEffect:release()

    mCurHeadNpcId = 1
    mCurStageId = 1
    mStageHeadList = {}
    mStageCellList = {}
    mRewardCellList = {}
    UILoadManager:delResByArr( resArr )
    StoryWindow.isShow = false
    mBolShowReward = false
end

