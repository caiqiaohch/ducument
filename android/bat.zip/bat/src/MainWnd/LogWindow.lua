require "tagMap.Tag_mainwnd"
local DataManager = require("data.DataManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local TextManager = require("ui.TextManager"):instance()

local __instance = nil

--点击空白处关闭按钮
local btnBlackBack

--log文本滚动区域
local mTxtErrorLog

local mNetDataList = {}

local mDataList = {}


--是否已经点击了关闭
local bolClose = false

local boxList = {}

LogWindow = class("LogWindow",function()
	return TuiBase:create()
end)

LogWindow.isShow = false
LogWindow.isOpen = false

function LogWindow:create()
	local ret = LogWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function LogWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function LogWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

function updateLog( logType )
    local arr 
    if logType == 1 then
        arr = DEBUG_WRITELOGTABLE
    else
        arr = mNetDataList
    end
    mDataList = {}
    table.merge(mDataList, arr)
    table.insert(mDataList, DEBUG_WRITELOGURL)
    gpvHead:setCountOfCell( #arr )
    gpvHead:setContentOffsetToRight()
    gpvHead:setContentOffsetToLeft()
    gpvHead:reloadData()    
end


--关闭界面
local function onClostClick(p_sender)
    PopScene(__instance)
--    keyboardManager:delKeyboardEvent( {key = "35"} )    
--   if true then return end
--    PopScene(__instance)
end

--查看网络协议界面
local function onNetClick(p_sender)
    LogWindow:getNetLog()
    updateLog( 2 )
end



local function onErrorClick(p_sender)
--    PopScene(__instance)
--
--    if true then return end
    if mTxtErrorLog:isVisible() == true then
        mTxtErrorLog:setVisible(false)
        gpvHead:setVisible(true)
    else
        mTxtErrorLog:setVisible(true)
        gpvHead:setVisible(false)

        mTxtErrorLog:setString( io.readfile(DEBUG_WRITELOGURL) )
    end
end

local function gpvHeadClick(p_convertview, idx)
	local pCell = p_convertview
	if pCell == nil then
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell( pCell, "cell_grid", PATH_MAINWND )
	end
    if idx == -1 then 
        pCell:setVisible(false)
        return pCell
    else
        pCell:setVisible(true)
    end

    local arr = mDataList
    local str

    str = arr[idx]
    if pCell.txt then        
        pCell.txt:setString( str )
    else
        local txt = TextManager:createTxt( str, 20, TXTFONTNAME, 1200 )
        txt:setPositionX(600)
        pCell:addChild(txt)
        pCell.txt = txt
        pCell.txt:setString( str )
    end
    
	return pCell
end


--初始化界面
function LogWindow:onLoadScene()
    self:onEnterScene()
end


function LogWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_logwnd",PATH_MAINWND)

     --覆盖战场关闭按钮
    btnBlackBack = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.BTN_LOGWNDBACK)
    btnBlackBack:setOnClickScriptHandler( onClostClick )

    btnNet = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.BTN_LOGNET)
    btnNet:setOnClickScriptHandler( onNetClick )

    txtNet = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.LABBMF_TXTLOGNET)
    txtNet:setString("Net")

    btnClose = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.BTN_LOGCLOSE)
    btnClose:setOnClickScriptHandler( onClostClick )

    txtClose = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.LABBMF_TXTLOGCLOSE)
    txtClose:setString("Close")

    btnError = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.BTN_LOGERROR)
    btnError:setOnClickScriptHandler( onErrorClick )

    txtError = self:getControl(Tag_mainwnd.PANEL_LOGWND, Tag_mainwnd.LABBMF_TXTLOGERROR)
    txtError:setString("Error")

    gpvHead = self:getControl(Tag_mainwnd.PANEL_LOGWND,Tag_mainwnd.GPV_LOG)
    gpvHead:setDataSourceAdapterScriptHandler(gpvHeadClick)
    gpvHead:setCountOfCell(9)
    gpvHead:setContentOffsetToRight()
    gpvHead:setContentOffsetToLeft()
    gpvHead:reloadData()
    gpvHead:setBounceable(false) --取消反弹

    mTxtErrorLog = TextManager:createTxt("", 20, TXTFONTNAME, 1200, 700)
    mTxtErrorLog:setPosition(600, 350)
    self:addChild(mTxtErrorLog)
        print(DEBUG_WRITELOGURL)
    updateLog(1)
    LogWindow.isShow = true
end

function LogWindow:getNetLog()
    local list = Network.DataSumList
    local str = ""
      
    local tempList = {}
    for k, v in pairs(list) do
        table.insert(tempList, {id = k, value = v})
    end
    table.sort(tempList, function(a,b)
        return a.value > b.value
    end)
--    for k, v in pairs(list) do
--        str = str.."\n"..k.." "..v
--    end
    mNetDataList = {}
    for i = 1, #tempList do
        str = str.."\n"..tempList[i].id.." "..tempList[i].value
        table.insert(mNetDataList, tempList[i].id.." "..tempList[i].value)
    end
    return str   
end


function LogWindow:onExitScene()
    LogWindow.isShow = false
    LogWindow.isOpen = false
end

