require "tagMap.Tag_mainwnd"
local RichLabel = require "text.RichLabel"

MainWindow = class("MainWindow",function()
	return TuiBase:create()
end)

local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local EffectManager = require("ui.EffectManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()
local MovManager = require("Mov.MovManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()
local SteamManager = require("app.SteamManager"):instance()
local ArenaManager = require("arena.ArenaManager"):instance()

local window  =	nil
local socket = require "socket"

--对战分页按钮
local img_BattleTab = nil
--商店分页按钮
local img_StoreTab = nil
--开包按钮
local btn_Summon = nil
--组牌按钮
local btn_Collect = nil

--四侧按钮等主要信息层
local mLayoutMain

--中间层
local mLayoutMiddle
--中间层 休闲按钮层
local mLayoutMiddleCasual
--中间层 对战按钮层
local mLayoutMiddleBattle
--中间层 竞技场按钮层
local mLayoutMiddleAdventure

--中间层 商城描述层
local mLayoutMiddleShop
--好友上线提示层 
local mLayoutFriendLogin

--休闲按钮
local btn_Casual = nil
--对战按钮
local btn_Battle = nil
--竞技场按钮
local btn_Adventure = nil

--卡包金币购买按钮
local btn_PackGold
--卡包宝石购买按钮
local btn_PackStone
--卡包金币购买文本
local mTxt_PackGold
--卡包宝石购买文本
local mTxt_PackStone
--卡包介绍
local mTxt_PackDesc

--卡包选择特效
local mPackSelEffect
local mPackSelEffect2

--
local mListShop

local mShopItemList = {300000, 100011, 100013, 100012, 300001}
local mShopCellList = {}
local mShopCurIdx = 1

--圣石文本
local stoneTxt = nil
--金币文本
local goldTxt = nil
--荣誉文本
local HonourTxt = nil
--等级
local LvTxt = nil

--卡包数量文本
local mTxtSummonNum
--卡包数量背景图
local mImgSummonNum

--收藏按钮新卡牌数量文本
local mTxtCollectNum
--MainWindow.mTxtFriendNum
--收藏按钮新卡牌数量背景图
local mImgCollectNum


--天梯积分图
local mRankIcon

--当前商店选择的卡包ID
local mCurPackId = 300000

--当前界面显示状态 1:主界面 2:商店
local mShowType = 1

--加载界面
local loadUI = nil

--要预加载的资源列表
local resArr = { PLIST_MAIN_URL }

local __instance = nil

local mBolPlaying = false

--是否显示主界面
MainWindow.isShow = false
--是否加载完成资源
MainWindow.isLoadendRes = false
--是否可以显示主界面
MainWindow.isCanShow = false
--是否第一次进入
MainWindow.mFirstCome = true


function MainWindow:create()
	local ret = MainWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function MainWindow:getPanel(tagPanel)
	local ret = nil
	ret = self:getChildByTag(tagPanel)
	return ret
end

function MainWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

local function updateTab()
    if mShowType == 1 then
        img_BattleTab:setSpriteFrame("mainwnd/img_MainBattle_select.png")
        img_StoreTab:setSpriteFrame("mainwnd/img_MainStore_normal.png")
    else 
        img_BattleTab:setSpriteFrame("mainwnd/img_MainBattle_normal.png")
        img_StoreTab:setSpriteFrame("mainwnd/img_MainStore_select.png")
    end 
end

--播放界面打开动态效果
function MainWindow:playOpenEffect()    
    if mBolPlaying == true then return end
    mBolPlaying = true
    updateTab()
    local sp
    local tx2d 
    local diy
    local effect
    local btnList = {}
    local objList = {}
    if mShowType == 1 then 
        btnList = {mLayoutMiddleCasual, mLayoutMiddleAdventure, mLayoutMiddleBattle }
        for i = 1, 3 do
            objList[i] = {x = btnList[i]:getPositionX(), y = btnList[i]:getPositionY(), effId = 100715 + i}
        end
        mListShop:setVisible(true)
        mLayoutMiddleShop:setVisible(true)

    elseif mShowType == 2 then 
        for i = mShopCurIdx, mShopCurIdx + 2 do
            table.insert(btnList, mShopCellList[i])
        end
        for i = 1, 3 do
            objList[i] = {x = mShopCellList[i]:getPositionX() + mListShop:getPositionX() - mShopCellList[i]:getContentSize().width, y = mShopCellList[i]:getPositionY() + mListShop:getPositionY(), effId = 100737 + i}
        end      

        mLayoutMiddleCasual:setVisible(true)
        mLayoutMiddleAdventure:setVisible(true)
        mLayoutMiddleBattle:setVisible(true)

        mLayoutMiddleShop:setVisible(true)
        sp = TextureManager:getSprite( mLayoutMiddleShop )      
        tx2d = sp:getTexture()
        diy = TextureManager:getDiyEffect( 100741, tx2d)
        effect = EffectManager:createHnyEffect( 100741, { x = mLayoutMiddleShop:getPositionX(), y = mLayoutMiddleShop:getPositionY() } , nil, diy ) 
        mLayoutMiddle:addChild(effect)
        mLayoutMiddleShop:setVisible(false)
        EffectManager:startHnyEffect( effect, { key = function () mLayoutMiddleShop:setVisible(true) end } )

    end

    for i = 1, #btnList do
        btnList[i]:setVisible(true)
        sp = TextureManager:getSprite( btnList[i] )        
        tx2d = sp:getTexture()
        diy = TextureManager:getDiyEffect(objList[i].effId , tx2d)
        effect = EffectManager:createHnyEffect( objList[i].effId , {x = objList[i].x, y = objList[i].y} , nil, diy ) 
        mLayoutMiddle:addChild(effect)
        btnList[i]:setVisible(false)
        EffectManager:startHnyEffect( effect, {time = 0.1 * math.pow(2, i - 2), key = function () btnList[i]:setVisible(true) end } )
    end

    mLayoutMain:setVisible(true)
    sp = TextureManager:getSprite( mLayoutMain )      
    tx2d = sp:getTexture()
    diy = TextureManager:getDiyEffect( 100719, tx2d)
    effect = EffectManager:createHnyEffect( 100719, { x = mLayoutMain:getPositionX(), y = mLayoutMain:getPositionY() } , nil, diy ) 
    window:addChild(effect)
    mLayoutMain:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () mLayoutMain:setVisible(true) end } )
    
    require("framework.scheduler").performWithDelayGlobal( function () mBolPlaying = false end, 1.5 )
    
    img_BattleTab:setTouchEnabled(true)
    img_StoreTab:setTouchEnabled(true)
end

--播放界面关闭动态效果
function MainWindow:playCloseEffect( runFun )
    if mBolPlaying == true then return end
    mBolPlaying = true
    if runFun == nil then runFun = function() end end

    img_BattleTab:setTouchEnabled(false)
    img_StoreTab:setTouchEnabled(false)

    local sp
    local tx2d 
    local diy
    local effect
    local btnList = {}
    local objList = {}
    if mShowType == 1 then 
        btnList = {mLayoutMiddleCasual, mLayoutMiddleAdventure, mLayoutMiddleBattle }
        for i = 1, 3 do
            objList[i] = {x = btnList[i]:getPositionX(), y = btnList[i]:getPositionY(), effId = 100704 + i}
        end

        mListShop:setVisible(false)
        mLayoutMiddleShop:setVisible(false)
    elseif mShowType == 2 then 
        for i = mShopCurIdx, mShopCurIdx + 2 do
            table.insert(btnList, mShopCellList[i])
        end
        for i = 1, 3 do
            objList[i] = {x = mShopCellList[i]:getPositionX() + mListShop:getPositionX() - mShopCellList[i]:getContentSize().width, y = mShopCellList[i]:getPositionY() + mListShop:getPositionY(), effId = 100719 + i}
        end
        mLayoutMiddleCasual:setVisible(false)
        mLayoutMiddleAdventure:setVisible(false)
        mLayoutMiddleBattle:setVisible(false)

        mLayoutMiddleShop:setVisible(true)
        sp = TextureManager:getSprite( mLayoutMiddleShop )      
        tx2d = sp:getTexture()
        diy = TextureManager:getDiyEffect( 100727, tx2d)
        effect = EffectManager:createHnyEffect( 100727, { x = mLayoutMiddleShop:getPositionX(), y = mLayoutMiddleShop:getPositionY() } , nil, diy ) 
        mLayoutMiddle:addChild(effect)
--        effect:KeyFramesCallback( function () mLayoutMiddleShop:setVisible(true) end)
        mLayoutMiddleShop:setVisible(false)
        EffectManager:startHnyEffect( effect )
    end

    for i = 1, #btnList do
        btnList[i]:setVisible(true)
        sp = TextureManager:getSprite( btnList[i] )        
        tx2d = sp:getTexture()
        diy = TextureManager:getDiyEffect(objList[i].effId , tx2d)
        effect = EffectManager:createHnyEffect( objList[i].effId , {x = objList[i].x, y = objList[i].y} , nil, diy ) 
        mLayoutMiddle:addChild(effect)
        btnList[i]:setVisible(false)
        EffectManager:startHnyEffect( effect, {time = 0.1 * math.pow(2, i - 2)} )
    end
    
    mLayoutMain:setVisible(true)
    sp = TextureManager:getSprite( mLayoutMain ) 
    tx2d = sp:getTexture()
    diy = TextureManager:getDiyEffect(100709 , tx2d)
    effect = EffectManager:createHnyEffect( 100709 , {x = mLayoutMain:getPositionX(), y = mLayoutMain:getPositionY()} , nil, diy ) 
    window:addChild(effect)
    
    EffectManager:startHnyEffect( effect, {time = 0.6, fun = function() mLayoutMain:setVisible(false) end, key = function() runFun() end } )

    require("framework.scheduler").performWithDelayGlobal( function () mBolPlaying = false end, 1.5 )
end


local function updateTxtDesc( descStr )
    local fontSize = TextManager:getFontSizeAuto(descStr, 21, {width = 442, height = 145}, "fonts/msyh.ttf")   
    if mTxt_PackDesc then mTxt_PackDesc:removeFromParent() end
    mTxt_PackDesc = TextManager:createTxt( descStr, fontSize, "fonts/msyh.ttf", 442, 145, 1, 1 )
    mTxt_PackDesc:setTextColor(cc.c4b(153,140,122,255))
    mTxt_PackDesc:setPosition( 386, 145 )
--    mTxt_PackDesc:setAdditionalKerning(-2)
    mLayoutMiddleShop:addChild( mTxt_PackDesc )
end

--更新商店卡包选中效果
local function updateShopBtn()   
    local char = CharacterManager:getMainPlayer()
    local packId = mCurPackId
    local descStr = ""
    if mCurPackId == 300000 or mCurPackId == 300001 then     
        local item = ItemManager:getItemData( packId )
        local day = CharacterManager:getVipDays()
        if mCurPackId == 300001 and day > 0 then            
            descStr = item.item_desc1_id .."\n"..string.gsub(DataManager:getStringDataTxt(4129, true),"$1", day)
            mTxt_PackDesc:setString( item.item_desc1_id .."\n"..string.gsub(DataManager:getStringDataTxt(4129, true),"$1", day) )
        else
            descStr = item.item_desc1_id 
            mTxt_PackDesc:setString( item.item_desc1_id ) 
        end
        updateTxtDesc(descStr)
        local shopData = ShopManager:getShopData( 1, packId ) 
        img_MidBuy:setTexture("other/currency/img_"..MONEYTYPE..".png")
        mTxtMidBuy:setString(shopData[MONEYTYPE]*0.01)
        return
    end
    local item = ItemManager:getItemData( packId )
    local shopData = ShopManager:getShopData( 1, packId ) 
--    mTxt_PackDesc:setString( item.item_desc1_id )
    updateTxtDesc( item.item_desc1_id )
    if shopData.Gold > 0 then
        mTxt_PackGold:setString( shopData.Gold ) 
        btn_PackGold:setVisible(true)
    else
        mTxt_PackGold:setString("") 
        btn_PackGold:setVisible(false)
    end
    if shopData.Gem > 0 then
        mTxt_PackStone:setString( shopData.Gem ) 
        btn_PackStone:setVisible(true)
    else
        mTxt_PackStone:setString("") 
        btn_PackStone:setVisible(false)
    end

    if char.gold < shopData.Gold then
        EffectManager:setBtnGrayFilter(btn_PackGold, true)
    else
        EffectManager:setBtnGrayFilter(btn_PackGold, false)
    end

    if char.stone < shopData.Gem then
        EffectManager:setBtnGrayFilter(btn_PackStone, true)
    else
        EffectManager:setBtnGrayFilter(btn_PackStone, false)
    end
end

--更新商店卡包选中效果
local function updateShopSelect()   
    mPackSelEffect:setVisible(false)
    mPackSelEffect2:setVisible(false)
    mPackSelEffect:removeFromParent()
    mPackSelEffect2:removeFromParent()

    for i = 1, #mShopCellList do
        if mShopCellList[i].packId == mCurPackId then
            if mShopCellList[i].packId == 300000 or mCurPackId == 300001 then
                local effId
                if  mShopCellList[i].packId == 300000 then
                    effId = 101033
                else
                    effId = 101032
                end
                if mPackSelEffect2 and tolua.isnull(mPackSelEffect2) == false then
                    mPackSelEffect2:release()
                end
                mPackSelEffect2 = EffectManager:createHnyEffect( effId, {x = 153, y = 187} )   
                mPackSelEffect2:retain() 
                EffectManager:startHnyEffect( mPackSelEffect2 )

                mShopCellList[i]:addChild(mPackSelEffect2, -1)
                mPackSelEffect2:setVisible(true)
            else
                mShopCellList[i]:addChild(mPackSelEffect, -1)
                mPackSelEffect:setVisible(true)
            end
        end
    end

    if mCurPackId == 300000 or mCurPackId == 300001 then
        btn_PackGold:setVisible(false)
        mTxt_PackGold:setVisible(false)
        btn_PackStone:setVisible(false)
        mTxt_PackStone:setVisible(false)
        img_MidBuy:setVisible(true)
        btn_MidBuy:setVisible(true)
        mTxtMidBuy:setVisible(true)        
    else
        btn_PackGold:setVisible(true)
        mTxt_PackGold:setVisible(true)
        btn_PackStone:setVisible(true)
        mTxt_PackStone:setVisible(true)
        img_MidBuy:setVisible(false)
        btn_MidBuy:setVisible(false)
        mTxtMidBuy:setVisible(false)
    end  
    updateShopBtn() 
end


--荣誉点击事件
local function HonourClick(p_sender)
    require("Music.MusicManager"):instance():PlaySound( 108 )
--	RunScene("LadderRankWindow")
    local fun = function() 
        RunScene("LadderRankWindow")
    end	
    MainWindow:playCloseEffect(fun)
end


--回合倒计时特效时间 time:结束回合的系统时间 addTime:1839发过来的增量
function MainWindow:setEndTurnTimes(time, addTime)
    endTurnTimes = time
    END_TURN_TIMES = time
    if addTime == nil then addTime = 0 end
    if war2CardManager:instance():isMainBuZhi() == true and war2CardManager:getBolShortTime() == true and addTime > 15 then
        local endTimes = socket.gettime()
        endTurnTimes = endTimes + 15
    end
    if endTurnTimer == nil then
        local fuc = function () updateEndTurnTimer() end
        endTurnTimer = require("framework.scheduler").scheduleGlobal( fuc, 1 )
        updateEndTurnTimer()
    end    
end


--金币点击事件
local function GoldClick(p_sender)
    if BOL_TEST_MODE == true and IS_STEAM_LOGIN == true then
        local itemData = ShopManager.DataShopStoneArr[10]
        SteamManager:requestPhpForSteamBuy( itemData )
    end
--   RunScene("LadderRewardWindow") 
    if true then return end
    local ShopManager = require("Shop.ShopManager"):instance()
    ShopManager.CurGoodsType = 1
	require("Music.MusicManager"):instance():PlaySound( 105 )
    RunScene("ShopGoodsWindow")
end


--圣石点击事件
local function StoneClick(p_sender)
    if IS_STEAM_INIT == false and IS_GOOGLE_LOGIN == false then 
        require("prompt.PromptManager"):instance():ShowByType( 4113 )
        return 
    end
    local ShopManager = require("Shop.ShopManager"):instance()
    ShopManager.CurGoodsType = 2
    require("Music.MusicManager"):instance():PlaySound( 104 )
	RunScene("ShopGoodsWindow")
end

--设置点击事件
local function SetClick(p_sender)
    print("set")
    require("Music.MusicManager"):instance():PlaySound( 108 )
	RunScene("MainSetWindow")
end

--设置长按事件
local function clickLongSetClick(p_sender)
    print("long set")
    require ("keyboardEvent.keyboardManager"):instance():delKeyboardEvent( {key = "35"} )   
    return false
end




--人物界面点击事件
local function MyInfoClick(p_sender)
    print("MyInfoClick")
    require("Music.MusicManager"):instance():PlaySound( 108 )	
    local fun = function() 
        RunScene("CharacterWindow") 
    end	
    MainWindow:playCloseEffect(fun)
end


--好友点击事件
local function FriendClick(p_sender)
--	if true then 
--        require("prompt.PromptManager"):instance():SetNotice( 4005 )    --暂未开放
--        return 
--    end  
 --UserDefaultManager:uploadLog()
--    ServMsgTransponder:SMTAreaSuiji( "" )
--    ServMsgTransponder:SMTDelete_decks( 9 )
    RunScene("FriendWnd")
    ServMsgTransponder:SMTOpenFriend()
    MainWindow:setFriendMsg(false)
end

--任务点击事件
local function QuestClick(p_sender)
    print("Quest")
    require("Music.MusicManager"):instance():PlaySound( 108 )
	ServMsgTransponder:SMTDailyOpen()
    TaskWindow.open = true
--    cc.Director:getInstance():setAnimationInterval(1/60)
end


--收集点击事件
local function CollectClick(p_sender)
    print("Collect")
	require("Music.MusicManager"):instance():PlaySound( 100 )
--    RunScene("CollectionWnd")

    local fun = function() 
        RunScene("CollectionWnd")
    end	
    MainWindow:playCloseEffect(fun)
end

--休闲模式点击事件
local function CasualClick(p_sender)
    print("CasualClick")
    require("Music.MusicManager"):instance():PlaySound( 107 )
    FightWnd:setAndShowType( WAR2_TYPE_XIUXIAN )
end

--开包点击事件
local function SummonClick(p_sender)
    print("OpenPackWindow")
    require("Music.MusicManager"):instance():PlaySound( 100 )
    ServMsgTransponder:SMTShopOpen()   
    local fun = function() 
        RunScene("OpenPackWindow")
    end	
    MainWindow:playCloseEffect(fun)
end

--竞技场点击事件
local function TrialsClick(p_sender)
--for i = 1, 4 do
--        table.insert( require("openbox.OpenBoxManager"):instance().BoxRewardList, {id = 1 + i, state = 1} )
--    end
--     table.insert( require("openbox.OpenBoxManager"):instance().BoxRewardList, {id = 100001, num = 15, state = 1} )
--     table.insert( require("openbox.OpenBoxManager"):instance().BoxRewardList, {id = 100002, num = 15, state = 1} )
--RunScene("OpenBoxWindow")
--	if true then 
--        require("prompt.PromptManager"):instance():ShowByType( 107,nil,1 )
--        require("prompt.PromptManager"):instance():SetNotice( 4005 )    --暂未开放
--        return 
--    end  

    require("Music.MusicManager"):instance():PlaySound( 107 )
    RunScene("StoryBattleWindow")
--    print("TrialsClick")
--    if CharacterManager:checkNpcWin( 30 ) == 1 then --没打赢这关的不开放
--        require("prompt.PromptManager"):instance():SetNotice( 4092 )    
--        return 
--    end
----    ServMsgTransponder:SMTAreaOpen()
--    ArenaManager:setIsSendOpen(true)   
--    if ArenaManager:getIsGetMsg() == false then
--        ServMsgTransponder:SMTAreaOpen()
--    elseif ArenaManager:getCurState() == 0 then
--        RunScene("ArenaEnterWindow")
--    elseif ArenaManager:getCurState() == 1 or ArenaManager:getCurState() == 2 then
--        RunScene("ArenaWindow")
--    end
    
--    mCurHeadNpcId = 999
--    local npcObj = DataManager:getDataMapNpcbyDi(mCurHeadNpcId)
--    if mCurHeadNpcId == 0 or npcObj == nil then return end
--    if npcObj.my_deck > 0 then --不需要选卡组的
--        ServMsgTransponder:SMTWarNPC( mCurHeadNpcId, CharacterManager:checkNpcWin(mCurHeadNpcId) )
--    else
--        ServMsgTransponder:SMTComposeCardFight( 1 )
--        require("framework.scheduler").performWithDelayGlobal( function ()  ServMsgTransponder:SMTWarNPC( mCurHeadNpcId, CharacterManager:checkNpcWin(mCurHeadNpcId) ) end, 0.5 )       
--    end


    print("Trials")
end

--对战点击事件
local function BattleClick(p_sender)     
    print("Battle")
    RunScene("BattleWindow")
    require("Music.MusicManager"):instance():PlaySound( 107 )
end


--商店点击事件
local function StoreTabClick(p_sender)
    require("Music.MusicManager"):instance():PlaySound( 109 )
	MainWindow:TurnMiddleLayout(2)
    updateTab()
end

--主界面点击事件
local function BattleTabClick(p_sender)
    require("Music.MusicManager"):instance():PlaySound( 109 )
	MainWindow:TurnMiddleLayout(1)
    updateTab()
end

--商店卡包点击事件
local function BtnCellShopClick(p_sender)
    print("BtnCellShopClick")
    require("Music.MusicManager"):instance():PlaySound( 110 )
    mCurPackId = p_sender.packId
    updateShopSelect()
end



--金币购买卡包按钮点击事件
local function BtnPackGoldClick(p_sender)
    local value = tonumber(mTxt_PackGold:getString())
    ShopManager:setCurBuyGold( value ) 
	ServMsgTransponder:SMTShopBuy( 1, 1, mCurPackId, 1 )
    --shop buy 购买类型 消耗类型 道具id 数量    购买道具   //购买类型：1卡包  2卡背  3单卡市场    消耗类型：1金币 2钻石
end

--宝石购买卡包按钮点击事件
local function BtnPackStoneClick(p_sender)
    local value = tonumber(mTxt_PackStone:getString())
    ShopManager:setCurBuyStone( value ) 
	ServMsgTransponder:SMTShopBuy( 1, 2, mCurPackId, 1 )
end

--新手礼包购买按钮点击事件
local function BtnMidBuyClick(p_sender)
    if IS_STEAM_INIT == false then 
        require("prompt.PromptManager"):instance():ShowByType( 4113 )
        return 
    end
--    if mCurPackId == 300001 then
--        local char = CharacterManager:getMainPlayer()
--        if char.BuyNewGift == -1 or char.BuyNewGift == 0 then--玩家是否已经购买了新手礼包 -1:还没收到协议 0:没买 1:已经买过了
--            packId = 300000
--        else
--            packId = 300001
--        end
--    end


    local shopData = ShopManager:getShopData( 1, mCurPackId ) 
    SteamManager:requestPhpForSteamBuy( shopData )
end

local mIsScrollIng = false

local function BtnShopUpClick(p_sender) 
    MusicManager:PlaySound( 101 )
    if mListShop:isVisible() == false then
        print("mListShop is hide")
    end
    print(" mListShop "..mListShop:getPositionX().." , "..mListShop:getPositionY().."  "..mShopCellList[1]:getPositionX().." , "..mShopCellList[1]:getPositionY())
    if mIsScrollIng == true or mBolPlaying == true then return end      
    print("BtnShopUpClick")
    mIsScrollIng = true
    require("framework.scheduler").performWithDelayGlobal( function () mIsScrollIng = false end, 0.3 )
    local _x = mListShop:getContentOffset().x
    if _x >= 0 then 
        mListShop:setContentOffsetInDuration(cc.p( 0, 0 ),  0.1)
        return 
    end
    mShopCurIdx = mShopCurIdx - 1
    mListShop:setContentOffsetInDuration( cc.p( _x + 300, 0 ), 0.3 )
--    mListShop:setContentOffsetToLeft()
end

local function BtnShopDownClick(p_sender)
    MusicManager:PlaySound( 101 ) 
    if mIsScrollIng == true or mBolPlaying == true then return end      
    print("BtnShopDownClick")
    mIsScrollIng = true
    require("framework.scheduler").performWithDelayGlobal( function () mIsScrollIng = false end, 0.3 )
    local _x = mListShop:getContentOffset().x
    local _w = mListShop:getContentSize().width
    if  _w - _x >= mListShop:getContainerSize().width then 
        mListShop:setContentOffsetInDuration(cc.p( _w - mListShop:getContainerSize().width, 0 ),  0.1)
        return 
    end
    mShopCurIdx = mShopCurIdx + 1
    mListShop:setContentOffsetInDuration( cc.p( _x - 300, 0 ), 0.3 )
end


--初始化界面
function MainWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () 
            MainWindow.isLoadendRes = true
            self:onEnterScene() 
        end )
end

--播放减金币/宝石效果
function MainWindow:addBuyEffect( value, moneyType )    
    local str = "-"..value--mLabBmfBuyMoney:getString()

    local addGEffect = cc.Sprite:create()
    local G_font = cc.LabelBMFont:create( str, "fonts/labBmf_BitFont+01.fnt" )
    local G_icon--
    local pos
    if moneyType == 1 then
        G_icon = cc.Sprite:create("other/img_Gold.png")
        pos = { x = mTxt_PackGold:getPositionX() + mTxt_PackGold:getContentSize().width * 0.5, y = mTxt_PackGold:getPositionY() }
    else
        G_icon = cc.Sprite:create("other/img_Spar.png")
        pos = { x = mTxt_PackStone:getPositionX() + mTxt_PackStone:getContentSize().width * 0.5, y = mTxt_PackStone:getPositionY() }
    end
    addGEffect:addChild(G_font)
    addGEffect:addChild(G_icon)
    G_icon:setPosition(40, 0)
    G_icon:setScale(0.6)
    mLayoutMiddleShop:addChild(addGEffect, 99)
    addGEffect:setPosition( pos.x, pos.y )

    local age_MB = cc.EaseCubicActionOut:create(cc.MoveBy:create(0.5, cc.p(0, 100)))
    local age_DT = cc.DelayTime:create(0.5)
    local age_RS = cc.RemoveSelf:create()
    local age_SQ = cc.Sequence:create(age_MB, age_DT, age_RS)
    addGEffect:runAction(age_SQ)
    
    
    local gf_FO = cc.FadeOut:create(0.5)
    local gf_SQ = cc.Sequence:create(age_DT:clone(), gf_FO)
    G_font:runAction(gf_SQ)
    G_icon:runAction(gf_SQ:clone())   
    
    require("Music.MusicManager"):instance():PlaySound( 114 ) 
end

--更新信息
function MainWindow:updatamsg()
    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then return end

    local char = CharacterManager:getMainPlayer()
    --圣石
    stoneTxt:setString( char.stone )
    --金币
    goldTxt:setString( char.gold )
    --等级
    if char.accounts=="test1" or char.accounts=="test2" then
        LvTxt:setString( char.Name.."(Lv."..char.CharLevel..")" ) 
    else
    	LvTxt:setString( "LV."..char.CharLevel )  
    end
    
    updateShopBtn()
end

--更新商城可购买卡包信息
function MainWindow:updataShopMsg()
--    if true then return end
--    local char = CharacterManager:getMainPlayer()
--    local packId
--    local effId
--    if char.BuyNewGift == -1 or char.BuyNewGift == 0 then--玩家是否已经购买了新手礼包 -1:还没收到协议 0:没买 1:已经买过了
--        img_Pack_1:setSpriteFrame("mainwnd/img_Pack_6.png")
--        packId = 300000
--        effId = 101033
--    else
--        img_Pack_1:setSpriteFrame("mainwnd/img_Pack_5.png")
--        packId = 300001
--        effId = 101032
--    end
--    if mPackSelEffect2 and tolua.isnull(mPackSelEffect2) == false then
--        mPackSelEffect2:removeFromParent()
--    end
--    mPackSelEffect2 = EffectManager:createHnyEffect( effId, {x = 108, y = 187} )    
--    mLayoutShopSmall:addChild(mPackSelEffect2, -1)
--    EffectManager:startHnyEffect( mPackSelEffect2 )

--    local shopData = ShopManager:getShopData( 1, packId ) 
--    img_MidBuy:setTexture("other/currency/img_"..MONEYTYPE..".png")
--    mTxtMidBuy:setString(shopData[MONEYTYPE]*0.01)
end

--更新商城可购买卡包信息
function MainWindow:updateVipTime( day )
    local str = string.gsub(DataManager:getStringDataTxt(4129, true),"$1", CharacterManager:getVipDays()) 
--    mTxt_PackDesc:s
end

--更新卡包数量信息
function MainWindow:updataSummonMsg()
    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then return end

    local num = 0
    local packIdList = {100010, 100011, 100012, 100013, 101001, 101002, 101003}
    for i = 1, #packIdList do
        if CollectionManager:getHasPackNum( packIdList[i] ) > 0 then
            num = num + CollectionManager:getHasPackNum( packIdList[i] )
        end
    end
    if num > 0 then
        mTxtSummonNum:setString(num)
        mImgSummonNum:setVisible(true)
    else
        mTxtSummonNum:setString("")
        mImgSummonNum:setVisible(false)
    end
end

--更新新卡牌数量信息
function MainWindow:updataCollectMsg()
--    if true then return end  --先屏蔽
    local num = 0
    for key, value in pairs( CollectionManager:getNewCardList() ) do  
        if value == 1 then
            num = num + 1
        end  
    end 
    if num > 0 then
        mTxtCollectNum:setString(num)
        mImgCollectNum:setVisible(true)
    else
        mTxtCollectNum:setString("")
        mImgCollectNum:setVisible(false)
    end
end

function MainWindow:setFriendMsg(flag)
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then return end   
    MainWindow.mTxtFriendNum:setVisible(flag)
end

--好友上线提示
function MainWindow:setFriendLoginMsg( friendName )
    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false or friendName == nil or friendName == "" then return end
    local txtState = mLayoutFriendLogin:getChildByTag( Tag_mainwnd.LABEL_FRIENDSTATE )
    local txtName = mLayoutFriendLogin:getChildByTag( Tag_mainwnd.LABEL_FRIENDNAME )

    txtName:setString(friendName)
    local head_str = FriendManager.GetMaxLenString(friendName,1) 
    txtState:setString(head_str)

    mLayoutFriendLogin:setPositionY( mLayoutFriendLogin:getPositionY() - 100 )
    mLayoutFriendLogin:setVisible(true)
    mLayoutFriendLogin:setOpacity(255)
    local age_MB = cc.EaseCubicActionOut:create(cc.MoveBy:create(0.5, cc.p(0, 100)))
    local age_DT = cc.DelayTime:create(0.5)
    local fadeout = cc.FadeOut:create(1);
    local age_SQ = cc.Sequence:create(age_MB, age_DT, fadeout)--, age_RS)
    mLayoutFriendLogin:runAction(age_SQ)
end



--更新天梯积分信息
function MainWindow:updataRankMsg() 
    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then return end

    local rankList = DataManager:getDataRank()
    local char = CharacterManager:getMainPlayer()
    local rankData
    for i=1, #rankList do        
        if rankList[i] and rankList[i].integral >= char.CharHonour then
            rankData = rankList[i]
            break
        end      
    end
    if rankData then
        mRankIcon:setTexture("other/rankIcon/"..rankData.icon..".png")
    end
    HonourTxt:setString( char.CharHonour )
end

--中间信息更改(动画) 1:主界面 2:商店
function MainWindow:TurnMiddleLayout( moveType )
    local value = 0
    mShowType = moveType
    if mShowType == 2 then value = 256
    else value = -468 end
    local MovMove = require("Mov.MovMove").new()    
    MovMove:init(mLayoutMiddle, false, mLayoutMiddle:getPositionX(), value, 500, -1)
    
--    MovMove.callBackFucFinished = callbackLeftMov
    MovManager:pushMov( MovMove )

--    img_Pack_1:setTouchEnabled(true)
--    img_Pack_2:setTouchEnabled(true)
--    img_Pack_3:setTouchEnabled(true)

    img_BattleTab:setTouchEnabled(true)
    img_StoreTab:setTouchEnabled(true)
end

function MainWindow:ChangeLanguage()
    local img = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_FONTHOME)
    img:setTexture("langImg/img_Font+Home_"..LANGUAGE..".png")

    img = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_FONTSTORE)
    img:setTexture("langImg/img_Font+Store_"..LANGUAGE..".png")

    img = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_FONTSUMMON)
    img:setTexture("langImg/img_Font+Summon_"..LANGUAGE..".png")

    img = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_FONTCOLLECT)
    img:setTexture("langImg/img_Font+collect_"..LANGUAGE..".png")


    img = mLayoutMiddleCasual:getChildByTag( Tag_mainwnd.IMG_FONTSTORY ) 
    img:setTexture("langImg/img_Font+Story_"..LANGUAGE..".png")

    img = mLayoutMiddleBattle:getChildByTag( Tag_mainwnd.IMG_FONTPLAY ) 
    img:setTexture("langImg/img_Font+Play_"..LANGUAGE..".png")

    img = mLayoutMiddleAdventure:getChildByTag( Tag_mainwnd.IMG_FONTARENA ) 
    img:setTexture("langImg/img_Font+Arena_"..LANGUAGE..".png")

    updateShopBtn()
end

--手动进入场景
function MainWindow:onHandEnterScene()
    if __instance == nil then return end
    __instance:onEnterScene()

    --协议、资源都加载完成
    if MainWindow.isCanShow == true and MainWindow.isLoadendRes == true then
        local mov = require("Mov.MovAlpha").new()
        local mBg = __instance:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.IMG_BG)
        mBg:setOpacity(0)
        mov:init( mBg, 255, 17 )
        require("Mov.MovManager"):instance():pushMov( mov )
    end
end

--都放到onEnterScene会报lua单个函数赋值过多的错误,所以分了部分出来
function MainWindow:initLayout()
    window = self:getPanel(Tag_mainwnd.PANEL_MAIN)
    mLayoutMain = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.LAYOUT_MAIN) 
    mLayoutMiddle = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.LAYOUT_MIDDLE) 
    mLayoutMiddleCasual = mLayoutMiddle:getChildByTag( Tag_mainwnd.LAYOUT_MIDDLE_CASUAL )  
    mLayoutMiddleBattle = mLayoutMiddle:getChildByTag( Tag_mainwnd.LAYOUT_MIDDLE_BATTLE )  
    mLayoutMiddleAdventure = mLayoutMiddle:getChildByTag( Tag_mainwnd.LAYOUT_MIDDLE_ADVENTURE )  

    mLayoutMiddleShop = mLayoutMiddle:getChildByTag( Tag_mainwnd.LAYOUT_SHOP ) 
        
    mLayoutFriendLogin = mLayoutMain:getChildByTag( Tag_mainwnd.LAYOUT_FRIENDLOGIN )
    mLayoutFriendLogin:setVisible(false)
end

function MainWindow:insertItemToShopList( shopObj )    
--    idx = data.idx + 1
--    local shopObj =  ShopManager:getShopData( 1, mShopItemList[idx] )	
    local pCell = CGridPageViewCell:new()
    TuiManager:getInstance():parseCell(pCell, "cell_shop", PATH_MAINWND)
    pCell.imgBg = pCell:getChildByTag( Tag_mainwnd.IMG_SHOPPACK )     
    pCell.btn =  pCell:getChildByTag( Tag_mainwnd.BTN_CELLSHOP )     
    pCell.btn:setOnClickScriptHandler( BtnCellShopClick )

    pCell.imgBg:setTexture("mainwnd/img_Pack_"..shopObj.ItemsID..".png")
    pCell:setVisible(true)    
    pCell.shopObj = shopObj
    pCell.packId = shopObj.ItemsID
    pCell.idx = idx

    pCell.btn.packId = shopObj.ItemsID
    pCell.btn.idx = idx

    pCell:setContentSize( cc.size( 300, 370 ) )
    mListShop:insertNodeAtLast(pCell)
    table.insert(mShopCellList, pCell)
end

--local function gpvShopClick(p_convertview, idx)
--	local pCell = p_convertview
--    idx = idx + 1
--    local shopObj =  ShopManager:getShopData( 1, mShopItemList[idx] )
--	if pCell == nil then
--        pCell = CGridPageViewCell:new()
--        TuiManager:getInstance():parseCell(pCell, "cell_shop", PATH_MAINWND)
--        pCell.imgBg = pCell:getChildByTag( Tag_mainwnd.IMG_SHOPPACK )     
--        pCell.btn =  pCell:getChildByTag( Tag_mainwnd.BTN_CELLSHOP )     
--        pCell.btn:setOnClickScriptHandler( BtnCellShopClick )
----        table.insert(mStageHeadList, pCell)
--	end
--    if shopObj == nil then
--        pCell:setVisible(false)
--        return pCell
--    end

--    pCell.imgBg:setTexture("mainwnd/img_Pack_"..shopObj.ItemsID..".png")
--    pCell:setVisible(true)    
--    pCell.shopObj = shopObj
--    pCell.packId = shopObj.ItemsID
--    pCell.idx = idx
--	return pCell
--end

--进入场景
function MainWindow:onEnterScene()
    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then
        --资源加载完了
        if MainWindow.isLoadendRes == true then
            if loadUI == nil then
                loadUI = EffectManager:createHnyEffect( 100473, { x = 640, y = 360 } )
                
--                loadUI = Hny.HnyParticleEffect:create( 100473, hyNo, nil )
                self:addChild(loadUI)
                EffectManager:startHnyEffect( loadUI )
--                loadUI:start()
            end
        end  
        return
    end
    if loadUI ~= nil then
        loadUI:removeFromParent()
        loadUI = nil
    end

    if NewbieManager:getBolNewbie() == true then
        StoryWindow.isPopAll = true
        MainWindow.isCanShow = false
        replaceScene("StoryWindow")
        return
    end
--    ServMsgTransponder:SMTWarMapNpc("6,7,21")
    --临时 退出之前所有场景
    popAllScene()
    
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_MAINWND)
    
    self:initLayout()
    --------------------------按钮-------------------------------------    
    --荣誉按钮
    local btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_HONOUR)
    btn:setOnClickScriptHandler(HonourClick)

    --个人信息按钮
    btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_MYINFO)
    btn:setOnClickScriptHandler(MyInfoClick)

    --任务按钮
    btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_QUEST)
    btn:setOnClickScriptHandler(QuestClick)

    --好友按钮
    btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_FRIEND)
    btn:setOnClickScriptHandler(FriendClick)

    --设置按钮
    btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_SET)
    btn:setOnClickScriptHandler(SetClick)
    btn:setOnLongClickScriptHandler( clickLongSetClick )

    --金币按钮
    btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_GOLD)
    btn:setOnClickScriptHandler(GoldClick)

    --圣石按钮
    btn = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_STONE)
    btn:setOnClickScriptHandler(StoneClick)

    --对战分页按钮
    img_BattleTab = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_BATTLETAB)
    img_BattleTab:setTouchEnabled(true)
    img_BattleTab:setOnClickScriptHandler(BattleTabClick)

    --商店分页按钮
    img_StoreTab = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_STORETAB)
    img_StoreTab:setTouchEnabled(true)
    img_StoreTab:setOnClickScriptHandler(StoreTabClick)

    --开包界面
    btn_Summon = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_SUMMON)
    btn_Summon:setOnClickScriptHandler(SummonClick)

    --收藏按钮
    btn_Collect = mLayoutMain:getChildByTag(Tag_mainwnd.BTN_COLLECT)
    btn_Collect:setOnClickScriptHandler(CollectClick)

    --休闲按钮
    btn_Casual = mLayoutMiddleCasual:getChildByTag( Tag_mainwnd.BTN_CASUAL ) 
    btn_Casual:setOnClickScriptHandler(CasualClick)
    btn_Casual:setAlphaTouchEnable(true) --设置透明区域不能点击
    --对战按钮
    btn_Battle = mLayoutMiddleBattle:getChildByTag( Tag_mainwnd.BTN_BATTLE )
    btn_Battle:setOnClickScriptHandler(BattleClick)
    btn_Battle:setAlphaTouchEnable(true)
    --冒险按钮
    btn_Adventure = mLayoutMiddleAdventure:getChildByTag( Tag_mainwnd.BTN_ADVENTURE )
    btn_Adventure:setOnClickScriptHandler(TrialsClick)
    btn_Adventure:setAlphaTouchEnable(true)

    btn_PackGold = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.BTN_SHOP_GOLD )
    btn_PackGold:setOnClickScriptHandler(BtnPackGoldClick)

    btn_PackStone = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.BTN_SHOP_STONE )
    btn_PackStone:setOnClickScriptHandler(BtnPackStoneClick)

    img_MidBuy = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.IMG_MIDBUY )
    btn_MidBuy = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.BTN_MIDBUY  )
    btn_MidBuy:setOnClickScriptHandler(BtnMidBuyClick)
    mTxtMidBuy = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.LABBMF_MIDBUY )

    btn_shopup = mLayoutMiddleShop:getChildByTag(Tag_mainwnd.BTN_SHOPUP)
    btn_shopup:setOnClickScriptHandler(BtnShopUpClick)
    btn_shopdown = mLayoutMiddleShop:getChildByTag(Tag_mainwnd.BTN_SHOPDOWN)
    btn_shopdown:setOnClickScriptHandler(BtnShopDownClick)
--    mTxtMidBuy:setAlignment(0, 1)

    img_MidBuy:setVisible(false)
    btn_MidBuy:setVisible(false)
    mTxtMidBuy:setVisible(false)

    mTxt_PackGold = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.LABBMF_BITFONTBUYGOLD )
    mTxt_PackStone = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.LABBMF_BITFONTBUGGEM )
    mTxt_PackDesc = mLayoutMiddleShop:getChildByTag( Tag_mainwnd.LABEL_SHOP_DESC )

    mPackSelEffect = EffectManager:createHnyEffect( 100916, {x = 153, y = 187} )    
    mPackSelEffect:retain()
    EffectManager:startHnyEffect( mPackSelEffect )

    mPackSelEffect2 = EffectManager:createHnyEffect( 101032, {x = 153, y = 187} )    
    mPackSelEffect2:retain()
--    mLayoutShopSmall:addChild(mPackSelEffect2, -1)
    EffectManager:startHnyEffect( mPackSelEffect2 )

    mListShop = mLayoutMiddle:getChildByTag( Tag_mainwnd.LIST_SHOP )  
    mListShop:setDirection(0) 
        print("f dsa "..mListShop:getPositionX()..","..mListShop:getPositionY())

--    mListShop:setDataSourceAdapterScriptHandler(gpvShopClick)
    mListShop:removeAllNodes()
    mListShop:initWithSize( cc.size(900, 370) )
    mListShop:setPosition(640, 465)
    mListShop:setDragable(false)
    mListShop:setOnScrollingScriptHandler(onScroll)
        ------------------------按钮-------------------------------------//

    --圣石
    stoneTxt = mLayoutMain:getChildByTag(Tag_mainwnd.LABBMF_BITFONTGEM)
    --金币
    goldTxt = mLayoutMain:getChildByTag(Tag_mainwnd.LABBMF_BITFONTGOLD)
    --荣誉
    HonourTxt = mLayoutMain:getChildByTag(Tag_mainwnd.LABBMF_BITFONTHONOUR)
    --等级
    LvTxt = mLayoutMain:getChildByTag(Tag_mainwnd.LABBMF_BITFONTLV)

    mTxtSummonNum = mLayoutMain:getChildByTag(Tag_mainwnd.LABBMF_BITFONT02)
    mTxtSummonNum:setString("")
    mImgSummonNum = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_SUMMON_NUM)
    mImgSummonNum:setVisible(false)

    mTxtCollectNum = mLayoutMain:getChildByTag(Tag_mainwnd.LABBMF_BITFONT01)
    mTxtCollectNum:setString("")
    mImgCollectNum = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_COLLECT_NUM)
    mImgCollectNum:setVisible(false)

    MainWindow.mTxtFriendNum = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_FRIEND_NUM)
    --mTxtFriendNum:setString("")
    MainWindow.mTxtFriendNum:setVisible(false)

    mRankIcon = mLayoutMain:getChildByTag(Tag_mainwnd.IMG_RANKICON)

    updateTab()
    self:updatamsg()
    self:updataShopMsg()
    self:UpDataShopListMsg()
    self:updataSummonMsg()
    self:updataCollectMsg()
    self:updataRankMsg()    
    updateShopSelect()

    local mBg = __instance:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.IMG_BG)
    mBg:setLocalZOrder(-1)

    local mMapEffect = EffectManager:createHnyEffect( 100968, {x = 0, y = 0})--{x = 640, y = 360} )    
    window:addChild(mMapEffect, -1)
    EffectManager:startHnyEffect( mMapEffect )

    MusicManager:PlaySound( 1 )
    MainWindow.isShow = true
        
    if NewbieManager.UseData.CollectionPre2nd == false then
        NewbieWindow:setAndShowType("CollectionPre2nd")
        return
    end
    ----------------------------不是要做新手任务才继续执行下面的---------------------------

    if MainWindow.mFirstCome == true then
        MainWindow.mFirstCome = false
        if UserDefaultManager:getStringForKey( "LadderReward" ) ~= "" then
            local honour = tonumber(UserDefaultManager:getStringForKey( "LadderReward" ))
            if honour > 0 then RunScene("LadderRewardWindow") end
        else
            TaskWindow.open = true
            ServMsgTransponder:SMTDailyOpen()     
        end           
        war2CardManager:setXianjiCardList( false )--清空临时保存的献祭卡组
    end
    if UserDefaultManager:getStringForKey( "LadderReward" ) ~= "" and UserDefaultManager:getStringForKey( "LadderReward" ) ~= "0" then
        local honour = tonumber(UserDefaultManager:getStringForKey( "LadderReward" ))
        if honour > 0 then RunScene("LadderRewardWindow") end
    elseif #TaskManager.RewardDataList > 0 then
        RunScene("RewardWindow")
    elseif TaskManager.BolOpenMainTask == true then
        RunScene("TaskWindow")
    end
    ServMsgTransponder:SMTShopOpen()    --向后台请求卡包数量 

end

function MainWindow:UpDataShopListMsg()
    mListShop:removeAllNodes()
    mShopCellList = {}
    local char = CharacterManager:getMainPlayer()
    if char.BuyNewGift == 1 then
        table.removebyvalue(mShopItemList, 300000, true) --table.removebyvalue(array, value, removeall)
    end        
    local len = #mShopItemList
    local shopObj
    for i=1, len do
        shopObj = ShopManager:getShopData( 1, mShopItemList[i] )	
        MainWindow:insertItemToShopList(shopObj)
    end
    mListShop:reloadData()

    mShopCurIdx = 1
    BtnCellShopClick(mShopCellList[mShopCurIdx].btn)
    mListShop:setContentOffsetToLeft()
end

function MainWindow:onExitScene()
    mShowType = 1
    MusicManager:StopMusic( 1 )
    UILoadManager:delResByArr( resArr )
    MainWindow.isShow = false
    MainWindow.isCanShow = false
    loadUI = nil
    mBolPlaying = false

    mShopCellList = {}
    mShopCurIdx = 1

    if mPackSelEffect and tolua.isnull(mPackSelEffect) == false then
        mPackSelEffect:release()
    end
    mPackSelEffect = nil
    if mPackSelEffect2 and tolua.isnull(mPackSelEffect2) == false then
        mPackSelEffect2:release()
    end
    mPackSelEffect2 = nil
end