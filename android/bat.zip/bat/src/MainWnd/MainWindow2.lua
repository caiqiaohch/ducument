require "tagMap.Tag_mainwnd"

local window  =	nil
--荣誉按钮
local btn_Honour = nil
--金币按钮
local btn_gold = nil
--圣石按钮
local btn_stone = nil
--钥匙按钮
local btn_key = nil
--下拉按钮
local btn_down = nil
--收起按钮
local btn_up = nil
--设置按钮
local btn_set = nil
--聊天按钮
local btn_chat = nil
--个人信息按钮
local btn_myinfo = nil
--朋友按钮
local btn_friend = nil
--手集按钮
local btn_Collect = nil
--竞技场按钮
local btn_Trials = nil
--对战按钮
local btn_Battle = nil
--商店按钮
local btn_Store = nil
--任务按钮
local btn_Quest = nil
--圣石文本
local stoneTxt = nil
--金币文本
local goldTxt = nil
--荣誉文本
local HonourTxt = nil
--钥匙文本
local keyTxt = nil
--背景音乐
local mBGMusic = nil

--卡包数量文本
local mTxtSummonNum
--卡包数量背景图
local mImgSummonNum

--新手npc地图
local mImgNewbieMap
--npc头像层
local mLayoutNpc
--NPC头像列表
local mNpcImgList = nil


MainWindow = class("MainWindow",function()
	return TuiBase:create()
end)

--要预加载的资源列表
local resArr = { PLIST_MAIN_URL }

local __instance = nil
local CharacterManager = require("characters.CharacterManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local EffectManager = require("ui.EffectManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()

--是否显示主界面
MainWindow.isShow = false
--是否加载完成资源
MainWindow.isLoadendRes = false
--是否可以显示主界面
MainWindow.isCanShow = false
--是否第一次进入
MainWindow.mFirstCome = true

function MainWindow:create()
	local ret = MainWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
--    local mBGMusic = MusicManager:getMusic(1)
--    AudioEngine.preloadEffect(mBGMusic)
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
   -- ret:setOnEnterSceneScriptHandler(function() ret:onEnterScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function MainWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function MainWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--荣誉点击事件
local function HonourClick(p_sender)
    RunScene("LadderRankWindow")
	
end

--金币点击事件
local function GoldClick(p_sender)
    local ShopManager = require("Shop.ShopManager"):instance()
    ShopManager.CurGoodsType = 1
    RunScene("ShopGoodsWindow")
end

--圣石点击事件
local function StoneClick(p_sender)
    local ShopManager = require("Shop.ShopManager"):instance()
    ShopManager.CurGoodsType = 2
    RunScene("ShopGoodsWindow")
end

----钥匙点击事件
--local function KeyClick(p_sender)
--    print("Key")
--end

--下拉点击事件
local function DownClick(p_sender)
    print("Down")
    local MovMove1 = require("Mov.MovMove").new()
--    local MovMove2 = require("Mov.MovMove").new()
--    local MovMove3 = require("Mov.MovMove").new()
    local MovMove4 = require("Mov.MovMove").new()
    if btn_up:isVisible() == false then
        local posX = btn_myinfo:getPositionX()
        local posY = btn_myinfo:getPositionY() - 100
        MovMove1:init(btn_myinfo, false, posX, posY, 100, 1)
--        MovMove2:init(btn_friend, false, posX, posY - 90, 100, 1) --这两个按钮都先隐藏掉
--        MovMove3:init(btn_chat, false, posX, posY - 180, 100, 1)
        MovMove4:init(btn_set, false, posX, posY - 90, 100, 1)
        btn_up:setVisible(true)
    else
        MovMove1:init(btn_myinfo, false, btn_down:getPositionX(), btn_down:getPositionY(), 100, -1)
--        MovMove2:init(btn_friend, false, btn_down:getPositionX(), btn_down:getPositionY(), 100, -1) --这两个按钮都先隐藏掉
--        MovMove3:init(btn_chat, false, btn_down:getPositionX(), btn_down:getPositionY(), 100, -1)
        MovMove4:init(btn_set, false, btn_down:getPositionX(), btn_down:getPositionY(), 100, -1)
        btn_up:setVisible(false)
    end
    MovManager:pushMov( MovMove1 )
--    MovManager:pushMov( MovMove2 )
--    MovManager:pushMov( MovMove3 )
    MovManager:pushMov( MovMove4 )
end

--设置点击事件
local function SetClick(p_sender)
    print("set")
    RunScene("MainSetWindow")
end


--人物界面点击事件
local function MyInfoClick(p_sender)
    print("MyInfoClick")
    RunScene("CharacterWindow")
end

--聊天点击事件
local function ChatClick(p_sender)
    print("chat")
    if true then return end
    RunScene("OpenBoxWindow")
end

local mNumid = 0

--好友点击事件
local function FriendClick(p_sender)
    print("friend")
    if true then return end
    local mTask = require("ChestRewardWnd.ChestRewardWindow").new()
    window:addChild(mTask)
    mTask:init()
end

--收集点击事件
local function CollectClick(p_sender)
    print("Collect")
    RunScene("CollectionWnd")
end

--开包点击事件
local function SummonClick(p_sender)
    print("OpenPackWindow")
    RunScene("OpenPackWindow")
end

--竞技场点击事件
local function TrialsClick(p_sender)
    if true then 
        require("prompt.PromptManager"):instance():SetNotice( 4005 )    --暂未开放
        return 
    end  
    print("Trials")
end

--对战点击事件
local function BattleClick(p_sender)
    print("Battle")
    FightWnd:set_battleNpc(nil)
    RunScene("FightWnd")
end

--商店点击事件
local function StoreClick(p_sender)
    RunScene("ShopWindow")
    print("Honour")
end

--任务点击事件
local function QuestClick(p_sender)
    print("Quest")
    TaskWindow.open = true
    ServMsgTransponder:SMTDailyOpen()
end

--npc点击事件
local function NpcClick(p_sender)
    local name = p_sender:getName()
    print(name)
    local value = string.split(name,":")
    local npcObj = DataManager:getDataMapNpcbyDi(value[2])
    if npcObj ~= nil and npcObj.my_deck > 0 then
        ServMsgTransponder:SMTWarNPC(value[2])
        return
    end
    FightWnd:set_battleNpc(value[2])
    RunScene("FightWnd")
end

function MainWindow:UpdateNpc()     --npc按钮
    print("-------更新NPC头像---")
    local npcArr =  CharacterManager.mapNpcPosList--:getMapNpc()
    local img_npc
    local npcObj
    if npcArr == nil then return end
    for i = 1, 15 do
        img_npc = mNpcImgList[i]  
        img_npc:setVisible(false)      
        if npcArr[i] ~= nil then
            npcObj = DataManager:getDataMapNpcbyDi(npcArr[i])
        else
            npcObj = nil
        end
        if npcObj ~=nil then
            img_npc:setName("NPC:"..npcArr[i])
            if img_npc.headPic == nil then 
                img_npc.headPic = cc.Sprite:create()
                img_npc:addChild( img_npc.headPic, -1 )
                img_npc:setTouchEnabled(true)
                img_npc:setOnClickScriptHandler(NpcClick)
                img_npc:setVisible(true)
                img_npc:setScale(0.8)

                if npcObj.npc_id < 7 then   --新手关卡要加上特效             
                    local hyNo = Hny.HnyNode:createWithXY( img_npc:getPositionX(),  img_npc:getPositionY() )
                    local effect = Hny.HnyParticleEffect:create( 100650, hyNo, nil )
                    mLayoutNpc:addChild(effect, -1)
                    effect:start()

                    hyNo = Hny.HnyNode:createWithXY( img_npc:getPositionX(),  img_npc:getPositionY() )
                    effect = Hny.HnyParticleEffect:create( 100651, hyNo, nil )
                    mLayoutNpc:addChild(effect)
                    effect:start()
                end
            end
            img_npc.headPic:setTexture("war2/head/HeadPic"..npcObj.npc_icon..".png")
            img_npc.headPic:setPosition( 64, 64 )
            img_npc.headPic:setScale(0.7)            
            img_npc:setVisible(true)            
        else
            img_npc:setVisible(false)
        end
    end
end


local function event_prog_hp(p_sender, n_value)
    print(n_value)
end

--清除
 function MainWindow:clear( tempSelf )
    for i in pairs(tempSelf.mData) do
        tempSelf.mData[i] = nil
    end
    tempSelf.mData = nil
end

--初始化界面
function MainWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () 
            MainWindow.isLoadendRes = true
            self:onEnterScene() 
        end )
end

--更新信息
function MainWindow:updatamsg()

    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then return end

    local char = CharacterManager:getMainPlayer()
    --圣石
    stoneTxt:setString( char.stone )

    --金币
    goldTxt:setString( char.gold )

    --荣誉
    HonourTxt:setString( char.CharHonour )

    --钥匙
    keyTxt:setString( char.boxkey.."/4" )
    self:UpdateNpc()
    
    -------------------------新手阶段的提示-----------------    
    local npcArr =  CharacterManager.mapNpcPosList
    local bolNewbie = false  --如果有npcid少于5的npc,则表示走新手流程了
    local bolWarNpc = true  --如果没有npcid为1的npc,则表示不需要箭头提示
    for i = 1, 15 do
        if npcArr[i] ~= nil then            
            if tonumber(npcArr[i]) < 7 then
                bolNewbie = true
                if tonumber(npcArr[i]) == 1 then
                    bolWarNpc = false
                end
            end
        end
    end
    if bolNewbie == false then
        if mImgNewbieMap ~= nil then
            mImgNewbieMap:setVisible(false)
        end
    else
        if mImgNewbieMap == nil then
            mImgNewbieMap = CImageView:create()
            mImgNewbieMap:setTexture( "other/img_Background.png" )
            mLayoutNpc:addChild( mImgNewbieMap, -2 )
            mImgNewbieMap:setPosition( mLayoutNpc:getContentSize().width * 0.5 - mLayoutNpc:getPositionX(), mLayoutNpc:getContentSize().height * 0.5 - mLayoutNpc:getPositionY() )--mLayoutNpc:getPositionX(),  360-mLayoutNpc:getPositionY() )
        end
        mImgNewbieMap:setVisible(true)
    end
    NewbieManager.UseData.WarNpc = bolWarNpc
    -------------------------新手阶段的提示-----------------    
end

--更新卡包数量信息
function MainWindow:updataSummonMsg()
    local num = 0
    for i = 100, 102 do
        if CollectionManager:getHasPackNum( i ) > 0 then
            num = num + CollectionManager:getHasPackNum( i )
        end
    end
    if num > 0 then
        mTxtSummonNum:setString(num)
        mImgSummonNum:setVisible(true)
    else
        mTxtSummonNum:setString("")
        mImgSummonNum:setVisible(false)
    end
end


--加载界面
local loadUI = nil
--手动进入场景
function MainWindow:onHandEnterScene()
    if __instance == nil then return end
    __instance:onEnterScene()

    --协议、资源都加载完成
    if MainWindow.isCanShow == true and MainWindow.isLoadendRes == true then
        local mov = require("Mov.MovAlpha").new()
        local mBg = __instance:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.IMG_BG)
        mBg:setOpacity(0)
        mov:init( mBg, 255, 17 )
        require("Mov.MovManager"):instance():pushMov( mov )
    end
end
--进入场景
function MainWindow:onEnterScene()
    --没收完协议 没加载完资源
    if MainWindow.isCanShow == false or MainWindow.isLoadendRes == false then
        --资源加载完了
        if MainWindow.isLoadendRes == true then
            if loadUI == nil then
                local hyNo = Hny.HnyNode:createWithXY( 640, 360 )
                loadUI = Hny.HnyParticleEffect:create( 100473, hyNo, nil )
                self:addChild(loadUI)
                loadUI:start()
            end
        end  
        return
    end
    if loadUI ~= nil then
        loadUI:removeFromParent()
        loadUI = nil
    end
    
    --临时 退出之前所有场景
    popAllScene()
    
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_MAINWND)
    
    window = self:getPanel(Tag_mainwnd.PANEL_MAIN)
    --------------------------按钮-------------------------------------
    
    --荣誉按钮
    btn_Honour = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_HONOUR)
    btn_Honour:setOnClickScriptHandler(HonourClick)

    --金币按钮
    btn_gold = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_GOLD)
    btn_gold:setOnClickScriptHandler(GoldClick)

    --圣石按钮
    btn_stone = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_STONE)
    btn_stone:setOnClickScriptHandler(StoneClick)

    --钥匙按钮
    btn_key = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_KEYMC)
--    btn_key:setOnClickScriptHandler(KeyClick)
    btn_key:setEnabled(  false);

    --下拉按钮
    btn_down = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_DOWN)
    btn_down:setOnClickScriptHandler(DownClick)

    --收起按钮
    btn_up = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_UP)
    btn_up:setOnClickScriptHandler(DownClick)
    btn_up:setVisible(false)

    --设置按钮
    btn_set = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_SET)
    btn_set:setOnClickScriptHandler(SetClick)

    --个人信息按钮
    btn_myinfo = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_MYINFO)
    btn_myinfo:setOnClickScriptHandler(MyInfoClick)


    --聊天按钮
    btn_chat = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_CHAT)
    btn_chat:setOnClickScriptHandler(ChatClick)

    --好友按钮
    btn_friend = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_FRIEND)
    btn_friend:setOnClickScriptHandler(FriendClick)
   
    --收藏按钮
    btn_Collect = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_COLLECT)
    btn_Collect:setOnClickScriptHandler(CollectClick)

    --开包界面
    btn_Summon = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_SUMMON)
    btn_Summon:setOnClickScriptHandler(SummonClick)

    --竞技场按钮
    btn_Trials = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_TRIALS)
    local img = btn_Trials:getNormalImage()
    btn_Trials:setOnClickScriptHandler(TrialsClick)
--    EffectManager:setGrayFilter( btn_Trials, true, true )

    --对战按钮
    btn_Battle = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_BATTLE)
    btn_Battle:setOnClickScriptHandler(BattleClick)

    --商店按钮
    btn_Store = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_STORE)
    btn_Store:setOnClickScriptHandler(StoreClick)

    --任务按钮
    btn_Quest = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_QUEST)
    btn_Quest:setOnClickScriptHandler(QuestClick)

    --宝箱按钮
    mBox = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.BTN_BOX)
    mBox:setOnClickScriptHandler(BoxClick)
    mBox:setVisible(false)

    --圣石
    stoneTxt = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.STONETXT)
    --金币
    goldTxt = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.GOLDTXT)
    --荣誉
    HonourTxt = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.HONOURTXT)
    --钥匙
    keyTxt = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.KEYTXT)

    mTxtSummonNum = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.LABEL_SUMMON_NUM)
    mTxtSummonNum:setString("")
    mImgSummonNum = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.IMG_SUMMON_NUM)
    mImgSummonNum:setVisible(false)
    ------------------------按钮-------------------------------------//
    mNpcImgList = {}
    mLayoutNpc = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.LAYOUT_NPC)
    for i = 1, 15 do
        mNpcImgList[i] = mLayoutNpc:getChildByTag(Tag_mainwnd["IMG_NPC"..i])--self:getControl(Tag_mainwnd.LAYOUT_NPC,Tag_mainwnd["IMG_NPC"..i])
    end
    
    self:updatamsg()
    self:updataSummonMsg()

    MusicManager:PlaySound( 1 )
    MainWindow.isShow = true

    if NewbieManager.UseData.WarNpc == false then
        NewbieManager.CurState = 1
        NewbieWindow:setAndShowType("WarNpc")

        --地图特效
        local hyNo = Hny.HnyNode:createWithXY( mLayoutNpc:getContentSize().width * 0.5, mLayoutNpc:getContentSize().height * 0.5 )
        local effect = Hny.HnyParticleEffect:create( 100649, hyNo, nil )   
        mLayoutNpc:addChild(effect, -1)--新手的话特效add在这里
        effect:start()
        return 
    else
        --地图特效
        local hyNo = Hny.HnyNode:createWithXY( 640, 360 )
        local effect = Hny.HnyParticleEffect:create( 100649, hyNo, nil )   
        local bg = self:getControl(Tag_mainwnd.PANEL_MAIN,Tag_mainwnd.IMG_BG)--不是新手的话特效add在这里
        bg:addChild(effect)
        effect:start()      
    end

    
    ----------------------------不是要做新手任务才继续执行下面的---------------------------
    if MainWindow.mFirstCome == true then
        require("net.ServMsgTransponder"):SMTDailyOpen()
        MainWindow.mFirstCome = false
    end
    if #TaskManager.RewardDataList > 0 then
        RunScene("RewardWindow")
    elseif TaskManager.BolOpenMainTask == true then
        RunScene("MainTaskWindow")
    end
    ServMsgTransponder:SMTShopOpen()    --向后台请求卡包数量
end

function MainWindow:onExitScene()
    MusicManager:StopMusic( 1 )
    UILoadManager:delResByArr( resArr )
    MainWindow.isShow = false
    MainWindow.isCanShow = false
    loadUI = nil
    mNpcImgList = {}
    mImgNewbieMap = nil
end