require "tagMap.Tag_puzzle"
local DataManager = require("data.DataManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local TaskManager = require("TaskWnd.TaskManager"):instance()

local __instance = nil
local window

--背景底图
local mImgBg

--关卡列表左按钮
local mBtnLeft
--关卡列表右按钮
local mBtnRight
local mTxtTitle
--底下小关卡menu列表
local mImgMenuList = {}

--关卡分页列表
local mGpvHead
local mStageHeadList= {}

--当前选中的关卡
local mCurNpcId = 1
--所属的关卡
local mCurStageId = 1
--头像Cell列表
local mStageCellList = {}

--上次的解谜关卡
local mLastPuzzleId = 0

--背景图
local mImgBg

local resArr = { PLIST_PUZZLE_URL }

PuzzleWindow = class("PuzzleWindow",function()
	return TuiBase:create()
end)

--是否之前已经退出所有场景,一般从战场退出的时候为true
PuzzleWindow.isPopAll = false

PuzzleWindow.isShow = false

function PuzzleWindow:create()
	local ret = PuzzleWindow.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)

	return ret
end

function PuzzleWindow:getPanel(tagPanel)
	return self:getChildByTag(tagPanel)
end

function PuzzleWindow:getControl(tagPanel,tagControl)
	return self:getPanel(tagPanel):getChildByTag(tagControl)
end


--跳到解锁关卡的那一页并选中
local function gotoTheNpc(stageId)
    print(stageId)
    local curNpcId = CharacterManager.stageNpcList[stageId]  --当前关卡已经解锁的NPCID
    local idx = 1
    local dataList = DataManager:getDataMapCampList( mCurStageId )
    local npcObj
    for i = 1, #dataList do
        npcObj =  dataList[i]
        if curNpcId == npcObj.npc_id then
            idx = math.ceil( i/6 ) - 1
            break
        end
    end

    mCurHeadNpcId = curNpcId  

    if idx > 0 then
        print(idx)
        local _x = mGpvHead:getContentOffset().x
        local _w = mGpvHead:getContentSize().width * idx
        local num = _x - _w 
        if num > 0 then num = 0 end
        mGpvHead:setContentOffsetInDuration( cc.p( num, 0 ), 0 )
    else
        mGpvHead:setContentOffsetInDuration( cc.p( 0, 0 ), 0 )
    end
end

--点击关闭事件
local function BtnCloseClick(p_sender)
    if PuzzleWindow.isPopAll == true then
        if MainWindow.isCanShow == true then
            PopScene(__instance)
        else
            MainWindow.isCanShow = true
            replaceScene("MainWindow")
        end
    else
        PopScene(__instance)
        MusicManager:PlaySound( 1 )
    end
end

--左点击事件
local function BtnLeftClick(p_sender)
    local _x = mGpvHead:getContentOffset().x
    local _w = mGpvHead:getContentSize().width
    if _x % _w ~= 0 or _x == 0 then return end
    mGpvHead:setContentOffsetInDuration( cc.p( _x + _w, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )  
    
    if mImgBg:getPositionX() == (mImgBg:getContentSize().width - 1280)* 0.5  then return end
    local nX = (mImgBg:getContentSize().width - 1280)* 0.5 - mImgBg:getPositionX() 
    local oldY = mImgBg:getPositionY()
    local age_MB = cc.EaseCubicActionOut:create(cc.MoveBy:create( 0.8, cc.p(nX, oldY)))
    local age_SQ = cc.Sequence:create(age_MB)
    mImgBg:runAction(age_SQ)
end

--右点击事件
local function BtnRightClick(p_sender)
    print( mGpvHead:getContentSize().width..","..mGpvHead:getContentSize().height)
    local _x = mGpvHead:getContentOffset().x
    local _w = mGpvHead:getContentSize().width
    if  _w - _x >= mGpvHead:getContainerSize().width then return end
--    if _x % _w ~= 0 or _x <= -( mCardGpvPage - 1 ) * _w then return end
    mGpvHead:setContentOffsetInDuration( cc.p( _x - _w, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )  

--    mImgBg:setPositionX( -(mImgBg:getContentSize().width - 1280) * 0.5 )
--    if true then return end

    if mImgBg:getPositionX() == -(mImgBg:getContentSize().width - 1280) * 0.5 then return end
    local nX = -(mImgBg:getContentSize().width - 1280) * 0.5 - mImgBg:getPositionX() 
    local oldY = mImgBg:getPositionY()
    local age_MB = cc.EaseCubicActionOut:create(cc.MoveBy:create(1, cc.p(nX, oldY)))
    local age_SQ = cc.Sequence:create(age_MB)
    mImgBg:runAction(age_SQ)

--    mImgBg:setPositionX( -(mImgBg:getContentSize().width - 1280)* 0.5)
end

local function BtnHeadIconClick(p_sender)
    print("BtnHeadIconClick")    
    mLastPuzzleId = p_sender.npcId
    if p_sender.lockId == 0 then return end
    mCurHeadNpcId = p_sender.npcId
    local npcObj = DataManager:getDataMapNpcbyDi(p_sender.npcId)
    if npcObj == nil then return end
    if npcObj.my_deck > 0 then --不需要选卡组的
        ServMsgTransponder:SMTWarNPC( p_sender.npcId, CharacterManager:checkNpcWin(p_sender.npcId) )
        return
    end
    FightWnd:setAndShowType( WAR2_TYPE_STORY, p_sender.npcId )
end

local function onMenuClick(p_sender)
    print("onMenuClick")    
    if mCurStageId == p_sender.stageId then return end
    mCurStageId = p_sender.stageId
    for i = 1, 4 do
        if mImgMenuList[i].stageId == mCurStageId then
            mImgMenuList[i]:setSpriteFrame("puzzle/img_PuzzleMenuItem+"..i.."_select.png")
            mImgBg:setTexture("puzzle/puzzleplant/img_PuzzleBg+"..i..".png")--"puzzle/puzzleplant/"..".png")
            mImgBg:setPositionX( (mImgBg:getContentSize().width - 1280)* 0.5 )
        else
            mImgMenuList[i]:setSpriteFrame("puzzle/img_PuzzleMenuItem+"..i.."_normal.png")
        end 
    end
    
    PuzzleWindow:UpDataHeadMsg()
    gotoTheNpc(mCurStageId)
end


--play按钮点击事件
local function BtnPlayClick(p_sender)
    print("npcplay "..mCurHeadNpcId)
    local npcObj = DataManager:getDataMapNpcbyDi(mCurHeadNpcId)
    if mCurHeadNpcId == 0 or npcObj == nil then return end
    if npcObj.my_deck > 0 then --不需要选卡组的
        ServMsgTransponder:SMTWarNPC( mCurHeadNpcId, CharacterManager:checkNpcWin(mCurHeadNpcId) )
        return
    end
    FightWnd:setAndShowType( WAR2_TYPE_PUZZLE, mCurHeadNpcId )
end

--初始化界面
function PuzzleWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end



--是否还是锁定状态 0:未解锁 1:解锁 2:打败了
local function bolNpcLock( npcId, stageId )
    local curNpcId = CharacterManager.stageNpcList[stageId]  --当前关卡已经解锁的NPCID,npcId比它大的表示还没解锁
    if curNpcId == nil then 
        curNpcId = 0 
    end  --未解锁关卡会为nil
    if curNpcId < npcId then
        return 0
    else
        if CharacterManager:checkNpcWin( npcId ) == 2 then
            return 2
        end
        return 1
    end
    return 0
end

--local function updateHeadIcon(pCell)
--    local sidx = mCurStageId - 99
--    local lockId = bolNpcLock(npcObj.npc_id, mCurStageId) 

--    if lockId == 0 then
--        pCell.imgBg:setSpriteFrame("puzzle/img_PuzzleItem+"..sidx.."_lock.png")
--    elseif lockId == 1 then
--        pCell.imgBg:setSpriteFrame("puzzle/img_PuzzleItem+"..sidx.."_select.png")
--    elseif lockId == 2 then
--        pCell.imgBg:setSpriteFrame("puzzle/img_PuzzleItem+"..sidx.."_win.png")
--    end
--end

--头像拖动设置
local function gpvHeadClick(p_convertview, idx)
	local pCell = p_convertview
    idx = idx + 1
    local dataList = DataManager:getDataMapCampList( mCurStageId )
    local npcObj =  dataList[idx]
	if pCell == nil then
        pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell(pCell, "cell_npc", PATH_PUZZLE)
        pCell.imgHeadIcon = pCell:getChildByTag( Tag_puzzle.IMG_HEADICON )
        pCell.imgHeadBg = pCell:getChildByTag( Tag_puzzle.IMG_PUZZLEITEMFACE )
        pCell.imgBg = pCell:getChildByTag( Tag_puzzle.IMG_PUZZLEITEM )     
        pCell.btn =  pCell:getChildByTag( Tag_puzzle.BTN_CELL_HEAD )     
        pCell.btn:setOnClickScriptHandler( BtnHeadIconClick )
        table.insert(mStageHeadList, pCell)
	end
    if npcObj == nil or npcObj.npc_icon == 0 then
        pCell:setVisible(false)
        return pCell
    end
    pCell.imgHeadIcon:setVisible(true)
    pCell.imgHeadBg:setVisible(true)

    local sidx = mCurStageId - 99
    local lockId = bolNpcLock(npcObj.npc_id, mCurStageId) 

    if lockId == 0 then
        pCell.imgBg:setSpriteFrame("puzzle/img_PuzzleItem+"..sidx.."_lock.png")
        pCell.imgHeadIcon:setVisible(false)
        pCell.imgHeadBg:setVisible(false)
    elseif lockId == 1 then
        pCell.imgBg:setSpriteFrame("puzzle/img_PuzzleItem+"..sidx.."_select.png")
    elseif lockId == 2 then
        pCell.imgBg:setSpriteFrame("puzzle/img_PuzzleItem+"..sidx.."_win.png")
    end
    pCell.lockId = lockId
    pCell.imgHeadIcon:setTexture("war2/head/HeadPic"..npcObj.npc_icon..".png")
    pCell:setVisible(true)    
    pCell.npcObj = npcObj
    pCell.btn.npcId = npcObj.npc_id
    pCell.btn.lockId = lockId
	return pCell
end

function PuzzleWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_PUZZLE)

    window = self:getChildByTag(Tag_puzzle.PANEL_MAIN)

    mImgBg = cc.Sprite:create()
    window:addChild(mImgBg, -1)

--    mImgBg = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle.IMG_BG)
--    mImgBg:setTouchEnabled(true)
    mBtnLeft = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle.BTN_LEFT)
    mBtnLeft:setOnClickScriptHandler( BtnLeftClick )
    mBtnRight = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle.BTN_RIGHT)
    mBtnRight:setOnClickScriptHandler( BtnRightClick )

    local btn_close = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle.BTN_CLOSE)
    btn_close:setOnClickScriptHandler( BtnCloseClick )    

    mTxtTitle = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle.LABEL_TITLE)
    mTxtTitle:setString(DataManager:getStringDataTxt(25, true))
    
    local txt
    for i = 1, 4 do
        mImgMenuList[i] = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle["IMG_MENU"..i])
        mImgMenuList[i].stageId = 99 + i --所属大关是100~103
        mImgMenuList[i].idx = i
        mImgMenuList[i]:setOnClickScriptHandler( onMenuClick )
        mImgMenuList[i]:setTouchEnabled(true)

        txt = self:getControl(Tag_puzzle.PANEL_MAIN, Tag_puzzle["LABEL_MENU"..i])
        txt:setString(DataManager:getStringDataTxt(4131 + i, true))
        txt:enableOutline(cc.c4b(0,0,0,245), 1)  --对文本进行描边
    end

    mGpvHead = self:getControl(Tag_puzzle.PANEL_MAIN,Tag_puzzle.GPV_NPC)    
    mGpvHead:setDataSourceAdapterScriptHandler(gpvHeadClick)

    local lastNpc = DataManager:getDataMapNpcbyDi(mLastPuzzleId)
    if lastNpc == nil or lastNpc.npc_camp == 100 then
        onMenuClick(mImgMenuList[1])
    elseif lastNpc.npc_camp == 101 then
        onMenuClick(mImgMenuList[2])
    elseif lastNpc.npc_camp == 102 then
        onMenuClick(mImgMenuList[3])
    elseif lastNpc.npc_camp == 103 then
        onMenuClick(mImgMenuList[4])
    else
        onMenuClick(mImgMenuList[1])
    end

    if #TaskManager.RewardDataList > 0 then
        RunScene("RewardWindow")
    end

    PuzzleWindow.isShow = true
    MusicManager:PlaySound( 6 )
end
  
--更新显示上侧头像列表
function PuzzleWindow:UpDataHeadMsg()
    local len = #DataManager:getDataMapCampList( mCurStageId )
    mGpvHead:setCountOfCell( len )
    mGpvHead:reloadData()
    mGpvHead:setBounceable(false) --取消反弹
end
  

function PuzzleWindow:reorderImgBgChild( idx )
    mImgBg:getParent():reorderChild( mImgBg, idx )
end


--关闭界面
function PuzzleWindow:closeWindow()
    BtnCloseClick(nil)
end

  
function PuzzleWindow:onExitScene()
    mCurHeadNpcId = 1
    mCurStageId = 1
    mStageHeadList = {}
    mStageCellList = {}
    mRewardCellList = {}
    UILoadManager:delResByArr( resArr )
    PuzzleWindow.isShow = false
    mBolShowReward = false
end

