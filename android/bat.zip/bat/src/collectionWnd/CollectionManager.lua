local CollectionManager = class()-- 定义一个类 test 继承于 base_type

function CollectionManager:ctor()

	print("CollectionManager:ctor --------------------------")
	
end

require("app.fun")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager"):instance()

--当前显示数组  --筛选后剩下来的数组
local mShowCardArr = {}

------------筛选参数--------------
--是否只显示圣物
local BolShowEq = false
--是否显示未拥有卡牌
local mBolShowAll = false

--费用筛选 当前选择的费用
local mSiftCostList = {}
--阵营派系筛选
local mSiftRaceList = {}
--卡牌种类类型筛选
local mSiftTypeList = {}
--卡牌稀有度筛选
local mSiftQltList = {}

--单/多色阵营派系筛选
local mSiftSingleRaceList = {}
local mVersionList = { {1, 100}, {21,22,23,24,25,26,27,28} }
--卡牌版本筛选
local mSiftVersionList = {}

--当前筛选文字
local mSiftStr = ""
------------筛选参数--------------



------------当前拥有卡牌更全部拥有卡牌主要是区分筛选-----
--当前拥有卡牌
local mHasCardArr = {}
--全部卡牌数组
local mAllCardArr = {}
--当前编辑中的套牌数组ID
local CurGroupID = 0
--当前编辑中的套牌圣物数组[卡牌表的data]
local CurGroupEquipArr = {}
--当前编辑中的套牌普通卡牌数组[ data = 卡牌表的data, num = 卡牌数量]
local CurGroupCardArr = {}

--编辑套牌中各卡牌的数量 [卡牌ID][卡片数量]
local CurGroupCardNumArr = {}
--编辑套牌中图鉴卡组显示的牌组数量 [卡牌ID][卡片数量] 即你总共拥有的卡牌减去套牌中的卡牌数量
local CurGpvCardNumArr = {}
----------------------------------------套牌(卡组)编辑------------------------------

--------------------------------玩家拥有的卡牌,卡组数据  从character移过来9.19--------------------
--玩家全部卡组数据列表
local mCardGroupList = {}
--玩家拥有卡牌数组
local mAllHasCardList = {}
--记录玩家得到的新卡牌数组
local mNewCardList = {}
--玩家拥有的卡包的数组
local mAllCardPackArr = {}
--------------------------------玩家拥有的卡牌,卡组数据  从character移过来9.19--------------------

--玩家最多可以拥有多少套卡组
CollectionManager.DECK_NUM = 16

--是否保存了卡组
local mIsSaveDeck = true

--向后台发送请求请求,1~6,每次后台会从1401返回id区间为0~200,200~400...的卡牌数据
local mSendOpenId = 1
local mSendOpenIdTimer

function CollectionManager:getIsSaveDeck()
    return mIsSaveDeck
end

function CollectionManager:setIsSaveDeck(bol)
    mIsSaveDeck = bol
end

--按顺序排卡组卡牌
local function CardGroupSort(obj1, obj2)
    if obj1.data.cost < obj2.data.cost then
        return true
    elseif obj1.data.cost > obj2.data.cost then
        return false
    end
    return obj1.data.id < obj2.data.id
end

--按稀有度（品质）排卡组卡牌
local function CardGroupSortByQlt(obj1, obj2)
    if obj1.data.qlt > obj2.data.qlt then
        return true
    elseif obj1.data.id < obj2.data.id then
        return false
    end
    return false
end

---------------------------------------------------------------------------
--开启第9栏	2000金币
--开启第10栏	4000金币
--开启第11栏	7000金币
--开启第12栏	10000金币
--开启第13栏	1000宝石
--开启第14栏	2000宝石
--开启第15栏	4000宝石
--开启第16栏	7000宝石
--解锁新的组牌位置
function CollectionManager:buyNewGroup()
    local char = CharacterManager:getMainPlayer()
    local curDeckNum = char.deckNum
    if curDeckNum >= 16 then return end
    local costList = {2000, 4000, 7000, 10000, 1000, 2000, 4000, 7000}
    local costNum = costList[curDeckNum - 7]
    local money = char.gold  --
    if curDeckNum >= 12 then
        if costNum > char.stone then
            require("framework.scheduler").performWithDelayGlobal( function() require("prompt.PromptManager"):instance():ShowByType(4111) end, 0.2 ) --你的宝石不足
            return
        end
    else
        if costNum > char.gold then
            require("framework.scheduler").performWithDelayGlobal( function() require("prompt.PromptManager"):instance():ShowByType(4110) end, 0.2 )  --你的金币不足
            return
        end
    end
    ServMsgTransponder:SMTShopBuy( 4, 1, 0, 0 )
end

local function getBuyTxtId()
    local curDeckNum = CharacterManager:getMainPlayer().deckNum
    local txtId = 4104  --你的套牌数量已经达到了上限，需要$1金币开启额外的套牌栏，请问是否开启？
    if curDeckNum > 12 then
        txtId = 4105 --你的套牌数量已经达到了上限，需要$1宝石开启额外的套牌栏，请问是否开启？
    end
end
--创建一个新卡组,返回其ID,如果不能创建返回0
function CollectionManager:createNewGroup()
    local idList = {}
    local obj = {}
    local curDeckNum = CharacterManager:getMainPlayer().deckNum
    for i = 1, curDeckNum do
        local bol = true
        for j = 1, #mCardGroupList do
            if mCardGroupList[j].id == i then
                bol = false --id取一个没占用的
            end
        end
        if bol == true then     
            obj.id = i       
            obj.name = "deck"..obj.id
            obj.headId = 1
        --    obj.save = true
            obj.getInfo = true
            obj.GroupEquipArr = {}
            obj.GroupCardArr = {}
            table.insert( mCardGroupList, obj)
--            mCardGroupList[i] = obj
            return obj.id
        end
    end
    if CollectionManager.DECK_NUM > curDeckNum then
        local curDeckNum = CharacterManager:getMainPlayer().deckNum
        if curDeckNum >= 16 then return 0 end
        local costList = {2000, 4000, 7000, 10000, 1000, 2000, 4000, 7000}
        local costNum = costList[curDeckNum - 7]
        local txtId = 4104  --你的套牌数量已经达到了上限，需要$1金币开启额外的套牌栏，请问是否开启？
        if curDeckNum >= 12 then
            txtId = 4105 --你的套牌数量已经达到了上限，需要$1宝石开启额外的套牌栏，请问是否开启？
        end
        local pStr = string.gsub(DataManager:getStringDataTxt(txtId, true),"$1", costNum) 

        require("prompt.PromptManager"):instance():SetPromptMsg(pStr, nil, function() CollectionManager:buyNewGroup() end)--, nil, 4025, 4026) 
        return
    end
    return 0
end

--新加入卡组到卡组数据列表
function CollectionManager:AddToCardGroupList( obj )
    for i = 1, #mCardGroupList do
        if mCardGroupList[i].id == obj.id then --如果卡组列表已经有该ID的卡组数据,则把obj赋予,然后退出
            mCardGroupList[i] = obj
            return
        end
    end
    table.insert(mCardGroupList, obj)
end

--根据ID删除卡组数据
function CollectionManager:RemoveFromCardGroupList( id )
    for i = 1, #mCardGroupList do
        if mCardGroupList[i].id == id then
            table.remove(mCardGroupList, i)
            return
        end
    end
end

--根据ID获取卡组数据
function CollectionManager:getCardGroupData( id )
    for i = 1, #mCardGroupList do
        if mCardGroupList[i].id == id then            
            return mCardGroupList[i]
        end
    end
end

--获取卡组列表
function CollectionManager:getCardGroupList()
    return mCardGroupList
end


--根据卡牌ID修改拥有的卡牌数量
function CollectionManager:setHasCardNum( id, num )
    mAllHasCardList[id] = num
end

--根据卡牌ID获取拥有的卡牌数量
function CollectionManager:getHasCardNum( id )
    if mAllHasCardList[id] == nil then
        mAllHasCardList[id] = 0
    end
    return mAllHasCardList[id]
end

--获取拥有的卡牌列表
function CollectionManager:getAllHasCardList()
    return mAllHasCardList
end

-----------------新卡牌-------------
--清空新获得的卡牌列表
function CollectionManager:clearNewCardList()
    mNewCardList = {}
end

--根据卡牌ID增加新获得的卡牌列表
function CollectionManager:setNewCardList(id, bol)
    if bol == false then
        mNewCardList[id] = nil
    else
        mNewCardList[id] = 1
    end
end

--获取新获得的卡牌列表
function CollectionManager:getNewCardList()
    return mNewCardList
end

--获取新获得的卡牌列表
function CollectionManager:getCardIsNew(id)
    return (mNewCardList[id] == 1)
end
-----------------新卡牌-------------


--根据卡包ID修改拥有的卡包数量
function CollectionManager:setHasPackNum( id, num )
    mAllCardPackArr[id] = num
end

--根据卡包ID获取拥有的卡包数量
function CollectionManager:getHasPackNum( id )
    if mAllCardPackArr[id] == nil then
        mAllCardPackArr[id] = 0
    end
    return mAllCardPackArr[id]
end

--获取拥有的卡包列表
function CollectionManager:getAllHasPackList()
    return mAllCardPackArr
end

function CollectionManager:initAllHasPackList()
    mAllCardPackArr = {}
end


--处理特殊礼包
function CollectionManager:handlePack()
    local item
    for k, v in pairs(mAllCardPackArr) do
        item = ItemManager:getItemData( k )
        if item and item.show == 1 then
            if 300000 <= item.item_id and 399999 >= item.item_id and v > 0 then   --如果玩家身上有需要自动打开的礼包 ID 300000~399999
                ServMsgTransponder:SMTItemUse( k, v)
                if item.item_id == 300002 then
                    TaskManager:setRewardData( 6, 100 ) --月卡每日奖励领取提示
                end
                self:setHasPackNum( k, 0  )
            end
        end
    end
end
---------------------------------------------------------------------------



--新建或编辑套牌
function CollectionManager:EditGroup( id )
    CurGroupID = id
    local group = self:getCardGroupData( CurGroupID )
    self:updateCurGroupEquipArr( group.GroupEquipArr )
    self:updateCurGroupCardArr( group.GroupCardArr )   
    self:updateCurGpvCardNumArr()
    table.sort( CurGroupCardArr, CardGroupSort )--排序
end


--退出编辑卡组模式, 发送套牌信息到后台  
function CollectionManager:SendGroupMsg()   
    if CollectionManager:getCardGroupData(CurGroupID) == nil then --如果已经把这个当成是空卡套清了
        CollectionTpWnd.saveDeckCallback()
        return 
    end
    
    local EqStr = ""
    local DinaryStr = ""

    for i = 1, #CurGroupEquipArr do
        EqStr = EqStr..CurGroupEquipArr[i].id..","
    end

    for i = 1, #CurGroupCardArr do
        for j = 1, CurGroupCardArr[i].num do
            DinaryStr = DinaryStr..CurGroupCardArr[i].data.id..","
        end
    end

    if DinaryStr == "" then
        self:DelGroupSuccess( CurGroupID ) 
        CollectionTpWnd.saveDeckCallback()
        return
    end
    if CollectionManager:getCardGroupData(CurGroupID).headId == nil then 
        CollectionManager:getCardGroupData(CurGroupID).headId = 1
    end
    CollectionManager:setIsSaveDeck(false)
    --compose_card decks 牌组编号 牌组名称 圣物卡牌数据 普通卡牌数据牌
    ServMsgTransponder:SMTDecks( CurGroupID, CollectionManager:getCardGroupData(CurGroupID).name, CollectionManager:getCardGroupData(CurGroupID).headId, EqStr, DinaryStr)

    require("framework.scheduler").performWithDelayGlobal( function() 
        if CollectionManager:getIsSaveDeck() == true then return end
        require("prompt.PromptManager"):instance():SetPromptMsg(4024, nil, CollectionManager.SendGroupMsg , CollectionTpWnd.saveDeckCallback, 4025, 4026) 
    end, 3 ) 
end


--卡组保存成功
function CollectionManager:SaveGroupSuccess()    
    if CurGroupID == 0 then return end
    local group = CollectionManager:getCardGroupData(CurGroupID)
    group.GroupEquipArr = {}
    table.merge(group.GroupEquipArr, CurGroupEquipArr)
    group.GroupCardArr = {}
    table.merge(group.GroupCardArr, CurGroupCardArr)
    group.save = true

    CurGroupID = 0
    CurGroupEquipArr = {}
    CurGroupCardArr = {}
    CurGpvCardNumArr = {}
end

--卡组删除成功
function CollectionManager:DelGroupSuccess( id ) 
    if id == nil then  id = self.DeleteGroupId end   
    CollectionManager:RemoveFromCardGroupList(id)
end

--卡组修改名字成功
function CollectionManager:EditGroupNameSuccess( id ) 
    if id == nil then  id = self.EditGroupId end 
    if CollectionManager:getCardGroupData(id) == nil then return end  
    CollectionManager:getCardGroupData(id).name = self.EditGroupName
    CollectionManager:getCardGroupData(id).headId = self.EditGroupHeadId
end

--套牌改变时候,更新套牌跟图鉴各卡牌数量
function CollectionManager:updateCurGpvCardNumArr()
    CurGroupCardNumArr = {}
    CurGpvCardNumArr = {}
    CurGroupTeamCardNumArr = {}
    table.merge(CurGpvCardNumArr, self:getAllHasCardList())
    for i = 1, #CurGroupEquipArr do
        if CurGroupCardNumArr[CurGroupEquipArr[i].id] == nil then
            CurGroupCardNumArr[CurGroupEquipArr[i].id] = 0
        end
        CurGroupCardNumArr[CurGroupEquipArr[i].id] = CurGroupCardNumArr[CurGroupEquipArr[i].id] + 1

        CurGpvCardNumArr[CurGroupEquipArr[i].id] = CurGpvCardNumArr[CurGroupEquipArr[i].id] - 1

        if CurGroupTeamCardNumArr[CurGroupEquipArr[i].team] == nil then
            CurGroupTeamCardNumArr[CurGroupEquipArr[i].team] = 0
        end
        CurGroupTeamCardNumArr[CurGroupEquipArr[i].team] = CurGroupTeamCardNumArr[CurGroupEquipArr[i].team] + 1
    end
    for i = 1, #CurGroupCardArr do
        CurGroupCardNumArr[CurGroupCardArr[i].data.id] = CurGroupCardArr[i].num
        if CurGpvCardNumArr[CurGroupCardArr[i].data.id] == nil then
            require("prompt.PromptManager"):instance():SetNotice( CurGroupCardArr[i].data.id.." Not Found"  )
        else
            CurGpvCardNumArr[CurGroupCardArr[i].data.id] = CurGpvCardNumArr[CurGroupCardArr[i].data.id] - CurGroupCardArr[i].num
        end

        if CurGroupTeamCardNumArr[CurGroupCardArr[i].data.team] == nil then
            CurGroupTeamCardNumArr[CurGroupCardArr[i].data.team] = 0
        end
        CurGroupTeamCardNumArr[CurGroupCardArr[i].data.team] = CurGroupTeamCardNumArr[CurGroupCardArr[i].data.team] + CurGroupCardArr[i].num
    end
end

--获取套牌费用法力曲线
function CollectionManager:getCurGroupCostArr( tempArr )
    if tempArr == nil then tempArr = CurGroupCardNumArr end
    local arr = {}
    local obj
    local cost
    for id, num in pairs( tempArr ) do
        if id > 9999 then --是圣物
--            obj = DataManager:getEq( id )  圣物不加入统计
--            if arr[0] == nil then
--                arr[0] = 0
--            end
--            arr[0] = arr[0] + num
        else  --------是普通卡牌
            obj = DataManager:getCardObjByID( id )
            cost = obj.cost
            if cost > 10 then cost = 10 end
            if arr[cost] == nil then
                arr[cost] = 0
            end
            arr[cost] = arr[cost] + num
        end
    end

    for i = 0, 10 do
        if arr[i] == nil then arr[i] = 0 end
    end
    return arr
end

--获取套牌各种类数量
function CollectionManager:getCurGroupTypeArr( tempArr )
    if tempArr == nil then tempArr = CurGroupCardNumArr end
    local arr = {}
    local obj
    for id, num in pairs( tempArr ) do
        if id > 9999 then --是圣物
        else  --------是普通卡牌
            obj = DataManager:getCardObjByID( id )
            if arr[obj.type] == nil then
                arr[obj.type] = 0
            end
            arr[obj.type] = arr[obj.type] + num
        end
    end

    for i = 1, 4 do
        if arr[i] == nil then arr[i] = 0 end
    end
    return arr
end

--更新套牌圣物数组
function CollectionManager:updateCurGroupEquipArr( arr )
    CurGroupEquipArr = {}
    if arr ~= nil then
        table.merge(CurGroupEquipArr, arr)
    end    
end 

--更新套牌普通卡牌数组
function CollectionManager:updateCurGroupCardArr( arr )
    CurGroupCardArr = {}
    if arr ~= nil then
        table.merge(CurGroupCardArr, arr)
    end
end


--判断图鉴卡牌的显示状态 0符合条件, 1:自身未拥有 2:不符合阵营要求 3:已经用完 4:不符合组牌可用张数限制
function CollectionManager:checkCardShowType(cardData)
    if self:getHasCardNum(cardData.id) == 0 then
        return 1
    end

    if cardData.id < 9999 then --不是圣物,要判断阵营
        if self:checkCardRace(cardData) == false then return 2 end
    end
    
    if CurGpvCardNumArr[cardData.id] == nil or CurGpvCardNumArr[cardData.id] <= 0 then return 3 end

    if self:checkCardFinity(cardData) == false then return 4 end

    return 0
end

--判断是否符合组牌限制
function CollectionManager:checkCardFinity(cardData)
    local curNum = CurGroupCardNumArr[cardData.id] or 0

    if cardData.finity <= curNum then --如果已经超过了组牌限制
        return false
    end
    local teamNum = CurGroupTeamCardNumArr[cardData.team] or 0
    if cardData.finity <= teamNum then --如果已经超过了组牌限制
        return false
    end
    return true
end

--根据圣物判断传入的普通卡牌阵营是否符合要求 
function CollectionManager:checkCardRace(cardData, equipArr)
    if cardData.race1 == 0 and cardData.race2 == 0 and cardData.race3 == 0 then --中立卡牌肯定符合
        return true
    end
    if equipArr == nil then equipArr = CurGroupEquipArr end
    local RaceArr = {}
    for i = 1, #equipArr do
        if RaceArr[equipArr[i].race] == nil then
            RaceArr[equipArr[i].race] = 0
        end
        RaceArr[equipArr[i].race] = RaceArr[equipArr[i].race] + 1
    end

    local mObjRaceArr = {}--拥有的各race数量
    for i = 1, 3 do
        if cardData["race"..i] ~= 0 then
            if mObjRaceArr[cardData["race"..i]] == nil then
                mObjRaceArr[cardData["race"..i]] = 0
            end
            mObjRaceArr[cardData["race"..i]] = mObjRaceArr[cardData["race"..i]] + 1
        end
    end
    local isOK = true
    for race, num in pairs(mObjRaceArr) do
        if race ~= 0 and (RaceArr[race] == nil or RaceArr[race] < num) then
            isOK = false
            break
        end
    end
        
    return isOK
end


--根据圣物判断传入的普通卡牌阵营是否符合要求,如果卡牌完全没有该圣物标记才返回false 
function CollectionManager:checkCardRace2(cardData)
    if cardData.race1 == 0 and cardData.race2 == 0 and cardData.race3 == 0 then --中立卡牌肯定符合
        return true
    end
    local RaceArr = {}
    for i = 1, #CurGroupEquipArr do
        if RaceArr[CurGroupEquipArr[i].race] == nil then
            RaceArr[CurGroupEquipArr[i].race] = 0
        end
        RaceArr[CurGroupEquipArr[i].race] = RaceArr[CurGroupEquipArr[i].race] + 1
    end
    local race
    for i = 1, 3 do
        race = cardData["race"..i]
        if RaceArr[race] ~= nil then
            return true
        end
    end
    return false
end


--更改卡套卡牌内容
function CollectionManager:ChangeCardGrop(id, isInGroup, bolAuto)
    local obj = nil
    local delboo = false
    local myEqNum = 0
    local num
    local isupdatashow = false
    
    if id > 9999 then --是圣物
        obj = DataManager:getEq( id )        
        --------如果是图鉴拖入卡组
        if isInGroup == false then
            if self:checkCardFinity(obj) == false then--不符合放入限制
                if bolAuto ~= true then require("prompt.PromptManager"):instance():SetNotice(4004) end
                return false
            end
            local bolAdd = false
            for i = 1, 3 do
                if CurGroupEquipArr[i] == nil then
                    CurGroupEquipArr[i] = obj
                    bolAdd = true
                    break
                end
            end
            if bolAdd == false then
                CurGroupEquipArr[3] = obj --否则直接替换最后一个圣物
            end
        else --如果是卡组拖回图鉴
            local idx = table.indexof(CurGroupEquipArr, obj)
            if idx ~= false then
                table.remove(CurGroupEquipArr, idx)
            end
        end

    --------是普通卡牌--------
    else  
        obj = DataManager:getCardObjByID( id )
        --如果是图鉴拖入卡组
        if isInGroup == false then
            local showType = self:checkCardShowType( obj )--判断图鉴卡牌的显示状态 0符合条件, 1:自身未拥有 2:不符合阵营要求 3:已经用完 4:不符合组牌可用张数限制
            if showType == 2 then
                if bolAuto ~= true then require("prompt.PromptManager"):instance():SetNotice(4000) end
            elseif showType == 3 then
                if bolAuto ~= true then require("prompt.PromptManager"):instance():SetNotice(63) end
            elseif showType == 4 then
                if bolAuto ~= true then require("prompt.PromptManager"):instance():SetNotice(4004) end
            end
            if showType ~= 0 then return false end
            
            local AllCardNum = 0
            for i = 1, #CurGroupCardArr do
                AllCardNum = AllCardNum + CurGroupCardArr[i].num
            end
            if AllCardNum + 1 > CollectionManager.GroupMaxNum then --如果已经超过了组牌张数限制
                if bolAuto ~= true then require("prompt.PromptManager"):instance():SetNotice(3009) end
                return false
            end
            local bolIn = false
            for i = 1, #CurGroupCardArr do
                if CurGroupCardArr[i].data == obj then
                    bolIn = true
                    CurGroupCardArr[i].num = CurGroupCardArr[i].num + 1
                    break
                end
            end
            if bolIn == false then
                table.insert(CurGroupCardArr, {data = obj, num = 1})
            end
            table.sort( CurGroupCardArr, CardGroupSort )--排序
        else --如果是卡组拖回图鉴
            for i = 1, #CurGroupCardArr do
                if CurGroupCardArr[i].data == obj then
                    CurGroupCardArr[i].num = CurGroupCardArr[i].num - 1
                    if CurGroupCardArr[i].num <= 0 then
                        table.remove(CurGroupCardArr, i)
                    end
                    break
                end
            end
        end
    end

--    if bolAuto ~= true then --不是自动组牌的话要更新
--        self:updateCurGpvCardNumArr()
--    end
    self:updateCurGpvCardNumArr()
    return true
end


function CollectionManager:getCurGroupID()
    return CurGroupID
end


function CollectionManager:getCurGroupEquipArr()
    return CurGroupEquipArr
end

function CollectionManager:getCurGroupCardArr()
    return CurGroupCardArr
end

function CollectionManager:getCurGpvCardNumArr()
    return CurGpvCardNumArr
end

function CollectionManager:getCurGroupCardNumArr()
    return CurGroupCardNumArr
end

function CollectionManager:setBolShowEq( bol )
    BolShowEq = bol
end
----------------------------------------套牌(卡组)编辑------------------------------


----------------------------------------筛选----------------------------------------

--判断是否处于筛选状态
function CollectionManager:getIsFilter()
    if #mSiftCostList == 0 and #mSiftRaceList == 0 and #mSiftTypeList == 0 and #mSiftQltList == 0 and mSiftStr == "" 
        and #mSiftSingleRaceList == 0 and #mSiftVersionList == 0 then
        return false    
    end
    return true
end

--是否显示未拥有卡牌
function CollectionManager:setBolShowAll( bol )
    mBolShowAll = bol
end
function CollectionManager:getBolShowAll( )
    return mBolShowAll
end

--stype 1费用 2阵营派系 3种类 4稀有度 获得某种类型的筛选列表
function CollectionManager:getSiftList( stype )
    local siftList
    if stype == SIFT_COST then 
        siftList = mSiftCostList
    elseif stype == SIFT_RACE then
        siftList = mSiftRaceList
    elseif stype == SIFT_TYPE then
        siftList = mSiftTypeList
    elseif stype == SIFT_QLT then
        siftList = mSiftQltList
    elseif stype == SIFT_SINGEL_RACE then
        siftList = mSiftSingleRaceList
    elseif stype == SIFT_VERSION then
        siftList = mSiftVersionList
    end
    return siftList
end

--stype 1费用 2阵营派系 3种类 4稀有度 bolAdd:true为增加,否则为删除该类型参数的筛选
function CollectionManager:setSiftList( stype, value, bolAdd )
    local siftList = self:getSiftList( stype )
    if bolAdd == true then
        table.insert( siftList, value )
    else
        for i = 1, #siftList do
            if value == siftList[i] then
                table.remove( siftList, i )
                break
            end
        end
    end
end

----stype 1费用 2阵营派系 3种类 4稀有度 筛选列表里面是否已经存在该参数
function CollectionManager:bolInSiftList( stype, value )
    local siftList = self:getSiftList( stype )
    for i = 1, #siftList do
        if value == siftList[i] then
            return true
        end
    end
    return false
end

--筛选花费
local function SiftSpend(obj)
    if #mSiftCostList == 0 then return true end --筛选数组为空表示不必筛选
    if obj.id > 9999 then return false end --如果是圣物,直接返回false

    for i = 1, #mSiftCostList do
        if obj.cost == mSiftCostList[i] then return true
        elseif obj.cost >= 10 and mSiftCostList[i] == 10 then return true end
    end
    return false
end

--筛选卡牌版本
local function SiftVersion(obj)
    if #mSiftVersionList == 0 or #mSiftVersionList > 1 then return true end --筛选数组为空或大于1表示不必筛选
    for i = 1, #mSiftVersionList do
        if table.indexof(mVersionList[mSiftVersionList[i]], obj.version) == false then
            return false
        else
            return true
        end
    end
    return false
end


--筛选单/多色派系阵营 
local function SiftSingleRace(obj)
    if #mSiftSingleRaceList == 0 or #mSiftSingleRaceList > 1 then return true end --筛选数组为空或大于1表示不必筛选
    if obj.id > 9999 then  --圣物不需要判断
        return true 
    end
    local raceNum = 0

    if obj.race1 == 0 and obj.race2 == 0 and obj.race3 == 0 then  --中立的话算单色
        raceNum = 1
    end

    local raceList = {}
    for j = 1, 3 do
        if obj["race"..j] ~= 0 and raceList[obj["race"..j]] == nil then
            raceNum = raceNum + 1
            raceList[obj["race"..j]] = 1
        end
    end
    if table.indexof(mSiftSingleRaceList,1) ~= false then
        if raceNum > 1 then 
            return true
        else
            return false
        end
    else
        if raceNum > 1 then 
            return false
        else
            return true
        end
    end
    return false
end

--筛选派系阵营 
local function SiftRace(obj)
    if #mSiftRaceList == 0 then return true end --筛选数组为空表示不必筛选
    
    if obj.id > 9999 then  --圣物只需要判断一个
        if obj.race == mSiftRaceList[i] then 
            return true 
        end
    else
        if obj.race1 == 0 and obj.race2 == 0 and obj.race3 == 0 then  --中立的话算
            return true 
        end
        local raceNum = 0
        local raceList = {}
        for j = 1, 3 do
            if obj["race"..j] ~= 0 and raceList[obj["race"..j]] == nil then
                raceNum = raceNum + 1
                raceList[obj["race"..j]] = 1
            end
        end

        local sameNum = 0
        for j = 1, #mSiftRaceList do
            if raceList[mSiftRaceList[j]] == 1 then
                sameNum = sameNum + 1
            end
        end
        if raceNum == 1 or #mSiftRaceList == 1 then
            return sameNum >= 1
        else
            return sameNum >= 2
        end
    end
    return false
end


--筛选种类
local function SiftType(obj)
    if #mSiftTypeList == 0 then return true end --筛选数组为空表示不必筛选
    if obj.id > 9999 then return false end --如果是圣物,直接返回false
    for i = 1, #mSiftTypeList do
        if obj.type == mSiftTypeList[i] then 
            return true 
        end
    end
    return false
end

--筛选稀有度
local function SiftQlt(obj)
    if #mSiftQltList == 0 then return true end --筛选数组为空表示不必筛选
    for i = 1, #mSiftQltList do
        if obj.qlt == mSiftQltList[i] then 
            return true 
        end
    end
    return false
end


--筛选关键字
local function SiftKey(obj)
    if mSiftStr == "" then return true end
    local arr = {"name_text_", "skill_text_", "class2_text_", "class1_text_"}
    local str = nil
    for i = 1, 4 do
        str = obj[arr[i]..LANGUAGE]
        str = string.lower( str )
        if string.find( str, mSiftStr ) then
            return true
        end
    end
    return false
end

--设置筛选关键字
function CollectionManager:setSiftStr(str)
    mSiftStr = str
end

--筛选是否拥有
local function SiftHasCard(obj)
    return mHasCardArr[obj.id] ~= nil
end

--初始化筛选数组
function CollectionManager:initSiftTypeArr( bolSetShowAll )
    mSiftCostList = {}
    mSiftRaceList = {}
    mSiftTypeList = {}
    mSiftQltList = {}
    mSiftStr = ""
    if bolSetShowAll == true then  --当为true的时候才需要设置是否显示未拥有卡牌
        mBolShowAll = false
    end
    -----------------------卡牌信息-------------------
    if #mAllCardArr == 0 then
        local _dataEq = table.values( DataManager.DataEqArr )
        local _dataCard = table.values( DataManager.DataCardArr )
        table.insertto( mAllCardArr,_dataEq )
        table.insertto( mAllCardArr,_dataCard )
    end
    -----------------------卡牌信息-------------------
end
----------------------------------------筛选----------------------------------------


--显示卡牌排序
local function Contrast(data1, data2)
    if data1.id > 9999 and data2.id < 9999 then  --圣物比0费普通牌优先
        return true
    elseif data1.id < 9999 and data2.id > 9999 then
        return false
    end
    if data1.id > 9999 or data2.id > 9999 then 
        if data1.id > 9999 and data2.id > 9999 then
            if data1.race ~= data2.race then
                return data1.race < data2.race
            else
                return data1.id < data2.id
            end
        elseif data1.id > 9999 then 
            num = data1.race 
            if num == getRace( data2.race1, data2.race2, data2.race3 ) then
                if data1.cost ~= data2.cost then
                    return data1.cost < data2.cost
                else
                    return data1.id < data2.id
                end
            else
                return num < getRace( data2.race1, data2.race2, data2.race3 )
            end
        elseif data2.id > 9999 then
            num = data2.race
            if getRace( data1.race1, data1.race2, data1.race3 ) == num then
                if data1.cost ~= data2.cost then
                    return data1.cost < data2.cost
                else
                    return data1.id < data2.id
                end
            else
                return getRace( data1.race1, data1.race2, data1.race3 ) < num
            end
        end
    else        
        for i = 1, 3 do
            if data1["race"..i] ~= data2["race"..i] and data1["race"..i] ~= 0 and data2["race"..i] ~= 0 then
                return data1["race"..i] < data2["race"..i]
            end
        end
        if data1.cost ~= data2.cost then
            return data1.cost < data2.cost
        else
            for i = 1, 3 do
                if data1["race"..i] ~= data2["race"..i] then
                    return data1["race"..i] < data2["race"..i]
                end
            end
            return data1.id < data2.id
        end
    end
end

--卡牌排序
local function UpdataCardPos(posArr)
    --将中立和多色阵型提取出来排序再放到后面
    local arr = {}
    local arr2 = {}
    local obj = nil
    local sub = 0
    for i = 1, #posArr do
        i = i - sub
        obj = posArr[i]
        if obj ~= 0 then
            if obj.id > 9999 then
                if obj.race == 0 then
                    table.remove( posArr, i )
                    table.insert( arr, obj )
                    sub = sub + 1
                end
            else
                if obj.race1 == 0 and obj.race2 == 0 and obj.race3 == 0 then
                    table.remove( posArr, i )
                    table.insert( arr, obj )
                    sub = sub + 1
                elseif (obj.race1 ~= obj.race2 and obj.race2 ~= 0) or (obj.race1 ~= obj.race3 and obj.race3 ~= 0)  then
                    table.remove( posArr, i )
                    table.insert( arr2, obj )
                    sub = sub + 1
                end
            end
        end
    end

    table.sort( arr, function( data1, data2 ) return Contrast( data1, data2 ) end )
    table.sort( arr2, function( data1, data2 ) return Contrast( data1, data2 ) end )
    table.sort( posArr, function( data1, data2 ) return Contrast( data1, data2 ) end )

    for i = 1, #arr2 do
        table.insert( posArr, arr2[i] )
    end

    for i = 1, #arr do
        table.insert( posArr, arr[i] )
    end
end

--卡组编辑中, 图鉴进入筛选状态
local function SiftCard(arr)
    local sub = 0
    local char = CharacterManager:getMainPlayer()
    local showArr = {}
    local obj = nil
    for i = 1, #arr do
        obj = arr[i]
        bolDel = false
        if 
        mBolShowAll == false and CollectionManager:getHasCardNum(obj.id) == 0 then  --如果没有开启了全部显示,则移出没有拥有的卡牌
            bolDel = true
        else
            if #CurGroupEquipArr < 3 or BolShowEq == true then
                --当圣物卡组不足,删除普通卡牌
                if obj.id < 9999 then
                    bolDel = true
                end
            elseif obj.id > 9999 then --圣物卡组满了的话,删除圣物卡牌
                bolDel = true
            else  --普通卡牌的判断
                if mBolShowAll == false then 
                    local isOK = CollectionManager:checkCardRace2(obj) --阵营是否符合圣物的要求
                    if isOK == false then
                        bolDel = true
                    end
                end
            end
        end
        if bolDel == false then
            table.insert(showArr, obj)
        end
    end
    return showArr
end


function CollectionManager:getShowCardArr()
    return mShowCardArr
end


--更新显示卡牌
function CollectionManager:UpDataCardMsg()
     ------------------------------判断显示所有or拥有卡牌---------------------
    mShowCardArr = {}
    if mBolShowAll == false then --是否显示全部卡牌(包括未拥有的)
        table.merge( mShowCardArr, mHasCardArr )
    else
        table.merge( mShowCardArr, mAllCardArr )
    end
    ------------------------------判断显示所有or拥有卡牌---------------------//SiftRace
    local okBoo = false    
    local myObj = nil
    local boo = false
    local arr = {}
    for i, obj in pairs( mShowCardArr ) do
        myObj = nil
        if obj == nil or obj.derive == 1 or obj.finity == 0 or table.indexof(CARD_VERSION_LIST, obj.version) == false then
            mShowCardArr[i] = nil  --衍生物或者不能显示的设为nil
        else
            --------筛选显示卡牌-----------
            if SiftSpend( obj ) == true and SiftRace( obj ) == true and SiftType( obj ) == true and
                SiftQlt( obj ) == true and SiftKey( obj ) == true and SiftSingleRace( obj ) == true and SiftVersion( obj ) == true then
                table.insert( arr, obj )
            end
                --------筛选显示卡牌-----------//
        end
    end    
    
    if #arr ~= 0 then
        if CollectionScWnd.mIsLeave == false then --编辑套牌中
            mShowCardArr = SiftCard(arr)
        else
            mShowCardArr = arr
        end
    else
        mShowCardArr = {}
    end
    UpdataCardPos( mShowCardArr )--对显示对象排序
end

    --更新主角拥有卡牌
function CollectionManager:updataHasCard()
    local char = CharacterManager:getMainPlayer()
    mHasCardArr = {}
    local tempArr
    if self.BolSellCard == true then --卖卡模式中
        tempArr = ShopManager.DataCardShopArr --卡牌市场数据
        print(" --卡牌市场数据 ")
    else
        tempArr = self:getAllHasCardList()
    end
    local obj
    for id, num in pairs( tempArr ) do
        if self:getHasCardNum( id ) > 0 then
            if id > 9999 then 
                obj = DataManager:getEq( id ) 
            else 
                obj = DataManager:getCardObjByID( id, false )
            end
            if obj then
                mHasCardArr[obj.id] = obj
            end
        end
    end
end

----------------------------------------显示卡牌筛选----------------------------------//

function CollectionManager:instance()
    local o = _G.CollectionManager
    if o then
    	return o
	end
 
    o = CollectionManager:new()
	_G.CollectionManager = o
    CollectionManager:init()
    return o
end

--初始化
function CollectionManager:init()
    --是否修改卡组名称成功 1成功 0不成功
    self.mIsRevisionName = 0
    --是否删除卡组成功 1成功 0不成功
    self.mIsDelCard = 0
    --是否是卖卡模式
    self.BolSellCard = false

    --要删除的卡组ID
    self.DeleteGroupId = 0

    --要更改名字的卡组ID
    self.EditGroupId = 0
    --要更改成的卡组新名字
    self.EditGroupName = ""
    --要更改成的卡组新头像ID
    self.EditGroupHeadId = 1

    --套牌最低需要的数量(不含圣物)
    self.GroupMinNum = 50
    --套牌最多可以容纳的数量(不含圣物)
    self.GroupMaxNum = 60

    --是否已经收到了1400协议
    self.Bol0x1400 = false
    --是否已经收到了1504协议
    self.Bol0x1504 = false
        
    --当前向后台发送请求详细卡组信息的套牌ID
    self.ComposeShowId = 0

------------筛选参数--------------
--是否只显示圣物
    BolShowEq = false
--是否显示未拥有卡牌
    mBolShowAll = false

--费用筛选 当前选择的费用
    mSiftCostList = {}
--阵营派系筛选
    mSiftRaceList = {}
--卡牌种类类型筛选
    mSiftTypeList = {}
--卡牌稀有度筛选
    mSiftQltList = {}

--当前筛选文字
    mSiftStr = ""
------------筛选参数--------------

------------当前拥有卡牌更全部拥有卡牌主要是区分筛选-----
--当前拥有卡牌
    mHasCardArr = {}
--全部卡牌数组
    mAllCardArr = {}
--当前编辑中的套牌数组ID
    CurGroupID = 0
--当前编辑中的套牌圣物数组[卡牌表的data]
    CurGroupEquipArr = {}
--当前编辑中的套牌普通卡牌数组[ data = 卡牌表的data, num = 卡牌数量]
    CurGroupCardArr = {}

--编辑套牌中各卡牌的数量 [卡牌ID][卡片数量]
    CurGroupCardNumArr = {}
--编辑套牌中图鉴卡组显示的牌组数量 [卡牌ID][卡片数量] 即你总共拥有的卡牌减去套牌中的卡牌数量
    CurGpvCardNumArr = {}

--编辑套牌中各异画卡牌的数量 [卡牌ID][卡片数量]
    CurGroupTeamCardNumArr = {}
----------------------------------------套牌(卡组)编辑------------------------------

--------------------------------玩家拥有的卡牌,卡组数据  从character移过来9.19--------------------
--玩家全部卡组数据列表
    mCardGroupList = {}
--玩家拥有卡牌数组
    mAllHasCardList = {}
--记录玩家得到的新卡牌数组
    mNewCardList = {}
--玩家拥有的卡包的数组
    mAllCardPackArr = {}
--------------------------------玩家拥有的卡牌,卡组数据  从character移过来9.19--------------------
end


--判断是否在套组区域内，并返回位置,传入坐标基于舞台左下角为0点
function CollectionManager:checkTouchBattle( _x, _y )
    if CollectionScWnd.mIsLeave == false then return false end
     if _x < 943 or _x > 1263 or _y < 97 or _y > 607 then return false end
    return true
end

--国家点击
function CollectionManager:UpadateFaction(faction)
    CollectionWnd:UpadateFaction(faction)
end

--向后台发送拥有卡牌的信息请求
function CollectionManager:SendOpenInfo()
--    if self.Bol0x1400 == true then return end
--    require("framework.scheduler").performWithDelayGlobal( function() ServMsgTransponder:SMTOpenCard_info() end, 0.1 )
    CollectionManager:SendOpenCardInfo()

    local fun = function()
        if self.Bol0x1504 == false then 
            ServMsgTransponder:SMTOpenDeck_info()
        end
        if self.Bol0x1400 == false then 
            require("framework.scheduler").performWithDelayGlobal( function() ServMsgTransponder:SMTOpenEquip_info() end, 0.5 )
        end
        mSendOpenId = 7
    end 
    require("framework.scheduler").performWithDelayGlobal( fun, 10 )--计时10秒,如果还没有收完就发一次请求过去
end

--向后台发送拥有卡牌的信息请求
function CollectionManager:SendOpenCardInfo( bolAdd )
    if mSendOpenId > 6 then 
        if mSendOpenId == 7 then  --到7时已经收完了
            if self.Bol0x1504 == false then 
                ServMsgTransponder:SMTOpenDeck_info()
            end
            if self.Bol0x1400 == false then 
                require("framework.scheduler").performWithDelayGlobal( function() ServMsgTransponder:SMTOpenEquip_info() end, 0.5 )
            end
        end
        mSendOpenId = 8
        return
    end
    if bolAdd == true then 
        mSendOpenId = mSendOpenId + 1 
    end
    ServMsgTransponder:SMTOpenCard_info(mSendOpenId)   

    if mSendOpenIdTimer ~= nil then
        require("framework.scheduler").unscheduleGlobal( mSendOpenIdTimer )
    end

    local fun = function()
        if mSendOpenId > 6 then
            require("framework.scheduler").unscheduleGlobal( mSendOpenIdTimer )
            mSendOpenIdTimer = nil
            return
        end
        if mSendOpenId == mLastSendOpenId then
            ServMsgTransponder:SMTOpenCard_info(mSendOpenId)
        end
    end 

    mLastSendOpenId = mSendOpenId
    mSendOpenIdTimer = require("framework.scheduler").scheduleGlobal( fun, 1 )
end


--自动组牌
function CollectionManager:AutoMakeDeck()
    local needCostList = { 6, 6, 7, 7, 7, 6, 5, 4, 2, 0}
    needCostList[0] = 0
    local allnum = 0
    local tArr = self:getCurGroupCostArr()
    for i = 0, 10 do
        allnum = allnum + tArr[i] 
        needCostList[i] =  needCostList[i] - tArr[i]
        if needCostList[i] < 0 then needCostList[i] = 0 end
    end

    if allnum >= self.GroupMinNum then 
        return
    end

    local gpvCardList = {}
    local cardData
    local cost = 0
    local curGpvNum = 0
    for id, num in pairs( CurGpvCardNumArr ) do
        cardData = DataManager:getCardObjByID(id)
        if cardData then
            cost = cardData.cost
            if cost > 9 then cost = 9 end
            if gpvCardList[cardData.cost] == nil then gpvCardList[cardData.cost] = {} end 
            table.insert(gpvCardList[cardData.cost], {data = cardData, num = num})
            curGpvNum = curGpvNum + num 
        end        
        
    end
--    table.sort( gpvCardList[2], CardGroupSortByQlt )--排序
    for i = 0, #gpvCardList do
        if gpvCardList[i] == nil then gpvCardList[i] = {} end 
        if #gpvCardList[i] > 1 then 
            table.sort( gpvCardList[i], CardGroupSortByQlt )--排序
        end        
    end

    local needNum = self.GroupMinNum - allnum
    local temArr = {}
--    while needNum > 0 do
--        needCostList
--    end

    local arr = self:getCurGroupCostArr()
    for i = 0, 10 do
        if gpvCardList[i] then
            for j = 1, #gpvCardList[i] do
                table.insert(temArr, gpvCardList[i][j])
            end
        end
--        if temArr[i] == nil then temArr[i] = {} end 
        
    end

    for i = 1, #temArr do
        if needNum > 0 then
            local tnum = temArr[i].num
            if tnum > temArr[i].data.finity then tnum = temArr[i].data.finity end
            for j = 1, tnum do
                if needCostList[temArr[i].data.cost] > 0 then 
                    local bolInsert = self:ChangeCardGrop(temArr[i].data.id, false, true)
                    if needNum == 0 then break end
                    if bolInsert == true then
                        needNum = needNum - 1
                        temArr[i].num = temArr[i].num - 1
                        needCostList[temArr[i].data.cost] = needCostList[temArr[i].data.cost] - 1
                    end
                end                
            end
        end        
    end

    for i = 1, #temArr do
        if needNum > 0 then
            local tnum = temArr[i].num
            if tnum > temArr[i].data.finity then tnum = temArr[i].data.finity end
            for j = 1, tnum do
                if needNum == 0 then break end
                local bolInsert = self:ChangeCardGrop(temArr[i].data.id, false, true)
                if bolInsert == true then
                    needNum = needNum - 1
                    temArr[i].num = temArr[i].num - 1
                end           
            end
        end        
    end
    self:updateCurGpvCardNumArr()
    CollectionWnd:updateGpvCardList(true)
--    CurGpvCardNumArr
--    CurGroupCardNumArr
end


return CollectionManager