----------------------------------------------------------
----------�ղؿ����ӽ��洦��--------------------------
------------------��Ҫ����ߵ�ͼ���������ұߵĿ����б�, �򿪽���ĳ�ʼ״̬----------------------------------------
require "tagMap.Tag_collectionwnd"
require "xiangxi.CardXiangXi"
local DataManager = require("data.DataManager"):instance()
local EffectManaget = require("ui.EffectManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()

local CollectionScWnd = {}-- ����һ���� test �̳��� base_type
local MainWnd = nil
--���ƿ��Ƶ��ʱ��ʾ��MASK
CollectionScWnd.ImgMask = nil
---------------------------------------------------------------------------------------
--�����ϲ���Ϣ1����
CollectionScWnd.mlayoutUp1 = nil
--�����м䲿��
CollectionScWnd.mlayoutMiddle = nil
--�Զ����۰�ť
CollectionScWnd.btn_AutoSell = nil
--ɸѡ��ť
CollectionScWnd.btn_OpenFilter = nil
--�Զ�����ͼƬ
CollectionScWnd.img_AutoMakeDeck = nil
--�Զ����ư�ť
CollectionScWnd.btn_AutoMakeDeck = nil
--��ʾȫ�����ư�ť
CollectionScWnd.btn_OpenShowAll = nil
--------------local Up1Arr = {}--------------------------------------------------
--������ť
CollectionScWnd.mbtn_Down = nil
--�Ƿ���ʾȫ���ı�
CollectionScWnd.LabShowAllTxt = nil
-------------�ұ����----------------------------------------
CollectionScWnd.layout_Right_wdsc = nil
--��ǰ���׸���
CollectionScWnd.CardTempPageStr = ""
--�Ƿ����Ŀ���
CollectionScWnd.mIsLast = false
--��ǰѡ����������
CollectionTpWnd.CardTitalFont = nil
--ͼ����������
CollectionScWnd.mgpvCardArr = {}
--��������
CollectionScWnd.mCardVec = nil
--���Ƶ������
CollectionScWnd.mCardClickVec = nil
--��ǰӵ�п���
CollectionScWnd.mHasCardArr = {}
--ͼ����ҳ��
CollectionScWnd.mCardGpvPage = 1
--���׹���
CollectionScWnd.gpvCardTemp = nil 

--�ղؿ�����ʾ����
CollectionScWnd.gpvCard = nil

function CollectionScWnd.init()

	print("CollectionScWnd:ctor --------------------------")
	
end

--���Ƶ���¼�����
local function btnCardGroup(p_sender)
    if p_sender then mCurGroup = tonumber(p_sender:getName()) end
    local obj = CollectionManager:getCardGroupData(mCurGroup)
    if obj == nil then --�����ڵĻ�
        return
    end
    if obj.getInfo == false then
        CollectionManager.ComposeShowId = mCurGroup
        ServMsgTransponder:SMTShow( mCurGroup )
        return
    end
    CollectionTpWnd.EditCardGroup(mCurGroup)
end

--�༭����, �˳�������ʾ����
local function EditLongClickardSpecial(p_sender)
   btnCardGroup()
end


--ɾ������
local function DeleteClick(p_sender)
    local index
    if  CollectionTpWnd.mlayoutLongClick:isVisible() then
        index = CollectionTpWnd.mlayoutLongClick.mIndex
    else  
        index = CollectionManager:getCurGroupID()
    end
    local group = CollectionManager:getCardGroupData(index)
    if group == nil then return end
    CollectionManager.DeleteGroupId = index
    if group.save == true then        
        ServMsgTransponder:SMTDelete_decks(CollectionManager.DeleteGroupId)
    else
        CollectionTpWnd:updataCardGroupMsg()
    end
        CollectionTpWnd.mlayoutLongClick:setVisible(false)
end

--�ұ���Ϣ����(����)
local function RightMov()
    trace("RightMov")
end

--ͼ��������ʾ״̬
local function gpvShowStage(pCell, id)
    local char = CharacterManager:getMainPlayer()
    local mShowCardArr = CollectionManager:getShowCardArr()

    local obj
    for k, mObj in pairs(mShowCardArr)do
        if mObj.id == id then
            obj = mObj 
            break 
        end
    end
    EffectManaget:setGrayFilter( pCell.imgCardUI, false )
    pCell.imgCardUI.cardUI:setCardRed( false )
    pCell.imgLock1:setVisible(false)
    pCell.imgLock2:setVisible(false)
    pCell.txtStr:setString("")

    if pCell.id == CollectionScWnd.selectId then
        pCell.btn_showCard:setVisible(true)
        pCell.btn_addCard:setVisible(true)
        pCell.btn_reduceCard:setVisible(true)
        local cardNum = CollectionManager:getCurGroupCardNumArr()[pCell.id]
        if cardNum == nil or cardNum <= 0 then
            pCell.btn_reduceCard:setVisible(false)
        end
    end

    local curNum = CollectionManager:getCurGpvCardNumArr()[obj.id] or 0
    pCell.txtNum:setString( curNum.."/"..CollectionManager:getHasCardNum( obj.id ) )
    local showType = CollectionManager:checkCardShowType( obj )--0��������, 1:����δӵ�� 2:������ʥ��Ҫ�� 3:�Ѿ����� 4:���������ƿ�����������
    if showType == 1 then
        pCell.txtNum:setString( 0 )
        EffectManager:setGrayFilter(pCell.imgCardUI, true)
        pCell.btn_addCard:setVisible(false)
        pCell.btn_reduceCard:setVisible(false)
    elseif showType == 2 then
        pCell.imgLock1:setVisible(true)
        pCell.txtStr:setSystemFontSize(16)
        pCell.txtStr:setString( DataManager:getStringDataTxt( 91, true ) )
        pCell.btn_addCard:setVisible(false)
    elseif showType == 3 then
        pCell.imgLock2:setVisible(true)
        pCell.txtStr:setSystemFontSize(24)
        pCell.txtStr:setString( DataManager:getStringDataTxt( 63, true ) )
        pCell.btn_addCard:setVisible(false)
    elseif showType == 4 then
        pCell.imgLock2:setVisible(true)
        pCell.txtStr:setSystemFontSize(24)
        pCell.txtStr:setString( DataManager:getStringDataTxt( 64, true ) )
        pCell.btn_addCard:setVisible(false)
    else
    end
end

--ͼ����Ŀ��Ʋ鿴��ť�¼�
local function showCardBtnClick( p_sender )
    if CardXiangXi.isShow == false then 
        RunScene( "CardXiangXi" )
        CardXiangXi:setAndShowCardXiangXi( p_sender:getParent().id, 1 )
		--require("Music.MusicManager"):instance():PlaySound( 108 )
         p_sender:getParent().imgCardUI.cardUI:updateNewEffect()
    end
end

--ͼ��������ӿ��Ƶ���¼�
local function addCardBtnClick( p_sender )
    if CollectionScWnd.mIsLeave == true or p_sender:getParent().id == nil then return end
    CollectionTpWnd.ChangeCardGrop(p_sender:getParent().id, false, 0)
	--require("Music.MusicManager"):instance():PlaySound( 108 )
end

--ͼ����ļ��ٿ��Ƶ���¼�
local function reduceCardBtnClick( p_sender )
    if CollectionScWnd.mIsLeave == true or p_sender:getParent().id == nil then return end
    CollectionTpWnd.ChangeCardGrop(p_sender:getParent().id, true, 0)
	--require("Music.MusicManager"):instance():PlaySound( 108 )
end

--ͼ����Ŀ��Ƶ���¼�
local function gpvTempCardUIClick( p_sender )
    if p_sender.id == nil then return end
    if CollectionScWnd.mIsLeave == true then--�����ڱ༭��������ʾ������ϸ
        if CardXiangXi.isShow == false then 
            RunScene( "CardXiangXi" )
            CardXiangXi:setAndShowCardXiangXi( p_sender.data.id, 1 )
            p_sender:getParent().imgCardUI.cardUI:updateNewEffect()
        end
        return
    end
    if CollectionScWnd.selectId == p_sender:getParent().id then
        CollectionScWnd.selectId = 0
    else
        CollectionScWnd.selectId = p_sender:getParent().id
    end
    for i = 1, #CollectionScWnd.mgpvCardArr do
        pCell = CollectionScWnd.mgpvCardArr[i]
        if pCell.id == CollectionScWnd.selectId then
            pCell.btn_showCard:setVisible(true)
            pCell.btn_addCard:setVisible(true)
            pCell.btn_reduceCard:setVisible(true)
            gpvShowStage( pCell, p_sender:getParent().id )
        else
            pCell.btn_showCard:setVisible(false)
            pCell.btn_addCard:setVisible(false)
            pCell.btn_reduceCard:setVisible(false)
        end
    end
end

--ͼ����Ŀ��Ƴ����¼�
local function gpvTempCardUILongClick( p_sender )
    if CardXiangXi.isShow == false then 
        RunScene( "CardXiangXi" )
        CardXiangXi:setAndShowCardXiangXi( p_sender.data.id, 1 )
         p_sender:getParent().imgCardUI.cardUI:updateNewEffect()
    end
    return false
end


--�����¼�
local function LeftClick(p_sender)
    local _x = CollectionScWnd.gpvCard:getContentOffset().x
    if _x%890 ~= 0 or _x == 0 then return end
    CollectionScWnd.gpvCard:setContentOffsetInDuration( cc.p( CollectionScWnd.gpvCard:getContentOffset().x + 890, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )
end

--�ҵ���¼�
local function RightClick(p_sender)
    local _x = CollectionScWnd.gpvCard:getContentOffset().x
    if _x % 890 ~= 0 or _x <= -( CollectionScWnd.mCardGpvPage - 1 ) * 890 then return end
    CollectionScWnd.gpvCard:setContentOffsetInDuration( cc.p( CollectionScWnd.gpvCard:getContentOffset().x - 890, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )
end

--��ɸѡ����
local function OpenFilterClick(p_sender)
    CollectionWnd:showPage(SHOW_SX_WN) 
end


--�Զ�������ť
local function AutoSellClick(p_sender)
    RunScene("CollectionSellWnd")
end

--�Զ����ư�ť
local function AutoMakeDeckClick(p_sender)
    if #CollectionManager:getCurGroupEquipArr() < 3 then
        require("prompt.PromptManager"):instance():SetNotice(4101) --��ѡ������ʥ�����ʹ�ô˹���
        return
    end
    CollectionManager:AutoMakeDeck()
end


--�Ƿ���ɸѡ��ӵ�п���
local function OpenShowAllClick(p_sender)
    local bol = not CollectionManager:getBolShowAll()
    CollectionManager:setBolShowAll( bol )
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

--����һ��gpv��cell
local function createGpvCard()

    local pCell = CGridPageViewCell:new()
    TuiManager:getInstance():parseCell( pCell, "cell_grid", PATH_COLLECTIONWND )
    local ImgCardNumBg = CImageView:createWithSpriteFrameName( "collectionwnd/img_CardCount.png" )
    ImgCardNumBg:setPosition( 100, 10 )
    pCell:addChild( ImgCardNumBg )
    local mTxtNum = CLabelBMFont:create( "", "fonts/labBmf_NumberFont30.fnt" )
    mTxtNum:setAlignment( 1, 0 )
    mTxtNum:setDimensions( 72, 40 )
    pCell:addChild( mTxtNum )
    mTxtNum:setPosition( 100, 8 )
    mTxtNum:setString( 2 )
    pCell.txtNum = mTxtNum

    local ImgCardUI = require( "war2.war2CardMCollect" ).new()
    ImgCardUI:init( 0, 1 )
    ImgCardUI:setPosition( 100, 140 )
    ImgCardUI:setTouchEnabled(false)
    pCell:addChild( ImgCardUI )
    pCell.imgCardUI = ImgCardUI

    local ImgCardLock = CImageView:createWithSpriteFrameName( "collectionwnd/img_Lock+1.png" )
    ImgCardLock:setPosition( 97, 140 )
    pCell:addChild( ImgCardLock )
    pCell.imgLock1 = ImgCardLock

    local ImgCardLock2 = CImageView:createWithSpriteFrameName( "collectionwnd/img_Lock+2.png" )
    ImgCardLock2:setPosition( 97, 140 )
    pCell:addChild( ImgCardLock2 )
    pCell.imgLock2 = ImgCardLock2

    local mTxtStr = TextManager:createTxt( "", 24, TXTFONTNAME )
    mTxtStr:setTextColor(cc.c4b(255,255,255,255))
    mTxtStr:setPosition( 100, 92 )
    mTxtStr:setAlignment( 1, 0 )
    mTxtStr:setDimensions(260, 30)
    pCell:addChild( mTxtStr )
    pCell.txtStr = mTxtStr

    table.insert( CollectionScWnd.mCardVec,ImgCardUI )
    local tempCardUI = CImageView:create()
    tempCardUI:setContentSize( 206, 240 )
    tempCardUI:setPosition( 100, 140 )
    pCell:addChild( tempCardUI )
    table.insert( CollectionScWnd.mCardClickVec, tempCardUI )
    tempCardUI:setOnClickScriptHandler( gpvTempCardUIClick )
    tempCardUI:setOnLongClickScriptHandler( gpvTempCardUILongClick )
    pCell.tempCardUI = tempCardUI

    pCell.btn_showCard = CButton:create()
    pCell.btn_showCard:setNormalSpriteFrameName( "collectionwnd/btn_Showcard_normal.png" )
    pCell:addChild( pCell.btn_showCard )
    pCell.btn_showCard:setPosition( 160, 200 )
    pCell.btn_showCard:setVisible( false )
    pCell.btn_showCard:setOnClickScriptHandler( showCardBtnClick )

    pCell.btn_addCard = CButton:create()
    pCell.btn_addCard:setNormalSpriteFrameName( "collectionwnd/btn_Addcard_normal.png" )    
    pCell:addChild( pCell.btn_addCard )
    pCell.btn_addCard:setPosition( 40, 200 )
    pCell.btn_addCard:setVisible( false )
    pCell.btn_addCard:setOnClickScriptHandler( addCardBtnClick )

    pCell.btn_reduceCard = CButton:create()
    pCell.btn_reduceCard:setNormalSpriteFrameName( "collectionwnd/btn_Reducecard_normal.png" )
    pCell:addChild( pCell.btn_reduceCard )
    pCell.btn_reduceCard:setPosition( 40, 50 )
    pCell.btn_reduceCard:setVisible( false )
    pCell.btn_reduceCard:setOnClickScriptHandler( reduceCardBtnClick )

    return pCell
end

--ͼ���϶�����
local function gpvCardClick(p_convertview, idx)
    
	local pCell = p_convertview
    if pCell == nil then
        pCell = createGpvCard()       
        table.insert( CollectionScWnd.mgpvCardArr, pCell ) 
	end

    if idx == -1 then
        pCell:setVisible( false )           
        return pCell
    else
        pCell:setVisible( true )
    end

    pCell.txtStr:setString("")
    pCell.imgLock1:setVisible(false)
    pCell.imgLock2:setVisible(false)
    pCell.txtNum:setString("")
    pCell.imgCardUI.cardUI:setCardRed( false )
    pCell.btn_showCard:setVisible(false)
    pCell.btn_addCard:setVisible(false)
    pCell.btn_reduceCard:setVisible(false)

    local mShowCardArr = CollectionManager:getShowCardArr()
    local obj = mShowCardArr[idx + 1] 
    if obj ~= 0 and obj ~= nil then
        local char = CharacterManager:getMainPlayer()
        pCell.id = obj.id
        pCell.imgCardUI:setCard( obj.id )
        pCell.imgCardUI:setName( obj.id )
        pCell.tempCardUI.id = obj.id
        pCell.tempCardUI.data = pCell.imgCardUI.cardUI.mCardData:getData()
        if CollectionScWnd.mIsLeave == false then
            gpvShowStage(pCell, obj.id)
        else
            if CollectionManager:getHasCardNum(obj.id) ~= 0 then
                pCell.txtNum:setString( CollectionManager:getHasCardNum(obj.id) )
                EffectManager:setGrayFilter(pCell.imgCardUI, false)
            else
                pCell.txtNum:setString( 0 )
                EffectManager:setGrayFilter(pCell.imgCardUI, true)
            end
        end
    else
        pCell:setVisible( false )
    end
   
	return pCell
end


--����ر�mask
local function cardUIMaskClick( p_sender )
    CollectionTpWnd.hideSelectCellUI()
end

--��������
local function btnCreateCard(p_sender)
    if p_sender then mCurGroup = tonumber(p_sender:getName()) end
    CollectionWnd:showPage(SHOW_YZ_WN) 
end


--���Ƴ����¼�����
local function btnCardGroupLongClick(p_sender)
    mCurGroup = tonumber(p_sender:getName())
    if mCurGroup == 99 then return false end
    CollectionTpWnd.mlayoutLongClick.mIndex = tonumber(p_sender:getName())
    print(CollectionTpWnd.mlayoutLongClick.mIndex)
    CollectionTpWnd.mlayoutLongClick:setVisible(true)
--    CollectionTpWnd.mlayoutLongClick:setPosition(100, 100)
    local pX =  CollectionTpWnd.mlayoutLongClick:getPositionX()
--    local pY =  CollectionScWnd.gpvCardTemp:getPositionY() + CollectionScWnd.layout_Right_wdsc:getPositionY() - 620 + p_sender:getParent():getPositionY()
    local pY =   p_sender:getParent():getPositionY()- 620

    CollectionTpWnd.mlayoutLongClick:setPosition(pX, pY)
    return false
end


--����һ������Ԫ��
local function createGpvCardTemp()
    print(debug.getinfo(1).name)
    local pCell = CGridPageViewCell:new()
    TuiManager:getInstance():parseCell( pCell, "cell_CardTemp", PATH_COLLECTIONWND )

--    local RacePhoFace = pCell:getChildByTag( Tag_collectionwnd.IMG_CARDTEMPCELLHEAD )
--    RacePhoFace:setTexture("war2/head/HeadPic10.png")

    local tempCardUI = CImageView:create()
    tempCardUI:setContentSize( 350, 110 )
    tempCardUI:setPosition( 350*0.5, 110*0.5 )
    tempCardUI:setTag( 92 )
    pCell:addChild( tempCardUI, 2 )
    tempCardUI:setOnClickScriptHandler( btnCardGroup )
    tempCardUI:setOnLongClickScriptHandler( btnCardGroupLongClick )
    return pCell
end

--�����б�
local function gpvCardTempClick(p_convertview, idx)
	local pCell = p_convertview
    local BtnCardTemp = nil
    local char = CharacterManager:getMainPlayer()
    local num = 0
    local EqArr = {}
        
    if pCell == nil then
		pCell = createGpvCardTemp()
	end
    local llist = CollectionManager:getCardGroupList()
    local group = CollectionManager:getCardGroupList()[idx + 1]
    if group == nil then
        pCell:setVisible(false)
        return pCell
    end
    pCell:setVisible( true )    

    local CardTempCellBg = pCell:getChildByTag( Tag_collectionwnd.IMG_CARDTEMPCELLBG )
    local mTxtName = pCell:getChildByTag( Tag_collectionwnd.LABEL_CARDTEMPCELLNAME )    
    local RacePhoFace = pCell:getChildByTag( Tag_collectionwnd.IMG_CARDTEMPCELLHEAD )
    local RacePho1 = pCell:getChildByTag( Tag_collectionwnd.IMG_CARDTEMPCELLICON1 )
    local RacePho2 = pCell:getChildByTag( Tag_collectionwnd.IMG_CARDTEMPCELLICON2 )
    local RacePho3 = pCell:getChildByTag( Tag_collectionwnd.IMG_CARDTEMPCELLICON3 )    
    local tempCardUI = pCell:getChildByTag( 92 )

    CollectionScWnd.mIsLast = false    
    RacePho1:setVisible(false)
    RacePho2:setVisible(false)
    RacePho3:setVisible(false)
    
    mTxtName:setString( group.name )
    RacePhoFace:setTexture("war2/head/HeadPic"..group.headId..".png")
    tempCardUI:setName( group.id )
    local dd = CollectionManager:getCardGroupData( group.id  )
    for i = 1, #group.GroupEquipArr do
        if i == 1 then
            RacePho1:setTexture( "war2/warEqIcon/"..group.GroupEquipArr[i].shape..".png" )
            RacePho1:setVisible(true)
        elseif i == 2 then
            RacePho2:setTexture( "war2/warEqIcon/"..group.GroupEquipArr[i].shape..".png" )
            RacePho2:setVisible(true)
        else
            RacePho3:setTexture( "war2/warEqIcon/"..group.GroupEquipArr[i].shape..".png" )
            RacePho3:setVisible(true)
        end
    end
    CardTempCellBg:setVisible(true)
    ----------------------------------3��ʥ����-----------------------------------------------//

    return pCell
end

--�رս���
 function CollectionScWnd.GoClick(p_sender) 
    local char = CharacterManager:getMainPlayer()
    CollectionScWnd.mIsLeave = false
    
    CollectionWnd:closeWindow()
end

function CollectionScWnd.onEnterScene(mMainWnd)
    CollectionScWnd.mCardVec = {}
    MainWnd = mMainWnd
    local char = CharacterManager:getMainPlayer()

    --��ť
     CollectionScWnd.btn_Left = CollectionScWnd.mlayoutMiddle:getChildByTag( Tag_collectionwnd.BTN_LEFTBTN )
     CollectionScWnd.btn_Left:setOnClickScriptHandler( LeftClick )
     CollectionScWnd.btn_Left:setVisible( true )
    
    --�Ұ�ť
     CollectionScWnd.btn_Right = CollectionScWnd.mlayoutMiddle:getChildByTag(  Tag_collectionwnd.BTN_RIGHTBTN )
     CollectionScWnd.btn_Right:setOnClickScriptHandler( RightClick )

    --�Զ����۰�ť
    CollectionScWnd.btn_AutoSell = MainWnd:getControl( 5, Tag_collectionwnd.BTN_AUTOSELL )
    CollectionScWnd.btn_AutoSell:setOnClickScriptHandler( AutoSellClick )
	--require("Music.MusicManager"):instance():PlaySound( 108 ) 
    
    --����ɸѡ��ť
    CollectionScWnd.mOpenFilterBtn = MainWnd:getControl( 5, Tag_collectionwnd.BTN_OPENFILTER )
    CollectionScWnd.mOpenFilterBtn:setOnClickScriptHandler( OpenFilterClick )
    --ɸѡ��ť��Ч
    CollectionScWnd.mFliterEffect = EffectManager:createHnyEffect( 100883, {x = 415, y = 42} )    
    CollectionScWnd.mlayoutUp1:addChild( CollectionScWnd.mFliterEffect )
--    EffectManager:startHnyEffect( CollectionScWnd.mFliterEffect )
    CollectionScWnd.mFliterEffect:stop()

    --�Զ����ư�ť
    CollectionScWnd.btn_AutoMakeDeck = MainWnd:getControl( 5, Tag_collectionwnd.BTN_AUTOMAKEDECK )
    CollectionScWnd.btn_AutoMakeDeck:setOnClickScriptHandler( AutoMakeDeckClick )
    CollectionScWnd.img_AutoMakeDeck = MainWnd:getControl( 5, Tag_collectionwnd.IMG_AUTOMAKEDECK )
    

    --������ʾȫ�����ư�ť
    CollectionScWnd.mOpenShowAllBtn = MainWnd:getControl( 5, Tag_collectionwnd.IMG_OPENSHOWALL )
--    CollectionScWnd.mOpenShowAllBtn:setTouchEnabled( true )
    CollectionScWnd.mOpenShowAllBtn:setOnClickScriptHandler(  OpenShowAllClick )


    --������������
    CollectionScWnd.btn_wdsc_createdeck = CollectionScWnd.layout_Right_wdsc:getChildByTag( Tag_collectionwnd.BTN_WDSC_CREATEDECK )
    CollectionScWnd.btn_wdsc_createdeck:setOnClickScriptHandler(  btnCreateCard )


    --btn_Go_sc�˳�����
    CollectionScWnd.btn_Go_sc = CollectionScWnd.layout_Right_wdsc:getChildByTag( Tag_collectionwnd.BTN_GO_SC )
    CollectionScWnd.btn_Go_sc:setOnClickScriptHandler( CollectionScWnd.GoClick )


    local window = mMainWnd:getChildByTag(Tag_collectionwnd.PANEL_MAIN)
    CollectionScWnd.gpvCard = CollectionScWnd.mlayoutMiddle:getChildByTag( Tag_collectionwnd.GPV_CARD )
    CollectionScWnd.gpvCard:setName( "60" )
    CollectionScWnd.gpvCard:setDataSourceAdapterScriptHandler( gpvCardClick )

    local len = #CollectionManager:getCardGroupList()
    CollectionScWnd.CardTempPageStr = CollectionScWnd.layout_Right_wdsc:getChildByTag( Tag_collectionwnd.LABBMF_MC8 )
    CollectionScWnd.CardTempPageStr:setString( len.."/"..char.deckNum )

    CollectionScWnd.gpvCardTemp = CollectionScWnd.layout_Right_wdsc:getChildByTag( Tag_collectionwnd.GPV_CARDTEMP_WDSC )
    CollectionScWnd.gpvCardTemp:setCountOfCell( len )
    CollectionScWnd.gpvCardTemp:setDataSourceAdapterScriptHandler( gpvCardTempClick )
    CollectionScWnd.gpvCardTemp:reloadData()
    CollectionScWnd.gpvCardTemp:setContentOffsetToTop()

    CollectionScWnd.ImgMask = CollectionWnd:getControl( 1, Tag_collectionwnd.IMG9_MASK)
    CollectionScWnd.ImgMask:setTouchEnabled(true)
    CollectionScWnd.ImgMask:setOpacity(200)
    CollectionScWnd.ImgMask:setOnClickScriptHandler( cardUIMaskClick )
    CollectionScWnd.ImgMask:setVisible(false)

    -----------------------������ʾ��Ϣ-------------------
    CollectionTpWnd.mlayoutLongClick:setLocalZOrder(2)
    local longTxt = CollectionTpWnd.mlayoutLongClick:getChildByTag( Tag_collectionwnd.LABEL_LONG_DELETE )
    longTxt:setString( DataManager:getStringDataTxt( 55, true ) )
    EffectManaget:setMultiplyColor( longTxt, 255, 0, 0 )
    longTxt = CollectionTpWnd.mlayoutLongClick:getChildByTag( Tag_collectionwnd.LABEL_LONG_EDIT )
    longTxt:setString( DataManager:getStringDataTxt( 90, true ) )

    local longBtn = CollectionTpWnd.mlayoutLongClick:getChildByTag( Tag_collectionwnd.BTN_LONG_DELETE )
    longBtn:setOnClickScriptHandler( DeleteClick )
    longBtn = CollectionTpWnd.mlayoutLongClick:getChildByTag( Tag_collectionwnd.BTN_LONG_EDIT )
    longBtn:setOnClickScriptHandler( EditLongClickardSpecial )
end



----------------------------------------��ʾ��������----------------------------------//

--������ʾͼ������
function CollectionScWnd.UpDataCardMsg()

    CollectionManager:UpDataCardMsg()

    local mShowCardArr = CollectionManager:getShowCardArr()
    -----------------------------------���ø�����ʾ����-------------------------
    CollectionScWnd.gpvCard:setCountOfCell(#mShowCardArr)
    CollectionScWnd.mCardGpvPage = math.ceil(#mShowCardArr / 8)    
     -----------------------------------���ø�����ʾ����-------------------------//
    CollectionScWnd.gpvCard:reloadData()
    CollectionScWnd.CardTempPageStr:setString( #CollectionManager:getCardGroupList().."/"..CharacterManager:getMainPlayer().deckNum )

    if CollectionManager:getBolShowAll() == true then
        CollectionScWnd.mOpenShowAllBtn:setOpacity(255)
    else
        CollectionScWnd.mOpenShowAllBtn:setOpacity(0)
    end
end

return CollectionScWnd