----------------------------------------------------------
----------�����޸��ӽ��洦��--------------------------
------------------��Ҫ�Ǳ༭����ʱ���ұߵĿ�����ϸ�б�����----------------------------------------
require "tagMap.Tag_collectionwnd"
require "xiangxi.CardXiangXi"

local DataManager = require("data.DataManager"):instance()
local EffectManaget = require("ui.EffectManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()


local CollectionTpWnd = {}-- ����һ���� test �̳��� base_type


--ȫ����������
CollectionTpWnd.mAllCardNum = nil
--���ƻ��Ѱٷֱ�ͼ�Ƿ�����
CollectionTpWnd.mIsLeft = false
--���Ѱٷֱ�ͼ
CollectionTpWnd.mLayoutSpends = nil
---��ǰ����ʥ��ͼƬ1\2\3-------------------------------------
CollectionTpWnd.mCardGroupImgArr = nil
-----------------------------------------------------------
--��ǰ����ʥ��༭�ϰ�ť
CollectionTpWnd.mCardGroupBtnUp = nil
--��ǰ����ʥ��༭�°�ť
CollectionTpWnd.mCardGroupBtnDown = nil
-------------------------------------------------------------
--����ʥ������
CollectionTpWnd.mlayoutGroupEquip = nil
--��ǰ���ƻ����������� { {pro, txt}, {pro2, txt2},... }����, �ı�
CollectionTpWnd.mCardSpendsArr = {}
CollectionTpWnd.mCardGroupImgArr = {}
--��ǰ���Ƹ����࿨�������ı�����
CollectionTpWnd.mCardTypesArr = {}

--������ʾ�˵����޸����ơ�ɾ�����ơ����������ƣ�
CollectionTpWnd.mlayoutLongClick = nil

CollectionTpWnd.layout_Right_tp = nil

--���ƿ��Ƶ��ʱ��ʾ��cardMiddle
CollectionTpWnd.cardUI = nil

------------���ƽ����ұ߿������С��----------------------------------------------------------
--���׿��ƹ���
CollectionTpWnd.gpvCardTempCards = nil
--����mask
CollectionTpWnd.gpvCardTempCardsMask = nil
--------------------------------------------------------------------------------------------------


function CollectionTpWnd.init()

end


--��ͷ���޸Ľ���
local function cardTitalBgClick(p_sender)
    RunScene("HeadWindow")
end

--���Ʒ��ð�ť����¼�
local function EditorClick(p_sender)
    local MovMove = require("Mov.MovMove").new()
    if CollectionTpWnd.mIsLeft == false then
        CollectionTpWnd.mIsLeft = true
        CollectionTpWnd.mLayoutSpends:setVisible(true)
        MovMove:init(CollectionTpWnd.mLayoutSpends, false, 620, CollectionTpWnd.mLayoutSpends:getPositionY(), 100, 1)  
        MovManager:pushMov( MovMove )
    else
        local MovMove = require("Mov.MovMove").new()
        CollectionTpWnd.mIsLeft = false
        MovMove:init(CollectionTpWnd.mLayoutSpends, false, 1200, CollectionTpWnd.mLayoutSpends:getPositionY(), 100, -1)
        MovMove.callBackFucFinished = function () CollectionTpWnd.mLayoutSpends:setVisible(false) end
        MovManager:pushMov( MovMove )
    end
end


--������Ŀ��Ƶ���¼�
local function tempCardUIClick(p_sender)
    if p_sender.id == nil or p_sender.id == 0 then
        return 
    end
    curGroupCardId = p_sender.id
    if p_sender.id > 9999 then --ʥ��ֱ��ȥ��
        CollectionTpWnd.ChangeCardGrop(p_sender.id, true, 0)
    elseif p_sender:getOpacity() == 0 then
        for i = 1, #CollectionTpWnd.mCardVecList do
            tempSp = CollectionTpWnd.mCardVecList[i]:getChildByTag( 98 )
            if tempSp == p_sender then
                tempSp:setOpacity(255)
                tempSp.BtnCardCountButton:setVisible( true )    
                tempSp.BtnCardCountButtonAdd:setVisible( true )            
            else
                tempSp:setOpacity(0)
                tempSp.BtnCardCountButton:setVisible( false )
                tempSp.BtnCardCountButtonAdd:setVisible( false )
                CollectionScWnd.ImgMask:setVisible(false)
            end
        end
        CollectionScWnd.ImgMask:setVisible(true)
        RightArr.cardUI:setCard( p_sender.id )
    else
        CollectionTpWnd.ChangeCardGrop(p_sender.id, true, 0)
    end
end

--������Ŀ��Ƴ����¼�
local function tempCardUILongClick(p_sender)
    if p_sender.data == nil then
        return false
    end 
    RunScene("CardXiangXi")
    CardXiangXi:setAndShowCardXiangXi( p_sender.data.id, 1 )
    CollectionTpWnd.hideSelectCellUI()
    return false
end

local function tempCardBtnClick( p_sender )
    CollectionTpWnd.ChangeCardGrop(curGroupCardId, true, 0)
end

local function tempCardBtnAddClick( p_sender )
    local arr = CollectionManager:getCurGpvCardNumArr()
    if arr[curGroupCardId] == nil or arr[curGroupCardId] == 0 then
        return
    end
    CollectionTpWnd.ChangeCardGrop(curGroupCardId, false, 0)
end

--ȡ��ѡ�еĿ���
function CollectionTpWnd.hideSelectCellUI()
    for i = 1, #CollectionTpWnd.mCardVecList do
        tempSp = CollectionTpWnd.mCardVecList[i]:getChildByTag( 98 )
        if curGroupCardId == tempSp.id then
            tempSp:setOpacity(0)
            tempSp.BtnCardCountButton:setVisible( false )
            tempSp.BtnCardCountButtonAdd:setVisible( false )
            CollectionScWnd.ImgMask:setVisible( false )
            break
        end        
    end
    curGroupCardId = 0
    CollectionScWnd.ImgMask:setVisible(false)
end

--�༭ʥ�ﰴť
local function CardTtitalBtnClick(p_sender)
    if CollectionTpWnd.mCardGroupBtnDown:isVisible() == true then --�����ǲ���ʾʥ��
         CollectionTpWnd.SetCardTtitalBtn(2)
    else
         CollectionTpWnd.SetCardTtitalBtn(1)
    end
    CollectionTpWnd.hideSelectCellUI()
end

--Ԥ�����Ʒ�����һ��
local function OnTurnTp(p_sender)
    if CollectionManager:getIsSaveDeck() == false then return end
--    CollectionTpWnd.hideSelectCellUI()
    CollectionManager:SendGroupMsg()      
--    CollectionWnd:showPage(SHOW_SC_WN)
--    CollectionTpWnd.SetCardTtitalBtn(1)
end

function CollectionTpWnd.saveDeckCallback()
    CollectionManager:setIsSaveDeck(true)
    CollectionTpWnd.hideSelectCellUI()
    CollectionWnd:showPage(SHOW_SC_WN)
    CollectionTpWnd.SetCardTtitalBtn(1)    
end

function CollectionTpWnd.onEnterScene(mMainWnd)

    MainWnd = mMainWnd
    local window = mMainWnd:getChildByTag(Tag_collectionwnd.PANEL_MAIN)
    local str = DataManager:getStringDataTxt( 56, true )

----------------------------------��ǰѡ�����Ʊ���------------------------------------------------------
    CollectionTpWnd.Btn_Rect = CollectionTpWnd.layout_Right_tp:getChildByTag(  Tag_collectionwnd.BTN_RECT ) 
    CollectionTpWnd.Btn_Rect:setOnClickScriptHandler( EditorClick )
---------------------------------------�ƶ���ť-------------------------------------------------------------
    CollectionTpWnd.mCardGroupBtnUp = CollectionTpWnd.mlayoutGroupEquip:getChildByTag( Tag_collectionwnd.BTN_CARDTITALUP )
    CollectionTpWnd.mCardGroupBtnUp:setOnClickScriptHandler( CardTtitalBtnClick )
    CollectionTpWnd.mCardGroupBtnUp:setLocalZOrder(4)
    CollectionTpWnd.mCardGroupBtnUp2 = CollectionTpWnd.mlayoutGroupEquip:getChildByTag( Tag_collectionwnd.BTN_CARDTITALUP2 )
    CollectionTpWnd.mCardGroupBtnUp2:setOnClickScriptHandler( CardTtitalBtnClick )
    CollectionTpWnd.mCardGroupTxtUp = CollectionTpWnd.mlayoutGroupEquip:getChildByTag(Tag_collectionwnd.LABEL_CARDTITALUP )
    CollectionTpWnd.mCardGroupTxtUp:setString(DataManager:getStringDataTxt( 4136, true ))

    CollectionTpWnd.mCardGroupBtnDown = CollectionTpWnd.mlayoutGroupEquip:getChildByTag(Tag_collectionwnd.BTN_CARDTITALDOWN )
    CollectionTpWnd.mCardGroupBtnDown:setOnClickScriptHandler( CardTtitalBtnClick )
    CollectionTpWnd.mCardGroupBtnDown2 = CollectionTpWnd.mlayoutGroupEquip:getChildByTag(Tag_collectionwnd.BTN_CARDTITALDOWN2 )
    CollectionTpWnd.mCardGroupBtnDown2:setOnClickScriptHandler( CardTtitalBtnClick )
    --CollectionTpWnd.mCardGroupBtnDown:setPositionY( 36 )
    CollectionTpWnd.mCardGroupTxtDown = CollectionTpWnd.mlayoutGroupEquip:getChildByTag(Tag_collectionwnd.LABEL_CARDTITALDOWN )
    CollectionTpWnd.mCardGroupTxtDown:setString(DataManager:getStringDataTxt( 4137, true ))
    CollectionTpWnd.mCardGroupBtnDown:setLocalZOrder(4)
    CollectionTpWnd.mCardGroupBtnDown2:setLocalZOrder(4)
    CollectionTpWnd.mCardGroupTxtDown:setLocalZOrder(4)
---------------------------------ʥ����µ�ͼƬ---------------------------------------------------------------
    CollectionTpWnd.mGroupImgDown = CollectionTpWnd.mlayoutGroupEquip:getChildByTag( Tag_collectionwnd.IMG_GROUPEQDOWN )
    CollectionTpWnd.mGroupImgUp = CollectionTpWnd.mlayoutGroupEquip:getChildByTag( Tag_collectionwnd.IMG_GROUPEQUP )
    CollectionTpWnd.mGroupImgUp:setTouchEnabled(true)
    CollectionTpWnd.mGroupImgUp:setLocalZOrder(3)
    CollectionTpWnd.mGroupImgDown:setLocalZOrder(3)

    CollectionTpWnd.mGroupImgMask = CollectionTpWnd.mlayoutGroupEquip:getChildByTag( Tag_collectionwnd.IMG9_CARDTITALMASK )
    CollectionTpWnd.mGroupImgMask:setOpacity( 255 * 0.7 )
    CollectionTpWnd.mGroupImgMask:setTouchEnabled(false)
    CollectionTpWnd.mGroupImgMask:setLocalZOrder(3)
--------------------------------------------------------------------------------------------------------------

    for i = 1, 3 do
        local img = require( "war2.war2CardSpecial" ).new()
        CollectionTpWnd.mCardGroupImgArr[i]  = img
        img:init( 0, 3 )
        img.IsInGroup = true
        img:setPosition( 75+100*(i-1), 100 )
        CollectionTpWnd.mlayoutGroupEquip:addChild( img )
        img:setVisible(false)
        img:setLocalZOrder(2)

        img.tempCardUI = CImageView:create()
        img.tempCardUI:setContentSize( 100, 100 )
        img.tempCardUI:setPosition( img:getPositionX(),img:getPositionY() )
        CollectionTpWnd.mlayoutGroupEquip:addChild( img.tempCardUI )
        table.insert( CollectionScWnd.mCardClickVec, img.tempCardUI )
        img.tempCardUI:setOnClickScriptHandler( tempCardUIClick )
        img.tempCardUI:setOnLongClickScriptHandler( tempCardUILongClick )
        img.tempCardUI:setLocalZOrder(2)
        img:setCard(10001)
    end

-----------------------------------------------------------------------------------------------------------------------------------
    local char = CharacterManager:getMainPlayer()

    CollectionTpWnd.CardTitalFont = CollectionTpWnd.layout_Right_tp:getChildByTag( Tag_collectionwnd.LABEL_GROUPNAME )
    CollectionTpWnd.CardTitalFont:setString( DataManager:getStringDataTxt( 34, true ) )
    CollectionTpWnd.CardTitalFont:setVisible( true )

    CollectionTpWnd.CardTitalHeadImg = CollectionTpWnd.layout_Right_tp:getChildByTag( Tag_collectionwnd.IMG_DECKHEAD )

    ----------------------------------��ǰѡ�����Ʊ���--------------------------------------------------------//
    CollectionTpWnd.CardTitalBg = CollectionTpWnd.layout_Right_tp:getChildByTag(Tag_collectionwnd.BTN_CARDTITALBG )
    CollectionTpWnd.CardTitalBg:setVisible( true )
    CollectionTpWnd.CardTitalBg:setOnClickScriptHandler( cardTitalBgClick )

    -----------------------������ʾ��Ϣ-----------------------------------------------------------------------
    CollectionTpWnd.btn_turn_tp = CollectionTpWnd.layout_Right_tp:getChildByTag(Tag_collectionwnd.BTN_TURN_TP )
    CollectionTpWnd.btn_turn_tp:setOnClickScriptHandler( OnTurnTp )

    
    ------------���뿨����Ϣ--------------
    local char = CharacterManager:getMainPlayer()
    local isok = false
    local mObj = nil

    CollectionTpWnd.mAllCardNum = CollectionTpWnd.layout_Right_tp:getChildByTag( Tag_collectionwnd.LABBMF_ALLCARDNUM )
    CollectionTpWnd.mAllCardNum:setAlignment( 1, 0 )
    CollectionTpWnd.mAllCardNum:setString("")

    CollectionTpWnd.gpvCardTempCards = CollectionTpWnd.layout_Right_tp:getChildByTag( Tag_collectionwnd.LIST_CARDTEMPCARDS )
    CollectionTpWnd.gpvCardTempCards:setVisible( true )
    CollectionTpWnd.gpvCardTempCards:removeAllNodes()
--    CollectionTpWnd.gpvCardTempCards:initWithSize( cc.size(330, 445) )
--    CollectionTpWnd.gpvCardTempCards:setPositionX( 180 )
--    CollectionTpWnd.gpvCardTempCards:setPositionY( 350 )

    CollectionTpWnd.gpvCardTempCardsMask = CollectionTpWnd.layout_Right_tp:getChildByTag( Tag_collectionwnd.IMG_RIGHTMASK_TP )
    CollectionTpWnd.gpvCardTempCardsMask:setTouchEnabled(true)
--    CollectionTpWnd.gpvCardTempCardsMask:setOpacity(150)
    CollectionTpWnd.gpvCardTempCardsMask:setVisible( false )
    CollectionTpWnd.gpvCardTempCardsMask:setOnClickScriptHandler( CardTtitalBtnClick )

    CollectionTpWnd.LabelTempCardsMask = CollectionTpWnd.layout_Right_tp:getChildByTag( Tag_collectionwnd.LABEL_RIGHTMASK_TP )
    CollectionTpWnd.LabelTempCardsMask:setString(DataManager:getStringDataTxt( 2125, true ))
    CollectionTpWnd.LabelTempCardsMask:setVisible( false )
    ------------���뿨����Ϣ--------------
    ---------------------���� + ���ѿ�------------------------------------------------begin
    CollectionTpWnd.CardBoxBg = MainWnd:getControl( 1, Tag_collectionwnd.IMG_CARDBOXBG )
--------------------------------------------------------------------------------------------
--    local mDownMask = CImageView:create( "collectionwnd/img_StoreBuyCard+Back.png" )
--    local mSpendMaskVec = cc.ClippingNode:create()
--    mSpendMaskVec:setContentSize( mDownMask:getContentSize() )--want click mask this
--    mSpendMaskVec:setStencil( mDownMask )
--    mSpendMaskVec:setPosition( 200, -500 )    
--    mDownMask:setPosition( mDownMask:getContentSize().width*0.5, mDownMask:getContentSize().height*0.5 )
--    window:removeChild( CollectionTpWnd.mLayoutSpends )
--    mSpendMaskVec:addChild( CollectionTpWnd.mLayoutSpends )

--    CollectionTpWnd.mLayoutSpends:setPosition( 1200, 183 )
--    mSpendMaskVec:setAlphaThreshold( 1 )
--    mSpendMaskVec:setInverted( false )
--    window:addChild( mSpendMaskVec )

-------------------------------------------------------------------------------------
    --���ѿ򱳾�ͼ
    local SpendsBg = MainWnd:getControl( 7, Tag_collectionwnd.IMG_PROFILEBOX )
    SpendsBg:setTouchEnabled( true )
    ---------------------���� + ���ѿ�------------------------------------------------
    --���Ϸ���1-2-3-4��������9
    local prog_Percent = nil
    local font = nil
    for i = 0, 10 do
        prog_Percent = MainWnd:getControl( 7, Tag_collectionwnd["PROG_PERCENT"..i] )
        prog_Percent:setDirection( 2 )
        prog_Percent:setValue( 0 )
        prog_Percent:setMaxValue( 40 )
        font = MainWnd:getControl( 7, Tag_collectionwnd["LABBMF_PERCENT"..i] )
        font:setString( 0 )
        CollectionTpWnd.mCardSpendsArr[i] = {pro = prog_Percent, txt = font}
    end

    CollectionTpWnd.mCardTypesArr = {}
    CollectionTpWnd.mCardTypesArr[1] = MainWnd:getControl( 7, Tag_collectionwnd["LABBMF_CREATURENUM"] ) --1����, 2����, 3����, 4����
    CollectionTpWnd.mCardTypesArr[2] = MainWnd:getControl( 7, Tag_collectionwnd["LABBMF_FLASHNUM"] )
    CollectionTpWnd.mCardTypesArr[3] = MainWnd:getControl( 7, Tag_collectionwnd["LABBMF_DOMAINNUM"] )
    CollectionTpWnd.mCardTypesArr[4] = MainWnd:getControl( 7, Tag_collectionwnd["LABBMF_SPELLNUM"] )

    CollectionTpWnd.SetCardTtitalBtn(1)
end

--����ʥ�ﰴť  0ȫ������ʾ, 1��ʾ�°�ť�Ҳ���ʾ����ʥ�� 2��ʾ�ϰ�ť������ʥ��
function CollectionTpWnd.SetCardTtitalBtn( showType )
    local type = 2
    if showType == 1 then 
        CollectionTpWnd.mCardGroupBtnDown:setVisible(true)
        CollectionTpWnd.mCardGroupBtnDown2:setVisible(true)
        CollectionTpWnd.mCardGroupTxtDown:setVisible(true)
        CollectionTpWnd.mGroupImgMask:setVisible(true)
        CollectionTpWnd.mCardGroupBtnUp:setVisible(false)
        CollectionTpWnd.mCardGroupBtnUp2:setVisible(false)
        CollectionTpWnd.mCardGroupTxtUp:setVisible(false)
        CollectionTpWnd.mGroupImgDown:setVisible(false)
        CollectionTpWnd.mGroupImgUp:setVisible(true)
        for i = 1, 3 do
            CollectionTpWnd.mCardGroupImgArr[i]:setVisible(true)
            CollectionTpWnd.mCardGroupImgArr[i]:setTouchEnabled(true)
        end

        local MovMove = require("Mov.MovMove").new()

        --MovMove:init(CollectionTpWnd.mlayoutGroupEquip, true, 0, -30, 200, -1)
        local y = CollectionTpWnd.mlayoutGroupEquip:getPositionY()
        MovMove:init(CollectionTpWnd.mlayoutGroupEquip, false, CollectionTpWnd.mlayoutGroupEquip:getPositionX(), 630, 200, -1)
        MovManager:pushMov( MovMove )
        CollectionTpWnd.gpvCardTempCardsMask:setVisible( false )
        CollectionTpWnd.LabelTempCardsMask:setVisible( false )

        CollectionManager:setBolShowEq( false )
        CollectionScWnd.UpDataCardMsg() 
    else
        CollectionTpWnd.mCardGroupBtnDown:setVisible(false)
        CollectionTpWnd.mCardGroupBtnDown2:setVisible(false)
        CollectionTpWnd.mCardGroupTxtDown:setVisible(false)
        CollectionTpWnd.mGroupImgMask:setVisible(false)
        CollectionTpWnd.mCardGroupBtnUp:setVisible(true)
        CollectionTpWnd.mCardGroupBtnUp2:setVisible(true)
        CollectionTpWnd.mCardGroupTxtUp:setVisible(true)
        CollectionTpWnd.mGroupImgDown:setVisible(true)
        CollectionTpWnd.mGroupImgUp:setVisible(false)
        for i = 1, 3 do
            CollectionTpWnd.mCardGroupImgArr[i]:setVisible(true)
            CollectionTpWnd.mCardGroupImgArr[i]:setTouchEnabled(true)
        end
        local MovMove = require("Mov.MovMove").new()
        --MovMove:init(CollectionTpWnd.mlayoutGroupEquip, true, 0, -30, 200, -1)
        MovMove:init(CollectionTpWnd.mlayoutGroupEquip, false, CollectionTpWnd.mlayoutGroupEquip:getPositionX(), 290+260+10, 200, -1)
        MovManager:pushMov( MovMove )
        CollectionTpWnd.gpvCardTempCardsMask:setVisible( true )
        CollectionTpWnd.LabelTempCardsMask:setVisible( true )

        CollectionManager:setBolShowEq( true )
        CollectionScWnd.UpDataCardMsg()
    end

end


--���ÿ�����
function CollectionTpWnd.updateCardGroupName()    
    if CollectionScWnd.mIsLeave == true then  --������Ǵ������Ʊ༭״̬,����¿����б�,����������Ƶı����ı�
        CollectionTpWnd.updataCardGroupMsg()
    else
        local group = CollectionManager:getCardGroupData( mCurGroup )
        CollectionTpWnd.CardTitalFont:setString( group.name )
        CollectionTpWnd.CardTitalHeadImg:setTexture( "war2/head/HeadPic"..group.headId..".png" )
    end
end

--�������ǿ�����Ϣ
function CollectionTpWnd.updataCardGroupMsg()
    local len = #CollectionManager:getCardGroupList()
    CollectionScWnd.gpvCardTemp:setCountOfCell( len )
    CollectionScWnd.gpvCardTemp:setContentOffsetToLeft()
    CollectionScWnd.gpvCardTemp:reloadData()
    CollectionScWnd.CardTempPageStr:setString( len.."/"..CharacterManager:getMainPlayer().deckNum )
end

--������������
function CollectionTpWnd.insertItemToList(idx)
    local pCell = CollectionTpWnd.mCardVecList[idx]
    if pCell == nil then
		pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell( pCell, "cell_grid", PATH_COLLECTIONWND )

        local ImgCardUI = require( "war2.war2CardSpecial" ).new()
        ImgCardUI:setTouchEnabled( true )
        ImgCardUI:setTag( 99 )
        ImgCardUI:init( 0, 2 )
        ImgCardUI.IsInGroup = true
        pCell:addChild( ImgCardUI, 1 )
        table.insert( CollectionTpWnd.mCardVecList,pCell )

        local tempCardUIRed =  CImageView:create()
        tempCardUIRed:setSpriteFrame( "collectionwnd/img_CardBoxLight+Red.png" )
        tempCardUIRed:setContentSize( 330, 65 )
        tempCardUIRed:setPosition( 330*0.5 - 7, 65*0.5 - 5 )
        tempCardUIRed:setTag( 97 )
        pCell:addChild( tempCardUIRed, 1 )

        local tempCardUI = CImageView:create()
        tempCardUI:setSpriteFrame( "collectionwnd/img_CardBoxLight.png" )
        tempCardUI:setContentSize( 330, 65 )
        tempCardUI:setPosition( 330*0.5 - 7, 65*0.5 - 5 )
        tempCardUI:setTag( 98 )
        tempCardUI:setOpacity(0)
        pCell:addChild( tempCardUI, 2 )
        tempCardUI:setOnClickScriptHandler( tempCardUIClick )
        tempCardUI:setOnLongClickScriptHandler( tempCardUILongClick )

        tempCardUI.BtnCardCountButton = CButton:create()
        tempCardUI.BtnCardCountButton:setNormalSpriteFrameName( "collectionwnd/btn_CardCountButton_normal.png" )
        tempCardUI.BtnCardCountButton:setSelectedSpriteFrameName( "collectionwnd/btn_CardCountButton_select.png" )
        tempCardUI.BtnCardCountButton:setPosition( 248, 34 )
        pCell:addChild( tempCardUI.BtnCardCountButton, 3 )
        tempCardUI.BtnCardCountButton:setVisible( false )
        tempCardUI.BtnCardCountButton:setOnClickScriptHandler( tempCardBtnClick )

        tempCardUI.BtnCardCountButtonAdd = CButton:create()
        tempCardUI.BtnCardCountButtonAdd:setNormalSpriteFrameName( "collectionwnd/btn_CardCountButtonADD_normal.png" )
        tempCardUI.BtnCardCountButtonAdd:setSelectedSpriteFrameName( "collectionwnd/btn_CardCountButtonADD_select.png" )
        tempCardUI.BtnCardCountButtonAdd:setPosition( 33, 34 )
        pCell:addChild( tempCardUI.BtnCardCountButtonAdd, 3 )
        tempCardUI.BtnCardCountButtonAdd:setVisible( false )
        tempCardUI.BtnCardCountButtonAdd:setOnClickScriptHandler( tempCardBtnAddClick )
	end
    pCell:setName( "" )
    local ImgCardUI = pCell:getChildByTag( 99 )
    local tempCardUI = pCell:getChildByTag( 98 )
    local tempCardUIRed = pCell:getChildByTag( 97 )
    local CurGroupCardArr = CollectionManager:getCurGroupCardArr()
    tempCardUIRed:setVisible( false )
    if #CurGroupCardArr ~= 0 then 
        if idx ~= -1 then
            local obj = CurGroupCardArr[idx].data
            if obj ~= 0 and obj ~= nil then
                local char = CharacterManager:getMainPlayer()
                ImgCardUI:setCard( obj.id )
                tempCardUI.id = obj.id
                tempCardUI.data = obj
                ImgCardUI:setName( idx )
                pCell:setName( idx )
                if  obj.id < 9999 then
                    ImgCardUI:setCardNum( CurGroupCardArr[idx].num )
                    -------------------��ϵ��־������ʥ������������ͨ���Ʋ��ܷ���---------
                    local isOK = CollectionManager:checkCardRace(obj)
                    if isOK == false then
                        tempCardUIRed:setVisible( true )
                    end
                    pCell:setVisible( true )

                    if obj.id < 9999 and curGroupCardId == obj.id then
                        tempCardUIClick(tempCardUI) --�ǵ�ǰѡ��ļ��ܵĻ���ѡ����
                    end
                end
            else
                pCell:setVisible( false )
            end
        else
            pCell:setVisible( false )
        end
    end
    pCell:setContentSize( cc.size( 340, 65 ) )
    CollectionTpWnd.gpvCardTempCards:insertNodeAtLast( pCell )
end




--���ؿ����Զ�����
local function AutoGroup()

end


--����ʥ�￨��
local function UpdateEquip()
    local mCurEqCardArr = CollectionManager:getCurGroupEquipArr()
    local num = 0
    for i = 1, 3 do
        if mCurEqCardArr[i] == nil then
            CollectionTpWnd.mCardGroupImgArr[i]:setCard(0)
            CollectionTpWnd.mCardGroupImgArr[i]:setName(0)
            CollectionTpWnd.mCardGroupImgArr[i].tempCardUI.id = 0
            CollectionTpWnd.mCardGroupImgArr[i].tempCardUI.data = nil
        else
            CollectionTpWnd.mCardGroupImgArr[i]:setCard( mCurEqCardArr[i].id )
            CollectionTpWnd.mCardGroupImgArr[i]:setName( mCurEqCardArr[i].id )
            CollectionTpWnd.mCardGroupImgArr[i].tempCardUI.id = mCurEqCardArr[i].id
            CollectionTpWnd.mCardGroupImgArr[i].tempCardUI.data = DataManager:getEq(mCurEqCardArr[i].id)
            num = num + 1
        end
    end
    if num == 3 then
        CollectionTpWnd.SetCardTtitalBtn( 1 )
        CollectionScWnd.gpvCard:setContentOffsetToLeft()
        return true
    end
    return false
end



--���Ŀ��׿�������
function CollectionTpWnd.ChangeCardGrop(id, isInGroup, moveType)
    CollectionManager:ChangeCardGrop(id, isInGroup)    
--    local isUpdataShow = not UpdateEquip()
    local isUpdataShow = false
    if id < 9999 then 
        isUpdataShow = true
    else
        isUpdataShow = not UpdateEquip()
    end
    CollectionWnd:updateGpvCardList(isUpdataShow)
end


--���ƻ�����������������
function CollectionTpWnd.CardSpendMsg(isUpdataShow)
    local arr = CollectionManager:getCurGroupCostArr()
    if arr == nil then return end
    local prog_Percent = nil
    local num = 0
    local char = CharacterManager:getMainPlayer()
    local AllCardNum = 0
    for i = 0, 10 do
        if CollectionTpWnd.mCardSpendsArr[i] ~= nil then
            prog_Percent = CollectionTpWnd.mCardSpendsArr[i].pro
            prog_Percent:setValue( arr[i] )
            AllCardNum = AllCardNum + arr[i]
            CollectionTpWnd.mCardSpendsArr[i].txt:setString( arr[i] )
        end
    end
    CollectionScWnd.CardTempPageStr:setPositionX( 100 )
    CollectionScWnd.CardTempPageStr:setString( "/"..CollectionManager.GroupMaxNum )
    CollectionTpWnd.mAllCardNum:setString(AllCardNum.."/"..60)
    if AllCardNum >= CollectionManager.GroupMinNum then
        CollectionTpWnd.mAllCardNum:setColor(cc.c3b(255,255,255))
    else
        CollectionTpWnd.mAllCardNum:setColor(cc.c3b(255,0,0))
    end

    local tArr = CollectionManager:getCurGroupTypeArr()
    for i = 1, 4 do
        CollectionTpWnd.mCardTypesArr[i]:setHorizontalAlignment(cc.ui.TEXT_ALIGN_RIGHT)
        CollectionTpWnd.mCardTypesArr[i]:setString("X"..tArr[i])
    end
end


--���Ʊ༭
function CollectionTpWnd.EditCardGroup( gId )
    if gId ~= nil then 
        mCurGroup = gId 
    else
        mCurGroup = CollectionManager:getCurGroupID()
    end
    local char = CharacterManager:getMainPlayer()
    
    
    local group = CollectionManager:getCardGroupData( mCurGroup )
    CollectionManager:EditGroup( mCurGroup )

    CollectionScWnd.mIsLeave = false
    CollectionTpWnd.CardTitalFont:setString( group.name )
    CollectionTpWnd.CardTitalHeadImg:setTexture( "war2/head/HeadPic"..group.headId..".png" )
    CollectionTpWnd.CardSpendMsg(true) 
    CollectionWnd:updateGpvCardList(false, true)
    if UpdateEquip() == false then
        CollectionTpWnd.SetCardTtitalBtn(2)    
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionTpWnd.gpvCardTempCards:setContentOffsetToTop()

    if #group.GroupEquipArr == 0 then 
        if NewbieManager.UseData.Collection3rd == false then
            require("framework.scheduler").performWithDelayGlobal( function () NewbieWindow:setAndShowType("Collection3rd") end, 0.5 )
        end
    else
        if NewbieManager.UseData.Collection2nd == false then
            NewbieWindow:setAndShowType("Collection2nd")
        end
    end
    CollectionWnd:showPage(SHOW_TP_WN) 
end

return CollectionTpWnd

