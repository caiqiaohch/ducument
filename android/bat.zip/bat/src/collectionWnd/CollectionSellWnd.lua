require "tagMap.Tag_ladder"
require "framework.display"
require "framework.cc.ui.UIListView"
local ServMsgTransponder = require("net.ServMsgTransponder")

local __instance = nil
--排行榜列表


--关闭按钮
local btn_close

local label_NumArr={}
local label_NumArrG={}

--总共能卖出多少文本
local label_GoldAll

--要预加载的资源列表
local resArr = { PLIST_COLLECT_URL }

CollectionSellWnd = class("CollectionSellWnd",function()
	return TuiBase:create()
end)

CollectionSellWnd.isShow = false

function CollectionSellWnd:create()
	local ret = CollectionSellWnd.new()
	__instance = ret
    ret:setAutoRemoveUnusedSpriteFrame(true)
    ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function CollectionSellWnd:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

function CollectionSellWnd:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

--界面外点击关闭事件
local function BtnCloseClick(p_sender)
    print("close")
    PopScene(__instance)
end


--清除
function CollectionSellWnd:clear( tempSelf )
    for i in pairs(tempSelf.mData) do
        tempSelf.mData[i] = nil
    end
    tempSelf.mData = nil
end


--初始化界面
function CollectionSellWnd:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )    
end

-----------------------------------------自动出售---------------------------------
--更新自动贩卖信息
local function updateAutoSellMsg()
    local qltArr = {0, 0, 0, 0}
    local goldArr = {0,0,0,0}
    local char = CharacterManager:getMainPlayer()
    local overflow = 0
    local sellGold = 0
    autoSellCardList = {}
    for i, num in pairs( CollectionManager:getAllHasCardList() ) do
        if ShopManager:getShopCardData(i) ~= nil and ShopManager:getShopCardData(i).exist == 1 then --在卡牌市场存在的物品才可以贩卖
            if i > 9999 then 
                obj = DataManager:getEq( i ) 
            else 
                obj = DataManager:getCardObjByID( i, false )
            end
                overflow = num - obj.finity
            if overflow > 0 then
                local gold = ShopManager:getShopCardData(obj.id).sell
                goldArr[obj.qlt] = goldArr[obj.qlt] + gold*overflow
                qltArr[obj.qlt] = qltArr[obj.qlt] + overflow

                sellGold = sellGold + ShopManager:getShopCardData(obj.id).sell * overflow
                table.insert(autoSellCardList, {id = obj.id, num = overflow})
            end        
        end
    end
    for i = 1, 4 do
        label_NumArr[i]:setString( qltArr[i] )
    end

    for i = 1, 4 do
        label_NumArrG[i]:setString( goldArr[i] )
    end

    label_GoldAll:setString( "+"..sellGold )
end


--出售按钮点击事件
local function BtnAutoSellClick(p_sender)
    print("BtnAutoSellClick")	
    if socket.gettime() - ShopManager.sellTime < 2 then return end
    local str = ""
    local sellNum = 0
    for i = 1, #autoSellCardList do
         str = str..autoSellCardList[i].id..","..autoSellCardList[i].num

        if i ~= #autoSellCardList then 
            str = str..";"
        end
        sellNum = sellNum + autoSellCardList[i].num
    end
    if sellNum <= 0 then return end
    ShopManager.sellTime = socket.gettime()
    ServMsgTransponder:SMTShopSell(str)--卡牌信息：   卡牌id1,数量1;卡牌id2,数量2;....
    PopScene(__instance)
--    require("prompt.PromptManager"):instance():SetNotice(72, mLabBmfGold:getString())
end

-----------------------------------------自动出售---------------------------------

function CollectionSellWnd:onEnterScene()
--    TuiManager:getInstance():parseScene(self,"panel_rank",PATH_LADDER)
    TuiManager:getInstance():parseScene(self,"panel_sell",PATH_COLLECTIONWND)

    btn_close = self:getControl(Tag_collectionwnd.PANEL_SELL, Tag_collectionwnd.BTN_CLOSE)
    btn_close:setOnClickScriptHandler( BtnCloseClick )

    btn_SellAll = self:getControl(Tag_collectionwnd.PANEL_SELL, Tag_collectionwnd.BTN_SELLALL)
    btn_SellAll:setOnClickScriptHandler( BtnAutoSellClick )

    label_GoldAll = self:getControl(Tag_collectionwnd.PANEL_SELL, Tag_collectionwnd.LABBMF_ALLGOLD)

    for i = 1, 4 do
        label_NumArr[i] = self:getControl(Tag_collectionwnd.PANEL_SELL,  Tag_collectionwnd["LABBMF_NUM"..i] )
    end

    for i = 1, 4 do
        label_NumArrG[i] = self:getControl(Tag_collectionwnd.PANEL_SELL,  Tag_collectionwnd["LABBMF_NUMG"..i] )
    end

--    ------------------------按钮-------------------------------------//
    updateAutoSellMsg()
    CollectionSellWnd.isShow = true
end


function CollectionSellWnd:onExitScene()
    CollectionSellWnd.isShow = false
end
