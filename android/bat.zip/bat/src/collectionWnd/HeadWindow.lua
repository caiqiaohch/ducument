require "tagMap.Tag_collectionwnd"
local war2CardManager = require("war2.war2CardManager")
local scheduler = require("framework.scheduler")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager"):instance()
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local CursorTextField = require("ui.CursorTextField")

HeadWindow = class("HeadWindow",function()
	return TuiBase:create()
end)

local __instance = nil
--总容器
local window = nil

--可拖动区域,用于触发事件
local mScroll

--当前头像id
local mCurHeadId = 0

local imgList = {}

local mBtnLeft
local mBtnRight

local mHeadImgList = {}
local mMaxId = 36
local mMinId = 1

local mEditReName

function HeadWindow:create()
	local ret = HeadWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function HeadWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end


function HeadWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end


-----------------------------点击触发事件--------------------------


local function trim (s) 
    local t = ""
    for s in string.gmatch(s,"[%w_]") do
        t = t .. s
    end
    return t
end 

--过滤特殊字符，保留中文、英文和数字
function filter_spec_chars(s)
    local ss = {}
    local k = 1
    while true do
        if k > #s then break end
        local c = string.byte(s,k)
        if not c then break end
        if c<192 then
            if (c>=48 and c<=57) or (c>= 65 and c<=90) or (c>=97 and c<=122) then
                table.insert(ss, string.char(c))
            end
            k = k + 1
        elseif c<224 then
            k = k + 2
        elseif c<240 then
            if c>=228 and c<=233 then
                local c1 = string.byte(s,k+1)
                local c2 = string.byte(s,k+2)
                if c1 and c2 then
                    local a1,a2,a3,a4 = 128,191,128,191
                    if c == 228 then a1 = 184
                    elseif c == 233 then a2,a4 = 190,c1 ~= 190 and 191 or 165
                    end
                    if c1>=a1 and c1<=a2 and c2>=a3 and c2<=a4 then
                        table.insert(ss, string.char(c,c1,c2))
                    end
                end
            end
            k = k + 3
        elseif c<248 then
            k = k + 4
        elseif c<252 then
            k = k + 5
        elseif c<254 then
            k = k + 6
        end
    end
    return table.concat(ss)
end


--更改卡套名字
local function eventmEditName(strEventName,editbox)
--    if strEventName == "return" then
--		print(pSender:getText())
--	end
    local str =  editbox:getText()
    str = filter_spec_chars(str)
    editbox:setText( str )
    editbox:setOpacity(255)
end

local function CursorTextListener(event, editbox)   --监听事件
    if event == 0 then
        if editbox.isInit == true then
            editbox:setText("")
            editbox.isInit = false
        end
--    elseif event == 2 or event == 3 then
--        local str = string.lower( editbox:getText() )
--        CollectionManager:setSiftStr(str)
--        CollectionScWnd.UpDataCardMsg()
    end
end

--关闭按钮点击事件
local function onCloseClick(p_sender)  
    PopScene(__instance)
end

--更换头像按钮点击事件
local function onFaceClick(p_sender)  
    CollectionManager.EditGroupId = CollectionManager:getCurGroupID()
    CollectionManager.EditGroupHeadId = mCurHeadId
    CollectionManager.EditGroupName = CollectionManager:getCardGroupData(CollectionManager.EditGroupId).name
    local str = CollectionManager.EditGroupName.."$"..CollectionManager.EditGroupHeadId.."$"..CollectionManager.EditGroupId
    ServMsgTransponder:SMTName( CollectionManager.EditGroupId, str )
    onCloseClick()  --最后关闭界面
end

--重命名按钮点击事件
local function onReNameClick(p_sender)  
--    mEditReName:touchDownAction(nil,2)
    CollectionTpWnd.mlayoutLongClick:setVisible(false)

    if CollectionScWnd.mIsLeave == false then
        CollectionManager.EditGroupId = CollectionManager:getCurGroupID()
    else  
        CollectionManager.EditGroupId = CollectionTpWnd.mlayoutLongClick.mIndex
    end

    if mEditReName:getText() ~= "" then
        local str = mEditReName:getText()
--        str = string.gsub(str, " ", "")
        CollectionManager.EditGroupName = str
        CollectionManager.EditGroupHeadId = CollectionManager:getCardGroupData(CollectionManager.EditGroupId).headId

        local len = string.len(str)
        str = str.."$"..CollectionManager.EditGroupHeadId.."$"..CollectionManager.EditGroupId
        if len > 15 then
            require("prompt.PromptManager"):instance():SetNotice(4023)  --牌组名长度已到上限
            return
        else
            ServMsgTransponder:SMTName( CollectionManager.EditGroupId, str )
        end
        onCloseClick()  --最后关闭界面
    end    
end

--删除按钮点击事件
local function onDeleteClick(p_sender)  
    local index = CollectionManager:getCurGroupID()
    local group = CollectionManager:getCardGroupData(index)
    if group == nil then return end
    CollectionManager.DeleteGroupId = index
    if group.save == true then        
        ServMsgTransponder:SMTDelete_decks(CollectionManager.DeleteGroupId)
    else
        CollectionTpWnd:updataCardGroupMsg()
    end

    onCloseClick()  --最后关闭界面
    CollectionWnd:showPage(SHOW_SC_WN)
end

function HeadWindow:onLoadScene()
    self:onEnterScene() 
end

--计算得出的id可能不符合要求,处理一下
local function getHeadId( id )
     if id < mMinId then id = mMaxId 
     elseif id > mMaxId then id = mMinId end
     return id
end

--播放特效, dir 0 向左滚动, headId + 1,  1 右, headId - 1
local function playEff( dir )  
    if mIsScrollIng == true then return end      
    imgList = {}

    local idList = {}
    local frontId = getHeadId( mCurHeadId - 1 )
    local behindId = getHeadId( mCurHeadId + 1  )
    if dir == 1 then
        idList[3] = getHeadId( frontId - 1 )
        idList[2] = getHeadId( frontId )
        idList[1] = getHeadId( mCurHeadId )
        idList[4] = getHeadId( behindId )
        mCurHeadId = getHeadId( mCurHeadId - 1 )
    else
        idList[4] = getHeadId( frontId )
        idList[1] = getHeadId( mCurHeadId )
        idList[2] = getHeadId( behindId )
        idList[3] = getHeadId( behindId + 1 )
        mCurHeadId = getHeadId( mCurHeadId + 1 )
    end

    for i = 1, 4 do
        imgHead = cc.Sprite:create()
        imgHead:setTexture("war2/head/HeadPic"..idList[i]..".png")
        local box = cc.Sprite:create()
        box:setTexture("other/img_heroFaceBox.png")
        imgHead:addChild(box)
        box:setPosition(90, 90)  --这里是以头像的大小(160*160)居中
        imgHead:setContentSize( cc.size( 180, 180 ) )
        imgHead:setFlippedY(true)
        box:setFlippedY(true)
        local sp = TextureManager:getSprite( imgHead )
        local tx2d = sp:getTexture()
        imgList[i] = tx2d
    end
    local effId = 100657
    if dir == 1 then
        effId = 100684
    end
    local diy = TextureManager:getDiyEffect(effId , imgList)
    local hyDiy = EffectManager:createHnyEffect( effId , {x = -100, y = 245}, nil, diy )   
    window:addChild( hyDiy )
    EffectManager:startHnyEffect( hyDiy, { key = function () HeadWindow:updateHeadList() end } )
    for i = 1, 3 do
        mHeadImgList[i]:setVisible(false)
    end
    mIsScrollIng = true
end


local function onScroll(p_sender)
--    print("onScroll")
    local pos = mScroll:getContentOffset()
    local w = mScroll:getContentSize().width
    local offX = pos.x - w * 0.5
    local con = mScroll:getContainerSize()
--    print( " off "..offX.." "..pos.x..","..con.width )
    if mScroll:getContentOffset().x > 20 then
        playEff(1)     
    elseif mScroll:getContentOffset().x < -20 then
        playEff(0)     
    end 
end

local function onBtnLeftClick(p_sender)  
    playEff(0)     
end

local function onBtnRightClick(p_sender)  
    playEff(1)     
end



function HeadWindow:updateHeadList()
    mIsScrollIng = false
    for i = 1, 3 do
        mHeadImgList[i]:setVisible(true)
    end
    local frontId = getHeadId( mCurHeadId - 1 )
    local behindId = getHeadId( mCurHeadId + 1  )
    mHeadImgList[1]:setTexture("war2/head/HeadPic"..frontId..".png")
    mHeadImgList[2]:setTexture("war2/head/HeadPic"..mCurHeadId..".png")
    mHeadImgList[3]:setTexture("war2/head/HeadPic"..behindId..".png")
    print("updateHeadList")
end

function HeadWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_headFace",PATH_COLLECTIONWND)
    window = self:getPanel(Tag_collectionwnd.PANEL_HEADFACE)

    local imgBg = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.IMG_FACE_FACEEDITBACK) 
    imgBg:setTouchEnabled(true)

    local btn = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.BTN_HEADCLOSE)
    btn:setOnClickScriptHandler(onCloseClick)
    
    btn = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.BTN_FACE_CHANGE)
    btn:setOnClickScriptHandler(onFaceClick)

    btn = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.BTN_FACE_RENAME)
    btn:setOnClickScriptHandler(onReNameClick)

    btn = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.BTN_FACE_DELETE)
    btn:setOnClickScriptHandler(onDeleteClick)

    mBtnLeft = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.BTN_FACE_LEFT)
    mBtnLeft:setOnClickScriptHandler(onBtnLeftClick)
    mBtnRight = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.BTN_FACE_RIGHT)
    mBtnRight:setOnClickScriptHandler(onBtnRightClick)


    --更改名字组件
    mEditReName = self:getControl( Tag_collectionwnd.PANEL_HEADFACE, Tag_collectionwnd.EDIT_RENAME_TP )    
    mEditReName:setText( DataManager:getStringDataTxt( 54, true ) )
    mEditReName:setCascadeOpacityEnabled(true)
--    mEditReName:setOpacity(255 * 0.4)
    mEditReName:registerScriptEditBoxHandler( eventmEditName )

    if BOL_CURSOR == true then  
        mEditReName:setVisible( false )
        text_name = mEditReName
        local oldPos = {x = text_name:getPositionX(), y = text_name:getPositionY()}
        text_name = CursorTextField.new()
        text_name:init( {width = 450, height = 40}, TXTFONTNAME, 28, 15)
        text_name:setEditCallBack( CursorTextListener )
        window:addChild(text_name)
        text_name:setPosition(oldPos.x, oldPos.y)--
        text_name.isInit = false
        mEditReName = text_name
        mEditReName:setText( DataManager:getStringDataTxt( 54, true ) )
    end
    mEditReName:setOpacity(255 * 0.4)
    if LANGUAGE == "cn" or LANGUAGE == "tw" then
        mEditReName:setMaxLength(18)
    else
        mEditReName:setMaxLength(12)
    end


    mScroll = CScrollView:create( cc.size(480, 180) )    
    mScroll:setDirection(0)
    mScroll:setPosition( -40, 245 )
    window:addChild( mScroll,1 ) 

    mScroll:setContainerSize( cc.size( 480, 180 ) )

--    imgHead = CGridPageViewCell:new()
--    imgHead:setContentSize( cc.size( 255, 102 ) )
    sprite = cc.Sprite:create()
--    sprite:setTexture("other/tim.png")
    sprite:setPosition( 240, 80 )
--    imgHead:addChild(sprite)
    mScroll:getContainer():addChild(sprite)
    mScroll:setOnScrollingScriptHandler(onScroll)

    mHeadImgList = {}
    for i = 1, 3 do
        local imgHead = cc.Sprite:create()
        local box = cc.Sprite:create()
        box:setTexture("other/img_heroFaceBox.png")
        imgHead:addChild(box)
        box:setPosition(80, 80)  --这里是以头像的大小(160*160)居中
        window:addChild( imgHead )
        imgHead:setPositionX( 20 + i * 100 - 245 )
        imgHead:setPositionY( 245 )
--        imgHead:setScale(0.6)
        table.insert(mHeadImgList, imgHead)
    end
    mHeadImgList[1]:setPositionX(-268)
    mHeadImgList[2]:setPositionX(-98)
    mHeadImgList[1]:setScale(0.6)
    mHeadImgList[3]:setScale(0.6)

    CollectionManager.EditGroupId = CollectionManager:getCurGroupID()
    mCurHeadId = CollectionManager:getCardGroupData(CollectionManager.EditGroupId).headId

    self:updateHeadList()

    HeadWindow.isShow = true
end


function HeadWindow:onExitScene()
    if BOL_CURSOR == true then
        CursorTextField:closeAllIME() 
    end
    window = nil
    HeadWindow.isShow = false
end