----------------------------------------------------------
----------ɸѡ�����ӽ��洦��--------------------------
----------------------------------------------------------
require "tagMap.Tag_collectionwnd"
require "xiangxi.CardXiangXi"
local DataManager = require("data.DataManager"):instance()
local EffectManaget = require("ui.EffectManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()
local CursorTextField = require("ui.CursorTextField")


local CollectionSxWnd = {}-- ����һ���� test �̳��� base_type
--ɸѡ���Ѱ�ť���״̬����
CollectionSxWnd.SpendBtnClickStateArr = nil
--ɸѡ����
CollectionSxWnd.mLayoutType = nil

CollectionSxWnd.layout_Right_sx = nil
--ɸѡ���ఴť
CollectionSxWnd.mLayoutType = nil
--�Ƿ���ʾɸѡ��������
CollectionSxWnd.mIsShowType = false

--�����ؼ������s
CollectionSxWnd.mEditSearch = nil

-------------�ϲ���Ϣ2(ɸѡ����)----------
--����ɸѡ�����ϲ���Ϣ2����
CollectionSxWnd.mlayoutUp2 = nil
-----------------------------------------
--�Ƿ�ɽ���ɸѡ  --ͼ���϶��оͲ���
CollectionSxWnd.mIsSiftBoo = false
-----------------------------------------
CollectionSxWnd.before = 1

------------------------------------------------------
--����15������16
--�ڰ�17, ����18
--��Ȼ19������20

--����4018�����4019
--����4020, ����4021

--��ͨ31������ͨ32
--ϡ��33, ʷʫ34
local btn_t_txt_arr = { 20,15,16,17,18,19, 4138, 4139,
4018,4019,
4020,4021,
31,32,
34,33,
21,26}


--����ɸѡ��ť
CollectionSxWnd.mSpendBtnArr = {}
--����ɸѡ��ť��Ч
CollectionSxWnd.mSpendBtnEffectArr = {}

--����ɸѡ��ť�б�
local mCostBtnList = {}
--�Ҳ�ɸѡ��ť�б�
local mSxBtnList = {}
------------------------------------------------------
function CollectionSxWnd.init()

end


--ɸѡ�ؼ���
 local function eventmEdit(strEventName,pSender)
	if strEventName == "return" then
		print(pSender:getText())
	end    
    if strEventName == "return" then
        local str = string.lower( pSender:getText() )
        CollectionManager:setSiftStr(str)
        CollectionScWnd.UpDataCardMsg()
    end

end

local function CursorTextListener(event, editbox)   --�����¼�
    if event == 0 then
--        if editbox.isInit == true then
--            editbox:setText("")
--            editbox.isInit = false
--        end
--        if (editbox == text_password or editbox == edit_repassword or editbox == edit_repassword2) then
--            editbox:setPasswordEnabled(true)
--        end
    elseif event == 2 or event == 3 then
        local str = string.lower( editbox:getText() )
        CollectionManager:setSiftStr(str)
        CollectionScWnd.UpDataCardMsg()
    end
end

-------------------ɸѡ���ѵ���¼�------------------
local function CostShiftClick(p_sender)
    local cost = p_sender.cost
    if CollectionManager:bolInSiftList( SIFT_COST, cost ) == true then --�����ǰ�Ѿ���ѡ��״̬,��ȡ��
        p_sender.imgSelect:setVisible(false)
        p_sender.effect:setVisible(false)
        p_sender.effect:stop()
        CollectionManager:setSiftList( SIFT_COST, cost, false )
    else
        p_sender.imgSelect:setVisible(true)
        p_sender.effect:setVisible(true)
        EffectManager:startHnyEffect( p_sender.effect )
        CollectionManager:setSiftList( SIFT_COST, cost, true )
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

-------------------��Ӫ��ϵɸѡ����¼�------------------
local function RaceShiftClick(p_sender)
    local race = p_sender.race
    if CollectionManager:bolInSiftList( SIFT_RACE, race ) == true then --�����ǰ�Ѿ���ѡ��״̬,��ȡ��
        p_sender.txt:setTextColor(cc.c4b(255,255,255,255))
        CollectionManager:setSiftList( SIFT_RACE, race, false )
    else
        p_sender.txt:setTextColor(cc.c4b(0,255,0,255))
        CollectionManager:setSiftList( SIFT_RACE, race, true )
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

-------------------��/˫ɫ��Ӫ��ϵɸѡ����¼�------------------
local function SingleRaceShiftClick(p_sender)
    local race = p_sender.race
    if CollectionManager:bolInSiftList( SIFT_SINGEL_RACE, race ) == true then --�����ǰ�Ѿ���ѡ��״̬,��ȡ��
        p_sender.txt:setTextColor(cc.c4b(255,255,255,255))
        CollectionManager:setSiftList( SIFT_SINGEL_RACE, race, false )
    else
        p_sender.txt:setTextColor(cc.c4b(0,255,0,255))
        CollectionManager:setSiftList( SIFT_SINGEL_RACE, race, true )
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

-------------------��������ɸѡ����¼�------------------
local function TypeShiftClick(p_sender)
    local stype = p_sender.stype
    if CollectionManager:bolInSiftList( SIFT_TYPE, stype ) == true then --�����ǰ�Ѿ���ѡ��״̬,��ȡ��
        p_sender.txt:setTextColor(cc.c4b(255,255,255,255))
        CollectionManager:setSiftList( SIFT_TYPE, stype, false )
    else
        p_sender.txt:setTextColor(cc.c4b(0,255,0,255))
        CollectionManager:setSiftList( SIFT_TYPE, stype, true )
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

-------------------ϡ�ж�ɸѡ����¼�------------------
local function QltShiftClick(p_sender)
    local qlt = p_sender.qlt
    if CollectionManager:bolInSiftList( SIFT_QLT, qlt ) == true then --�����ǰ�Ѿ���ѡ��״̬,��ȡ��
        p_sender.txt:setTextColor(cc.c4b(255,255,255,255))
        CollectionManager:setSiftList( SIFT_QLT, qlt, false )
    else
        p_sender.txt:setTextColor(cc.c4b(0,255,0,255))
        CollectionManager:setSiftList( SIFT_QLT, qlt, true )
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

-------------------���ư汾ɸѡ����¼�------------------
local function VersionShiftClick(p_sender)
    local version = p_sender.version
    if CollectionManager:bolInSiftList( SIFT_VERSION, version ) == true then --�����ǰ�Ѿ���ѡ��״̬,��ȡ��
        p_sender.txt:setTextColor(cc.c4b(255,255,255,255))
        CollectionManager:setSiftList( SIFT_VERSION, version, false )
    else
        p_sender.txt:setTextColor(cc.c4b(0,255,0,255))
        CollectionManager:setSiftList( SIFT_VERSION, version, true )
    end
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

--ɸѡ��ť���
local function SxClick(p_sender)
    if BOL_CURSOR == true then
        CursorTextField:closeAllIME() 
    end
    CollectionWnd:showPage(CollectionSxWnd.before) 
end

--ɸѡ��ť���
local function ResetClick(p_sender)
    if BOL_CURSOR == true then
        CursorTextField:closeAllIME() 
    end
    CollectionManager:initSiftTypeArr()

    for i = 1, #mCostBtnList do
        btn = mCostBtnList[i]
        btn.imgSelect:setVisible(false)
        btn.effect:setVisible(false)
        btn.effect:stop()
    end

    for i = 1, #mSxBtnList do
        btn = mSxBtnList[i]
        btn.txt:setTextColor(cc.c4b(255,255,255,255))
    end
    CollectionSxWnd.mEditSearch:setText("")
    CollectionScWnd.UpDataCardMsg()
    CollectionScWnd.gpvCard:setContentOffsetToLeft()
end

function CollectionSxWnd.onEnterScene()
    --�����ؼ������
    CollectionSxWnd.mEditSearch = CollectionSxWnd.layout_Right_sx:getChildByTag(  Tag_collectionwnd.EDIT_SX_SEARCH )
    CollectionSxWnd.mEditSearch:registerScriptEditBoxHandler( eventmEdit )
    CollectionSxWnd.mEditSearch:setPlaceHolder( DataManager:getStringDataTxt( 22, true ) )
    CollectionSxWnd.mEditSearch:setVisible( true )

    if BOL_CURSOR == true then  
        CollectionSxWnd.mEditSearch:setVisible( false )
        text_name = CollectionSxWnd.mEditSearch 
        local oldPos = {x = text_name:getPositionX(), y = text_name:getPositionY()}
        text_name = CursorTextField.new()
        text_name:init( {width = 228, height = 43}, TXTFONTNAME, 28, 15)
        text_name:setEditCallBack( CursorTextListener )
        CollectionSxWnd.layout_Right_sx:addChild(text_name)
        text_name:setPosition(oldPos.x, oldPos.y)
        CollectionSxWnd.mEditSearch  = text_name
    end

    local btn_sx_done =  CollectionSxWnd.layout_Right_sx:getChildByTag(  Tag_collectionwnd.BTN_SX_DONE )
    btn_sx_done:setOnClickScriptHandler( SxClick )

    local btn_reset =  CollectionSxWnd.layout_Right_sx:getChildByTag(  Tag_collectionwnd.BTN_RESET )
    btn_reset:setOnClickScriptHandler( ResetClick )
    ---------------------ɸѡ����-------------------------------
    mCostBtnList = {}
    local hyNo = nil
    local hyObj1
    local hyEff = nil
    local imgSelect
    for i = 0, 11 do
        font = CollectionSxWnd.mlayoutUp2:getChildByTag( Tag_collectionwnd["LABBMF_SPEND"..i] )
        if i ~= 11 then
            btn = CollectionSxWnd.mlayoutUp2:getChildByTag(Tag_collectionwnd["BTN_SPEND"..i] )           

            imgSelect = CImageView:create()  --ѡ��״̬����ͼƬ
            imgSelect:setSpriteFrame( "collectionwnd/btn_Costs+N_select.png" )
            imgSelect:setVisible( false )
            imgSelect:setPosition( btn:getPositionX() - imgSelect:getContentSize().width * 0.5, btn:getPositionY() - imgSelect:getContentSize().height * 0.5  )
            imgSelect:setContentSize(0,0)
            CollectionSxWnd.mlayoutUp2:addChild( imgSelect )

            hyObj1 = {x = btn:getPositionX(), y = btn:getPositionY() }
            table.insert( mCostBtnList, btn )
            hyEff = EffectManager:createHnyEffect( 100479, hyObj1 )--ѡ��״̬��Ч
            hyEff:setVisible( false )
            hyEff:stop()
            CollectionSxWnd.mlayoutUp2:addChild( hyEff )

            btn.cost = i
            btn.effect = hyEff
            btn.imgSelect = imgSelect
            btn:setOnClickScriptHandler( CostShiftClick )

            font:setString( i )
            CollectionSxWnd.mlayoutUp2:reorderChild( font, 1 )
        else
            font:setString( "+" )
        end
    end

    ---------------------��Ӫ��ϵɸѡ-------------------------------

    mLayoutSxBtn = CollectionSxWnd.layout_Right_sx:getChildByTag(  Tag_collectionwnd.LAYOUT_RIGHT_SXBTN )
    mLayoutSxBtn:retain()
    mLayoutSxBtn:removeFromParent()

    local arrival = mLayoutSxBtn:getOrderOfArrival()--��ȡ�㼶

    mScroll = CScrollView:create( cc.size(315, 510) )    --�������϶����棬�����ÿ��������С
    mScroll:setDirection(1)
    mScroll:setPosition( 185, 355 )
    CollectionSxWnd.layout_Right_sx:addChild( mScroll ) 
    mScroll:setOrderOfArrival(arrival - 1)

    local consize =  mLayoutSxBtn:getContentSize()
    mScroll:setContainerSize( cc.size( consize.width, consize.height) )
    mScroll:getContainer():addChild(mLayoutSxBtn)
    mLayoutSxBtn:setPosition( consize.width * 0.5, consize.height * 0.5 )
--    mScroll:setOnScrollingScriptHandler(onScroll)
    mScroll:setContentOffsetToTop()
    mLayoutSxBtn:release()

    mSxBtnList = {}
        ---------------------��Ӫ��ϵɸѡ-------------------------------
    for i = 0, 5 do
        btn = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["BTN_SXRACE_"..i] ) 
        btn.race = i
        btn.txt = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["LABEL_SXRACE_"..i] ) 
        btn.txt:setString(DataManager:getStringDataTxt( btn_t_txt_arr[i+1], true ))
        btn:setOnClickScriptHandler( RaceShiftClick )
        table.insert(mSxBtnList, btn)
    end
            ---------------------��˫ɫ��Ӫ��ϵɸѡ-------------------------------
    for i = 1, 2 do
        btn = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["BTN_SXSINGLERACE_"..i] ) 
        btn.race = i
        btn.txt = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["LABEL_SXSINGLERACE_"..i] ) 
        btn.txt:setString(DataManager:getStringDataTxt( btn_t_txt_arr[i+6], true ))
        btn:setOnClickScriptHandler( SingleRaceShiftClick )
        table.insert(mSxBtnList, btn)
    end

    ---------------------��������ɸѡ-------------------------------
    for i = 1, 4 do
        btn = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["BTN_SXTYPE_"..i] ) 
        btn.stype = i
        btn.txt = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["LABEL_SXTYPE_"..i] ) 
        btn.txt:setString(DataManager:getStringDataTxt( btn_t_txt_arr[i+8], true ))
        btn:setOnClickScriptHandler( TypeShiftClick )
        table.insert(mSxBtnList, btn)
    end

    ---------------------ϡ�ж�ɸѡ-------------------------------
    for i = 1, 4 do
        btn = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["BTN_SXQLT_"..i] ) 
        btn.qlt = i
        btn.txt = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["LABEL_SXQLT_"..i] ) 
        btn.txt:setString(DataManager:getStringDataTxt( btn_t_txt_arr[i+12], true ))
        btn:setOnClickScriptHandler( QltShiftClick )
        table.insert(mSxBtnList, btn)
    end

    ---------------------���ư汾ɸѡ-------------------------------
    for i = 1, 2 do
        btn = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["BTN_SXVERSION_"..i] ) 
        btn.version = i
        btn.txt = mLayoutSxBtn:getChildByTag(  Tag_collectionwnd["LABEL_SXVERSION_"..i] ) 
        btn.txt:setString(DataManager:getStringDataTxt( btn_t_txt_arr[i+16], true ))
        btn:setOnClickScriptHandler( VersionShiftClick )
        table.insert(mSxBtnList, btn)
    end

    CollectionManager:updataHasCard()
end

return CollectionSxWnd