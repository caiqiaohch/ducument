require "tagMap.Tag_collectionwnd"
require "xiangxi.CardXiangXi"
local DataManager = require("data.DataManager"):instance()
local EffectManaget = require("ui.EffectManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()

-------------------------------------------------------------------------------
CollectionWnd = class("CollectionWnd",function()
	return TuiBase:create()
end)
-------------------------------------------------------------------------------
--��Ҫ�Ǳ༭����ʱ���ұߵĿ�����ϸ�б�����
CollectionTpWnd = require("collectionWnd.CollectionTpWnd")
--��Ҫ����ߵ�ͼ���������ұߵĿ����б�, �򿪽���ĳ�ʼ״̬
CollectionScWnd = require("collectionWnd.CollectionScWnd")
--ɸѡ�����ӽ��洦��
CollectionSxWnd = require("collectionWnd.CollectionSxWnd")
--
--CollectionYzWnd = require("collectionWnd.CollectionYzWnd")
-------------------------------------------------------------------------------

--local mAcquiesceFont = nil

--��ť
local btn_Left = nil
--�Ұ�ť
local btn_Right = nil
--������
local window = nil

-------------�ϲ���Ϣ1(��ɸѡ����)----------
--�ϲ���Ϣ1���--

--��ǰѡ��༭�Ŀ�������
local mCurGroup

--�ұ����
RightArr = {}

--�ұ���Ϣ����
local mlayoutRight = nil

--����Ƥ������
RightArr.CardTempArr = {}

--�˳�/���ذ�ť
RightArr.GoBtn = nil
--�ɷ��л��������
CollectionScWnd.mIsLeave = true

--��ǰѡ�����Ʊ���
CollectionTpWnd.CardTitalBg = nil

--�༭���ư�ť
CollectionTpWnd.EditorBtn = nil

--ok��ť
RightArr.BtnOk = nil
--ok��
RightArr.labBmfOk = nil

--�������Ƶ��������б�
CollectionTpWnd.mCardVecList = {}

--�Ƿ��Ѵ򿪽���
local mIsOpenWindow = false

--�����׽������
local mCardGroupEqSignArr = {}

--��ǰѡ������ƿ���ID
local curGroupCardId = 0

--������ʾ�ı���
local mImgNormalBg

--ɸѡʱ��ʾ�ı���
local mImgSiftBg

-------------�ұ����------------//


local resArr = { PLIST_WAR2_URL, PLIST_COLLECT_URL,PLIST_XIANGXI_URL, PLIST_CARDUI_URL, PLIST_WAR2CARDSG_URL,
    PLIST_CARDMIDDLEUI_URL, PLIST_CARDBIGUI1_URL, PLIST_CARDBIGUI2_URL, PLIST_CARDBIGUI3_URL, PLIST_CARDBIGUI4_URL, PLIST_CARDBIGUI5_URL }


local __instance = nil

CollectionWnd.isShow = false

function CollectionWnd:create()
	local ret = CollectionWnd.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
    CollectionWnd.__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end


--��ʼ��
local function initLay( tempSelf )
    window = tempSelf:getChildByTag(Tag_collectionwnd.PANEL_MAIN)

    CollectionScWnd.mlayoutUp1 = window:getChildByTag(Tag_collectionwnd.LAYOUT_UP1)

    CollectionSxWnd.mlayoutUp2 = window:getChildByTag(Tag_collectionwnd.LAYOUT_UP2)

    CollectionScWnd.mlayoutMiddle = window:getChildByTag(Tag_collectionwnd.LAYOUT_MIDDLE)

    mlayoutRight = window:getChildByTag(Tag_collectionwnd.LAYOUT_RIGHT)

    CollectionScWnd.layout_Right_wdsc = mlayoutRight:getChildByTag(Tag_collectionwnd.LAYOUT_RIGHT_WDSC)
    --CollectionYzWnd.layout_yztp = window:getChildByTag(Tag_collectionwnd.LAYOUT_YZTP)
    CollectionSxWnd.layout_Right_sx = mlayoutRight:getChildByTag(Tag_collectionwnd.LAYOUT_RIGHT_SX)
    CollectionTpWnd.layout_Right_tp =  mlayoutRight:getChildByTag(Tag_collectionwnd.LAYOUT_RIGHT_TP)

    CollectionTpWnd.mLayoutSpends = window:getChildByTag(Tag_collectionwnd.LAYOUT_SPEEDS)
    CollectionTpWnd.mlayoutLongClick = window:getChildByTag(Tag_collectionwnd.LAYOUT_LONGCLICK) 
    CollectionTpWnd.mlayoutLongClick:setTouchEnabled(true)

    CollectionTpWnd.mlayoutGroupEquip = CollectionTpWnd.layout_Right_tp:getChildByTag(Tag_collectionwnd.LAYOUT_GROUPEQUIP) 

    window:setPositionY(720)
    window:setPositionX(0)

end

---------------------------------�������---------------------------------//

--���Ž���򿪶�̬Ч��
local function playOpenEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true
    local sp = TextureManager:getSprite( mlayoutRight )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100731, tx2d)
    local effect = EffectManager:createHnyEffect( 100731 , {x = mlayoutRight:getPositionX() + mlayoutRight:getContentSize().width * 0.5 , y = mlayoutRight:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    mlayoutRight:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () mlayoutRight:setVisible(true) mBolPlaying = false end  } )

    local sp = TextureManager:getSprite( CollectionScWnd.mlayoutMiddle )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100732, tx2d)
    local effect = EffectManager:createHnyEffect( 100732 , {x = CollectionScWnd.mlayoutMiddle:getPositionX() - CollectionScWnd.mlayoutMiddle:getContentSize().width * 0.5, y = CollectionScWnd.mlayoutMiddle:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    CollectionScWnd.mlayoutMiddle:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () CollectionScWnd.mlayoutMiddle:setVisible(true) mBolPlaying = false end } )

    local sp = TextureManager:getSprite( CollectionScWnd.mlayoutUp1 )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100733, tx2d)
    local effect = EffectManager:createHnyEffect( 100733 , {x = CollectionScWnd.mlayoutUp1:getPositionX() - CollectionScWnd.mlayoutUp1:getContentSize().width * 0.5, y = CollectionScWnd.mlayoutUp1:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    CollectionScWnd.mlayoutUp1:setVisible(false)
    EffectManager:startHnyEffect( effect, { key = function () CollectionScWnd.mlayoutUp1:setVisible(true) mBolPlaying = false end } )

    CollectionScWnd.mOpenShowAllBtn:setTouchEnabled( true )
end

--���Ž���رն�̬Ч��
local function playCloseEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true
    local sp = TextureManager:getSprite( mlayoutRight )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100735, tx2d)
    local effect = EffectManager:createHnyEffect( 100735 , {x = mlayoutRight:getPositionX() + mlayoutRight:getContentSize().width * 0.5 , y = mlayoutRight:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    mlayoutRight:setVisible(false)
    EffectManager:startHnyEffect( effect )

    local sp = TextureManager:getSprite( CollectionScWnd.mlayoutMiddle )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100736, tx2d)
    local effect = EffectManager:createHnyEffect( 100736 , {x = CollectionScWnd.mlayoutMiddle:getPositionX() - CollectionScWnd.mlayoutMiddle:getContentSize().width * 0.5, y = CollectionScWnd.mlayoutMiddle:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    CollectionScWnd.mlayoutMiddle:setVisible(false)
    EffectManager:startHnyEffect( effect )

    local sp = TextureManager:getSprite( CollectionScWnd.mlayoutUp1 )
    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100737, tx2d)
    local effect = EffectManager:createHnyEffect( 100737 , {x = CollectionScWnd.mlayoutUp1:getPositionX() - CollectionScWnd.mlayoutUp1:getContentSize().width * 0.5, y = CollectionScWnd.mlayoutUp1:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    CollectionScWnd.mlayoutUp1:setVisible(false)
    EffectManager:startHnyEffect( effect, {close = function () mBolPlaying = false PopScene(__instance) end}  )
end

function CollectionWnd:onEnterScene()
    CollectionWnd.mCardVec = {}
    CollectionScWnd.mCardClickVec = {}
    CollectionScWnd.mIsLeave = true
    CollectionScWnd.mIsLast = false
    TuiManager:getInstance():parseScene( self, "panel_main", PATH_COLLECTIONWND )

    initLay( self )
    mIsOpenWindow = true

    CollectionManager:initSiftTypeArr( true )

    CollectionWnd.isShow = true

    CollectionScWnd.onEnterScene(self)
    CollectionTpWnd.onEnterScene(self)
    CollectionSxWnd.onEnterScene(self)
    --CollectionYzWnd.onEnterScene(self)

    RightArr.cardUI = require("war2.cardBig").new()
    RightArr.cardUI:init( 0 )
    RightArr.cardUI:setCardIsFront(true)
    CollectionScWnd.ImgMask:addChild( RightArr.cardUI ) 
    RightArr.cardUI:setPosition( 680, 300 )

    CollectionWnd:showPage(SHOW_SC_WN) 

    CollectionScWnd.UpDataCardMsg()
    if NewbieManager.UseData.Collection1st == false then
        NewbieWindow:setAndShowType("Collection1st")
    end
    MusicManager:PlaySound( 4 )

    playOpenEffect()
--    require("framework.scheduler").performWithDelayGlobal( function() playOpenEffect() end, 2 )
end

function CollectionWnd:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end



--��ȡ����ָ������ mType 1������ 2�ұ���Ϣ 3������ 4������ϸ��Ϣ 5:�ϲ���Ϣ1 6:�ϲ���Ϣ2 7�����ѰٷֱȽ��� 8:ɸѡ���� 9:������ʾ 10 ����ʥ����
function CollectionWnd:getControl( mSpType, tagControl )
    local ret = nil
    if mSpType == 1 then
        ret = window:getChildByTag(tagControl)
    elseif mSpType == 2 then
        ret = mlayoutRight:getChildByTag(tagControl)
    elseif mSpType == 3 then
--        ret = mLayBoxHead:getChildByTag(tagControl)
    elseif mSpType == 5 then
        ret = CollectionScWnd.mlayoutUp1:getChildByTag(tagControl)
    elseif mSpType == 6 then
        ret = CollectionSxWnd.mlayoutUp2:getChildByTag(tagControl)
    elseif mSpType == 7 then
        ret = CollectionTpWnd.mLayoutSpends:getChildByTag(tagControl)
    elseif mSpType == 8 then
        ret = CollectionSxWnd.mLayoutType:getChildByTag(tagControl)
    elseif mSpType == 9 then
        ret = CollectionTpWnd.mlayoutLongClick:getChildByTag(tagControl)
    elseif mSpType == 10 then
        ret = CollectionTpWnd.mlayoutGroupEquip:getChildByTag(tagControl)
    end
	return ret
end

----------------------------------------��ʾ��������----------------------------------

--���ñ䰵
local function setShowDark( sp, bool )
    local EffectManager = require("ui.EffectManager"):instance()
    if bool == true then
        EffectManager:setMultiplyColor( sp, 128, 128, 128 )
    else
        EffectManager:setMultiplyColor( sp, 255, 255, 255 )
    end
end

--��������
local function ComeToStage()
    local MovBounce = require("Mov.MovBounce").new()
    MovBounce:init(mlayoutRight, mlayoutRight:getPositionX(), 0)
    MovManager:pushMov( MovBounce )
end

--�ղػ��������
local function CloseSpend()
    local MovMove = require("Mov.MovMove").new()
    CollectionTpWnd.mIsLeft = false
    MovMove:init(mLayoutSpends, false, 1200, mLayoutSpends:getPositionY(), 100, -1)
    MovManager:pushMov( MovMove )
end

local function tempCardBtnAddClick( p_sender )
    print(debug.getinfo(1).name)
    local arr = CollectionManager:getCurGpvCardNumArr()
    if arr[curGroupCardId] == nil or arr[curGroupCardId] == 0 then
        return
    end
    CollectionTpWnd.ChangeCardGrop(curGroupCardId, false, 0)
end


function CollectionWnd:closeWindow()
    CollectionWnd.isShow = false
    playCloseEffect()
end

--�������Ƽ�ͼ��
function CollectionWnd:updateGpvCardList(isUpdataShow, isToLeft)
    print(debug.getinfo(1).name)
    CollectionTpWnd.gpvCardTempCards:removeAllNodes()
    CollectionScWnd.ImgMask:setVisible(false)
    CollectionTpWnd.mCardVecList = {}
    local CurGroupCardArr = CollectionManager:getCurGroupCardArr()
    len = #CurGroupCardArr
    local bolSel = false
    for i=1, len do
        if CurGroupCardArr[i].data then
            if CurGroupCardArr[i].data.id == curGroupCardId then
                bolSel = true
            end
            CollectionTpWnd.insertItemToList(i)
        end
    end
    if bolSel == false then curGroupCardId = 0 end
    CollectionTpWnd.gpvCardTempCards:reloadData()
    if CollectionScWnd.mIsLeave == false then
        CollectionTpWnd.CardSpendMsg()--���·���
    end

    if isUpdataShow == true then
        CollectionScWnd.UpDataCardMsg()
    end
    if isToLeft == true then
        CollectionScWnd.gpvCard:setContentOffsetToLeft()
    end

end

function CollectionWnd:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
    CollectionManager:SendOpenInfo()
end


local function event_edit_login(strEventName,pSender)
	if strEventName == "return" then
		print(pSender:getText())
	end
end


---------------------------------�������---------------------------------



function CollectionWnd:onExitScene()
--    CollectionManager:clearNewCardList() --����¿�����
    MusicManager:PlayLastSound()
--    for i = 1, #CollectionSxWnd.mUp2Arr.mSpendBtnEffectArr do
--        CollectionSxWnd.mlayoutUp2:removeChild( CollectionSxWnd.mUp2Arr.mSpendBtnEffectArr[i] )
--        CollectionSxWnd.mUp2Arr.mSpendBtnEffectArr[i] = nil
--    end
    CollectionScWnd.mgpvCardArr = {}
    CollectionManager:setBolShowAll( false )
    mSiftArr = {}
    CollectionTpWnd.mCardSpendsArr = {}

    for i = 1, #CollectionTpWnd.mCardVecList do
        CollectionTpWnd.mCardVecList[i]:getChildByTag( 99 ):clear()
    end
    CollectionTpWnd.mCardVecList = {}

    for i = 1, #CollectionScWnd.mCardVec do
        CollectionScWnd.mCardVec[i]:clear()
    end

    for i = 1, #RightArr do
        RightArr[i]:clear()
    end

--    for i = 1, #Up1Arr do
--        Up1Arr[i]:clear()
--    end
    window = nil
    UILoadManager:delResByArr( resArr )
    CollectionWnd.isShow = false

--    display.removeUnusedTextures()  --������ͼ
    TextureManager:clearTx2dList()--������ͼ

    MainWindow:updataCollectMsg()

    MainWindow:playOpenEffect()
end

--local SHOW_SC_WN = 1    --��ʾ�����ղ�ҳ�棬��N�����������
--local SHOW_SX_WN = 2    --��ʾɸѡ����
--local SHOW_TP_WN = 3    --��ʾ�༭���ƽ���
--local SHOW_YZ_WN = 4    --��ʾԤ�����
function CollectionWnd:showPage(value) 

    window:setVisible(true)
    CollectionScWnd.mlayoutUp1:setVisible(false)
    CollectionSxWnd.mlayoutUp2:setVisible(false)
    CollectionScWnd.layout_Right_wdsc:setVisible(false)
    --CollectionYzWnd.layout_yztp:setVisible(false)
    CollectionSxWnd.layout_Right_sx:setVisible(false)
    CollectionTpWnd.layout_Right_tp:setVisible(false)
    CollectionTpWnd.mLayoutSpends:setVisible(false)
    CollectionTpWnd.mlayoutLongClick:setVisible(false)
    CollectionScWnd.gpvCard:setVisible(true)
    CollectionScWnd.btn_Left:setVisible(true)
    CollectionScWnd.btn_Right:setVisible(true)
    CollectionTpWnd.CardBoxBg:setVisible(true)

    CollectionScWnd.btn_AutoMakeDeck:setVisible(false)  
    CollectionScWnd.img_AutoMakeDeck:setVisible(false)

    CollectionSxWnd.before =  CollectionWnd.winshow
    CollectionWnd.winshow = value

    if value == SHOW_SC_WN then
        CollectionScWnd.mIsLeave = true 
        CollectionScWnd.mlayoutUp1:setVisible(true)    
        CollectionScWnd.layout_Right_wdsc:setVisible(true)    
        CollectionScWnd.selectId = 0
        CollectionScWnd.UpDataCardMsg() 
        if CollectionScWnd.gpvCardTempCards~=nil then
         CollectionScWnd.gpvCardTempCards:reloadData()
        end
        if CollectionScWnd.gpvCardTemp~=nil then
            CollectionScWnd.gpvCardTemp:reloadData()
            CollectionScWnd.gpvCardTemp:setContentOffsetToTop()
        end
    elseif value == SHOW_SX_WN then
        CollectionSxWnd.mlayoutUp2:setVisible(true)
        CollectionSxWnd.layout_Right_sx:setVisible(true)

    elseif value == SHOW_TP_WN then
        CollectionScWnd.mlayoutUp1:setVisible(true)    
        CollectionTpWnd.layout_Right_tp:setVisible(true)  
        CollectionScWnd.btn_AutoMakeDeck:setVisible(true)  
        CollectionScWnd.img_AutoMakeDeck:setVisible(true)
--        CollectionTpWnd.SetCardTtitalBtn( 2 )
    elseif value == SHOW_YZ_WN then
        window:setVisible(false)
        RunScene( "CollectionYzWnd" )
    end

    if CollectionManager:getIsFilter() == true then
        if CollectionScWnd.mFliterEffect:isVisible() == false then
            CollectionScWnd.mFliterEffect:setVisible(true)
            EffectManager:startHnyEffect( CollectionScWnd.mFliterEffect )
        end
    else
        CollectionScWnd.mFliterEffect:stop()
        CollectionScWnd.mFliterEffect:setVisible(false)
    end

end

