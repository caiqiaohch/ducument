require "tagMap.Tag_collectionwndYz"
require "xiangxi.CardXiangXi"
local DataManager = require("data.DataManager"):instance()
local EffectManaget = require("ui.EffectManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local MusicManager = require("Music.MusicManager"):instance()
local ShopManager = require("Shop.ShopManager"):instance()
local TextManager = require("ui.TextManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()

--------------------------------------Ԥ�����-----------------------------------------
CollectionYzWnd = class("CollectionYzWnd",function()
	return TuiBase:create()
end)
-------------------------------------------------------------------------------

CollectionYzWnd.layout_yztp = nil
--������ʾ�б�
CollectionYzWnd.gpv_Card_yz = nil
CollectionYzWnd.mCardGpvPage = 1
CollectionYzWnd.selcetCell = nil
--Ԥ��ʥ����ʾ
CollectionYzWnd.mCardGroupImgArr = {}
CollectionYzWnd.mCardVecList = {}
-------------�ұ����------------//
CollectionYzWnd.selectDeck = nil

local curGroupCardId = 0

local resArr = { PLIST_WAR2_URL, PLIST_COLLECT_URL,PLIST_COLLECT_URL,PLIST_XIANGXI_URL, PLIST_CARDUI_URL, PLIST_WAR2CARDSG_URL,
    PLIST_CARDMIDDLEUI_URL, PLIST_CARDBIGUI1_URL, PLIST_CARDBIGUI2_URL, PLIST_CARDBIGUI3_URL, PLIST_CARDBIGUI4_URL, PLIST_CARDBIGUI5_URL }


local __instance = nil

CollectionYzWnd.isShow = false

function CollectionYzWnd:create()
	local ret = CollectionYzWnd.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
    CollectionYzWnd.__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

--��ʼ��
local function initLay( tempSelf )
    window = tempSelf:getChildByTag(Tag_collectionwndyz.PANEL_MAIN)
    window:setPositionY(764)
    window:setPositionX(0)

end

function CollectionYzWnd:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end

----------------------------------------��ʾ��������----------------------------------
--���ñ䰵
local function setShowDark( sp, bool )
    local EffectManager = require("ui.EffectManager"):instance()
    if bool == true then
        EffectManager:setMultiplyColor( sp, 128, 128, 128 )
    else
        EffectManager:setMultiplyColor( sp, 255, 255, 255 )
    end
end

--��������
local function ComeToStage()
    local MovBounce = require("Mov.MovBounce").new()
    MovBounce:init(mlayoutRight, mlayoutRight:getPositionX(), 0)
    MovManager:pushMov( MovBounce )
end


function CollectionYzWnd:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

---------------------------------�������---------------------------------

------------------------------------------------------------------------------------------------------------------------------------------

--�˳��Զ�������
function CollectionYzWnd.Onbtn_Go_yztp()
    CollectionWnd:showPage(SHOW_SC_WN)
    PopScene(__instance)
end

--�˳��Զ������Ʋ鿴������ϸ
function CollectionYzWnd.Onbtn_turn_tp()
    CollectionYzWnd.layout_Right_tp:setVisible(false)
    CollectionYzWnd.layout_yztp_right1:setVisible(true)
    if CollectionYzWnd.selcetCell~= nil then
        CollectionYzWnd.selcetCell:setOpacity(1)
        CollectionYzWnd.selcetCell.label_desc:setVisible(false)
    end
    CollectionYzWnd.selcetCell = nil
    CollectionYzWnd.btn_yztp_cjtp:setVisible(false)
    CollectionYzWnd.img_FontCreateDeck:setVisible(false)
    CollectionYzWnd.hideSelectCellUI()
end

--1835Э�鷵�غ󴴽�һ������
function CollectionYzWnd.createNewGroupByBuy()
    if CollectionYzWnd.selcetCell~= nil then
        CollectionYzWnd:Onbtn_yztp_cjtp()
    else
        CollectionYzWnd.Onbtn_yztp_zdy()
    end
end

--�Զ������� ����һ���հ׵�����
function CollectionYzWnd.Onbtn_yztp_zdy()
    local mCurGroup = CollectionManager:createNewGroup()--����һ���¿���,������ID,������ܴ�������0
    if mCurGroup == nil then return end
    if mCurGroup == 0 then 
        require("prompt.PromptManager"):instance():SetNotice(4022)  --�����ѵ�����
        return
    end
    PopScene(__instance)
    CollectionWnd:showPage(SHOW_TP_WN)
    CollectionTpWnd.EditCardGroup( mCurGroup )  --����༭״̬
end

--�������ư�ť  ����Ԥ�������
function CollectionYzWnd:Onbtn_yztp_cjtp()
    local mCurGroup = CollectionManager:createNewGroup()--����һ���¿���,������ID,������ܴ�������0
    if mCurGroup == nil then return end
    if mCurGroup == 0 then 
        require("prompt.PromptManager"):instance():SetNotice(4022)  --�����ѵ�����
        return
    end
    local id = CollectionYzWnd.selectDeck.my_deck
    local data = DataManager:getDataPlayerTp(id)
    local obj
    local gpEqList = {}
    local gpCardList ={}
    ------------���ӵ�еĻ�,�����������ʥ�￨���뿨���ʥ���б�
    for i = 1, 3 do
        if CollectionManager:getHasCardNum(data[i].card_id) > 0 then
            obj = DataManager:getEq(data[i].card_id)
            table.insert(gpEqList, obj)
        end
    end
    ------------���ӵ�еĻ�,�������������ͨ�����뿨��Ŀ����б�
    local data = DataManager:getDataPlayerTpNum(id)
    local tpDataList = DataManager:getDataPlayerTpNum(id)

    for k, v in pairs(tpDataList) do
        if CollectionManager:getHasCardNum(k) > 0 then
            obj = DataManager:getCardObjByID(k)
            local num = tpDataList[k]
            if num > CollectionManager:getHasCardNum(k) then num = CollectionManager:getHasCardNum(k) end
            table.insert(gpCardList, {data = obj, num = num})
        end
    end

    obj = {}
    obj.id = mCurGroup
    obj.name = DataManager:getStringDataTxt(CollectionYzWnd.selectDeck.deck_name, true )
    obj.headId = 1
    obj.getInfo = true
    obj.GroupEquipArr = gpEqList
    obj.GroupCardArr = gpCardList
    CollectionManager:AddToCardGroupList( obj )  --��Ԥ��õĿ�����뿨�������б�

    CollectionTpWnd:updataCardGroupMsg()
    CollectionTpWnd.EditCardGroup( mCurGroup )
    CollectionWnd:showPage(SHOW_TP_WN)   
    
    PopScene(__instance)
end

--�����¼�
function CollectionYzWnd.Onbtn_LeftBtn_yz()
    local _x = CollectionYzWnd.gpv_Card_yz:getContentOffset().x
    if _x % CollectionYzWnd.gpv_Card_yz:getContentSize().width ~= 0 or _x == 0 then return end
    CollectionYzWnd.gpv_Card_yz:setContentOffsetInDuration( cc.p( CollectionYzWnd.gpv_Card_yz:getContentOffset().x + CollectionYzWnd.gpv_Card_yz:getContentSize().width, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )
end

--�ҵ���¼�
function CollectionYzWnd.Onbtn_RightBtn_yz()
    local _x = CollectionYzWnd.gpv_Card_yz:getContentOffset().x
    if _x % CollectionYzWnd.gpv_Card_yz:getContentSize().width ~= 0 or _x <= -( CollectionYzWnd.mCardGpvPage - 1 ) * CollectionYzWnd.gpv_Card_yz:getContentSize().width then return end
    gpvCard:setContentOffsetInDuration( cc.p( CollectionYzWnd.gpv_Card_yz:getContentOffset().x - CollectionYzWnd.gpv_Card_yz:getContentSize().width, 0 ), 0.5 )
    MusicManager:PlaySound( 101 )
end


--������Ŀ��Ƶ���¼�
local function tempCardUIClick(p_sender)
    if p_sender.id == nil then
        return
    end 
--    RunScene("CardXiangXi")
--    CardXiangXi:setAndShowCardXiangXi( p_sender.data, 1 )
    CollectionYzWnd.showSelectCellUI( p_sender.id )
    curGroupCardId = p_sender.id
    for k, tempSp in pairs(CollectionYzWnd.mCardVecList) do
        if tempSp.img_CardBoxLight == p_sender then
            tempSp.img_CardBoxLight:setOpacity(255)    
        else
            tempSp.img_CardBoxLight:setOpacity(0)
        end
    end
    return
end


local function gpvTempCardUIClick(p_sender)

    if p_sender==CollectionYzWnd.selcetCell then 
        return 
    end

    if p_sender.lock == true then
        return 
    end
    p_sender:setOpacity(255)       
    p_sender.label_desc:setVisible(true)
    if CollectionYzWnd.selcetCell~= nil then
        CollectionYzWnd.selcetCell:setOpacity(1)
        CollectionYzWnd.selcetCell.label_desc:setVisible(false)
    else
--        p_sender.label_desc:setVisible(true)
    end

    CollectionYzWnd.selcetCell = p_sender
    CollectionYzWnd.btn_yztp_cjtp:setVisible(true)
    CollectionYzWnd.img_FontCreateDeck:setVisible(true)
    CollectionYzWnd:updateGpvCardList(p_sender.selectid)

    if NewbieManager.UseData.CollectionYz == false then
       NewbieWindow:setAndShowType("CollectionYz")
    end
end

--����һ��gpv��cell
local function createGpvCard()

    local pCell = CGridPageViewCell:new()
    TuiManager:getInstance():parseCell( pCell, "cell_CardTempYz", PATH_COLLECTIONWNDYZ )

    local tempCardUI = pCell:getChildByTag(Tag_collectionwndyz.IMG_NEWDECK)
    tempCardUI:setTouchEnabled(true)
--    tempCardUI:setContentSize(cc.size(250,283))
    tempCardUI:setOnClickScriptHandler( gpvTempCardUIClick )
    pCell.label_yz_num = pCell:getChildByTag( Tag_collectionwndyz.LABEL_YZ_NUM )
    pCell.label_yz_num:enableOutline(cc.c4b(0,0,0,255),2)  --���ı��������
    tempCardUI.label_yz_num = pCell.label_yz_num
    return pCell

end

--��ȡ����
local function getStr( str ,num )
    if num ~= nil then
        local mStr = DataManager:getStringDataTxt(str, true)
        str = string.gsub(mStr,"$1", num)
    end
    return str
end

--��ȡ��ǰ����
local function getCurNum( id )
    local obj = DataManager:getYzTpData(id)
    if obj == nil then return 0 end
    local char = CharacterManager:getMainPlayer()
    local tpDataList = DataManager:getDataPlayerTpNum(obj.my_deck)
    local cardNum = 0
    local curNum = 0  --��ǰӵ�е�����
    for k, v in pairs(tpDataList) do
        cardNum = CollectionManager:getHasCardNum(k)
        if cardNum > tpDataList[k] then cardNum = tpDataList[k] end
        curNum = curNum + cardNum
    end
    return curNum   
end

--Ԥ��ͼ���϶�����
local function gpvCardClickYz(p_convertview, idx)
	local pCell = p_convertview
    local ImgCardUI = nil
    local str = nil
	if pCell == nil then
        pCell = createGpvCard()        
	end

    if idx == -1 then
        pCell:setVisible( false )
        return pCell
    else
        pCell:setVisible( true )
    end

    local label_need_lv = pCell:getChildByTag( Tag_collectionwndyz.LABEL_NEED_LV )
    local img_NewDeckLock = pCell:getChildByTag( Tag_collectionwndyz.IMG_NEWDECKLOCK )
    local label_deck_name = pCell:getChildByTag( Tag_collectionwndyz.LABEL_DECK_NAME )
    pCell.label_desc = pCell:getChildByTag( Tag_collectionwndyz.LABEL_DESC )
    local img_NewDeck =  pCell:getChildByTag( Tag_collectionwndyz.IMG_NEWDECK )
    local img_deck_pic1 = pCell:getChildByTag( Tag_collectionwndyz.IMG_DECK_PIC1 )
    img_NewDeck:setOpacity(1)

    img_NewDeck.selectid = idx+1
    img_NewDeck.label_desc = pCell.label_desc

    pCell.label_desc:setVisible(false)

    local obj = DataManager:getYzTpData(idx+1)
    if obj ~= 0 and obj ~= nil then
        img_NewDeck.selectdeck = obj.my_deck 
        local char = CharacterManager:getMainPlayer()        
        if char.CharLevel>=obj.deck_lv then
            img_NewDeckLock:setVisible(false)
            label_need_lv:setVisible(false)
            label_deck_name:setString( DataManager:getStringDataTxt(obj.deck_name, true ) )
            img_NewDeck.lock = false
        else
            img_NewDeckLock:setVisible(true)
            label_need_lv:setVisible(true)
            label_need_lv:setAlignment(1,1)
            img_NewDeck.lock = true
        end
        img_deck_pic1:setSpriteFrame( "collectionwnd/"..obj.deck_pic..".png" )

        pCell.label_yz_num:setString( getCurNum(obj.deck_id) .."/".. obj.card_num)
        label_need_lv:setString( getStr(4015, obj.deck_lv ) )

        label_deck_name:setString( DataManager:getStringDataTxt(obj.deck_name, true ) )
        pCell.label_desc:setString( DataManager:getStringDataTxt(obj.deck_desc, true) )

    else
        pCell:setVisible( false )
    end

	return pCell
end

local function cardUIMaskClick(p_sender)
    CollectionYzWnd.hideSelectCellUI()
end

--ȡ��ѡ�еĿ��ƴ�ͼ��ʾ
function CollectionYzWnd.hideSelectCellUI()
    for k, tempSp in pairs(CollectionYzWnd.mCardVecList) do
        if curGroupCardId == k then
            tempSp.img_CardBoxLight:setOpacity(0)
            break
        end    
    end
    curGroupCardId = 0
    CollectionYzWnd.btn_Buy:setVisible(false)
    CollectionYzWnd.img_FontBuy:setVisible(false)
    CollectionYzWnd.img_GoldCount_buy:setVisible(false)
    CollectionYzWnd.labBmf_buy_money:setVisible(false)
    CollectionYzWnd.ImgMask:setVisible(false)
end

--ѡ�еĿ��ƴ�ͼ��ʾ
function CollectionYzWnd.showSelectCellUI( id )
    CollectionYzWnd.cardUI:setCard( id )      
    CollectionYzWnd.ImgMask:setVisible(true)

    local shopData = ShopManager:getShopCardData(id)
    if shopData ~= nil and shopData.buy > 0 then
        CollectionYzWnd.btn_Buy:setVisible(true)  
        CollectionYzWnd.img_FontBuy:setVisible(true)  
        CollectionYzWnd.img_GoldCount_buy:setVisible(true)
        CollectionYzWnd.labBmf_buy_money:setVisible(true)
        CollectionYzWnd.labBmf_buy_money:setString( "-"..shopData.buy )
    end
end

--������ƹ���
local function clickBuyCard(_Handler)    --shop buy �������� �������� ����id ����    �������   //�������ͣ�1����  2����  3�����г�    �������ͣ�1��� 2��ʯ
    ServMsgTransponder:SMTShopBuy( 3, 1, curGroupCardId, 1 )
end

---------------------------------�������---------------------------------//
function CollectionYzWnd:onEnterScene()
    CollectionWnd.mCardVec = {}
    CollectionScWnd.mCardClickVec = {}

    TuiManager:getInstance():parseScene( self, "panel_main", PATH_COLLECTIONWNDYZ )
    local window = self:getChildByTag(Tag_collectionwndyz.PANEL_MAIN)

---------------------------------------��ť-------------------------------------------------------------

    CollectionYzWnd.btn_yztp_cjtp = window:getChildByTag(Tag_collectionwndyz.BTN_YZTP_CJTP )
    CollectionYzWnd.btn_yztp_cjtp:setOnClickScriptHandler( CollectionYzWnd.Onbtn_yztp_cjtp )
    CollectionYzWnd.btn_yztp_cjtp:setVisible(false)
    CollectionYzWnd.img_FontCreateDeck = window:getChildByTag(Tag_collectionwndyz.IMG_FONTCREATEDECK )
    CollectionYzWnd.img_FontCreateDeck:setVisible(false)
    
    CollectionYzWnd.btn_LeftBtn_yz = window:getChildByTag(Tag_collectionwndyz.BTN_LEFTBTN_YZ )
    CollectionYzWnd.btn_LeftBtn_yz:setOnClickScriptHandler( CollectionYzWnd.Onbtn_LeftBtn_yz )

    CollectionYzWnd.btn_RightBtn_yz = window:getChildByTag(Tag_collectionwndyz.BTN_RIGHTBTN_YZ )
    CollectionYzWnd.btn_RightBtn_yz:setOnClickScriptHandler( CollectionYzWnd.Onbtn_RightBtn_yz )


---------------------------------------------------------------------------------------------------------------------------
    CollectionYzWnd.layout_yztp_right1 = window:getChildByTag( Tag_collectionwndyz.LAYOUT_YZTP_RIGHT1 )
    CollectionYzWnd.btn_Go_yztp = CollectionYzWnd.layout_yztp_right1:getChildByTag(Tag_collectionwndyz.BTN_GO_YZTP )
    CollectionYzWnd.btn_Go_yztp:setOnClickScriptHandler( CollectionYzWnd.Onbtn_Go_yztp )

    CollectionYzWnd.btn_yztp_zdy = CollectionYzWnd.layout_yztp_right1:getChildByTag( Tag_collectionwndyz.BTN_YZTP_ZDY )
    CollectionYzWnd.btn_yztp_zdy:setOnClickScriptHandler( CollectionYzWnd.Onbtn_yztp_zdy )

    local len = 0
    for k, v in pairs(DataManager:getYzTp()) do
        len = len + 1
    end
    CollectionYzWnd.gpv_Card_yz = window:getChildByTag(Tag_collectionwndyz.GPV_CARD_YZ )    
    CollectionYzWnd.gpv_Card_yz:setDataSourceAdapterScriptHandler( gpvCardClickYz )
    CollectionYzWnd.gpv_Card_yz:setCountOfCell(len)
    CollectionYzWnd.gpv_Card_yz:reloadData()
----------------------------------------------------------------------------------------------------------------------------

    CollectionYzWnd.layout_Right_tp = window:getChildByTag(Tag_collectionwndyz.LAYOUT_RIGHT_TP )
    CollectionYzWnd.layout_yztp_right1 = window:getChildByTag(Tag_collectionwndyz.LAYOUT_YZTP_RIGHT1 )

----------------------------------------------------------------------------------------------------------------------------
    CollectionYzWnd.layout_Right_tp:setVisible(false)
    CollectionYzWnd.layout_yztp_right1:setVisible(true)
----------------------------------------------------------------------------------------------------------------------------

    CollectionYzWnd.btn_turn_tp = CollectionYzWnd.layout_Right_tp:getChildByTag( Tag_collectionwndyz.BTN_TURN_TP )
    CollectionYzWnd.btn_turn_tp:setOpacity(200)
    CollectionYzWnd.btn_turn_tp:setOnClickScriptHandler( CollectionYzWnd.Onbtn_turn_tp )

    CollectionYzWnd.gpvCardTempCards = CollectionYzWnd.layout_Right_tp:getChildByTag( Tag_collectionwndyz.LIST_CARDTEMPCARDS )
    CollectionYzWnd.gpvCardTempCards:setVisible( true )
    CollectionYzWnd.gpvCardTempCards:removeAllNodes()
--    CollectionYzWnd.gpvCardTempCards:initWithSize( cc.size(330, 490) )
--    CollectionYzWnd.gpvCardTempCards:setPositionX( 180 )
--    CollectionYzWnd.gpvCardTempCards:setPositionY( 340 )

    CollectionYzWnd.ImgMask = window:getChildByTag(Tag_collectionwndyz.IMG9_MASK)
    CollectionYzWnd.ImgMask:setContentSize( {width = 1280, height = 720} )
    CollectionYzWnd.ImgMask:setTouchEnabled(true)
    CollectionYzWnd.ImgMask:setOpacity(200)
    CollectionYzWnd.ImgMask:setOnClickScriptHandler( cardUIMaskClick )
    CollectionYzWnd.ImgMask:setVisible(false)

    CollectionYzWnd.cardUI = require("war2.cardBig").new()
    CollectionYzWnd.cardUI:init( 0 )
    CollectionYzWnd.cardUI:setCardIsFront(true)
    CollectionYzWnd.ImgMask:addChild( CollectionYzWnd.cardUI ) 
    CollectionYzWnd.cardUI:setPosition( 680, 400 )

    CollectionYzWnd.btn_Buy = window:getChildByTag( Tag_collectionwndyz.BTN_BUY )
    CollectionYzWnd.btn_Buy:setOnClickScriptHandler( clickBuyCard )
    CollectionYzWnd.btn_Buy:setVisible(false)
    CollectionYzWnd.img_FontBuy = window:getChildByTag( Tag_collectionwndyz.IMG_FONTBUY )
    CollectionYzWnd.img_FontBuy:setVisible(false)
    CollectionYzWnd.img_GoldCount_buy = window:getChildByTag( Tag_collectionwndyz.IMG_GOLDCOUNT_BUY )
    CollectionYzWnd.img_GoldCount_buy:setVisible(false)
    CollectionYzWnd.labBmf_buy_money = window:getChildByTag( Tag_collectionwndyz.LABBMF_BUY_MONEY )
    CollectionYzWnd.labBmf_buy_money:setVisible(false)    
------------------------------------------------------------------------------------------------------------------------------
    CollectionYzWnd.mAllCardNum = CollectionYzWnd.layout_Right_tp:getChildByTag( Tag_collectionwndyz.LABBMF_ALLCARDNUM )
    CollectionYzWnd.mAllCardNum:setAlignment( 1, 0 )
    CollectionYzWnd.mAllCardNum:setString("")
--------------------------------------------------------------------------------------------------------------
    for i = 1, 3 do
        CollectionYzWnd.mCardGroupImgArr[i] = CollectionYzWnd.layout_Right_tp:getChildByTag( Tag_collectionwndyz["IMG_EQUIP_"..i] )  
    end
-----------------------------------------------------------------------------------------------------------------------------------
    CollectionYzWnd.isShow = true

end

--��˳���ſ��鿨��
local function CardGroupSort(data1, data2)
    if data1.cost < data2.cost then
        return true
    elseif data1.cost > data2.cost then
        return false
    end
    return data1.id < data2.id
end


--����Ԥ�������ұ��б�
function CollectionYzWnd:updateGpvCardList(id)
    if id == nil then
        id = CollectionYzWnd.selcetCell.selectid
    end
    --�Ƴ��ұ���ʾ���нڵ�
    CollectionYzWnd.gpvCardTempCards:removeAllNodes()

    local deck = DataManager:getYzTpData(id)
    id  = deck.my_deck
    CollectionYzWnd.selectDeck  = deck
    local data = DataManager:getDataPlayerTp(id)

    for i = 1, 3 do
        CollectionYzWnd.mCardGroupImgArr[i]:setTexture( "war2/warEqIcon/"..data[i].card_id..".png" )
    end
    CollectionYzWnd.mCardVecList = {}
    local data = DataManager:getDataPlayerTpNum(id)
    local tempList = {}
    for k, v in pairs(data) do
        local cardData = DataManager:getCardObjByID( k, false )
        if cardData then
            table.insert(tempList, cardData)
        end
    end
    table.sort( tempList, CardGroupSort )
    for i = 1, #tempList do
        CollectionYzWnd.insertItemToList(tempList[i].id, data[tempList[i].id])
    end
--    for k, v in pairs(data) do
--         CollectionYzWnd.insertItemToList(k,v)
--    end
    local curNum = getCurNum(deck.deck_id)
    CollectionYzWnd.gpvCardTempCards:reloadData()
    CollectionYzWnd.layout_Right_tp:setVisible(true)
    CollectionYzWnd.layout_yztp_right1:setVisible(false)
    if curNum >= deck.card_num then
        CollectionYzWnd.mAllCardNum:setColor(cc.c3b(255,255,255))
    else
        CollectionYzWnd.mAllCardNum:setColor(cc.c3b(255,0,0))
    end
    CollectionYzWnd.mAllCardNum:setString(curNum.."/"..deck.card_num)
    CollectionYzWnd.selcetCell.label_yz_num:setString(curNum.."/"..deck.card_num)
end

--������������
function CollectionYzWnd.insertItemToList(k,v)
    local idx = k
    local pCell = CollectionYzWnd.mCardVecList[idx]
    if pCell == nil then
		pCell = CGridPageViewCell:new()
        TuiManager:getInstance():parseCell( pCell, "cell_grid_zy", PATH_COLLECTIONWNDYZ )
        CollectionYzWnd.mCardVecList[idx] = pCell
	end
    pCell:setName( "" )
    local img_CardCount2 = pCell:getChildByTag( Tag_collectionwndyz.IMG_CARDCOUNT2 )
    local labbmf_yz_need = pCell:getChildByTag( Tag_collectionwndyz.LABBMF_YZ_NEED )
    local labbmf_yz_have = pCell:getChildByTag( Tag_collectionwndyz.LABBMF_YZ_HAVE )
    local labBmf_CardCountRace = pCell:getChildByTag( Tag_collectionwndyz.LABBMF_CARDCOUNTRACE )
    local img_CardBoxLight = pCell:getChildByTag( Tag_collectionwndyz.IMG_CARDBOXLIGHT )
    local img_CardBoxRed = pCell:getChildByTag( Tag_collectionwndyz.IMG_CARDBOXRED ) 
    local label_CardCountName = pCell:getChildByTag( Tag_collectionwndyz.LABEL_CARDCOUNTNAME )
    pCell.img_CardBoxLight = img_CardBoxLight
    label_CardCountName:enableOutline(cc.c4b(0,0,0,245),2)  --���ı��������
    label_CardCountName:setLineBreakWithoutSpace(true)
    img_CardBoxLight.id = k    
    if img_CardBoxLight.id == curGroupCardId then
        img_CardBoxLight:setOpacity(255)
    else
        img_CardBoxLight:setOpacity(1)
    end
    img_CardBoxLight:setTouchEnabled(true)
    img_CardBoxLight:setOnClickScriptHandler( tempCardUIClick )    
    local cardData = DataManager:getCardObjByID( k, false )
    img_CardBoxLight.data = cardData
    labBmf_CardCountRace:setString(cardData.cost)
    label_CardCountName:setString(cardData["name_text_"..LANGUAGE])
    labbmf_yz_need:setString(v)

    labbmf_yz_have:setString(CollectionManager:getHasCardNum(k))

    if v <= CollectionManager:getHasCardNum( k ) then
        labbmf_yz_have:setColor(cc.c3b(255,255,255))
        img_CardBoxRed:setVisible(false)
    else
        labbmf_yz_have:setColor(cc.c3b(255,0,0))
        img_CardBoxRed:setVisible(true)
    end
    img_CardCount2:setTexture( "collectionwnd/cardImg/"..cardData.shape..".png" )
    pCell:setVisible( true )
    pCell:setContentSize( cc.size( 340, 70 ) )
    CollectionYzWnd.gpvCardTempCards:insertNodeAtLast( pCell )
    CollectionYzWnd.gpvCardTempCards:setVisible(true)
end


function CollectionYzWnd:onExitScene()

    MusicManager:StopMusic( 101 )
    MusicManager:PlayLastSound()

    mSiftArr = {}
    CollectionYzWnd.mCardSpendsArr = {}
    CollectionYzWnd.mCardVecList = {}

    if CollectionYzWnd.selcetCell~= nil then
        CollectionYzWnd.selcetCell:setOpacity(1)
    end
    CollectionYzWnd.selcetCell = nil
    CollectionYzWnd.btn_yztp_cjtp:setVisible(false)
    CollectionYzWnd.isShow = false
    window = nil

end