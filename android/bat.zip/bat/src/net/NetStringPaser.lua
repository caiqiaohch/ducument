local DataManager = require("data.DataManager"):instance()
local CompoundString = {}
		
--/**
--	* 解析服务器返回的警告窗口信息 
--	* @param msg
--	* @return 
--	* 
--	*/
function CompoundString.ParseParmMsg( msg )

	local conversationID =  msg:readInt()
    local var_conversationID = {}
    local data = DataManager:getStringDataTxt(conversationID)
    if data ~= nil then 
        str = data["text_"..LANGUAGE]
    end

	if( data=="" ) then 
		print( "找不到对话内容 [id: " + conversationID + "]!" )
		return "";
	end
			
	local id = 1
	local mtype
	local len
	local cont
	local s = 115
	local d = 100
			
	while( msg:getAvailable() ) do
		mtype = msg:readByte()				
		if( mtype == s ) then
			len = msg:readInt()
            cont = msg:readStringBytes( len )
		elseif( mtype == d ) then
			cont = msg:readInt()
		end
		table.insert(var_conversationID, cont)
    end
			
    self:ParseParmMsgVar( data,var_conversationID )

end
	

--$N      第N个参数(直接用服务器发来的%d/%s代替)				
--|N      第N个参数(只对数字有效，查相对应的文本信息表字串来代替)				
--&N      第N个参数(只对数字有效,查相对应的文字表字串代替)				
--\n      换行				
--\t     水平制表符				
--@N      道具名称				
function CompoundString.ParseParmMsgVar( data,value )
    local len = #value
    local i
    for i=1,len do
        string.gsub(data,"$"..i,value[i])   
    end
    return data   
end

return CompoundString