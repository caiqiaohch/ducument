cc.utils 				= require("framework.cc.utils.init")
cc.net 					= require("framework.cc.net.init")

local Crypt = require("net.Crypt")
local PacketBuffer = require("net.PacketBuffer")
local Protocol = require("net.Protocol")
local StructList = require("struct.StructList")

local Network = class()-- 定义一个类 test 继承于 base_type

Network.DataSumList = {}

function Network:instance()

--	print("network instance call")

    local o = _G.Network
    if o then
    	print("return cur network")
    	return o
	end
 
    o = Network:new()
	_G.Network = o
    o:init()
--	print("return new network")
    return o

end

function Network:clear()

    _G.Network = false

end

  
function Network:ctor()

	print("Network:ctor --------------------------")
	
end

function Network:init()

    self._socket=nil
    --当前未完整拼接的协议包
    self.mPendingPacket  = nil --cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
    --包的长度
    self.mPacketLength_ = 0
    --协议包队列
    self.mPacketQueue_ = StructList.new()
    --协议处理字典表
    self.mProtocols_ = {}
    --实际包的长度
    self.mRealPackLen_ = 0
    --网络消息数据缓冲
    self._mSocketDataBuf  = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
    --是否可以处理socket
    self.bisDispose_ = true
    --是否需要处理TGW
    self.isSendTGW_ = false
    --TGW
    self.tgwStr_ =""

    self.host_ = ""

    self.port_ = 0
    --是否暂停消息包的解析处理
    self.mPauseMsgProc = false   
    
    --是否发送加密
    self.UseEcrypt = true

    --没有链接
    self.mIsConnected = false

    --是否初始化协议
    self.mIsInitProtocol = false
    --self:initAllProtocols()  
end


function Network:initAllProtocols()
--	self.mProtocols
--InProtocolDefination.RECV_GAME_SERVER_LIST_CMD.toString(), new --ProcRecvGameServerList(InProtocolDefination.RECV_GAME_SERVER_LIST_CMD)
    if self.mIsInitProtocol == true then
        return
    end
    self.mIsInitProtocol = true
    
    self.mProtocols_["Proc0x1001"] = require("net.inProtocol.login.Proc0x1001").new()
    self.mProtocols_["Proc0x1100"] = require("net.inProtocol.login.Proc0x1100").new()
    self.mProtocols_["Proc0xffb5"] = require("net.inProtocol.login.Proc0xffb5").new()
    self.mProtocols_["Proc0xf001"] = require("net.inProtocol.login.Proc0xf001").new()
    self.mProtocols_["Proc0x1202"] = require("net.inProtocol.login.Proc0x1202").new()
    self.mProtocols_["Proc0x1204"] = require("net.inProtocol.login.Proc0x1204").new()
    self.mProtocols_["Proc0x1205"] = require("net.inProtocol.login.Proc0x1205").new()
    self.mProtocols_["Proc0x1210"] = require("net.inProtocol.login.Proc0x1210").new()
    self.mProtocols_["Proc0x1300"] = require("net.inProtocol.login.Proc0x1300").new()

    self.mProtocols_["Proc0x2000"] = require("net.inProtocol.game.Proc0x2000").new()
    self.mProtocols_["Proc0x2001"] = require("net.inProtocol.game.Proc0x2001").new()
    self.mProtocols_["Proc0x2002"] = require("net.inProtocol.game.Proc0x2002").new()
    self.mProtocols_["Proc0x2003"] = require("net.inProtocol.game.Proc0x2003").new()
    self.mProtocols_["Proc0x2004"] = require("net.inProtocol.game.Proc0x2004").new()
    self.mProtocols_["Proc0x2005"] = require("net.inProtocol.game.Proc0x2005").new()
    self.mProtocols_["Proc0x2006"] = require("net.inProtocol.game.Proc0x2006").new()
    self.mProtocols_["Proc0x2007"] = require("net.inProtocol.game.Proc0x2007").new()
    self.mProtocols_["Proc0x2011"] = require("net.inProtocol.game.Proc0x2011").new()
    self.mProtocols_["Proc0x2012"] = require("net.inProtocol.game.Proc0x2012").new()
    self.mProtocols_["Proc0x2013"] = require("net.inProtocol.game.Proc0x2013").new()
    self.mProtocols_["Proc0x2014"] = require("net.inProtocol.game.Proc0x2014").new()
    self.mProtocols_["Proc0x2016"] = require("net.inProtocol.game.Proc0x2016").new()
    self.mProtocols_["Proc0x2017"] = require("net.inProtocol.game.Proc0x2017").new()
    self.mProtocols_["Proc0x2021"] = require("net.inProtocol.game.Proc0x2021").new()
    self.mProtocols_["Proc0x2022"] = require("net.inProtocol.game.Proc0x2022").new()
    self.mProtocols_["Proc0x2023"] = require("net.inProtocol.game.Proc0x2023").new()
    self.mProtocols_["Proc0x2024"] = require("net.inProtocol.game.Proc0x2024").new()
    self.mProtocols_["Proc0x2031"] = require("net.inProtocol.game.Proc0x2031").new()
    self.mProtocols_["Proc0x2032"] = require("net.inProtocol.game.Proc0x2032").new()
    self.mProtocols_["Proc0x2041"] = require("net.inProtocol.game.Proc0x2041").new()
   
    --技能相关
    self.mProtocols_["Proc0x2040"] = require("net.inProtocol.game.Proc0x2040").new()
    self.mProtocols_["Proc0x2050"] = require("net.inProtocol.game.Proc0x2050").new()
    self.mProtocols_["Proc0x2051"] = require("net.inProtocol.game.Proc0x2051").new()
    self.mProtocols_["Proc0x2052"] = require("net.inProtocol.game.Proc0x2052").new()
    self.mProtocols_["Proc0x2053"] = require("net.inProtocol.game.Proc0x2053").new()
    self.mProtocols_["Proc0x2054"] = require("net.inProtocol.game.Proc0x2054").new()
    self.mProtocols_["Proc0x2055"] = require("net.inProtocol.game.Proc0x2055").new()
    self.mProtocols_["Proc0x2056"] = require("net.inProtocol.game.Proc0x2056").new()
    self.mProtocols_["Proc0x2057"] = require("net.inProtocol.game.Proc0x2057").new()
    self.mProtocols_["Proc0x2058"] = require("net.inProtocol.game.Proc0x2058").new()
    self.mProtocols_["Proc0x2059"] = require("net.inProtocol.game.Proc0x2059").new()
    self.mProtocols_["Proc0x2060"] = require("net.inProtocol.game.Proc0x2060").new()
    self.mProtocols_["Proc0x2061"] = require("net.inProtocol.game.Proc0x2061").new()
    self.mProtocols_["Proc0x2062"] = require("net.inProtocol.game.Proc0x2062").new()
    self.mProtocols_["Proc0x2063"] = require("net.inProtocol.game.Proc0x2063").new()
    self.mProtocols_["Proc0x2066"] = require("net.inProtocol.game.Proc0x2066").new()
    self.mProtocols_["Proc0x2067"] = require("net.inProtocol.game.Proc0x2067").new()
    self.mProtocols_["Proc0x2070"] = require("net.inProtocol.game.Proc0x2070").new()

    --组牌相关
    self.mProtocols_["Proc0x1400"] = require("net.inProtocol.collectionWnd.Proc0x1400").new()
    self.mProtocols_["Proc0x1401"] = require("net.inProtocol.collectionWnd.Proc0x1401").new()
    self.mProtocols_["Proc0x1402"] = require("net.inProtocol.collectionWnd.Proc0x1402").new()
    self.mProtocols_["Proc0x1403"] = require("net.inProtocol.collectionWnd.Proc0x1403").new()
    self.mProtocols_["Proc0x1404"] = require("net.inProtocol.collectionWnd.Proc0x1404").new()
    self.mProtocols_["Proc0x1405"] = require("net.inProtocol.collectionWnd.Proc0x1405").new()
    self.mProtocols_["Proc0x1406"] = require("net.inProtocol.collectionWnd.Proc0x1406").new()
    self.mProtocols_["Proc0x1500"] = require("net.inProtocol.collectionWnd.Proc0x1500").new()
    self.mProtocols_["Proc0x1501"] = require("net.inProtocol.collectionWnd.Proc0x1501").new()
    self.mProtocols_["Proc0x1502"] = require("net.inProtocol.collectionWnd.Proc0x1502").new()
    self.mProtocols_["Proc0x1503"] = require("net.inProtocol.collectionWnd.Proc0x1503").new()
    self.mProtocols_["Proc0x1504"] = require("net.inProtocol.collectionWnd.Proc0x1504").new()

    --主角相关
    self.mProtocols_["Proc0x1800"] = require("net.inProtocol.attribute.Proc0x1800").new()
    self.mProtocols_["Proc0x1801"] = require("net.inProtocol.attribute.Proc0x1801").new()
    self.mProtocols_["Proc0x1802"] = require("net.inProtocol.attribute.Proc0x1802").new()
    self.mProtocols_["Proc0x1803"] = require("net.inProtocol.attribute.Proc0x1803").new()
    self.mProtocols_["Proc0x1804"] = require("net.inProtocol.attribute.Proc0x1804").new()
    self.mProtocols_["Proc0x1805"] = require("net.inProtocol.attribute.Proc0x1805").new()
    self.mProtocols_["Proc0x1806"] = require("net.inProtocol.attribute.Proc0x1806").new()
    self.mProtocols_["Proc0x1807"] = require("net.inProtocol.attribute.Proc0x1807").new()
    self.mProtocols_["Proc0x1808"] = require("net.inProtocol.attribute.Proc0x1808").new()

    self.mProtocols_["Proc0x1830"] = require("net.inProtocol.attribute.Proc0x1830").new()
    self.mProtocols_["Proc0x1831"] = require("net.inProtocol.attribute.Proc0x1831").new()
    self.mProtocols_["Proc0x1832"] = require("net.inProtocol.attribute.Proc0x1832").new()
    self.mProtocols_["Proc0x1833"] = require("net.inProtocol.attribute.Proc0x1833").new()
    self.mProtocols_["Proc0x1834"] = require("net.inProtocol.attribute.Proc0x1834").new()
    self.mProtocols_["Proc0x1835"] = require("net.inProtocol.attribute.Proc0x1835").new()
    self.mProtocols_["Proc0x1836"] = require("net.inProtocol.attribute.Proc0x1836").new()
    self.mProtocols_["Proc0x1837"] = require("net.inProtocol.attribute.Proc0x1837").new()
    self.mProtocols_["Proc0x1838"] = require("net.inProtocol.attribute.Proc0x1838").new()
    self.mProtocols_["Proc0x1839"] = require("net.inProtocol.attribute.Proc0x1839").new()
    --测试协议
    self.mProtocols_["Proc0x2100"] = require("net.inProtocol.game.Proc0x2100").new()

    --天梯系统
    self.mProtocols_["Proc0x3100"] = require("net.inProtocol.Ladder.Proc0x3100").new()
    self.mProtocols_["Proc0x3101"] = require("net.inProtocol.Ladder.Proc0x3101").new()
    self.mProtocols_["Proc0x3102"] = require("net.inProtocol.Ladder.Proc0x3102").new()

    self.mProtocols_["Proc0x3400"] = require("net.inProtocol.Ladder.Proc0x3400").new()
    
    --商城系统
    self.mProtocols_["Proc0x2201"] = require("net.inProtocol.Shop.Proc0x2201").new()
    self.mProtocols_["Proc0x2202"] = require("net.inProtocol.Shop.Proc0x2202").new()

    --好友系统
    self.mProtocols_["Proc0x2701"] = require("net.inProtocol.friend.Proc0x2701").new()
    self.mProtocols_["Proc0x2702"] = require("net.inProtocol.friend.Proc0x2702").new()
    self.mProtocols_["Proc0x2703"] = require("net.inProtocol.friend.Proc0x2703").new()
    self.mProtocols_["Proc0x2704"] = require("net.inProtocol.friend.Proc0x2704").new()
    self.mProtocols_["Proc0x2705"] = require("net.inProtocol.friend.Proc0x2705").new()
    --好友观战
    self.mProtocols_["Proc0x2043"] = require("net.inProtocol.game.Proc0x2043").new()
    self.mProtocols_["Proc0x2044"] = require("net.inProtocol.game.Proc0x2044").new()
    self.mProtocols_["Proc0x2045"] = require("net.inProtocol.game.Proc0x2045").new()
        
    self.mProtocols_["Proc0x2710"] = require("net.inProtocol.friend.Proc0x2710").new()
    self.mProtocols_["Proc0x2711"] = require("net.inProtocol.friend.Proc0x2711").new()
    --任务系统
    self.mProtocols_["Proc0x4101"] = require("net.inProtocol.taskWnd.Proc0x4101").new()
    self.mProtocols_["Proc0x4102"] = require("net.inProtocol.taskWnd.Proc0x4102").new()
    self.mProtocols_["Proc0x4103"] = require("net.inProtocol.taskWnd.Proc0x4103").new()
    self.mProtocols_["Proc0x4104"] = require("net.inProtocol.taskWnd.Proc0x4104").new()
    --成就系统
    self.mProtocols_["Proc0x5101"] = require("net.inProtocol.taskWnd.Proc0x5101").new()
    self.mProtocols_["Proc0x5102"] = require("net.inProtocol.taskWnd.Proc0x5102").new()
    self.mProtocols_["Proc0x5103"] = require("net.inProtocol.taskWnd.Proc0x5103").new()
    self.mProtocols_["Proc0x5104"] = require("net.inProtocol.taskWnd.Proc0x5104").new()

    --开奖励宝箱系统
    self.mProtocols_["Proc0x2098"] = require("net.inProtocol.openbox.Proc0x2098").new()
    self.mProtocols_["Proc0x2099"] = require("net.inProtocol.openbox.Proc0x2099").new()

    --竞技场相关
    self.mProtocols_["Proc0x2800"] = require("net.inProtocol.arena.Proc0x2800").new()
    self.mProtocols_["Proc0x2801"] = require("net.inProtocol.arena.Proc0x2801").new()
    self.mProtocols_["Proc0x2802"] = require("net.inProtocol.arena.Proc0x2802").new()
    self.mProtocols_["Proc0x2803"] = require("net.inProtocol.arena.Proc0x2803").new()

    --挑战者相关
--    self.mProtocols_["Proc0x2900"] = require("net.inProtocol.challenger.Proc0x2900").new()
--    self.mProtocols_["Proc0x2901"] = require("net.inProtocol.challenger.Proc0x2901").new()

    --断线重连
    self.mProtocols_["Proc0x2042"] = require("net.inProtocol.game.Proc0x2042").new()

    --服务器时间
    self.mProtocols_["Proc0x4455"] = require("net.inProtocol.login.Proc0x4455").new()
    
--    dyh_size = 0
end

function Network:getPauseMsgProc()

	return self.mPauseMsgProc
	
end

function Network:setPauseMsgProc(value)
	self.mPauseMsgProc = value
			
	if self.mPauseMsgProc == false then
        --恢复消息包的处理
		self:action()
    end
end

--记录数据量
function Network:setDataSumList(str, value)
    if str == "clear" then Network.DataSumList = {} return end
	if Network.DataSumList[str] == nil then Network.DataSumList[str] = 0 end
    Network.DataSumList[str] = Network.DataSumList[str] + value
end


function Network:connect(vhost,vport)
	print("Network:connect:"..vhost.."_"..vport)
	self.port_ = vhost
	self.host_ = vport

	if self._socket then	
		self._socket:close()
		self._socket = nil
	end
	
	if not self._socket then
		print("self._socket connect")
		self._socket = cc.net.SocketTCP.new(self.port_, self.host_, true)--false)
		self._socket:addEventListener(cc.net.SocketTCP.EVENT_CONNECTED, handler(self, self.onConnect))
		self._socket:addEventListener(cc.net.SocketTCP.EVENT_CLOSE, handler(self,self.onClose))
		self._socket:addEventListener(cc.net.SocketTCP.EVENT_CLOSED, handler(self,self.onClose))
		self._socket:addEventListener(cc.net.SocketTCP.EVENT_CONNECT_FAILURE, handler(self,self.onSecurityError))
		self._socket:addEventListener(cc.net.SocketTCP.EVENT_DATA, handler(self,self.onReceive))
	end
	self._socket:connect()
end


function Network:onConnect(evt)
	printInfo("socket status: %s", evt.name)
	
	self.mIsConnected = true
	print( "socket onConnect()" )
	
	self:callBackFunConnected()
end

function Network:callBackFunConnected()
	print("Network:callBackFunConnected")
	if  self.mCallBackFuncOnConnect ~= nil then
		self:mCallBackFuncOnConnect()
	end
end

function Network:close()
	self.mIsConnected = false
	print( "***** socket close() *****" )
	self._socket:close()
end

function Network:onClose(evt)
	self.mIsConnected = false
	print( "socket:onClose()" )
	
	if  self.mCallBackFuncOnClose ~= nil then

		self:mCallBackFuncOnClose()
	end
	
	self.mCallBackFuncOnClose = nil
end

function Network:onSecurityError(evt)

	self.mIsConnected = false
	print( "socket:onSecurityError()" )
	
	if  self.mCallBackFuncOnClose ~= nil then

		self:mCallBackFuncOnClose()
	end
	
	self.mCallBackFuncOnClose = nil
	
end

function Network:onError(evt)

	print( "socket:onError()" )
	if self.mCallBackFuncOnClose ~= nil then
		self:mCallBackFuncOnClose()
	end
	self.mCallBackFuncOnClose = nil
	
end

function Network:addProtcol(protocol)

	self.mIsConnected = false
	print( "socket:addProtcol()" )
	if self.mCallBackFuncOnClose ~= nil then

		self:mCallBackFuncOnClose()
	end
	self.mCallBackFuncOnClose = nil
	
end

-----------------------------打印每分钟接受协议数量-----------------------
local mTime = 0
local mTimer 
local getMsgList = {}
local mBolPrintMsg = false

local function addToMsgList(key)
    if getMsgList[key] == nil then
        getMsgList[key] = 0
    end
    getMsgList[key] = getMsgList[key] + 1
end

local function printgetMsgList()
    print("-------------------------------------------------\n")
    for k, v in pairs(getMsgList) do
        print(k.." num "..v)
    end
    print("-------------------------------------------------\n")
    getMsgList = {}--每一分钟重新计算
end

function Network:SetBolPrintMsg(bol)
    mBolPrintMsg = bol

    if mBolPrintMsg == true then
        if mTimer == nil then
            getMsgList = {}
            mTimer = require("framework.scheduler").scheduleGlobal( function ()  printgetMsgList() end, 60 )
        end
    elseif mTimer ~= nil then
        require("framework.scheduler").unscheduleGlobal( mTimer )
        mTime = 0
        mTimer = nil            
    end
    
end

-----------------------------打印每分钟接受协议数量-----------------------

function Network:action()
    --print("Network:action")
    --if self.mPauseMsgProc or 

    if self.mPauseMsgProc == true or self.mPacketQueue_:GetSize() == 0 then
--        print("PauseMsg")
        return 0
    end
    
    local msg
    local cmd
    local str
    self:initAllProtocols()
--    mTime = os.clock()
    while self.mPacketQueue_:GetSize()>0 do
         if self.mPauseMsgProc == true then
            return 0
         end     
        msg = self.mPacketQueue_:popleft()
--        dyh_size = dyh_size+self.mPacketQueue_:GetSize();
 --       print("popright ",dyh_size)
        if msg~=nil then
            msg:setPos(1)
            cmd = "Proc0x"..string.format("%x",msg:readInt())
            --str = cmd.toString(16); 
            --print("socket receive cmd:%u", cmd)
            print("客户端收到:"..cmd.."长度：".. msg:getLen())
            if war2CardManager.isPlaying == true then
                Network:setDataSumList(cmd, 1)
            end
            local pro = self.mProtocols_[cmd]
            if pro~=nil then
                pro:FromByteArray(msg)
            end        
            if mTimer then addToMsgList(cmd) end
        end      
    end 
--    print( "mTime "..( os.clock() - mTime ) )
--    mTime = os.clock()
end

function Network:packDispose(pack)
    print("self._mSocketDataBuf:getAvailable(): "..self._mSocketDataBuf:getAvailable() )
    if war2CardManager.isPlaying == true then
        Network:setDataSumList("AllSum", self._mSocketDataBuf:getAvailable())
    end
    if self._mSocketDataBuf:getAvailable() > 4000 and require("war2.war2CardManager"):instance().isPlaying == true then
        war2FightScene:setTxtNetWarn( self._mSocketDataBuf:getAvailable() )
    end
--    if self.mPacketLength and self.mPacketLength > 10000 then --超过10000明显错误
--        print("self.mPacketLength > 10000")
--        self.mPendingPacket = nil;       
--    end
    while self._mSocketDataBuf:getAvailable() > 0 do
        if self.mPendingPacket ~=nil then
           --如果上一个包不是一个完整包 
            if self._mSocketDataBuf:getAvailable() >= self.mPacketLength - self.mPendingPacket:getAvailable() then
                self._mSocketDataBuf:readBytes(self.mPendingPacket,self.mPendingPacket:getLen(),self.mPacketLength - self.mPendingPacket:getAvailable());
                self.mPacketQueue_:pushright( self.mPendingPacket )
                self.mPendingPacket = nil;       
            else
                self._mSocketDataBuf:readBytes(self.mPendingPacket,self.mPendingPacket:getLen())
            end    
        else
            if self._mSocketDataBuf:getAvailable() < 4 then  --如果长度少于4，则表示包不完整，连长度都不能读出来 
                self.mPacketLength = 4 --把长度设置为4，待下次接收包内容时调用
--                break
            else
                self.mPacketLength = self._mSocketDataBuf:readInt() - 4
            end
--            self.mPacketLength = self._mSocketDataBuf:readInt() - 4
--            print("self.mPacketLength: "..self.mPacketLength)
            self.mPendingPacket = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
            if self._mSocketDataBuf:getAvailable() >= self.mPacketLength then
--                print("ba.available1:"..self._mSocketDataBuf:getAvailable())
                --local zpos = self._mSocketDataBuf:getPos()
                --printf( "zpos: %u", zpos )

                --self._mSocketDataBuf:setPos( self._mSocketDataBuf:getPos()-1 )
                self._mSocketDataBuf:readBytes( self.mPendingPacket,1,self.mPacketLength - 1 )
                --print( "ba.available2:", self._mSocketDataBuf:getAvailable() )
                                   
                self.mPacketQueue_:pushright(self.mPendingPacket)
                --print("self.mPendingPacket.toString(16):", self.mPendingPacket:toString(16))
                self.mPendingPacket = nil

            
            else    --如果包剩余长度小于 包应该的长度 表示未发完整 记录剩余包 及长度  待下次接收包内容时调用
                print(" 未完整包剩余长度 "..self._mSocketDataBuf:getAvailable().." 应有长度 ".. self.mPacketLength)
                if self.mPacketLength > 10000 then
--                    self._mSocketDataBuf:clear()  --数据出错的时候清理这次收到的数据
--                    self.mPendingPacket = nil
--                    return
                end
                self._mSocketDataBuf:readBytes(self.mPendingPacket,1,self._mSocketDataBuf:getAvailable() )
            end
        end
    end	

    self:action()
end

function Network:onReceive(__event)
--    print("socket receive raw data:"..cc.utils.ByteArray.toString(__event.data, 16))

--    self._mSocketDataBuf:setPos(self._mSocketDataBuf:getLen()+1)
--    self._mSocketDataBuf:writeBuf(__event.data)
--    self._mSocketDataBuf:setPos(1)

    --如果网络消息已经读完了,就清空一下消息缓冲区
	if self._mSocketDataBuf:getAvailable() == 0 then
		self._mSocketDataBuf:clear()
    else
        if self._mSocketDataBuf:getPos() > 1 then
            print( "网络消息未处理完 _mSocketDataBuf:remove "..self._mSocketDataBuf:getPos() )
            self._mSocketDataBuf:remove( 1, self._mSocketDataBuf:getPos() - 1 )
        end
    end
    self._mSocketDataBuf:setPos(self._mSocketDataBuf:getLen()+1)
    self._mSocketDataBuf:writeBuf(__event.data)
    self._mSocketDataBuf:setPos(1)

    self:packDispose()
end

function Network:firstSend(netString)
    local msg = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
	msg:writeStringBytes(netString)
	msg:writeByte(0)
	msg:setPos(1)
	self:send( msg:getPack() )
   
--  msg:writeStringUShort(netString);
--  msg:writeByte(0x6d)
--  msg:writeByte(0x68)
--  msg:writeByte(0x68)
--  msg:writeByte(0x7a)  
--    msg:writeByte(0x68)
--    msg:writeByte(0x79)
--    msg:writeByte(0x77)
--    msg:writeByte(0x6c)    
--    msg:writeByte(0)
--	if(self._socket) then
--        self._socket:send( msg:getPack() );
--        printf("send %s packet: %s", "firstSend", msg:toString(16)) 
--	end
end

function Network:send(_buf)
	if self._socket and self._socket.isConnected == true then
		self._socket:send(_buf)
    else
        require("prompt.PromptManager"):instance():SetReConnectMsg()
	end
end

function Network:sendbyte(msg)
	if self._socket then
		self._socket:send( msg:getPack(3) );
    else
        require("prompt.PromptManager"):instance():SetReConnectMsg()
		--printf("send %s packet: %s", "sendStrings", msg:toString(16))  
	end
end

function Network:sendStrings(netString, isCryptMsgType)
    print("命令："..netString)
    isCryptMsgType = isCryptMsgType or true
    local res = 0
    local msg = nil
    --加密后发送
    if self.UseEcrypt == true then
        msg = Crypt:Encode( netString, isCryptMsgType ).encodeBA
		msg:setPos(1)
		res = self:send(msg:getPack())				
        --printf("send %s packet: %s", "sendStrings", msg:toString(16))  
    else   
        res = 0
        msg = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)

        msg:writeStringUShort(netString)
        msg:writeByte(0x0)

--        send_dyh = send_dyh+1
--        print( "网络消息发送包："..send_dyh.."长度："+msg:getLen() )
        if(self._socket) then
            self._socket:send( msg:getPack(3) )
        else
            require("prompt.PromptManager"):instance():SetReConnectMsg()
        end
    end
    
    return res
end

function Network:getCallBackFuncOnConnect()

	return self.mCallBackFuncOnConnect
	
end

function Network:setCallBackFuncOnConnect(value)

	self.mCallBackFuncOnConnect=value
	
end

function Network:getCallBackFuncOnClose()

	return self.mCallBackFuncOnClose
	
end

function Network:setCallBackFuncOnConnect(value)

	self.mCallBackFuncOnConnect = value
	
end

function Network:getCallBackFuncOnClose()

	return self.mCallBackFuncOnClose
	
end


function Network:setCallBackFuncOnClose(value)

	self.mCallBackFuncOnClose = value
	
end

		
function Network:getCallBackFuncOnSecurityError()

	return self.mCallBackFuncOnSecurityError
	
end

function Network:setCallBackFuncOnSecurityError(value)

	self.mCallBackFuncOnSecurityError = value
	
end


function Network:getCallBackFuncOnError()

	return self.mCallBackFuncOnError
	
end

function Network:setCallBackFuncOnError(value)

	self.mCallBackFuncOnError = value
	
end

function Network:getIsConnected()

	return self.mIsConnected
	
end

function Network:setIsConnected(value)

	self.mIsConnected = value
	
end

return Network