local ServMsgTransponder = class()

local Network = require("net.Network"):instance()
local socket = require "socket"


--请求加密钥匙
function ServMsgTransponder:SMTGetEcryptKey()
	local msg = "mhhz"
    Network:firstSend(msg)
end


function ServMsgTransponder:SMTOpenFriend( )
    local msg = "friend open "
    Network:sendStrings( msg )

    local writablePath = cc.FileUtils:getInstance():getWritablePath()
end

--添加好友
--friend add_hy 角色id        删除好友
function ServMsgTransponder:SMTDelHy( number ,mtype )
    local msg = "friend del_hy "..number.." "..mtype
    Network:sendStrings( msg )

    local writablePath = cc.FileUtils:getInstance():getWritablePath()
end

--添加好友
--friend add_hy 角色id        添加好友
function ServMsgTransponder:SMTAddHy( number , name)
    local msg = "friend add_hy "..number.." "..name
    Network:sendStrings( msg )

    local writablePath = cc.FileUtils:getInstance():getWritablePath()
end

--添加好友
--friend add_hy 角色id 角色名字        添加好友
function ServMsgTransponder:SMTAcceptHy( number , name)
    local msg = "friend accept_hy "..number.." "..name
    Network:sendStrings( msg )
end

--friend wt_hy 角色id        观战好友
function ServMsgTransponder:SMTWatchWar( number )
    local msg = "friend wt_hy "..number
    Network:sendStrings( msg )
end

--friend wt_hy_del      退出好友观
function ServMsgTransponder:SMTWatchWarDel()
    local msg = "friend wt_hy_del"
    Network:sendStrings( msg )
end

--friend no_watch      是否禁止好友观战 1不许看 0可以看
function ServMsgTransponder:SMTFriendNoWatch( sign )
    local msg = "friend no_watch "..sign
    Network:sendStrings( msg )
end


--friend ft_hy 角色id        对战申请
function ServMsgTransponder:SMTRefuseApplyWar( number )
    local msg = "friend ft_refuse "..number
    Network:sendStrings( msg )
end

--friend ft_hy 角色id        对战申请
function ServMsgTransponder:SMTApplyWar( number )
    local msg = "friend ft_hy "..number
    Network:sendStrings( msg )
end

function ServMsgTransponder:SMTApplyWar2( number )
    local msg = "friend ft_hy2 "..number
    Network:sendStrings( msg )
end

-- 查找好友
-- friend search 角色id
function ServMsgTransponder:SMTSearchHy( number )
    local msg = "friend search "..number
    Network:sendStrings( msg )
end

--账户登录
function ServMsgTransponder:SMTLogin( account, password )
    local msg = "LOGIN 0.1 "..account.." "..password.." 1" 
    Network:sendStrings( msg )

    local writablePath = cc.FileUtils:getInstance():getWritablePath()

    print("writablePath is  "..writablePath)
end

--创建新角色
function ServMsgTransponder:SMTCreateCharacter( str )
    local msg = "new_user "..str.." 1 1"
    print(msg)
	Network:sendStrings( msg )	
end

--请求服务器列表信息
function ServMsgTransponder:SMTGetGameServerList()
	local msg = "get_gameos all"
    Network:sendStrings( msg )
end

--玩家进入场景
function ServMsgTransponder:SMTEnterGame( account, objID )
	local msg = "ENTER "..account.." "..objID
    Network:sendStrings( msg )
end

--直接发送命令到后台
function ServMsgTransponder:SMTDbg( msg )
    Network:sendStrings( msg )
end

--war npc nType 1:还没打过的 2:已经打赢过,得到奖励了的
function ServMsgTransponder:SMTWarNPC(value, nType)
    if nType == nil then nType = 1 end
    local msg
    if nType == 1 then
        msg = "war npc "..value
    else    
        msg = "war npc2 "..value
    end
    Network:sendStrings( msg )
end

--userinfo head 编号id      //设置头像
function ServMsgTransponder:SMTUserinfoHead( id )
    local msg = "userinfo head "..id
    Network:sendStrings( msg )
end

--war ai value 是否开启ai匹配
function ServMsgTransponder:SMTWarAI(value)
    local msg = "war ai "..value
    Network:sendStrings( msg )
end

--compose_card fight 套牌编号  //申请战斗前认证卡牌合法性
function ServMsgTransponder:SMTComposeCardFight(mType)
    local msg = "compose_card fight "..mType
    Network:sendStrings( msg )
end

--compose_card fight2 套牌编号  //申请战斗前认证竞技场卡牌合法性 用于竞技场
function ServMsgTransponder:SMTComposeCardFight2(mType)
    local msg = "compose_card fight2 "..mType
    Network:sendStrings( msg )
end

--war apply type    // 寻找对手,开始战斗 type：1匹配对战 天梯对战，2休闲模式 与AI战斗
function ServMsgTransponder:SMTWarApply(mType)
    local msg = "war apply "..mType
    Network:sendStrings( msg )
end

function ServMsgTransponder:SMTWarMapNpc(string)
    local msg = "war mapNpc "..string
    Network:sendStrings( msg )
end 

--war withdraw type // 取消匹配对战     type：1为取消匹配对战，2为取消天梯对战
function ServMsgTransponder:SMTWarWithDraw(mType)
    local msg = "war withdraw "..mType
    Network:sendStrings( msg )
end

--war exchange  // 更换手牌
function ServMsgTransponder:SMTWarExchange()
    local msg = "war exchange"
    Network:sendStrings( msg )
end

--war giveup    // 放弃,认输
function ServMsgTransponder:SMTWarGiveUp()
    local msg = "war giveup"
    Network:sendStrings( msg )
end

--war sacrifice cardid pos // 献祭手牌,增加资源
function ServMsgTransponder:SMTWarSacrifice( id, pos )
    if spos == 0 then
        print("error")
    end
    local msg = "war sacrifice "..id.." "..pos
    Network:sendStrings( msg )
end

function ServMsgTransponder:SMTWarSacrificeNpc( id, pos )
    if spos == 0 then
        print("error")
    end
    local msg = "war_npc sacrifice "..id.." "..pos
    Network:sendStrings( msg )
end

--向后台请求手牌信息net hand 1 1
function ServMsgTransponder:SMTNetHand( msg )
    if msg == nil then return end
    local war2CardManager = require("war2.war2CardManager"):instance()
    if msg == nil then msg = "hand 1 1" end
    Network:sendStrings( msg )
end

-- war order objId cardid sarea spos destid darea dpos dobjId
-- cardid 发送效果的卡牌id(圣物牌，圣物牌id)  pos 战场上的牌的位置  destid 目标牌id  darea 效果区域  dsop  目标位置 objId 卡牌objId,手牌出才有
-- 使用技能
--旧sarea 1圣物 2手牌 3战场 4使用结界
--新sarea 4圣物 1手牌 7战场 9使用结界 3墓地
-- 如果有目标:destid darea dpos
-- 目标是指挥部：destid为0，darea为指挥部区域（5、6）,dpos 为0
function ServMsgTransponder:SMTWarOrder( cardid, sarea, spos, destid, darea, dpos, objId, dobjId )
    if objId == nil then objId = 0 end
    if dobjId == nil then dobjId = 0 end
    local war2CardManager = require("war2.war2CardManager"):instance()
    if sarea == WAR2_AREA_TYPE_ZHANCHANG then spos = war2CardManager:getBattleIndex( spos ) end
    if darea == WAR2_AREA_TYPE_ZHANCHANG then dpos = war2CardManager:getBattleIndex( dpos ) end
    local msg = "war order "..objId.." "..cardid.." "..sarea.." "..spos.." "..destid.." "..darea.." "..dpos.." "..dobjId
    Network:sendStrings( msg )
end

function ServMsgTransponder:SMTWarOrderNpc( cardid, sarea, spos, destid, darea, dpos, objId, dobjId )
    if objId == nil then objId = 0 end
    if dobjId == nil then dobjId = 0 end
    local war2CardManager = require("war2.war2CardManager"):instance()
    if sarea == WAR2_AREA_TYPE_ZHANCHANG then spos = war2CardManager:getBattleIndex( spos ) end
    if darea == WAR2_AREA_TYPE_ZHANCHANG then dpos = war2CardManager:getBattleIndex( dpos ) end
    local msg = "war_npc order "..objId.." "..cardid.." "..sarea.." "..spos.." "..destid.." "..darea.." "..dpos.." "..dobjId
    Network:sendStrings( msg )
end

--war deploy cardid spos destid darea dpos
--同上，部署部队时，有主动技能指向发送
function ServMsgTransponder:SMTWarDeploy( cardid, spos, destid, darea, dpos, dobjId )
    local war2CardManager = require("war2.war2CardManager"):instance()
    if spos ~= 0 then spos = war2CardManager:getBattleIndex( spos ) end
    if darea == WAR2_AREA_TYPE_ZHANCHANG then dpos = war2CardManager:getBattleIndex( dpos ) end
    if dobjId == nil then dobjId = 0 end
    local msg = "war deploy "..cardid.." "..spos.." "..destid.." "..darea.." "..dpos.." "..dobjId
    Network:sendStrings( msg )
end

--war mov cardid s spos d dpos     // sarea区域spos的牌,移动到 darea区域dpos的位置 objId 手牌的objId
--放到某个区域 0战术区 1手牌 2牌库 3墓地 4将军 5对方指挥部 6自己指挥部 7战场 8消失
function ServMsgTransponder:SMTWarMov( id, sarea, spos, darea, dpos, objId )
    if spos == 0 then
        print("error")
    end
    if objId == nil then objId = 0 end
    local war2CardManager = require("war2.war2CardManager"):instance()
    if sarea == WAR2_AREA_TYPE_ZHANCHANG then spos = war2CardManager:getBattleIndex( spos ) end
    if darea == WAR2_AREA_TYPE_ZHANCHANG then dpos = war2CardManager:getBattleIndex( dpos ) end
    local msg = "war mov "..objId.." "..id.." "..sarea.." "..spos.." "..darea.." "..dpos
    Network:sendStrings( msg )
    require("prompt.NewbieManager"):instance():updateBySendWarMov()
end
--war mov cardid s spos d dpos     // sarea区域spos的牌,移动到 darea区域dpos的位置 objId 手牌的objId
--放到某个区域 0战术区 1手牌 2牌库 3墓地 4将军 5对方指挥部 6自己指挥部 7战场 8消失
function ServMsgTransponder:SMTWarMovNpc( id, sarea, spos, darea, dpos, objId )
    if spos == 0 then
        print("error")
    end
    if objId == nil then objId = 0 end
    local war2CardManager = require("war2.war2CardManager"):instance()
    if sarea == WAR2_AREA_TYPE_ZHANCHANG then spos = war2CardManager:getBattleIndex( spos ) end
    if darea == WAR2_AREA_TYPE_ZHANCHANG then dpos = war2CardManager:getBattleIndex( dpos ) end
    local msg = "war_npc mov "..objId.." "..id.." "..sarea.." "..spos.." "..darea.." "..dpos
    Network:sendStrings( msg )
end


--war deploy cardid spos destid darea dpos
--同上，部署部队时，有主动技能指向发送
function ServMsgTransponder:SMTWarDeployNpc( cardid, spos, destid, darea, dpos, dobjId )
    local war2CardManager = require("war2.war2CardManager"):instance()
    if spos ~= 0 then spos = war2CardManager:getBattleIndex( spos ) end
    if darea == WAR2_AREA_TYPE_ZHANCHANG then dpos = war2CardManager:getBattleIndex( dpos ) end
    if dobjId == nil then dobjId = 0 end
    local msg = "war_npc deploy "..cardid.." "..spos.." "..destid.." "..darea.." "..dpos.." "..dobjId
    Network:sendStrings( msg )
end


--war turnover结束回合
function ServMsgTransponder:SMTWarTurnover()
    local msg = "war turnover"
    Network:sendStrings( msg )
end

--war ok 操作结束,进入下一阶段
function ServMsgTransponder:SMTWarOK()
    local war2CardManager = require("war2.war2CardManager"):instance()
    local msg = "war ok "..war2CardManager.State
    Network:sendStrings( msg )
--    if war2CardManager.State ~= 0 then
--        war2CardManager:setBolShortTime( false )
--    else
----        war2CardManager:setBolShortTime( true )
--    end
end

function ServMsgTransponder:SMTWarOKNpc()
    local war2CardManager = require("war2.war2CardManager"):instance()
    local msg = "war_npc ok "..war2CardManager.State
    Network:sendStrings( msg )
end

--war comm  客户端表现结束发送命令
function ServMsgTransponder:SMTWarNext()
    local war2CardManager = require("war2.war2CardManager"):instance()
    local msg = "war next "..war2CardManager.OrderSign
    Network:sendStrings( msg )
end

--war comm  客户端信息转发  测试用
function ServMsgTransponder:SMTWarComm( str )
    local msg = "war comm "..str
    Network:sendStrings( msg )
end


----------------------------------天梯系统--------------------------
--rank open  //打开天梯界面
function ServMsgTransponder:SMTRankOpen()
    local msg = "rank open"
    Network:sendStrings( msg )
end


local rankcntime = 0
local LadderManager = require("Ladder.LadderManager"):instance()
--rank cnt   //天梯页面信息  cnt 页码
function ServMsgTransponder:SMTRankCnt( page )

    local time = socket.gettime()
    if time - 0.5 < rankcntime then
        LadderManager.BolGetMsg = false
        return
    end
    rankcntime = time
    local msg = "rank cnt "..page
    Network:sendStrings( msg )
end
----------------------------------天梯系统--------------------------

----------------------------------天梯系统--------------------------
local warboxtime = 0
--war box index //开箱子
function ServMsgTransponder:SMTWarBox( index )
    local time = socket.gettime()
        print("SMTWarBox "..time)
    if time - 0.5 < warboxtime then
        return
    end
    warboxtime = time
    local msg = "war box "..index
    Network:sendStrings( msg )
end


--war key 请求宝箱钥匙,每隔一小时请求一次
function ServMsgTransponder:SMTWarKey()
    local msg = "war key"
    Network:sendStrings( msg )
end
----------------------------------天梯系统--------------------------

----------------------------------组牌界面---------------------------
--compose_card delete_decks                 // 删除牌组
function ServMsgTransponder:SMTDelete_decks( id )
    local msg = "compose_card delete_decks "..id
    Network:sendStrings( msg )
end

--compose_card decks 牌组编号 牌组名称$牌组头像id 圣物卡牌数据 普通卡牌数据牌
function ServMsgTransponder:SMTDecks( id, name, headId, EqStr, DinaryStr )
    name = string.gsub(name, "$", "")
    name = string.gsub(name, "#", "")
    name = string.gsub(name, " ", "_")
    name = name.."$"..headId.."$"..id
    local msg = "compose_card decks "..id.." "..name.." "..EqStr.." "..DinaryStr
    Network:sendStrings( msg )
end

--compose_card decks2 牌组编号 牌组名称$牌组头像id 圣物卡牌数据 普通卡牌数据牌
--竞技场组牌
function ServMsgTransponder:SMTDecks2( id, name, headId, EqStr, DinaryStr )
    name = string.gsub(name, "$", "")
    name = string.gsub(name, "#", "")
    name = string.gsub(name, " ", "_")
    name = name.."$"..headId.."$"..id
    local msg = "compose_card decks2 "..id.." "..name.." "..EqStr.." "..DinaryStr
    Network:sendStrings( msg )
end

--compose_card name 牌组编号 牌组名字    //设置牌组名字
function ServMsgTransponder:SMTName( id, name )
    name = string.gsub(name, " ", "_")
    local msg = "compose_card name "..id.." "..name
    Network:sendStrings( msg )
end  

--friend rename  玩家改名
function ServMsgTransponder:SMTReName( name )
    name = string.gsub(name, " ", "_")
    local msg = "friend rename "..name
    Network:sendStrings( msg )
end  


--compose_card show 编号    //申请牌组信息
function ServMsgTransponder:SMTShow( id )
    local msg = "compose_card show "..id 
    Network:sendStrings( msg )
end


--open equip_info    //请求牌组信息
function ServMsgTransponder:SMTOpenEquip_info()
    local msg = "open equip_info"
    Network:sendStrings( msg )
end

--open card_info  //请求拥有的卡牌信息
function ServMsgTransponder:SMTOpenCard_info( id )
    local msg = "open card_info"
    if id ~= nil then
        msg = "open card_info "..id
    end
    Network:sendStrings( msg )
end

--open deck_info   //请求牌组信息
function ServMsgTransponder:SMTOpenDeck_info()
    local msg = "open deck_info"
    Network:sendStrings( msg )
end

----------------------------------组牌界面---------------------------//

----------------------------------任务界面---------------------------
--daily refresh  任务ID
function ServMsgTransponder:SMTDailyRefresh( id )
    local msg = "daily refresh  "..id
    Network:sendStrings( msg )
end

--daily open
function ServMsgTransponder:SMTDailyOpen()
    local msg = "daily open 1"
    Network:sendStrings( msg )
end
----------------------------------任务界面---------------------------//

----------------------------------成就界面---------------------------
--daily opencj 1
function ServMsgTransponder:SMTDailyCJOpen()
    local msg = "daily opencj 1"
    Network:sendStrings( msg )
end
----------------------------------成就界面---------------------------//

----------------------------------商城系统--------------------------

--shop info 卡牌id编号集合      获取商品信息     //卡牌id编号集合格式：  卡牌id1,卡牌id2,......
function ServMsgTransponder:SMTShopInfo( str )
    local msg = "shop info "..str
    Network:sendStrings( msg )
end

--shop buy 购买类型 消耗类型 道具id 数量    购买道具   //购买类型：1卡包  2卡背  3单卡市场    消耗类型：1金币 2钻石 5新手卡包 6月VIP
function ServMsgTransponder:SMTShopBuy( type1, type2, id, num )
    local msg = "shop buy "..type1.." "..type2.." "..id.." "..num
    Network:sendStrings( msg )
end

--shop buy2 orderid 道具id 数量 
function ServMsgTransponder:SMTShopBuy2( orderid, id, num )
    local msg = "shop buy2 "..orderid.." "..id.." "..num
    Network:sendStrings( msg )
end

--shop sell 卡牌信息       出售卡牌              //卡牌信息：   卡牌id1,数量1;卡牌id2,数量2;....
function ServMsgTransponder:SMTShopSell( str )
    local msg = "shop sell "..str
    Network:sendStrings( msg )
end

--shop open 打开商城发送卡包和卡背信息
function ServMsgTransponder:SMTShopOpen()
    local msg = "shop open"
    Network:sendStrings( msg )
end


--item use 物品id 数量
function ServMsgTransponder:SMTItemUse(id, num)
    local msg = "item use "..id.." "..num
    Network:sendStrings( msg )
end


--发送聊天信息
function ServMsgTransponder:SMTTrans( str )
    local msg = "trans "..str
    print(msg)
	Network:sendStrings( msg )	
end

----------------------------------商城系统--------------------------

---------------------------------竞技场系统--------------------------
--area open 请求竞技场信息
function ServMsgTransponder:SMTAreaOpen( )
    local msg = "area open"
    print(msg)
	Network:sendStrings( msg )	
end

--area regist 竞技场报名 1点券 2宝石 3点券
function ServMsgTransponder:SMTAreaRegist( id )
    local msg = "area regist "..id
    print(msg)
	Network:sendStrings( msg )	
end

--area apply 角色id 对战申请匹配
function ServMsgTransponder:SMTAreaApply()
    local msg = "area apply"
    print(msg)
	Network:sendStrings( msg )	
end

--area deck 套牌选完
function ServMsgTransponder:SMTAreaDeck()
    local msg = "area deck"
    print(msg)
	Network:sendStrings( msg )	
end

--area giveup 弃权按钮
function ServMsgTransponder:SMTAreaGiveUp()
    local msg = "area giveup"
    print(msg)
	Network:sendStrings( msg )	
end

--area suiji 随机参数值 发送给后台保存当前随机参数
function ServMsgTransponder:SMTAreaSuiji( str )
    local msg = "area suiji "..str
    print(msg)
	Network:sendStrings( msg )	
end

--area withdraw type // 取消匹配对战  
function ServMsgTransponder:SMTAreaWithDraw()
    local msg = "area withdraw"
    Network:sendStrings( msg )
end

---------------------------------竞技场系统--------------------------

return ServMsgTransponder
