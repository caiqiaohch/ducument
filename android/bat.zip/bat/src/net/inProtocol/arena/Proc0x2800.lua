local Proc0x2800 = class("Proc0x2800")
local NewbieManager = require("prompt.NewbieManager"):instance()
local ArenaManager = require("arena.ArenaManager"):instance()
local CollectionManager = require("collectionWnd.CollectionManager"):instance()

function Proc0x2800:ctor()

end

--[0x2800 %d][竞技场阶段 %c] 0没报名 1选牌阶段 2已选牌阶段
function Proc0x2800:FromByteArray(msg)
    local state = msg:readByte()
    print("0x2800 "..state)
    local old = ArenaManager:getCurState()
    ArenaManager:setCurState(state)
    
    if state == 0 then
        ArenaManager:clear()        
        if ArenaManager:getIsSendOpen() == true and BattleWindow.isShow == true and ArenaWindow.isShow == false then
            BattleWindow:OpenArena()
        end
    elseif state == 1 or state == 2 then
--        if ArenaEnterWindow.isShow == true then
--            ArenaEnterWindow:closeWindow()
--        end
        if ArenaManager:getIsSendOpen() == true and old == 0 and state > 0 then
            RunScene("ArenaWindow")
        elseif ArenaWindow.isShow == true then
            ArenaWindow:updateMsg()
            ArenaWindow:updateGpvCardList()
        end
    end
    ArenaManager:setIsSendOpen(false)   
end

return Proc0x2800