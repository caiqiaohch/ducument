local Proc0x2802 = class("Proc0x2802")
local NewbieManager = require("prompt.NewbieManager"):instance()
function Proc0x2802:ctor()

end

--[0x2802 %d][当前随机参数 %s]
function Proc0x2802:FromByteArray(msg)
    local str = msg:readStringBytes( msg:getAvailable() - 1 )
    print("0x2802 "..str)
    if ArenaManager:getIsGetMsg() == true then
        return
    end   
    ArenaManager:setIsGetMsg(true)
    ArenaManager:setDataByMsg(str)
    if ArenaWindow.isShow == true then
        ArenaWindow:updateMsg()
    end
end

return Proc0x2802