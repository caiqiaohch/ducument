local Proc0x2801 = class("Proc0x2801")
local NewbieManager = require("prompt.NewbieManager"):instance()
function Proc0x2801:ctor()

end

--[0x2801 %d][竞技场1 %c][竞技场2 %c][竞技场3 %c][竞技场4 %c][竞技场5 %c]
function Proc0x2801:FromByteArray(msg)
    local result1 = msg:readByte()
    local result2 = msg:readByte()
    local result3 = msg:readByte()
    local result4 = msg:readByte()
    local result5 = msg:readByte()

    ArenaManager:setWinList({result1, result2, result3, result4, result5})
    print("0x2801 "..result1..","..result2..","..result3..","..result4..","..result5)
end

return Proc0x2801