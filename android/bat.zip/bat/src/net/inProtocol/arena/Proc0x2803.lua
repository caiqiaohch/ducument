local Proc0x2803 = class("Proc0x2803")
local NewbieManager = require("prompt.NewbieManager"):instance()
function Proc0x2803:ctor()

end

--[0x2803 %d][奖励ID %d]
function Proc0x2803:FromByteArray(msg)
    local id = msg:readInt()
    print("0x2803 "..id)
    TaskManager:setRewardData( 4, id )
end

return Proc0x2803