local Proc0x3400 = class("Proc0x3400")

function Proc0x3400:ctor()

end

--[0x3400 %d][1 %c]                             //开始
--[0x3400 %d][2 %c][页码 %c][数据 %s]           //数据：    荣誉值#姓名
--[0x3400 %d][3 %c]                             //结束
--天梯数据

function Proc0x3400:FromByteArray(msg)
    
    local LadderManager = require("Ladder.LadderManager"):instance()

    local tag = msg:readByte()
    if tag == 1 then
        print("开始")
    elseif tag == 3 then
        LadderRankWindow:updateList()
        LadderManager.BolGetMsg = false   
        print("结束")
    else
        page = msg:readByte()
        LadderManager.NextPage = page + 1
        local dataList = LadderManager.LadderDataArr
        if dataList[page] == nil then
            dataList[page] = {}
        end
        local str = msg:readStringBytes(msg:getAvailable() - 1)
        local arr = string.split( str, ";" )
        for i=1, #arr do
            local arr2 = string.split( arr[i], "#" )
            if #arr2 == 2 then                         
                local len = #dataList[page]
                dataList[page][len+1] = { rank = (page-1) * 10 + len + 1, capnum = tonumber(arr2[1]), name = arr2[2] }
                print("3400 page:"..page.."  "..str)
            end
        end
        
    end
        

    print("3400 tag:"..tag)
end

return Proc0x3400
