local Proc0x3101 = class("Proc0x3101")

function Proc0x3101:ctor()

end

local LadderManager = require("Ladder.LadderManager"):instance()

--[0x3101 %d][排名 %c][玩家id %d][分数 %d][玩家名字 %s] //发送排行榜数据
function Proc0x3101:FromByteArray(msg)
    local rank = msg:readByte()
    local charId = msg:readInt()
    local capnum = msg:readInt()
    local name = msg:readStringBytes(msg:getAvailable() - 1)

    local dataList = LadderManager.LadderDataArr
    if dataList[LadderManager.CurPage] == nil then
        dataList[LadderManager.CurPage] = {}
    end
--    dataList[page][len+1] = { rank = rank, charId = charId, capnum = charId, name = name }
    table.insert( dataList[LadderManager.CurPage], { rank = rank, charId = charId, capnum = capnum, name = name } )
    print( "3101 "..rank.." ".." "..capnum.." "..name)
--    local str = msg:readStringBytes(msg:getAvailable() - 1)
--    local arr = string.split( str, ";" )
--    for i=1, #arr do
--        local arr2 = string.split( arr[i], "#" )
--        if #arr2 == 2 then                         
--            local len = #dataList[page]
--            dataList[page][len+1] = { rank = (page-1) * 10 + len + 1, capnum = tonumber(arr2[1]), name = arr2[2] }
--            print("3400 page:"..page.."  "..str)
--        end
--    end
end

return Proc0x3101
