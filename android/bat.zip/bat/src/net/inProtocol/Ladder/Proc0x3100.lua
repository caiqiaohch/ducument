local Proc0x3100 = class("Proc0x3401")

function Proc0x3100:ctor()

end

local LadderManager = require("Ladder.LadderManager"):instance()
local lastPage = 0
--[0x3100 %d][页数 %c][总页数 %c][1 %c]               //开始
--[0x3100 %d][页数 %c][总页数 %c][2 %c]               //结束
function Proc0x3100:FromByteArray(msg)
    local cur = msg:readByte()
    local max = msg:readByte()
    local tag = msg:readByte()
    if tag == 1 then
        print("0x3100开始")
        lastPage = LadderManager.CurPage
        LadderManager.CurPage = cur
        local dataList = LadderManager.LadderDataArr
        dataList[LadderManager.CurPage] = {}
    elseif tag == 2 then
        LadderManager.BolGetMsg = false   
        local dataList = LadderManager.LadderDataArr
        if #dataList[LadderManager.CurPage] == 0 then
            LadderManager.CurPage = lastPage --如果没有数据,就表示还是前一页
        end

        if LadderRankWindow.isShow == true then
            LadderRankWindow:updateList()
        end
        print("0x3100结束")
    end
end

return Proc0x3100