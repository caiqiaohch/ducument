local Proc0x3102 = class("Proc0x3102")

function Proc0x3102:ctor()

end

--[0x3102 %d][当前排名 %c][分数 %d]--分数即荣誉值虽然后台还发但不需要                    当前排名
function Proc0x3102:FromByteArray(msg)
    local rank = msg:readByte()
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.Rank = rank
    print( "0x3102 "..rank)
end

return Proc0x3102