local Proc0x3401 = class("Proc0x3401")

function Proc0x3401:ctor()

end

--[0x3401 %d][总场数 %d][胜利场数 %d]
--1805代替了
function Proc0x3401:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.CharFightNum = msg:readInt()
    char.CharFightSuccessNum = msg:readInt()
    if CharacterWindow.isShow == true then
        CharacterWindow:updateMsg()
    end
end

return Proc0x3401