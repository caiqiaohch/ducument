local Proc0x1214 = class("Proc0x1214")

function Proc0x1214:ctor()

end


local isFirst = true

--[0x2701 %d][好友ID %d][好友是否在线 %c][好友是否战斗 %w][好友名字 %s]
function Proc0x1214:FromByteArray(msg)
    local number = msg:readInt()
    require("prompt.PromptManager"):instance():SetNotice(number)
end

return Proc0x1214