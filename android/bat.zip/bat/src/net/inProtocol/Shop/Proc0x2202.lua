local Proc0x2202 = class("Proc0x2202")

function Proc0x2202:ctor()

end

--[0x2202 %d][卡牌信息 %s]          //使用卡包，获得卡牌的信息    格式：卡牌id1#num,卡牌id2#num,....
function Proc0x2202:FromByteArray(msg)
    local ShopManager = require("Shop.ShopManager"):instance()
    local str = msg:readStringBytes( msg:getAvailable() - 1 )
    local arr = string.split(str, ",")
    local id = 0
    local num = 0
    local mCardArr = {}
    ShopManager.CurCardPackArr = {}
    for i = 1, #arr do
        if arr[i] ~= "" then
            id = tonumber(string.split(arr[i], "#")[1])
            num = tonumber(string.split(arr[i], "#")[2])
            for j = 1, num do
                table.insert(ShopManager.CurCardPackArr, id)
            end
            print("2202,"..id..",".. num)
        end
    end
    if OpenPackWindow.isShow == true then
         OpenPackWindow:showCard()
    end
end

return Proc0x2202