local Proc0x2201 = class("Proc0x2201")
require "xiangxi.CardXiangXi"

function Proc0x2201:ctor()

end

--[0x2201 %d][商城卡牌信息 %s]      //更新商城卡牌信息         格式：  卡牌id,商城数量,,购买价格,出售价格;
function Proc0x2201:FromByteArray(msg)
    
    local ShopManager = require("Shop.ShopManager"):instance()

    local str = msg:readStringBytes( msg:getAvailable() - 1 )
    print( "2201 "..str )
    local arr = string.split(str, ";")
    local mCardArr = {}
    for i = 1, #arr do
        if arr[i] ~= "" then
            mCardArr = arr[i]:split(",")
            if #mCardArr == 4 then
                ShopManager.ShopCardList[ tonumber( mCardArr[1] ) ] = { cardId = tonumber( mCardArr[1] ), num = tonumber( mCardArr[2] ), buyPrice = tonumber( mCardArr[3] ), sellPrice = tonumber( mCardArr[4] ) }
            end
        end
    end

    if CardXiangXi.isShow == true then
        CardXiangXi:updateBuyMsg()
    end
end

return Proc0x2201
