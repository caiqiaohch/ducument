local Proc0x2702 = class("Proc0x2702")

function Proc0x2702:ctor()

end


--[0x2702]删除好友
function Proc0x2702:FromByteArray(msg)
    local friend = msg:readInt()
    local number = msg:readInt()
    FriendManager:del(friend,number)
    print("Proc0x2701  "..str)
   -- "添加"..str.."("..")为好友"
   if FriendWnd.isShow == true then
    FriendWnd:updateList()
   end
end

return Proc0x2702