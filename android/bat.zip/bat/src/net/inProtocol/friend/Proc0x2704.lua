local Proc0x2704 = class("Proc0x2704")
local ServMsgTransponder = require("net.ServMsgTransponder")

function Proc0x2704:ctor()

end

--与好友对战
--[0x2703 %d][玩家ID %d][玩家名字 %d]
function Proc0x2704:FromByteArray(msg)

    local number = msg:readInt()
    local str = msg:readStringBytes( msg:getAvailable() - 1 )

    print("Proc0x2704  "..str)


    local char = CharacterManager:getMainPlayer()

   -- "添加"..str.."("..")为好友"
    require("prompt.PromptManager"):instance():SetPromptMsg(4079, str, function ()
--         FightWnd:set_battlefriend2(number)
--           RunScene("FightWnd")
        require("framework.scheduler").performWithDelayGlobal( function () 
           FightWnd:setAndShowType( WAR2_TYPE_FRIEND, {friend2 = number} )
           end, 0.2 )
     end, function () ServMsgTransponder:SMTRefuseApplyWar( number ) end, nil, nil, false)

--   require("framework.scheduler").performWithDelayGlobal( function () 
--   FightWnd:closeWindow() 
--   end, 0.2 )

end

return Proc0x2704