local Proc0x2701 = class("Proc0x2701")
local ServMsgTransponder = require("net.ServMsgTransponder")
local FriendManager = require("data.FriendManager"):instance()
function Proc0x2701:ctor()

end


local isFirst = true
local mGolalTimer

local function updateFriendWnd()
    if FriendWnd.isShow == true then
        FriendWnd:updateList()
   elseif friend == 2 then
        MainWindow:setFriendMsg(true)
   end
   mGolalTimer = nil
end

--[0x2701 %d][好友ID %d][好友是否在线 %c][好友是否战斗 %w][好友名字 %s]
function Proc0x2701:FromByteArray(msg)
    local friend = msg:readInt()
    local number = msg:readInt()
    local online = msg:readByte()
    local onbattle =  msg:readByte()
    local name = msg:readStringBytes( msg:getAvailable() - 1 )
    print("Proc0x2701  "..friend..","..number..","..online..","..onbattle..","..name)
--    if online == nil then return end
--    if onbattle == nil then return end
    FriendManager:add(friend,number,online,onbattle,name)
   -- "添加"..str.."("..")为好友"

    if mGolalTimer == nil then
        mGolalTimer = require("framework.scheduler").performWithDelayGlobal( updateFriendWnd, 0.2 ) 
    end    
end

return Proc0x2701