local Proc0x2705 = class("Proc0x2705")
local ServMsgTransponder = require("net.ServMsgTransponder")
--local FightWnd = require ("fightWnd.FightWnd")
function Proc0x2705:ctor()

end


function Proc0x2705:FromByteArray(msg)
    FightWnd:set_battlefriend(nil)
    FightWnd:set_battlefriend2(nil)

    if FightWaitWindow.isShow == true then
        FightWaitWindow:closeWindow()
    end

    FightWnd.fight_friend_isWaiting = false
    if FightWnd.isShow == true then
         FightWnd.needHide =true
    end
    if FightWnd.isShow == true then
         FightWnd.needHide =true
         FightWnd:closeWindow() 
    end
--    require("framework.scheduler").performWithDelayGlobal( function () 
--    if FightWnd.isShow == true then
--         FightWnd.needHide =true
--         FightWnd:closeWindow() 
--    end
--    end, 0.2 )

end

return Proc0x2705