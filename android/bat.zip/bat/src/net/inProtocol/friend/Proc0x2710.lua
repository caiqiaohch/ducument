local Proc0x2710 = class("Proc0x2710")
local ServMsgTransponder = require("net.ServMsgTransponder")

function Proc0x2710:ctor()

end

--[0x2710 %d][玩家ID %d]			//上线通知  广播给在线的客户端,玩家上线的信息,客户端自己判断该玩家上线是否自己要处理（师徒上线也用此协议处理）
function Proc0x2710:FromByteArray(msg)

    local id = msg:readInt()
    local onbattle = msg:readInt()
    local flag,flag1
    flag = FriendManager:update_online(id,1)
    flag1 =FriendManager:update_onbattle(id,onbattle)
    if flag == 1 or flag1 == 1 then
        if FriendWnd.isShow == true then
            FriendWnd:updateList()
        end
    end

    if war2FightScene.isShow == true then
        war2FightScene:getCharMsgLayout():setEMHeadGray(id, false)
    end
end

return Proc0x2710