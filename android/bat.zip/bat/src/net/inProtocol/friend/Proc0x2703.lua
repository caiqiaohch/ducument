local Proc0x2703 = class("Proc0x2703")
local ServMsgTransponder = require("net.ServMsgTransponder")

function Proc0x2703:ctor()

end

--[0x2703 %d][玩家ID %d][玩家名字 %d] 好友申请提示
function Proc0x2703:FromByteArray(msg)

    local number = msg:readInt()
    local str = msg:readStringBytes( msg:getAvailable() - 1 )

    print("Proc0x2703  "..str)
   -- "添加"..str.."("..")为好友"
    require("prompt.PromptManager"):instance():SetPromptMsg(4085, str, function () ServMsgTransponder:SMTAddHy(number,str) end, nil, nil, "确定", true)

    --require("prompt.PromptManager"):instance():SetNotice()

--    ServMsgTransponder:SMTRefuseApplyWar( number )
end

return Proc0x2703