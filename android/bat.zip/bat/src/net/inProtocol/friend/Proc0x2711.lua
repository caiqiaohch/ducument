local Proc0x2711 = class("Proc0x2711")
local ServMsgTransponder = require("net.ServMsgTransponder")

function Proc0x2711:ctor()

end

--[0x2711 %d][玩家ID %d]			//下线通知  广播给在线的客户端,玩家下线的信息,客户端自己判断该玩家上线是否自己要处理（师徒上线也用此协议处理）
function Proc0x2711:FromByteArray(msg)
    local id = msg:readInt()
    local flag = 0
    flag = FriendManager:update_online(id,0)
    if flag == 1 then
        if FriendWnd.isShow == true then
            FriendWnd:updateList()
        end
    end

    if war2FightScene.isShow == true then
        war2FightScene:getCharMsgLayout():setEMHeadGray(id, true)
    end
end

return Proc0x2711