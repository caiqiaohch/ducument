local Proc0x1830 = class("Proc0x1830")

function Proc0x1830:ctor()

end

--[0x1830 %d][金币 %d][钻石 %d][宝箱钥匙 %d][竞技场点券 %d][尘 %d]
function Proc0x1830:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.gold = msg:readInt()
    char.stone = msg:readInt()
    char.boxkey = msg:readInt()
    char.arenaPoints = msg:readInt()
    char.dust = msg:readInt()
    MainWindow:updatamsg()
end

return Proc0x1830