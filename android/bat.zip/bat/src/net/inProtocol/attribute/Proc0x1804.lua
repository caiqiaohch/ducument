local Proc0x1804 = class("Proc0x1804")

function Proc0x1804:ctor()

end

--[0x1804 %d][荣誉值 %d][最大荣誉值 %d]
function Proc0x1804:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.OldCharHonour = char.CharHonour
    char.CharHonour = msg:readInt()
    print( msg:getAvailable())
    if msg:getAvailable() >= 4 then
        char.CharMaxHonour = msg:readInt()       
    end
    if char.CharMaxHonour < char.CharHonour then
        char.CharMaxHonour = char.CharHonour
    end
    MainWindow:updataRankMsg()
    if CharacterWindow.isShow == true then
        CharacterWindow:updateMsg()
    end
    print("CharHonour "..char.CharHonour.." "..char.CharMaxHonour)
end

return Proc0x1804