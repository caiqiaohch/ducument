local Proc0x1806 = class("Proc0x1806")

function Proc0x1806:ctor()

end

--[0x1806 %d][地图npc刷怪 %s]
function Proc0x1806:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local str = msg:readStringBytes( msg:getAvailable() - 1 )
    local mapNpc = string.split(str, ",")
    print("1806 "..str)
    if mapNpc[#mapNpc] == "" then
        table.remove( mapNpc, #mapNpc )
    end  
    
    for i = 1, #mapNpc do
        mapNpc[i] = tonumber(mapNpc[i])
        if mapNpc[i] == 4 or mapNpc[i] == 5 or mapNpc[i] == 6 then
            mapNpc[i] = 3  --新手从6关减少到3关,处理一下之前打通了新手的数据
        end
    end    
    CharacterManager:updateMapNpcMsg( mapNpc )
    if StoryWindow.isShow == true then
        StoryWindow:UpDataMsg()
    end
end

return Proc0x1806