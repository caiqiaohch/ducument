local Proc0x1835 = class("Proc0x1835")

function Proc0x1835:ctor()

end

--[0x1835 %d][卡组解锁数量 %d]
function Proc0x1835:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.deckNum = msg:readInt()

    if CollectionYzWnd.isShow == true then
        CollectionYzWnd.createNewGroupByBuy()
    end
    print( "1835 "..char.deckNum)
end

return Proc0x1835