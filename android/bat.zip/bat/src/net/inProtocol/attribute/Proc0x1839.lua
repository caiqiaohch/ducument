local Proc0x1839 = class("Proc0x1839")
local CharacterManager = require("characters.CharacterManager"):instance()

function Proc0x1839:ctor()

end

--[0x1839 %d][剩余时间 %d][领奖天数 %d][是否购买过新手礼包 %d]
function Proc0x1839:FromByteArray(msg)
    local char = CharacterManager:getMainPlayer()
    
    local lastTime = msg:readInt()
    local lastDay = msg:readInt()

    local old = char.BuyNewGift
    local new = msg:readInt()
    char.BuyNewGift = new
    if old == 0 and char.BuyNewGift == 1 then
        TaskManager:setRewardData( 5, 0 ) --新手礼包领取提示
    end

    old = char.VipTime
    if old ~= -1 and lastTime > old then
        TaskManager:setRewardData( 6, 600 ) --月卡礼包领取提示
    end
    char.VipTime = lastTime
    char.VipGetDay = lastDay
    
    if MainWindow.isShow == true then
        MainWindow:UpDataShopListMsg()
    end  

    print("0x1839 "..lastTime..","..lastDay..","..new )
--    local endTimes = os.time()
--    if endTimes < 0 then
--        endTimes = socket.gettime()
--    end
----        time = 30
--    endTimes = endTimes + lastTime
--    print( endTimes )

     
    CharacterManager:setVipTime(lastTime, lastDay)

end

return Proc0x1839