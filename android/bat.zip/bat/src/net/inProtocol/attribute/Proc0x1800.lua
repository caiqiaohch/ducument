local Proc0x1800 = class("Proc0x1800")
local NewbieManager = require("prompt.NewbieManager"):instance()
function Proc0x1800:ctor()

end

--[0x1800 %d][主角ID %d][头像编号 %c][当前等级 %c][当前经验 %d][荣誉值 %d][角色名 %s]
function Proc0x1800:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.CharID = msg:readInt()
    char.HeadId = msg:readByte()
    char.CharLevel = msg:readByte()
    char.CharExp = msg:readInt()
    char.CharHonour = msg:readInt()
    char.Name = msg:readStringBytes( msg:getAvailable() - 1 )

    char.OldCharLevel = char.CharLevel
    char.OldCharExp = char.CharExp
    char.OldCharHonour =  char.CharHonour
    MainWindow:updatamsg()
    MainWindow:updataRankMsg()

    if char.CharLevel > 10 then
        NewbieManager:resetColData( true )  --超过10级一般已经过了新手了,重置编辑套牌指引全部为true
    end
end

return Proc0x1800