local Proc0x1803 = class("Proc0x1803")

function Proc0x1803:ctor()

end

--[0x1803 %d][当前经验 %d]
function Proc0x1803:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.OldCharExp = char.CharExp
    char.CharExp = msg:readInt()
    print("0x1803 "..char.OldCharExp.." "..char.CharExp)
    MainWindow:updatamsg()
end

return Proc0x1803