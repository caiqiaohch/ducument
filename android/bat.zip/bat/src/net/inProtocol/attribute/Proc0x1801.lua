local Proc0x1801 = class("Proc0x1801")

function Proc0x1801:ctor()

end

--[0x1801 %d][头像编号 %c]
function Proc0x1801:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.HeadId = msg:readByte()
    MainWindow:updatamsg()
--    if CharacterWindow.isShow == true then
--        CharacterWindow:updataHead()
--    end
end

return Proc0x1801