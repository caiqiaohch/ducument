local Proc0x1838 = class("Proc0x1838")
local CharacterManager = require("characters.CharacterManager"):instance()

function Proc0x1838:ctor()

end

--[0x1838 %d][用于卡牌购买的尘 %d]
function Proc0x1838:FromByteArray(msg)
    local char = CharacterManager:getMainPlayer()
    local old = char.dust
    char.dust = msg:readInt()
    print("0x1838 "..char.dust )
    if CardXiangXi.isShow == true then
        CardXiangXi:updateShopBtn()
    end  
end

return Proc0x1838