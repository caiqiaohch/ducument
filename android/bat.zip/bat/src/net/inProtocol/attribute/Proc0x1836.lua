local Proc0x1836 = class("Proc0x1836")

function Proc0x1836:ctor()

end

--[0x1836 %d][是否天梯AI %d]
function Proc0x1836:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.AllowAI = msg:readInt()

    if FightWnd.isShow == true then
        FightWnd:updateAllowAI()
    end
    print( "1836 "..char.AllowAI)
end

return Proc0x1836