local Proc0x1808 = class("Proc0x1808")

function Proc0x1808:ctor()

end

--[0x1808 %d][可以领天梯赛季奖励的标记 %]
function Proc0x1808:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    
    UserDefaultManager:setStringForKey("LadderReward", char.CharMaxHonour)
    if MainWindow.isShow == true and char.CharMaxHonour > 0 then
        if TaskWindow.isShow == true then
            TaskWindow:close()
        end
        RunScene("LadderRewardWindow")
    end
end

return Proc0x1808