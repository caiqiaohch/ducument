local Proc0x1807 = class("Proc0x1807")
local TaskManager = require("TaskWnd.TaskManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()
function Proc0x1807:ctor()

end

--��δ���˵�NPCID
function Proc0x1807:FromByteArray(msg)

    local CharacterManager = require("characters.CharacterManager"):instance()
    local value = msg:readInt()
    print("1807 "..value)
    if CharacterManager:checkNpcWin(value) == 1 then
        TaskManager:setRewardData( 1, value )
        if value == 3 then
            NewbieManager:setBolEndStory( true )  
            NewbieManager:resetColData( false )  --���ñ༭����ָ��

            NewbieManager:EditNewBieGroupName() 
        end
    end
    CharacterManager:callbackNpcWin(value)
    if StoryWindow.isShow == true then
        StoryWindow:UpDataMsg()
    end
end

return Proc0x1807