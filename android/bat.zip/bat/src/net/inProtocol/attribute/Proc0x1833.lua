local Proc0x1833 = class("Proc0x1833")

function Proc0x1833:ctor()

end

--[0x1833 %d][宝箱钥匙 %d]
function Proc0x1833:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.boxkey = msg:readInt()
    if MainWindow.isShow == true then
        MainWindow:updatamsg()
    end
    print( "1833 "..char.boxkey)
    if OpenBoxWindow.isShow == true then
        OpenBoxWindow:updateNum()
    end
end

return Proc0x1833