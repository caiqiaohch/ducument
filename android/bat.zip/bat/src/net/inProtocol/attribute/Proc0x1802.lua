local Proc0x1802 = class("Proc0x1802")

function Proc0x1802:ctor()

end

--[0x1802 %d][当前等级 %c]
function Proc0x1802:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.OldCharLevel = char.CharLevel
    char.CharLevel = msg:readByte()
    MainWindow:updatamsg()
end

return Proc0x1802