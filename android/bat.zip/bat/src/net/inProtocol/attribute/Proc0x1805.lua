local Proc0x1805 = class("Proc0x1805")

function Proc0x1805:ctor()

end

--[0x1805 %d][胜利场数 %d][失败场数 %d]
function Proc0x1805:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    char.Wins = msg:readInt()
    char.Lose = msg:readInt()

    if CharacterWindow.isShow == true then
        CharacterWindow:updateMsg()
    end
end

return Proc0x1805