local Proc0x1832 = class("Proc0x1832")
local ShopManager = require("Shop.ShopManager"):instance()

function Proc0x1832:ctor()

end

--[0x1832 %d][钻石 %d]
function Proc0x1832:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    local oldStone = char.stone
    char.stone = msg:readInt()
    local value = oldStone - char.stone
    if MainWindow.isShow == true then
        MainWindow:updatamsg()
        if value ==  ShopManager:getCurBuyStone() then
            MainWindow:addBuyEffect( value, 2 )    
        end
    end
    if OpenBoxWindow.isShow == true then
        OpenBoxWindow:updateNum()
    end

    

    if CharacterWindow.isShow == true then
        CharacterWindow:updateStone()
    end
end

return Proc0x1832