local Proc0x1837 = class("Proc0x1837")
local ShopManager = require("Shop.ShopManager"):instance()
local CharacterManager = require("characters.CharacterManager"):instance()

function Proc0x1837:ctor()

end

--[0x1837 %d][竞技场点券 %d]
function Proc0x1837:FromByteArray(msg)
    local char = CharacterManager:getMainPlayer()
    local old = char.arenaPoints
    char.arenaPoints = msg:readInt()
    print("0x1837 "..char.arenaPoints )
--    local value = old - char.arenaPoints
--    if MainWindow.isShow == true then
--        MainWindow:updatamsg()
--    end
--    if MainWindow.isShow == true and value ==  ShopManager:getCurBuyGold() then
--        print(oldGold)
--        MainWindow:addBuyEffect( value, 1 )    
--    end
end

return Proc0x1837