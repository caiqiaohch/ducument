local Proc0x1834 = class("Proc0x1834")
local scheduler = require("framework.scheduler")
local ServMsgTransponder = require("net.ServMsgTransponder")
local ztime
local mBattleTimer
function Proc0x1834:ctor()

end

--[0x1834 %d][宝箱钥匙时间 %d]
function Proc0x1834:FromByteArray(msg)
    ztime = msg:readInt()
    print("1834 "..ztime)
--    ztime = math.floor(ztime/60)

--    self:setAiTimer(false,0)
      if ztime == 3600 then
            ServMsgTransponder:SMTWarKey()
      end
      self:setAiTimer(true,3600-ztime+5)
--    self:setAiTimer(true,5)
end

function Proc0x1834:CheckKeyTime()
    if mBattleTimer ~= nil then
        scheduler.unscheduleGlobal( mBattleTimer )--清理计时器
        mBattleTimer = nil
    end
    ServMsgTransponder:SMTWarKey()
end

--计时器开启或关闭
function Proc0x1834:setAiTimer(bol,mtime)
    --计时器开启 
    if bol == true then
        if mBattleTimer ~= nil then
            scheduler.unscheduleGlobal( mBattleTimer )--清理计时器
            mBattleTimer = nil
        end
        local fuc = function () self:CheckKeyTime() end
        mBattleTimer = scheduler.scheduleGlobal( fuc, mtime )
    elseif bol == false then
        scheduler.unscheduleGlobal( mBattleTimer )--清理计时器
    end
end

return Proc0x1834