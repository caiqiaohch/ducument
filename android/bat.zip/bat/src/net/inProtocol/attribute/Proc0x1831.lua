local Proc0x1831 = class("Proc0x1831")
local ShopManager = require("Shop.ShopManager"):instance()

function Proc0x1831:ctor()

end

--[0x1831 %d][金币 %d]
function Proc0x1831:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    local oldGold = char.gold
    char.gold = msg:readInt()
    local value = oldGold - char.gold
    if MainWindow.isShow == true then
        MainWindow:updatamsg()
    end
    if MainWindow.isShow == true and value ==  ShopManager:getCurBuyGold() then
        print(oldGold)
        MainWindow:addBuyEffect( value, 1 )    
    end
    if CardXiangXi.isShow == true then
        CardXiangXi:updateShopBtn()
    end   
end

return Proc0x1831