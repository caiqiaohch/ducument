local Proc0x1300 = class("Proc0x1300")

function Proc0x1300:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()


--[0x1300 %d]     //可以进入游戏
function Proc0x1300:FromByteArray(msg)
    if war2CardManager.isPlaying ~= true then
        MainWindow.isCanShow = true
        MainWindow:onHandEnterScene()
    end
end

return Proc0x1300