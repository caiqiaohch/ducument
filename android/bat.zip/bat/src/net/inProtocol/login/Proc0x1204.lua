local Proc0x1204 = class("Proc0x1204")

local mTimer
local bolInit = false
local bolConnect = true
local LoginSer = require("net.LoginSer"):instance()

local function updateTimer()
    if LoginSer:getServerState() ~= 2 or Network.instance():getIsConnected() == false then  --只有在游戏服状态才有效        
        bolConnect = true
        return
    end

    if bolConnect == false then
        require("prompt.PromptManager"):instance():SetReConnectMsg()        
        UserDefaultManager:uploadLog()
        UserDefaultManager:setBolSendLog(false)
    else
        bolConnect = false
    end
end

local function init()
    mTimer = require("framework.scheduler").scheduleGlobal( updateTimer, 15 )
end

--心跳, 后台5秒发送一次
function Proc0x1204:ctor()
end

function Proc0x1204:FromByteArray(msg)
    --内容
	local mark = msg:readByte()
    bolConnect = true
--	require("prompt.PromptManager"):instance():SetNotice( mContents )
    if bolInit == false then
        bolInit = true
        init()
    end
end

return Proc0x1204