local Proc0x1001 = class("Proc0x1001")

local isCreate = false

function Proc0x1001:ctor()

end

function Proc0x1001:FromByteArray(msg)

    local CharacterManager = require("characters.CharacterManager"):instance()
    local LoginSer = require("net.LoginSer"):instance()

    --角色id
    local id = msg:readInt()
    --角色等级
    local level = msg:readByte()
    --角色性别
    local sex = msg:readByte()
    --角色职业
    local school = msg:readByte()
    --角色名称
    local strName = msg:readStringBytes(msg:getAvailable() - 1)
    print("0x1001 "..id..","..level..","..sex..","..school..","..strName)
    if id == 0 then
        --创建角色
        local scheduler = require("framework.scheduler")
        local fuc = nil
        isCreate = false
        fuc = function ()
            if isCreate == true then return end
            if LoginSer.charName == nil or LoginSer.charName == "" then
                LoginSer.charName = LoginSer.accounts
            end
            LoginSer:SendCreateChar(LoginSer.charName)
            scheduler.performWithDelayGlobal( fuc, 3 )
        end
        scheduler.performWithDelayGlobal( fuc, 1 )
    else
        isCreate = true
        --创建主角对象
        local char = CharacterManager:createPlayer( id, true )
        char.accounts = LoginSer.accounts
        char.Name = strName
        --请求服务器列表
        LoginSer:SendGetGame()
    end

    if buglyAddUserValue then
        buglyAddUserValue("charId", id)
        if LoginSer.charName ~= nil then
            buglyAddUserValue("charName", strName.." "..LoginSer.charName)
        else
            buglyAddUserValue("charName", strName)
        end        
    end
end

return Proc0x1001