local Proc0x1100 = class("Proc0x1100")


function Proc0x1100:ctor()

end

function Proc0x1100:FromByteArray(msg)

    print("Proc0x1100 begin")
    local test = msg:readByte();

    print("test:",test)
    print("Proc0x1100 end")    
    
end

return Proc0x1100