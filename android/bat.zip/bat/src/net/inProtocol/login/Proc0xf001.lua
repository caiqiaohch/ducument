local Proc0xf001 = class("Proc0xf001")
local socket = require "socket"


function Proc0xf001:ctor()

end

function Proc0xf001:FromByteArray(msg)
    --服务器的线号
	local mLineID = msg:readInt()
	
    local LoginSer = require("net.LoginSer"):instance()

    --开始接收
    if mLineID == 0 then
        return
    --结束接收
    elseif mLineID == -1 then
        --自动选线
        LoginSer:autoSelectLine()
--        LoginSer.f001Time = socket.gettime()
--        require("framework.scheduler").performWithDelayGlobal( function () 
--            if MainWindow.isCanShow == false then
--                 end, 
--            5 )
        return
    end
			
	--服务器人数
	local mCurPlayerCount = msg:readInt()
	local info = msg:readStringBytes( msg:getAvailable() - 1 )
	local arr = string.split( info, "`" )
			
	--ip地址
	local mIP = arr[1]
	--端口
	local mPort = arr[2]
	--服务器名称
	local mTip = arr[3]

	--ip地址
--	--local mIP = "144.34.181.158"--arr[1]
--	--端口
--	local mPort = 8998 -- arr[2]
--	--服务器名称
--	--local mTip = arr[3]

    --加入可选游戏服务器
	LoginSer:addServerList(mLineID, mCurPlayerCount, mIP, mPort, mTip )
end

return Proc0xf001