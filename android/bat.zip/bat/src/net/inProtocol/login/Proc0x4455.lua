local Proc0x4455 = class("Proc0x4455")
local CharacterManager = require("characters.CharacterManager"):instance()

function Proc0x4455:ctor()

end
local socket = require "socket"

-- //[0x4455 %d][服务器时间 %d]   
function Proc0x4455:FromByteArray(msg)
    
--    local time = msg:readInt()
    SERVER_TIME = msg:readInt()
    SERVER_GET_TIME = socket.gettime() 
--os.time({day=17, month=5, year=2012, hour=0, minute=0, second=0}) -- 指定时间的时间戳
    print( "0x4455 "..SERVER_TIME.." "..os.date("%Y-%m-%d-%H",SERVER_TIME) )

    CharacterManager:setVipTime()
end

return Proc0x4455

