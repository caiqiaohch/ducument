local Proc0x1205 = class("Proc0x1205")

function Proc0x1205:ctor()

end

--通用信息提示
function Proc0x1205:FromByteArray(msg)
    local lineID = msg:readInt()

    local txtID = msg:readInt()
    local DataManager = require("data.DataManager"):instance()
    local str = DataManager:getStringDataTxt( txtID, true )
    local id = 1
	local mType,len,cont
    while msg:getAvailable() > 1 do
		local mType = msg:readByte()
				
		if mType == 115 then
		    len = msg:readInt()
		    cont = msg:readStringBytes( len )
            str = string.gsub(str,"$"..id, cont)
		    id = id + 1
		elseif mType == 100  then
			cont = msg:readInt()
            str = string.gsub(str,"$"..id, cont)
			id = id + 1
        end
    end
    print("1205 "..str)
    if txtID == 3049  then 
        if  FriendManager:isFriend(1,cont)==true then
--            require("prompt.PromptManager"):instance():SetNotice(str)]
            MainWindow:setFriendLoginMsg(cont)
        end
        return
    end
    if str == "" then 
        print("txtID"..txtID.." is nil ")
        return 
    end --str为空的时候不提示

    local txtType = nil
    local txtData = DataManager:getStringDataTxt( txtID )
    if txtData and txtData.NoticeType == 0 then
        txtType = 3
    end
     require("prompt.PromptManager"):instance():ShowByType( txtID, {str = str}, 1 )
--    require("prompt.PromptManager"):instance():SetNotice(str)
end

return Proc0x1205