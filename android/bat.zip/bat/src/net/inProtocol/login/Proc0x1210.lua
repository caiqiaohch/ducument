local Proc0x1210 = class("Proc0x1210")

function Proc0x1210:ctor()

end

function Proc0x1210:FromByteArray(msg)

----    --线号
--    local lineId = msg:readInt()
--    --类型
--	local channel = msg:readInt()
--    --玩家ID
--	local charID = msg:readInt()
--    --VIP等级
--	local vipLevel = msg:readInt()
--    --身价
--	local shenjia = msg:readInt()
    --内容
	local mContents = msg:readStringBytes(msg:getAvailable() - 1)
    print(mContents)
end

return Proc0x1210