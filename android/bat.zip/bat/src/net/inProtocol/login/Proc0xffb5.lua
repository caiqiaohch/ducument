local Proc0xffb5 = class("Proc0xffb5")

function Proc0xffb5:ctor()

end

function Proc0xffb5:FromByteArray(msg)

    local Crypt = require("net.Crypt")
    local LoginSer = require("net.LoginSer"):instance()

    local ecrypt = msg:readByte()
	local move = msg:readByte()
	move = move % 7 + 1
	encodeBA = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
    encodeBA:writeBytes( msg, msg:getPos(), msg:getAvailable() )
	key = Crypt:DecodeBA( encodeBA, false )
    if ecrypt == 0 then
        UseEcrypt = false
    else
        UseEcrypt = true
    end
	Crypt:setMsgKey( move, key )

    --如果是在没连接状态
    if LoginSer:getServerState() == 0 then
        LoginSer:setServerState( 1 )--设置为登录服状态
--        LoginWindow:autoLogin()
        LoginWindow:ShowNotice()
        return
    end

    --如果是在登陆服
     if LoginSer:getServerState() == 1 then
        LoginSer:setServerState( 2 )--设置为游戏服状态
        --发送进入场景的协议
        LoginSer:SendEnterGame()
        return
    end

end

return Proc0xffb5