local Proc0x1202 = class("Proc0x1202")

function Proc0x1202:ctor()

end

function Proc0x1202:FromByteArray(msg)

    --内容
	local mContents = msg:readStringBytes(msg:getAvailable() - 1)

--	require("prompt.PromptManager"):instance():SetNotice( mContents )
    print("后台输出:"..mContents)
end

return Proc0x1202