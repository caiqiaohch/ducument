local Proc0x2052 = class("Proc0x2052")

function Proc0x2052:ctor()

end

local isMain = false

--部队布置 源区域默认手牌,目标区域默认战场
--[0x2052][玩家ID %d][cardid %d][spos %c][dpos %c]
---------------------------------后台不发了--------------------------------
function Proc0x2052:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()
    local charId = msg:readInt()    
    local cardID = msg:readInt()
    local spos = msg:readByte()
    local dpos = msg:readByte()
    print( "2052  "..charId.." "..cardID.." "..spos.." "..dpos)    

    war2CardManager:addToBattlePhaseList({data = {charId, cardID, spos, dpos}, fun = self.process, dtime = 1})
end

function Proc0x2052:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardID = data[2]
    local spos = data[3]
    local dpos = data[4]
    dpos = war2CardManager:getBattleIndex( dpos )
        --删除手牌
    isMain = war2CardManager:isMainByID( charId )
    if isMain == true then
--        war2CardManager:addOrDelMainHandCard( spos, cardID, true )
--        war2FightScene:updateMainHand()
    end

    --战场卡牌布置
    --生成一张卡牌，由第一条命令决定，后续命令挂靠在此牌上
    local card = require("war2.war2Card").new()
    card:init( cardID )
    card.mIsMain = isMain
    card.mPos = dpos

    local cardType = card:getData().type
    --部队
    if cardType == 1 or cardType == 9 then
       war2FightScene:setFightCard( dpos, war2CardManager:addOrDelBattleCard( dpos, card ), true )
    --工事
    elseif cardType == 2 then
        war2CardManager:addOrDelBattleWorkCard( dpos, card, cardID )
        war2FightScene:setFightWorkCard( dpos, card )
    end

    if card.mIsMain == false then 
        war2FightScene:playUseCardEffect(spos, dpos)
    end
end

return Proc0x2052
