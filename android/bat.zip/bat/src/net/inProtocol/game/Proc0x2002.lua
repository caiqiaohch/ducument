local Proc0x2002 = class("Proc0x2002")

function Proc0x2002:ctor()

end
local war2CardManager = require("war2.war2CardManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()

--[0x2002 %d][玩家ID %d]  胜利方
function Proc0x2002:FromByteArray(msg)    
    local charId = msg:readInt()
    print( " 0x2002 "..charId)
    if war2CardManager.Bol2002 == true then return end
    war2CardManager.Bol2002 = true
    
    local char = CharacterManager:getPlayerByCharID( war2CardManager.mOtherID )
    if char and ( char.NPCID == 30 or char.NPCID == 42 or char.NPCID == 49 ) then
        local isMain = war2CardManager:isMainByID( charId )    --如果是玩家胜利了在播放特效前插入提示
        if isMain == true then
            war2CardManager:addToBattlePhaseList({data = {str = "ShowStoryTips", state = char.NPCID}, fun = NewbieWindow.setAndShowType, dtime = 0})  
        end
    end

    war2CardManager:addToBattlePhaseList({data = {charId}, fun = self.process, dtime = 0})
end

function Proc0x2002:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local isMain = war2CardManager:isMainByID( charId )        
    
    if isMain == true then --打败对方的瞬间，说话
        if NewbieManager.CurState == 3 then  --第三关处理
            war2FightScene:getCharMsgLayout():showTalkMsg( 1, 2097 )
        elseif NewbieManager.CurState ~= 2 then
            local txtId = math.random(3138,3140)
            war2FightScene:getCharMsgLayout():showTalkMsg( 1, txtId ) 
        end
    end 
    
    war2CardManager:setXianjiCardList( false )--清空临时保存的献祭卡组
    war2CardManager:endFightClear()
    NewbieManager.CurState = 0
    war2CardManager.curFightPlayerID = 0
    --对战结束界面
    war2FightScene:endFight(isMain)
end

return Proc0x2002