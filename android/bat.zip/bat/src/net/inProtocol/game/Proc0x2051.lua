local Proc0x2051 = class("Proc0x2051")
local war2CardManager = require("war2.war2CardManager"):instance()

function Proc0x2051:ctor()

end

--部队移动 源区域默认战场,目标区域默认战场
--[0x2051][spos %c][dpos %c]
function Proc0x2051:FromByteArray(msg)
    local spos = msg:readByte()
    local dpos = msg:readByte()
    print( "2051  "..spos.."  "..dpos)
    local interlink = nil
    if war2CardManager.State == 1 then interlink = 2051 end --在第一阶段才需要一起前进
    war2CardManager:addToBattlePhaseList({data = {spos, dpos}, fun = self.process, dtime = 0, interlink = interlink})
--    Proc0x2051:process({spos, dpos})
end

function Proc0x2051:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    spos = war2CardManager:getBattleIndex( data[1] )
    dpos = war2CardManager:getBattleIndex( data[2] )

    local card = war2CardManager:getBattleCard( spos )
    local cardData = card:getData()
    local _state = card.mState
    local _id = cardData.id
    local _isMain = card.mIsMain
    local _curAtk = cardData.curAtk
    local _curHealth = cardData.curHealth
    local _maxHealth = cardData.maxHealth
--    war2CardManager:addOrDelBattleCard( spos, 0 )
--    card = war2CardManager:addOrDelBattleCard( dpos, _id )
    card = war2CardManager:exchangeBattleCard(spos, dpos)
    card.mIsMain = _isMain
    card.mPos = dpos
    card.mState = _state
    card:getData().curAtk = _curAtk
    card:getData().curHealth = _curHealth
    card:getData().maxHealth = _maxHealth
--    war2FightScene:setFightCard( spos, nil )
--    war2FightScene:setFightCard( dpos, card )
    war2FightScene:playMoveEff( card, spos, dpos )
end


return Proc0x2051