local Proc0x2024 = class("Proc0x2024")

function Proc0x2024:ctor()

end

--[0x2024 %d][pos %c][护盾数值 %c]
--护盾/护甲值
function Proc0x2024:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()
    local pos = msg:readByte()
    local num = msg:readByte()
    print("2024 "..pos.." "..num)
    war2CardManager:addToBattlePhaseList({data = {pos,num}, fun = self.process, dtime = 0})
end

function Proc0x2024:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local pos = data[1]
    local num = data[2]

    pos = war2CardManager:getBattleIndex( pos )
    local card = war2CardManager:getBattleCard(pos)
    if card == nil then return end
    card.mDef = num
    war2FightScene:updateBattleDef( pos )
end

return Proc0x2024