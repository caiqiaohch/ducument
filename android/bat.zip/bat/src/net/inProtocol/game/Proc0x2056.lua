local Proc0x2056 = class("Proc0x2056")

local FightSceneShow = require "war2.FightSceneShow"
local war2CardManager = require("war2.war2CardManager"):instance()

local banIdList = {82, 333, 373, 458, 667} --磨牌库的牌, 要屏蔽其引发的弃牌效果 前提是这些牌要在法术堆叠区

function Proc0x2056:ctor()

end

--墓地删除/增加卡牌
--[0x2056][0墓地删除卡牌/1墓地增加卡牌 %c][玩家ID %d][cardid %d][sarea %c][objId %d]
function Proc0x2056:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()
    local mark = msg:readByte()
    local charId = msg:readInt()
    local cardID = msg:readInt()
    local sarea = msg:readByte()
    local objId = msg:readInt()
    war2CardManager:addToBattlePhaseList({data = {mark,charId, cardID, sarea, objId}, fun = self.process, dtime = 0})   
    print("2056 "..mark.." "..charId.." "..cardID.." "..sarea.." "..objId)
end

function Proc0x2056:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local mark = data[1]
    local charId = data[2]
    local cardID = data[3]
    local sarea = data[4]
    local objId = data[5]

    local isMain = war2CardManager:isMainByID( charId )
    local isAdd = mark == 1
    if isMain == true then
        war2CardManager:setCeneteryList( isAdd, cardID, objId )
        war2FightScene:updateMainCeneteryNum()
    else
        war2CardManager:setOtherCeneteryList( isAdd, cardID, objId )
        war2FightScene:updateOtherCeneteryNum()
    end

    if war2CardManager.CurPlayingCardId == cardID and sarea == WAR2_AREA_TYPE_SHOUPAI then
        war2CardManager.CurPlayingCardId = 0
        if war2CardManager.CurPlayingShiXiao == cardID then            
            war2CardManager.CurPlayingShiXiao = 0
        end
        if war2CardManager.CurPlayingShiXiao ~= 0 then
            FightSceneShow.playShixiaoCardEffect( cardID, isMain )
        end
        return
    elseif war2CardManager.CurPlayingShiXiao == cardID and sarea == WAR2_AREA_TYPE_SHOUPAI then
        war2CardManager.CurPlayingShiXiao = 0
        return         
    end

    if sarea == WAR2_AREA_TYPE_SHOUPAI or sarea == WAR2_AREA_TYPE_PAIKU then  --1手牌 2牌库  播放破碎效果
        if table.indexof(banIdList, war2CardManager.CurPlayingCardId) == false then
            FightSceneShow.playCenCardEffect( isMain, sarea, cardID )   
        end
        if sarea == WAR2_AREA_TYPE_SHOUPAI then
            local cardData = DataManager:getCardObjByID( cardID, true )
            if cardData and cardData.type == JIEJIE_KA then
                if isMain == true then
                    war2CardManager:getMainTacTicCard( cardID, -1, true )   
                    war2FightScene:updateMainTactic()
                else
                    war2CardManager:getOtherTacTicCard( cardID, -1, true )
                    war2FightScene:updateOtherTactic()
                end
            end
        end
--        if war2CardManager.CurPlayingCardId == cardID then war2CardManager.CurPlayingCardId = 0 end
    end
end

return Proc0x2056