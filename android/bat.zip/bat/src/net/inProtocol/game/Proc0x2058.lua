local Proc0x2058 = class("Proc0x2058")


function Proc0x2058:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()
local SkillManager = require("skill.SkillManager"):instance()

--farg属于这几个类型的,不用处理
local ignoreList = {}--{6, 8, 10, 11}


--战斗阶段技能协议 (源区域默认战场)
--[0x2058 %d][玩家ID %d][cardid %d][技能编号 %d][sarea %c][spos %c][目标区域 %c][dpos %s] 
--0战术区 1手牌 2牌库 3墓地 5对方指挥部 6自己指挥部 7战场 8消失
--dpos 25对手玩家 26自己
function Proc0x2058:FromByteArray(msg)
    local charId = msg:readInt()
    local cardID = msg:readInt()
    local skillID = msg:readInt()
    local sarea = msg:readByte()
    local spos = msg:readByte()
    local darea = msg:readByte()
    
    local dpos
    local dposArr = {}
    local len = msg:getAvailable()
    for i = 1, len do
        dpos = msg:readByte()
        if dpos ~= 0 then
            table.insert(dposArr, dpos)
        end
    end
    

    local skillData = SkillManager:getSkillData( skillID )
    if skillData == nil or table.indexof(ignoreList, skillData.ftarget) ~= false then 
        print("2058 "..charId.." "..cardID.."  "..skillID.." "..sarea.." "..spos.." "..darea.."  不处理") 
        return 
    end
    local dtime  = 0
    if tonumber(skillData.effect_id) ~= 0 then 
        dtime = 1
    end

    --这里是单纯为了打印信息
    dpos = dposArr[1]
    if dpos == nil then dpos = 0 end
    print("2058 "..charId.." "..cardID.."  "..skillID.." "..sarea.." "..spos.." "..darea.."  "..dpos.." "..len) 
    --这里是单纯为了打印信息

--    war2CardManager:addToBattlePhaseList({data = {charId, cardID, skillID, sarea, spos, darea, dposArr}, fun = self.process, dtime = dtime})

    self:handle( {charId, cardID, skillID, sarea, spos, darea, dposArr} )  ---修改后不进入堆栈,直接处理
end

function Proc0x2058:handle(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardID = data[2]
    local skillID = data[3]
    local sarea = data[4]
    local spos = data[5]
    local darea = data[6]
    local dposArr = data[7]

    local roundNum = 1 --持续时间,暂时没用到,写死为1先
    local isMain = war2CardManager:isMainByID( charId )

    ---25对手玩家 26自己
    if isMain == false then  --把非主角时的玩家类型转换过来
        if spos == 25 then 
            spos = 26
        elseif spos == 26 then
            spos = 25
        end
    end
    if spos == 25 then sarea  = WAR2_AREA_TYPE_ENEMY 
    elseif spos == 26 then sarea  = WAR2_AREA_TYPE_MAIN end

    for i = 1, #dposArr do
        dpos = dposArr[i]
        print( "dddp "..dpos)
        if isMain == false then
            if dposArr[i] == 25 then 
                dposArr[i] = 26
            elseif dposArr[i] == 26 then
                dposArr[i] = 25
            end
        end
--        if dpos == 25 then darea = WAR2_AREA_TYPE_ENEMY
--        elseif dpos == 26 then darea  = WAR2_AREA_TYPE_MAIN end
        --战场位置
        if darea == WAR2_AREA_TYPE_ZHANCHANG and dpos > 0 and dpos <= 18 then dposArr[i] = war2CardManager:getBattleIndex( dpos ) end
    end
    

    if sarea == WAR2_AREA_TYPE_ZHANCHANG then spos = war2CardManager:getBattleIndex( spos ) end 
    
    obj = { cardID = cardID, skillID = skillID, roundNum = roundNum, sarea = sarea, spos = spos, darea = darea, dposArr = dposArr, isMain = isMain }
    obj.net = 2058

    local oldObj = SkillManager:getWarSkillByIdx()
    if oldObj and oldObj.cardID == cardID and oldObj.skillID == skillID and (war2CardManager:getBolGettingSkill() == true or oldObj.net == 2050) then   --这种情况覆盖之前的2050技能数据,否则创造一条新数据
        SkillManager:addToWarSkillList( obj )
    else
        SkillManager:setWarSkillIdx()
        idx = SkillManager:getWarSkillIdx()
        SkillManager:addToWarSkillList( obj )
        war2CardManager:addToBattlePhaseList({data = {idx}, fun = self.process, dtime = 0.8})
    end
end

function Proc0x2058:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local idx = data[1]
    SkillManager:playWarSkillEffect(idx)
end
   
return Proc0x2058