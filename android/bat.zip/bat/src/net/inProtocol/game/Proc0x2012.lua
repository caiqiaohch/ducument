local Proc0x2012 = class("Proc0x2012")

function Proc0x2012:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()
local warAi =  require("war2.warAi"):instance()

--[0x2012][玩家ID %d][当前资源 %c]  // 时时更新
function Proc0x2012:FromByteArray(msg)

    local charId = msg:readInt()
    --回合状态 
    local res = msg:readByte()
    print( "2012 "..charId.." "..res)
    war2CardManager:addToBattlePhaseList({data = {charId, res}, fun = self.process, dtime = 0})    
end

function Proc0x2012:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local res = data[2]

    local isMain = war2CardManager:isMainByID(charId)
    
    if war2CardManager.isPlaying == true then
        if isMain == true then 
            local oldRes = war2CardManager.mMainCandUseRes
            war2CardManager.mMainCandUseRes = res
            war2FightScene:updateMainRes(oldRes, res)
        else 
            local oldRes = war2CardManager.mOtherCandUseRes
            war2CardManager.mOtherCandUseRes = res
            war2FightScene:updateOtherRes(oldRes, res)            
        end
    end
   
end

return Proc0x2012