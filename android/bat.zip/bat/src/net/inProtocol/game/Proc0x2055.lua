local Proc0x2055 = class("Proc0x2055")

function Proc0x2055:ctor()

end

--抽牌
--[0x2055][玩家ID %d][cardid %d][spos %c][objId %d][sarea %c][fpos %c]
function Proc0x2055:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()
    if war2CardManager.ShowState == 0 then 
        print( "2055 ")
        return 
    end
    local charId = msg:readInt()
    local cardID = msg:readInt()
    local spos = msg:readByte()
    local objId = msg:readInt()
    local sarea = 0
    local fpos = 0
    
    if msg:getAvailable() > 0 then
        sarea = msg:readByte()
    end

    if msg:getAvailable() > 0 then
        fpos = msg:readByte()
    end

    war2CardManager:addToBattlePhaseList({data = {charId, cardID, spos, objId, sarea, fpos}, fun = self.process, dtime = 0}) 

    print( "2055 "..charId.." "..cardID.."  "..spos.."  "..objId.."  "..sarea.." "..fpos)
--    self:process({charId, cardID, spos})
end

function Proc0x2055:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardID = data[2]
    local spos = data[3]
    local objId = data[4]
    local sarea = data[5]
    local fpos = data[6]
    local isMain = war2CardManager:isMainByID( charId )
    if isMain == true and cardID == 0 then
        print( "己方手牌ID收到0" )
        return
    end
    fpos = war2CardManager:getBattleIndex( fpos )
    local showPos = 0
    if isMain == true then
        war2CardManager:addOrDelMainHandCard( spos, cardID, objId )
        showPos = #war2CardManager:getMainHandCardList()
    else
        war2CardManager:addOrDelOtherHandCard( spos, cardID, objId )
        war2CardManager.mOtherHandNum =  war2CardManager.mOtherHandNum + 1
        showPos = #war2CardManager.mOtherHandCardList-- war2CardManager.mOtherHandNum
    end

    if sarea == WAR2_AREA_TYPE_PAIKU then
        local skillObj = SkillManager:getActSkillObj( war2CardManager.CurPlayingCardId )
        if skillObj and table.indexof( skillObj.skillData.fargIdArr, 4 ) ~= false then  
            for i = 1, #skillObj.skillData.fargArr do
                if skillObj.skillData.fargArr[i].fargId == 4 and skillObj.skillData.fargArr[i].fargValue == 10 then
                    sarea = WAR2_AREA_TYPE_ENY_PAIKU  --有抽取对方牌库效果的卡牌下牌库区域应该是对方的牌库
                end
            end 
        end
    end
    
    war2FightScene:DrawCard( isMain, showPos, sarea, fpos )
end

return Proc0x2055