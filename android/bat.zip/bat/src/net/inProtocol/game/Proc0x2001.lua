local Proc0x2001 = class("Proc0x2001")

function Proc0x2001:ctor()

end

--[0x2001 %d][%d 角色ID] 0从上而下从左向右索引递增,1从下向上从右向左递增
--收到0的排列:
--1  2  3  4  5  6
--7  8  9  10 11 12
--13 14 15 16 17 18
--收到1的排列:
--18 17 16 15 14 13
--12 11 10 9 8 7 
--6 5 4 3 2 1
function Proc0x2001:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()
    local id  = msg:readInt()
    print( "2001 "..id)
    local isMain = war2CardManager:isMainByID( id )
--    --位置索引标识
--    local sign = msg:readByte()
    war2CardManager.CurFightSign = isMain
--    if isMain == true then
--        war2CardManager.CurFightSign = false
--    else
--        war2CardManager.CurFightSign = true
--    end
end

return Proc0x2001