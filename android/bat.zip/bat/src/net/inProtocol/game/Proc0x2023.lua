local Proc0x2023 = class("Proc0x2023")

function Proc0x2023:ctor()

end

--[0x2023 %d][pos %c][状态 %c][数值 %c][回合数 %d]
--状态参考技能表的farg属性栏
function Proc0x2023:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()
    local pos = msg:readByte()
    local farg = msg:readByte()
    local num = msg:readByte()
    local roundNum = msg:readInt()
    print("2023 "..pos.." "..farg.." "..num.." "..roundNum)
    war2CardManager:addToBattlePhaseList({data = {pos,farg,num,roundNum}, fun = self.process, dtime = 0})
end

function Proc0x2023:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local pos = data[1]
    local farg = data[2]
    local num = data[3]
    local roundNum = data[4]
    
    local bolAdd = roundNum ~= 0

    if war2CardManager.CurFightSign == false then
        if pos == 101 then pos = 102 
        elseif pos == 102 then pos = 101
        end
    end
    if pos == 101 then  --目标是己方玩家        
        war2CharMsgLayout:playHeadBoxEff( true, farg, bolAdd )
    elseif pos == 102 then --目标是对方玩家
        war2CharMsgLayout:playHeadBoxEff( false, farg, bolAdd )
    end

    pos = war2CardManager:getBattleIndex( pos )
    local card = war2CardManager:getBattleCard(pos)
    if card == nil then return end

    local obj = {farg = farg, num = num, roundNum = roundNum }
    card:addFargList(obj)

    if war2CardManager.isPlaying == true then
        if farg == 39 then
            SkillManager:updateHaloSkill()
            war2FightScene:updateBattleMov( card.mPos )
            war2FightScene:updateBattleDef( card.mPos )
        end      

        if farg == 28 then 
            war2FightScene:updateBattleMov( pos )
        end   

        local cardBatter = war2FightScene:getBattleCard(card.mPos)
        cardBatter:updateSkillIcon()
    end
    
end

return Proc0x2023