local Proc0x2042 = class("Proc0x2042")

function Proc0x2042:ctor()

end
local war2CardManager = require("war2.war2CardManager"):instance()
--[0x2042][断线重连开始与结束标记 c%]
function Proc0x2042:FromByteArray(msg)    
    local sign = msg:readByte()    
    print( "2042 "..sign)
    if sign == 1 then
        war2CardManager:addToBattlePhaseList({data = {sign}, fun = self.process, dtime = 0})
    else
        self:process({sign})--在初始化前进入下面的会被清空
    end
end

function Proc0x2042:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local sign = data[1]
    if sign == 0 then 
        war2CardManager:setReConnect()
    else
        war2CardManager:initReConnect()
        --计算光环类技能
        SkillManager:updateHaloSkill()
    end    
end

return Proc0x2042