local Proc0x2045 = class("Proc0x2045")

function Proc0x2045:ctor()

end
local CharacterManager = require("characters.CharacterManager"):instance()

--[0x2045][退出观战 d%]
function Proc0x2045:FromByteArray(msg)    
    local sign = msg:readInt()    
    print( "2045 "..sign)
    local char = CharacterManager:getMainPlayer()
    char.ForbidWatch = sign
    if MainSetWindow.isShow == true then
        MainSetWindow:updateAllowWatch()
    end
end

return Proc0x2045