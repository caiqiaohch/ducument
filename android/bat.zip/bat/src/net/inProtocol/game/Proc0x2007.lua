local Proc0x2007 = class("Proc0x2007")

function Proc0x2007:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()
local socket = require "socket"

-- //[0x2007 %d][回合状态时间 %d]   
function Proc0x2007:FromByteArray(msg)
    
    local time = msg:readInt()
    local endTimes = 0
    if war2CardManager.isPlaying == true and ( war2CardManager.State == 2 or war2CardManager.State == 3 ) and time > 16 then
--        endTimes = os.time()
--        if endTimes < 0 then
--            endTimes = socket.gettime()
--        end
        endTimes = socket.gettime()
--        time = 30
        endTimes = endTimes + time
        print( endTimes )
        war2CardManager:setEndTurnTimes( endTimes, time )
    else
        war2CardManager:setEndTurnTimes(0)
--        war2FightScene:setEndTurnEff( false )  --不需要倒计时的情况,直接把可能显示的特效跟正在的倒计时都去掉     
    end
    print( "0x2007 "..time.." "..war2CardManager.State)
end

return Proc0x2007
--region *.lua
--Date
--此文件由[BabeLua]插件自动生成



--endregion
