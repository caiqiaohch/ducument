local Proc0x2041 = class("Proc0x2041")

function Proc0x2041:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()
local FightSceneShow = require "war2.FightSceneShow"


--[0x2041][玩家ID %d][手牌 %s] // 手牌 位置默认1开始 "110011,100016,110000,410000,100017,110003,410001,0,0,0#345,372,369,368,348,378,364,0,0,0"
function Proc0x2041:FromByteArray(msg)  
    local charId = msg:readInt()
    local str = msg:readStringBytes(msg:getAvailable() - 1)
    if war2CardManager:getBolBattlePhase() == true then
        war2CardManager:addToBattlePhaseList({data = {charId, str}, fun = self.process, dtime = 0})
    else
        self:process({charId, str})--在初始化前进入下面的会被清空
    end
    print(" 2041 "..charId.." "..str)
--    war2CardManager:addToBattlePhaseList({data = {str}, fun = self.process, dtime = 0})
end

function Proc0x2041:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local str = data[2]
    local tempArr = string.split( str, "#" )

    local arr = string.split( tempArr[1], "," )
    local arr2 = string.split( tempArr[2], "," )
    local debugStr = ""
    local debugStr2 = ""
    local len = #arr
    local temp = {}
    for i=1,len do
        if tonumber(arr[i]) ~= 0 then
            temp[#temp+1] = { id = tonumber(arr[i]), pos = #temp+1, objId = tonumber(arr2[i]) }
        end
        debugStr = debugStr.." "..tonumber(arr[i])
    end

    local isMain = war2CardManager:isMainByID( charId )
    if isMain == true then        
        war2CardManager.mMainHandCardList = {}
        local arrold = war2CardManager:getMainHandCardList()
        for i=1,#arrold do
            debugStr2 = debugStr2.." "..arrold[i].id
        end
        print(" 2041 "..debugStr)
        print(" 2041  原"..debugStr2)
--        war2CardManager:resAllMainHandCard( temp )
        for i = 1, #temp do
            war2CardManager:addOrDelMainHandCard( temp[i].pos, temp[i].id, temp[i].objId )
        end

        if war2CardManager.isPlaying == true then
            war2FightScene:updateMainHand()
        end
    else
--        war2CardManager:resAllOtherHandCard( temp )
        war2CardManager.mOtherHandCardList = {}
        for i = 1, #temp do
            war2CardManager:addOrDelOtherHandCard( temp[i].pos, temp[i].id, temp[i].objId )
        end
        war2CardManager.mOtherHandNum = #temp
        if war2CardManager.isPlaying == true then
            war2FightScene:updateOtherHandNum()
        end
        if war2CardManager.BolGetOtherHand == false then
            war2CardManager.BolGetOtherHand = true
        else
            war2CardManager.BolGetOtherHand = false
        end
    end

    if isMain == true and (war2CardManager.ShowState == 0 or NewbieManager.CurState == 3) and war2CardManager.Bol2041 == false and war2CardManager.isPlaying == true then --如果是表示准备阶段更换手牌完毕
        war2CardManager.Bol2041 = true
        war2FightScene:getXianJiLayout():playReplaceHandEffect()
    end

    if isMain == false and war2CardManager.ShowState == 0 and war2CardManager.BolGetOtherHand == true and war2CardManager.isPlaying == true then --如果是表示准备阶段更换手牌完毕
        FightSceneShow.playOtherChangeHandEffect()
    end
   
end

return Proc0x2041