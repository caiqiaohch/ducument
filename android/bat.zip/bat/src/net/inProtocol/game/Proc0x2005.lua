local Proc0x2005 = class("Proc0x2005")

function Proc0x2005:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()

--[0x2005 %d][玩家ID %d][回合数 %c]  本轮攻击方
function Proc0x2005:FromByteArray(msg)
    local charId = msg:readInt()
    local turn = msg:readByte()     
    
    local isMain = war2CardManager:isMainByID(charId)
    war2CardManager.isMainPhase = isMain 
    print( "0x2005 "..charId.." "..turn )
    if war2CardManager.ShowState ~= 0 then --是否已经初始化
        war2CardManager:addToBattlePhaseList({data = {charId, turn}, fun = self.process, dtime = 0}, 1)
    else
        self:process({charId, turn})--在初始化前进入下面的会被清空
    end
    
end

function Proc0x2005:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local turn = data[2]

    war2CardManager.TurnNum = turn

    local isMain = war2CardManager:isMainByID(charId)
    war2CardManager.isAtk = isMain
    
    print( "0x2005 process"..charId )

    --战斗部署的时候开启NPCAI计时
    if war2CardManager.mOtherID == 1 then
        warAi:setAiTimer(true)
    end
    if war2FightScene.isShow == true then
        war2FightScene:setTurnNum()   
    end    
--    if war2CardManager:getBolBattlePhase() == true then --是否开启战斗序列的处理
--        NewbieManager:updateByTurnNum()  
--    end
    
end

return Proc0x2005