local Proc0x2013 = class("Proc0x2013")

function Proc0x2013:ctor()

end

--[0x2013][玩家ID %d][手牌数量 %c]  // 时时更新
function Proc0x2013:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()
    local charId = msg:readInt()
    local num = msg:readByte()
    local isMain = war2CardManager:isMainByID( charId )
    if isMain == true then return end
    print( "2013 "..charId.."  "..num)
    war2CardManager:addToBattlePhaseList({data = {charId, num}, fun = self.process, dtime = 0})    
end

function Proc0x2013:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local num = data[2]
    war2CardManager.mOtherHandNum = num 
    if war2CardManager.isPlaying == true then
        war2FightScene:updateOtherHandNum()
    end
end

return Proc0x2013