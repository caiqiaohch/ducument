local Proc0x2011 = class("Proc0x2011")

function Proc0x2011:ctor()

end

--[0x2011][玩家ID %d][当前血量 %d]  // 时时更新
function Proc0x2011:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()

    local charId = msg:readInt()
    local hp = msg:readInt()
    print("2011 "..charId.." "..hp)
    war2CardManager:addToBattlePhaseList({data = {charId, hp}, fun = self.process, dtime = 0})
end

function Proc0x2011:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local hp = data[2]
    if hp < 0 then hp = 0 end
    local isMain = war2CardManager:isMainByID(charId)
    if isMain == true then 
        local tempHp = war2CardManager.mMainCurHp
        war2CardManager.mMainCurHp = hp
        if tempHp == 0 then
            war2FightScene:updateMainHp()
        else
            war2FightScene:updateMainHp( tempHp - hp )
        end
    else 
        local tempHp = war2CardManager.mOtherCurHp
        war2CardManager.mOtherCurHp = hp 
        if tempHp == 0 then
            war2FightScene:updateOtherHp()
        else
            war2FightScene:updateOtherHp( tempHp - hp )
        end
    end
end

return Proc0x2011