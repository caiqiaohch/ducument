local Proc0x2003 = class("Proc0x2003")

function Proc0x2003:ctor()

end

--[0x2003 %d][玩家ID %d] 等待对方响应 //一方确认完,等另一方响应的时候用
function Proc0x2003:FromByteArray(msg)

    
end

return Proc0x2003