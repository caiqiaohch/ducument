local Proc0x2070 = class("Proc0x2070")

function Proc0x2070:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()

--墓地卡牌
--[0x2070][id%d][%d 卡牌ID 1]...[][%d 卡牌ID N]
function Proc0x2070:FromByteArray(msg)    
    local charId = msg:readInt()

    local cardId
    local objId
    local cardIdArr = {}
    local str = ""
    while msg:getAvailable() >= 4 do
        cardId = msg:readInt()
        objId = msg:readInt()
        if cardId ~= 0 then
            table.insert(cardIdArr, {id = cardId, objId = objId})
        end
        str = str.." "..cardId.." "..objId
    end
    war2CardManager:addToBattlePhaseList({data = {charId, cardIdArr}, fun = self.process, dtime = 0})   
    print("2070 "..charId.." "..str)
end

function Proc0x2070:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardIdArr = data[2]

    local isMain = war2CardManager:isMainByID( charId )    
    local cardId
    local objId
    if isMain == true then        
        for i = 1, #cardIdArr do
            cardId = cardIdArr[i].id
            objId = cardIdArr[i].objId
            war2CardManager:setCeneteryList( true, cardId, objId )
            war2FightScene:updateMainCeneteryNum()
        end
        
    else
        for i = 1, #cardIdArr do
            cardId = cardIdArr[i].id
            objId = cardIdArr[i].objId
            war2CardManager:setOtherCeneteryList( true, cardId, objId )
            war2FightScene:updateOtherCeneteryNum()
        end
    end
end

return Proc0x2070