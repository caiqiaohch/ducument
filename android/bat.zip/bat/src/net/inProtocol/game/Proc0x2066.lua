local Proc0x2066 = class("Proc0x2066")

function Proc0x2066:ctor()

end

--删除手牌
--[0x2066][charID %d][cardID %d][pos %c][objId %d]  玩家ID, 卡ID, pos:手牌位置 objId:卡牌对象ID
function Proc0x2066:FromByteArray(msg)    
    local war2CardManager = require("war2.war2CardManager"):instance()
    local charID = msg:readInt()
    local cardID = msg:readInt()
    local pos = msg:readByte()   
    local objId = msg:readInt()
    print( "2066 "..charID.." "..cardID.." "..pos.." "..objId)
    war2CardManager:addToBattlePhaseList({data = {charID, cardID, pos, objId}, fun = self.process, dtime = 0})    
end

function Proc0x2066:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charID = data[1]
    local cardID = data[2]
    local pos = data[3]   
    local objId = data[4]
    local isMain = war2CardManager:isMainByID( charID )
    if isMain then
        war2CardManager:addOrDelMainHandCard( pos, cardID, objId, true )
        war2FightScene:getCardListMiddle():clearObjHide()
        war2FightScene:updateMainHand()
    else
        war2CardManager:addOrDelOtherHandCard( pos, cardID, objId, true )
        war2FightScene:updateOtherHandNum()
    end
end

return Proc0x2066
