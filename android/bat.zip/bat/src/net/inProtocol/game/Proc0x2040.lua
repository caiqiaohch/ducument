local Proc0x2040 = class("Proc0x2040")

function Proc0x2040:ctor()

end

--结界放置 源区域默认手牌,目标区域默认战场
--[0x2040][玩家ID %d][cardid %d][dpos %c][sarea %c]//结界放置

local war2CardManager = require("war2.war2CardManager"):instance()


function Proc0x2040:FromByteArray(msg)    
    local charId = msg:readInt()
    local cardID = msg:readInt()
    local dpos = msg:readByte()

    local sarea = 0
    if msg:getAvailable() > 0 then
        sarea = msg:readByte()
    end
    print( "2040  "..charId.." "..cardID.." "..dpos.." "..sarea)

    war2CardManager:addToBattlePhaseList({data = {charId, cardID, dpos, sarea}, fun = self.process, dtime = 1})
end

function Proc0x2040:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardID = data[2]
    local dpos = data[3]
    local sarea = data[4]
    dpos = war2CardManager:getBattleIndex( dpos )
    
    --战场卡牌布置
    --生成一张卡牌，由第一条命令决定，后续命令挂靠在此牌上
    local card = require("war2.war2Card").new()
    card:init( cardID )
    local isMain = war2CardManager:isMainByID( charId )
    card.mIsMain = isMain
    card.mPos = dpos

    war2CardManager:addOrDelBattleWorkCard( dpos, card, cardID )
        
    --详细说明看2059
    local cardData = nil
    if isMain == true then
        cardData = war2CardManager:getMainTacTicCard( cardID, -1, true )
        if cardData ~= nil then
            war2FightScene:updateMainTactic()
        end
    else
        cardData = war2CardManager:getOtherTacTicCard( cardID, -1, true )
        if cardData ~= nil then
            war2FightScene:updateOtherTactic()
        end
    end

    if war2CardManager.BolReConnect == false and cardData then --如果不是断线重连状态跟攻击且在堆叠区则需要播放特效
        war2FightScene:playWorkCardEffect( dpos, card, isMain )
    else
        war2FightScene:setFightWorkCard( dpos, card )
    end
end

return Proc0x2040
