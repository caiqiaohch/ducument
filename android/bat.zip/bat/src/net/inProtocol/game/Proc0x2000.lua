local Proc0x2000 = class("Proc0x2000")

function Proc0x2000:ctor()

end

local CharacterManager = require("characters.CharacterManager"):instance()
local war2CardManager = require("war2.war2CardManager"):instance()
local DataManager = require("data.DataManager"):instance()
local warAi =  require("war2.warAi"):instance()
local NewbieManager = require("prompt.NewbieManager"):instance()

local isFirst = true
--[0x2000][玩家ID %d][天梯积分(荣誉值) %d][npcId(不是则发0) %d][战斗类型 %c][对方信息 %s]   // 进场发送,用于初始化
--格式:对手id#对手最大血量#对手最大资源#指挥官1#指挥官2#指挥官3#对手姓名#对手所用牌组名
----- 战斗类型 1手牌 2牌库 3墓地 4圣物 5对方指挥部 6自己指挥部 7战场 8消失
function Proc0x2000:FromByteArray(msg)
    --清理战场数据
    if isFirst == true then
        war2CardManager:endFightClear()
        warAi:endFightClear()
    end
    isFirst = isFirst == false

    war2CardManager.isPlaying = false
    local isMain = war2CardManager:isMainByID( msg:readInt() )
    local honour = msg:readInt()
    local npcId = msg:readInt()
    local wartype = msg:readByte()
    local str = msg:readStringBytes(msg:getAvailable() - 1)
    local arr = string.split( str, "#" )
    print( "0x2000 "..honour.." "..npcId.." "..wartype.." "..str)
    --创建角色对象
    if isMain == true then--自己
        local char
         
        if war2CardManager:isWatching() == true then --如果是在观战
            char = CharacterManager:createPlayer( tonumber(arr[1]), false )
        else
            char = CharacterManager:createPlayer( tonumber(arr[1]), true )
        end
        char.Name = arr[7]
        char.CharHonour = honour
        char.NPCID = npcId
--        arr[4] = 10001 arr[5] = 10001 arr[6] = 10001
        war2CardManager.mMainCurHp = tonumber(arr[2])
        war2CardManager.mMainResource = tonumber(arr[3])
        war2CardManager.mMainCandUseRes = tonumber(arr[3])
        war2CardManager:initMainEq( 1, tonumber(arr[4]) )
        war2CardManager:initMainEq( 2, tonumber(arr[5]) )
        war2CardManager:initMainEq( 3, tonumber(arr[6]) )

        local deckArr = string.split( arr[8], "$" )
        if deckArr[2] == nil or tonumber(deckArr[2]) == 0 then
            char.headId = 1
        else    
            char.headId = tonumber(deckArr[2])
        end
        ----------------战斗开始前初始化,为战斗结束界面做准备----------------
        char.OldCharLevel = char.CharLevel
        char.OldCharExp = char.CharExp
        char.OldCharHonour =  char.CharHonour
        ----------------战斗开始前初始化,为战斗结束界面做准备----------------
    else
        local char = CharacterManager:createPlayer( tonumber(arr[1]), false )
        char.Name = arr[7]
        char.CharHonour = honour
        char.NPCID = npcId
        war2CardManager.mOtherNpcId = npcId
--        arr[4] = 10001 arr[5] = 10001 arr[6] = 10001
        war2CardManager.mOtherCurHp = tonumber(arr[2])
        war2CardManager.mOtherResource = tonumber(arr[3])
        war2CardManager.mOtherCandUseRes = tonumber(arr[3])
        war2CardManager:initOtherEq( 1, tonumber(arr[4]) )
        war2CardManager:initOtherEq( 2, tonumber(arr[5]) )
        war2CardManager:initOtherEq( 3, tonumber(arr[6]) )

        war2CardManager.mOtherID = tonumber(arr[1])

        war2CardManager.WarType = wartype
        --char.Name
        FriendWnd.curFriendName = arr[7]

        if char.NPCID > 0 then
            local npcObj = DataManager:getDataMapNpcbyDi(char.NPCID)
            if npcObj then
                char.Name = npcObj.npc_name
                char.headId = npcObj.npc_icon
                if npcObj.player_face > 0 then
                    CharacterManager:getMainPlayer().headId = npcObj.player_face
                end
                if npcObj.player_face > 0 then --如果是在观战
                    if npcObj.npc_camp >= 100 and npcObj.npc_camp < 200 and war2CardManager:isWatching() == false then
                        war2CardManager.WarType = WAR2_TYPE_PUZZLE
                    end                    
                end 
            end  
        else
            local deckArr = string.split( arr[8], "$" )
            if deckArr[2] == nil or tonumber(deckArr[2]) == 0 then
                char.headId = 1
            else    
                char.headId = tonumber(deckArr[2])
            end          
        end
    end
    if war2CardManager:isWatching() == true then --如果是在观战
        war2CardManager.WarType = WAR2_TYPE_WATCH
    end 
    war2CardManager.Bol2002 = false
    war2CardManager.Bol2041 = true
    war2CardManager.BolGetOtherHand = nil

    if isMain == false then
        war2CardManager:setXianjiCardList( true )--读取临时保存的献祭卡组

        if npcId == 0 then
            NewbieManager.CurState = 1000
        else
            NewbieManager.CurState = npcId
        end
        if NewbieManager.CurState < 5 then  --是新手流程的时候
            if war2CardManager.BolReConnect == false then
                NewbieManager:resetData(npcId)
            end
        end
    end

--    Network:SetBolPrintMsg(true)
end

return Proc0x2000