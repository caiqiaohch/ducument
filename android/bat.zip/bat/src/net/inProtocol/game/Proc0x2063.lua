local Proc0x2063 = class("Proc0x2063")

local FightSceneShow = require "war2.FightSceneShow"
local war2CardManager = require("war2.war2CardManager"):instance()

function Proc0x2063:ctor()

end

--放置生物
--[0x2063][玩家ID %d][cardid %d][dpos %c][sarea %c][spos %c]
function Proc0x2063:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()

    local charId = msg:readInt()
    local cardID = msg:readInt()
    local dpos = msg:readByte()
    local sarea = 0
    local spos = 0
    if msg:getAvailable() > 0 then
        sarea = msg:readByte()
    end
    if msg:getAvailable() > 0 then
        spos = msg:readByte()
    end
    print( "2063 "..charId.." "..cardID.." "..dpos.." "..sarea.." "..spos) 
    if sarea == 7 then return end --战场移动的不在这里执行
    local cardData = DataManager:getCardObjByID( cardID, true )
    if cardData and cardData.type ~= 1 and cardData.type ~= 9 then return end
    local dtime = 0
    if sarea == 1 then dtime = 0.5 end
    war2CardManager:addToBattlePhaseList({data = {charId, cardID, dpos, sarea, spos}, fun = self.process, dtime = dtime})    
end

function Proc0x2063:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardID = data[2]
    local dpos = data[3]
    local sarea = data[4]
    local spos = data[5]
    dpos = war2CardManager:getBattleIndex( dpos )
    local isMain = war2CardManager:isMainByID( charId )
    --战场卡牌布置
    --生成一张卡牌，由第一条命令决定，后续命令挂靠在此牌上
    local card = require("war2.war2Card").new()
    card:init( cardID )
    card.mIsMain = isMain
    card.mPos = dpos

    local bolBack = false --是否要显示背面及背面特效
    if war2CardManager.ReConBackList[dpos] == 1 then --在2059传入的有该位置的牌,则是盖牌
        bolBack = true
    end

    --衍生物
    if card:getData().type == SHENGWU_KA then
        if sarea == 1 then
            war2FightScene:setFightCard( dpos, war2CardManager:addOrDelBattleCard( dpos, card ), true )
            if isMain == true and war2CardManager:isWatching() == true then
                FightSceneShow.playUseTrEffectOther( spos, dpos, 1 )
            elseif card.mIsMain == false then 
                war2FightScene:playUseCardEffect(spos, dpos)
            end
        elseif sarea == 2 or sarea == 3 then  --3墓地 
            FightSceneShow.playSceneEffect( isMain, sarea, dpos, function () war2FightScene:setFightCard( dpos, war2CardManager:getBattleCard( dpos ), bolBack, false, bolBack ) end )   
            war2CardManager:addOrDelBattleCard( dpos, card )
--            require("framework.scheduler").performWithDelayGlobal( function () war2FightScene:setFightCard( dpos, war2CardManager:getBattleCard( dpos ), bolBack, false, bolBack ) end, 1 )
        else
            war2FightScene:setFightCard( dpos, war2CardManager:addOrDelBattleCard( dpos, card ), bolBack, false, bolBack )
        end
    end    
end

return Proc0x2063
