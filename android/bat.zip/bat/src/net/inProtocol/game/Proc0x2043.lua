local Proc0x2043 = class("Proc0x2043")
local war2CardManager = require("war2.war2CardManager"):instance()

function Proc0x2043:ctor()

end
--[0x2043][观战角色ID d%]
function Proc0x2043:FromByteArray(msg)    
    local charId = msg:readInt()    
    print( "2043 "..charId)
    war2CardManager.curFightPlayerID = charId


end


return Proc0x2043