local Proc0x2061 = class("Proc0x2061")

function Proc0x2061:ctor()

end

--受击方缓存，对方攻击完再攻击
local mGethitArr = nil

local isWait = false
--先攻技能攻击 源区域默认战场
--[0x2061 %d][8]
--[0x2061][玩家ID %d][spos %c][目标区域 %c][dpos %c]
--5对方指挥部 6自己指挥部 7战场
--[0x2061 %d][9]
function Proc0x2061:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()

    local isMain = msg:readInt()
    --开始
    if isMain == 8 then
        mGethitArr = {}
        isWait = false
    --结束
    elseif isMain == 9 then
        if isWait == false then return end
        --停止接收协议
        require("net.Network"):instance():setPauseMsgProc( true )

        require("framework.scheduler").performWithDelayGlobal(
            function ()
                for key, value in pairs(mGethitArr) do  
                    --播放攻击
                    war2FightScene:setBattleCardFight( value[4], 7, value[2] )
                end 

                --开启接收协议
                require("framework.scheduler").performWithDelayGlobal( function () require("net.Network"):instance():setPauseMsgProc( false ) end, 1.2)
            end
        ,2)
    --正常普通攻击
    else
        isWait = true
        local spos = msg:readByte()
        local darea = msg:readByte()
        local dpos = msg:readByte()
        spos = war2CardManager:getBattleIndex( spos )
        if darea == 7 then dpos = war2CardManager:getBattleIndex( dpos ) end

        --播放攻击
        war2FightScene:setBattleCardFight( spos, darea, dpos )

        if mGethitArr[spos] ~= nil then
            mGethitArr[spos] = nil 
        --战场的要还击
        elseif darea == 7 then
            mGethitArr[dpos] = { war2CardManager:isMainByID( isMain ), spos, darea, dpos }
        end
    end  
end

return Proc0x2061