local Proc0x2032 = class("Proc0x2032")

function Proc0x2032:ctor()

end
local war2CardManager = require("war2.war2CardManager"):instance()
--[0x2032][str %s] 玩家ID#聊天信息ID
function Proc0x2032:FromByteArray(msg)
    local str = msg:readStringBytes(msg:getAvailable() - 1)
    local arr = string.split( str, "#" )
    war2FightScene:getCharMsgLayout():showTalkMsg( tonumber(arr[1]), tonumber(arr[2]) )
end


return Proc0x2032