local Proc0x2031 = class("Proc0x2031")

function Proc0x2031:ctor()

end
local war2CardManager = require("war2.war2CardManager"):instance()
--更新指挥官中某个位置的牌信息
--[0x2031][玩家ID %d][id %d][状态 %c][位置 %c] 0正常,1力竭
function Proc0x2031:FromByteArray(msg)
    local charId = msg:readInt()
    local id = msg:readInt()
    local state = msg:readByte()
    local pos = msg:readByte() 
    war2CardManager:addToBattlePhaseList({data = {charId, id, state, pos}, fun = self.process, dtime = 0})
    print( "2031 "..charId.." "..id.." "..state.." "..pos)
end

function Proc0x2031:process(data)
    if data == nil then
        data = war2CardManager.bda
    end

    local charId = data[1]
    local id = data[2]
    local state = data[3]
    local pos = data[4]

    local isMain = war2CardManager:isMainByID( charId )
    local warEq = nil
    --主角
    if isMain == true then 
        if war2CardManager:getMainEq( pos ) ~= nil then
            warEq = war2CardManager:getMainEq( pos )
        else
            warEq = war2CardManager:getMainEqByID( id )
        end
    else 
        if war2CardManager:getOtherEq( pos ) ~= nil then
            warEq = war2CardManager:getOtherEq( pos )
        else
            warEq = war2CardManager:getOtherEqByID( id )
        end
    end
    if warEq then
        warEq.mState = state
        war2FightScene:updateEq( pos, isMain )
    end
end

return Proc0x2031