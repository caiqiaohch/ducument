local Proc0x2014 = class("Proc0x2014")

local FightSceneShow = require "war2.FightSceneShow"
local war2CardManager = require("war2.war2CardManager"):instance()

function Proc0x2014:ctor()

end

--[0x2014][玩家ID %d][牌库数量 %c][cardId %d][sarea %c][spos %c]  // 时时更新
function Proc0x2014:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()

    local charId = msg:readInt()
    local num = msg:readByte()
    local cardId = 0
    local sarea = 0
    local spos = 0
    if msg:getAvailable() > 4 then
        cardId = msg:readInt()
        sarea = msg:readByte()
        spos = msg:readByte()
    end
    print( "2014 "..charId.." "..num.." "..cardId.." "..sarea.." "..spos)
    war2CardManager:addToBattlePhaseList({data = {charId, num, cardId, sarea, spos}, fun = self.process, dtime = 0})    
end

function Proc0x2014:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local num = data[2]
    local cardId = data[3]
    local sarea = data[4]
    local spos = data[5]
    spos = war2CardManager:getBattleIndex( spos ) 
    local isMain = war2CardManager:isMainByID(charId)
    --自己
    if isMain == true then
        war2CardManager.mMainDeckNum = num
        if war2CardManager.isPlaying == true then
            war2FightScene:updateMainDeckNum()
        end
    else
        war2CardManager.mOtherDeckNum = num
        if war2CardManager.isPlaying == true then
            war2FightScene:updateOtherDeckNum()
        end
    end
   
   if war2CardManager.CurPlayingCardId == 370 then
        return    
    end

   if NewbieManager.CurState ~= 3 and war2CardManager.ShowState ~= 0 and (sarea == WAR2_AREA_TYPE_SHOUPAI or sarea == WAR2_AREA_TYPE_MUDI or sarea == WAR2_AREA_TYPE_ZHANCHANG) then  --sarea:源区域 1手牌 3墓地  7战场
        FightSceneShow.playDeckCardEffect( isMain, sarea, cardId, spos )    
    end
end

return Proc0x2014