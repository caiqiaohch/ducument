local Proc0x2022 = class("Proc0x2022")

function Proc0x2022:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()

--[0x2022][pos %c][血量 %c][最大血量 %c][攻击 %c]
function Proc0x2022:FromByteArray(msg)
    local pos = msg:readByte()
    local hp = msg:readByte()
    local maxhp = msg:readByte()
    local atk = msg:readByte()   
    print("2022  "..pos.."  "..hp.."  "..maxhp.."  "..atk)
    war2CardManager:addToBattlePhaseList({data = {pos, hp, maxhp, atk}, fun = self.process, dtime = 0})
end

function Proc0x2022:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local pos = data[1]
    local hp = data[2]
    local maxhp = data[3]
    local atk = data[4]

    pos = war2CardManager:getBattleIndex( pos )
    local card = war2CardManager:getBattleCard(pos)

    if card == nil then return end
    local lastCurHp = card:getData().curHealth
    local lastMaxHp = card:getData().maxHealth
    local lastAtk = card:getData().curAtk

    if hp < 0 or hp == 255 then
        hp = lastCurHp  --发过来的属性数值如果少于0 ，则表示该数值没有更新，设回现的数值
    end
    if maxhp < 0 or maxhp == 255 then
        maxhp = lastMaxHp
    end
    if atk < 0 or atk == 255 then
        atk = lastAtk
    end

    local card = war2CardManager:setBattleCard( pos, nil, nil, atk, hp, maxhp )
    war2FightScene:updateBattleCardHp( pos )

    if war2CardManager.BolReConnect == true then return end --断线重连进来的不用表现下面的效果
    
    if lastMaxHp == maxhp then
        --回血效果
        if hp > lastCurHp then
            local card = war2FightScene:getBattleCard(pos)
            card:palyAddHpEffect()
            card:palyHpChangeEffect()
        --受击效果
        elseif hp < lastCurHp then
            war2FightScene:getBattleCard(pos):palyHitEffect()
            war2FightScene:getBattleCard(pos):runAction(Diy.Shake:create(0.2, 5))--震屏
        end
    elseif lastMaxHp ~= maxhp or lastCurHp ~= hp then --血量有变化就显示效果
        war2FightScene:getBattleCard(pos):palyHpChangeEffect()
    end
    
    if lastAtk ~= atk then
        war2FightScene:getBattleCard(pos):palyAtkChangeEffect()
    end
end

return Proc0x2022