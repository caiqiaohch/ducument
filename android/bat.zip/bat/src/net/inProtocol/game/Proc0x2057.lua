local Proc0x2057 = class("Proc0x2057")
local FightSceneShow = require "war2.FightSceneShow"

function Proc0x2057:ctor()

end

--献祭成功
--[0x2057][玩家ID %d][cardid %d][spos %c]
function Proc0x2057:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()

    local charId = msg:readInt() 
    local cardId = msg:readInt()
    local spos = msg:readByte()
    print("2057 "..charId..","..cardId..","..spos)
    war2CardManager:addToBattlePhaseList({data = {charId, cardId, spos}, fun = self.process, dtime = 0})    
end

function Proc0x2057:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local cardId = data[2]
    local spos = data[3]
    
    local isMain = war2CardManager:isMainByID(charId) 
    --自己
    if isMain == true then
        war2FightScene:getXianJiLayout():playHandXianJiEffect()
        if war2CardManager:isWatching() == true then
            FightSceneShow.playXianJiEffectOther( cardId )
        end
    else
        FightSceneShow.playOtherXianJiEffect( spos, cardId )
    end
end

return Proc0x2057