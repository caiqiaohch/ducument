local Proc0x2062 = class("Proc0x2062")

function Proc0x2062:ctor()

end

--部署主动选择技能协议 源区域默认手牌
--[0x2062][玩家ID %d][cardid %d][spos %c][目标区域 %c][dpos %c]
function Proc0x2062:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()

    local isMain = war2CardManager:isMainByID( msg:readInt() )
    local cardID = msg:readInt()
    local spos = msg:readByte()
    local darea = msg:readByte()
    local dpos = msg:readByte()
    if darea == 7 then dpos = war2CardManager:getBattleIndex( dpos ) end
    
    local warCard = war2CardManager:getBattleCard(spos)
    if warCard == nil then return end
    warCard.mTagetData = { darea, dpos }
end

return Proc0x2062