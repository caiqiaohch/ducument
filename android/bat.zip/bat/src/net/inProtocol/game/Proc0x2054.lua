local Proc0x2054 = class("Proc0x2054")

function Proc0x2054:ctor()

end

--部队死亡 源区域默认战场 目标区域默认墓地
--[0x2054][cardid %d][[spos %c]
function Proc0x2054:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()

    local cardID = msg:readInt()
    local spos = msg:readByte()
    print( "2054  ".." "..cardID.." "..spos)
    war2CardManager:addToBattlePhaseList({data = {cardID, spos}, fun = self.process, dtime = 0})    
end

function Proc0x2054:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local cardID = data[1]
    local spos = data[2]
    spos = war2CardManager:getBattleIndex( spos ) 

    local tempCard = require("data.DataManager"):instance():getCardObjByID( cardID, false )
    if tempCard == nil then return end
    --工事
    if tempCard.type == JIEJIE_KA then
        war2CardManager:addOrDelBattleWorkCard( spos, nil, cardID )
        war2FightScene:setBattleCardDead( spos, 2 )
    --部队   
    else
        war2CardManager:addOrDelBattleCard( spos, 0 )
        war2FightScene:setBattleCardDead( spos, 1 )
    end    
end

return Proc0x2054