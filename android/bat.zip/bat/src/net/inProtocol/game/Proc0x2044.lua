local Proc0x2044 = class("Proc0x2044")

function Proc0x2044:ctor()

end
local war2CardManager = require("war2.war2CardManager"):instance()
--[0x2044][退出观战 d%]
function Proc0x2044:FromByteArray(msg)    
    local sign = msg:readInt()    
    print( "2044 "..sign)
    war2CardManager:endFightClear()
    NewbieManager.CurState = 0
    war2CardManager.curFightPlayerID = 0
    popAllScene()
    MainWindow.isCanShow = true
    require("framework.scheduler").performWithDelayGlobal( function () replaceScene("MainWindow") end, 0.5 )            
end

return Proc0x2044