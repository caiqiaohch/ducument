local Proc0x2050 = class("Proc0x2050")

local _dataArr = nil
local isMain = false
local war2CardManager = require("war2.war2CardManager"):instance()
local DataManager = require("data.DataManager"):instance()

function Proc0x2050:ctor()

end

--法术牌效果
--[0x2050 %d][8]
--[0x2050 %d][玩家ID %d][cardid %d][cardpos %c][技能编号 %d][是否继续播放效果 0否/1是/2反击失效 %c]
--[0x2050 %d][9]
--前台主动触发的技能才有,其他条件触发的不发
function Proc0x2050:FromByteArray(msg)
    local charId = msg:readInt()
    if charId == 8 then --开始
        print( "2050  start" )
        war2CardManager:setBolGettingSkill(true)
        war2CardManager:setBolStopTimer( true )
        war2CardManager:addToBattlePhaseList({data = {}, fun = function() end, dtime = 0.5})  --单纯为了延迟0.5秒,好让第一个技能效果接受完成才播放
        return
    elseif charId == 9 then  --结束
        print( "2050  end" )
        war2CardManager:setBolGettingSkill(false)
        war2CardManager:setBolStopTimer( false )
        return
    else
        
    end
    local cardID = msg:readInt()
    local cardpos = msg:readByte()
    local skillID = msg:readInt()
    local bolPlay = msg:readByte()


--    if bolPlay ~= 1 then 
--        return 
--    end  --如果已经不播放效果则直接退出

    -----------------------------------每条2050协议会创建一个待播放技能数据,如果2050之后接了2058,则2058的数据会覆盖2050--------------
   
    ----------------------------------此次技能的索引ID, 同时只把该ID堆入战斗堆栈, 而不是直接传入下面的技能数据---------------
    SkillManager:setWarSkillIdx()
    local idx = SkillManager:getWarSkillIdx()
    ---------------------------------此次技能的索引ID, 同时只把该ID堆入战斗堆栈, 而不是直接传入下面的技能数据---------------

    isMain = war2CardManager:isMainByID( charId )  
    local skillData = SkillManager:getSkillData( skillID )
    if skillData == nil  then
        return
    elseif skillData.runtime == 2 then  --即时结算因为没有发开始结束,所以特殊处理
        if skillData.type == 1 or skillData.type == 5 or skillData.type == 7 or skillData.type == 10 or skillData.type == 11 or ( skillData.type ~= 3 and skillData.ftarget ~= 8 and skillData.fselect == 8 ) then --这种走2058流程
            return  --这几个类型2058会发,在那边处理
        end
    end

    if skillData.runtime == 2 or ( skillData.condition == 2 and skillData.effect_id ~= 0 ) then  --即时结算跟生物显现技能不走堆叠区
        local sarea
        local spos
        if cardID > 9999 then
            if isMain == true then sarea = 6 else sarea = 5 end
            spos = cardpos
        else
            sarea = 7
            spos = war2CardManager:getBattleIndex( cardpos )
        end
        cardData = { cardID = cardID, skillID = skillID, sarea = sarea, spos = spos , darea = 7, dpos = 100 } 
    else
--        if isMain == true then
--            cardData = war2CardManager:getMainTacTicCard( cardID, skillID )  --从自己或者对手堆叠区获取技能数据 --详细说明看2059
--        else
--            cardData = war2CardManager:getOtherTacTicCard( cardID, skillID )
--        end
        cardData = { cardID = cardID, skillID = skillID, tacTic = true } 
    end

    if cardData ~= nil then 
        cardData.isMain = isMain
        cardData.bolPlay = bolPlay
        cardData.net = 2050
        SkillManager:addToWarSkillList( cardData )  --把待播放技能数据加进列表,如果2058有发,则会覆盖此数据
    end

    war2CardManager:addToBattlePhaseList({data = {idx}, fun = self.process, dtime = 0})
    print("2050 "..charId.." "..cardID.."  "..cardpos.." "..skillID.." "..bolPlay.." idx "..idx)      
end

function Proc0x2050:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local idx = data[1]
    SkillManager:playWarSkillEffect(idx)
end

return Proc0x2050