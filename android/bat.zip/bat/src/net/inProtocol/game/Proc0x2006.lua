local Proc0x2006 = class("Proc0x2006")

function Proc0x2006:ctor()

end

--[0x2006 %d][0不合法/1合法 %c]  //选择战斗牌组
function Proc0x2006:FromByteArray(msg)    
    local state = msg:readByte()
    if state == 0 then
        --该套牌卡牌数量不足或使用了非法的卡牌，无法使用。 
        require("prompt.PromptManager"):instance():SetNotice( 3004 )
    else
        if FightWnd.isShow == true then
            FightWnd:StartLink()
        elseif ArenaWindow.isShow == true then
            ArenaWindow:StartLink()
        end
    end
end

return Proc0x2006