local Proc0x2100 = class("Proc0x2010")

function Proc0x2100:ctor()

end

--[0x2010][客户端信 %s] // 客户端信息
function Proc0x2100:FromByteArray(msg)

    --字符串
    local str = msg:readStringBytes(msg:getAvailable() - 1)

--    local war2CardManager = require("war2.war2CardManager"):instance()
--    local arr = string.split( str, ";" )
--    local temp = nil
--    --开局
--    if arr[1] == "100" then
--        temp = string.split( arr[2], "," )
--        war2CardManager.mOtherCommander[1] = tonumber(temp[1])
--        war2CardManager.mOtherCommander[2] = tonumber(temp[2])
--        war2CardManager.mOtherCommander[3] = tonumber(temp[3])
--        war2CardManager.mOtherHp = 0
--        for i = 1, 3 do
--            local data = DataManager:getGeneral( temp[i] )
--            war2CardManager.mOtherHp = war2CardManager.mOtherHp + data.health
--        end
--        --切换到战场
--        CSceneManager:getInstance():replaceScene(
--		    CCSceneExTransitionFade:create(0.5,LoadScene("war2FightScene")))
--        war2FightScene:startFightInit()

--        war2CardManager.State = 1
--    --布置卡牌
--    elseif arr[1] == "99" then
--        temp = string.split( arr[2], "," )
--        --部队、工事牌
--        if #temp == 2 then
--            local battleCard = war2CardManager:setOtherBattleCard( tonumber(temp[1]), tonumber(temp[2]) )
--            war2FightScene:setOtherFightCard( index, battleCard )
--        else
--            local DataManager = require("data.DataManager"):instance()
--            local card = DataManager:getCardObjByID( temp[1] )
--            --地形卡
--            if card.type == 5 then
--                war2CardManager.curLand = tonumber(temp[1])
--            --战术卡
--            else
--                war2CardManager:addOtherTacTicCard( tonumber(temp[1]) )
--            end

--        end
--    end
end

return Proc0x2100