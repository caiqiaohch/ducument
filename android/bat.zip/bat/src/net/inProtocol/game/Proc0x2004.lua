local Proc0x2004 = class("Proc0x2004")
local warAi = require("war2.warAi"):instance()
function Proc0x2004:ctor()

end

local war2CardManager = require("war2.war2CardManager"):instance()
local OpenBoxManager = require("openbox.OpenBoxManager"):instance()
--是否初始化战场
local isInitFight = false

--0//对战初始化        开局，双方都没操作过的状态,客户端从等待界面切入战场界面
--1//回合开始阶段      己方布置出牌的状态。
--2//攻击玩家部署阶段  对方布置状态
--3//防御玩家部署阶段  开打表现
--4//卡牌结算阶段
--5//生物战斗阶段
--6//回合结束阶段
--[0x2004 %d][回合状态 %c][开始0/结束1 %c] 0对战初始化 1回合开始阶段，2 攻击玩家部署阶段 3防御玩家部署阶段 4卡牌结算阶段 5生物战斗阶段 6回合结束阶段
function Proc0x2004:FromByteArray(msg)
    --回合状态 
    local state = msg:readByte()
    local sign = msg:readByte()
    
    print("0x2004   state "..state.." "..sign)
    if state == 0 and war2CardManager.isPlaying == true then  --战斗正式开始后state0就不处理了
        return
    end
    if sign == 0 then
        war2CardManager:addToBattlePhaseList({data = state, fun = war2CardManager.setShowState, dtime = 0})
    end
    war2CardManager.State = state    

--    if isInitFight == true and state == 0 then
--    return end
    war2CardManager.BattleStateList[state] = sign

    if war2CardManager.BolReConnect == true then
        war2CardManager.BattleStateList[state] = 1
    end
    --对战初始化(开局)
    if state == 0 then
        --切换到主界面
        if sign == 1 or war2CardManager.BolReConnect == true then
            replaceScene("war2FightScene")
            war2CardManager.isPlaying = true
            isInitFight = true
            war2CardManager:initBattlePhaseList()
            --是否有宝箱奖励
            OpenBoxManager.BoxRewardList = {}
            war2CardManager:addToBattlePhaseList({data = war2FightScene, fun = war2FightScene.updateState, dtime = 0})    
            return
        end
    end
    if isInitFight == true and (state ~= 0 or sign ~= 0) then
        isInitFight = false
--        war2FightScene:startFightInit()--初始化战场 很多数据都是接受了state 0 后得到的
--        war2FightScene:setXianJiLayoutHide()
--        war2CardManager:setBattleTimer(true)
    end
    if sign == 1 or ( state == 6 and war2CardManager.BolReConnect == true ) then 
        war2CardManager:addToBattlePhaseList({data = {state, sign}, fun = self.updateStateEnd, dtime = 0})
        return 
    end  
    if state ~= 0 then  --阶段为0的话走上面的对战初始化(开局)
        war2CardManager:addToBattlePhaseList({data = war2FightScene, fun = war2FightScene.updateState, dtime = 0}, 1)
    end
end

function Proc0x2004:updateStateEnd(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local state = data[1]
    local sign = data[2]
    --战斗结算状态
    if state == 4 and sign == 1 then
        --清空所有战场部队作用目标信息
        war2CardManager:clearBattleTarget()
        --计算光环类技能
        SkillManager:updateHaloSkill()
    elseif state == 6 and ( sign == 1 or war2CardManager.BolReConnect == true ) then 
        war2CardManager.CurPlayingCardId = 0
        SkillManager:initWarSkillList()
        require("net.ServMsgTransponder"):SMTWarOK()
        if war2CardManager.mOtherID == 1 then
            warAi:setAiTimer(false)
            warAi:Init()
        end
    end
end

return Proc0x2004