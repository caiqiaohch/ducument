local Proc0x2017 = class("Proc0x2017")

function Proc0x2017:ctor()

end

--[0x2017 %d][玩家ID %d][最大资源 %c]  // 时时更新
function Proc0x2017:FromByteArray(msg)

    local war2CardManager = require("war2.war2CardManager"):instance()

    local charId = msg:readInt()
    local res = msg:readByte()
    war2CardManager:addToBattlePhaseList({data = {charId, res}, fun = self.process, dtime = 0})    
end

function Proc0x2017:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charId = data[1]
    local res = data[2]
    local isTheSame = false
    local isMain = war2CardManager:isMainByID( charId )
    
    if war2CardManager.isPlaying == true then
        if isMain == true then 
            local oldRes = war2CardManager.mMainResource
            war2CardManager.mMainResource = res
            war2FightScene:updateMainRes(oldRes, res, true)
        else 
--            local oldRes = war2CardManager.mOtherResource
--            war2CardManager.mOtherResource = res
--            war2FightScene:updateOtherRes(oldRes, res, true)
            require("framework.scheduler").performWithDelayGlobal( function () 
                local oldRes = war2CardManager.mOtherResource
                war2CardManager.mOtherResource = res
                war2FightScene:updateOtherRes(oldRes, res, true) end, 1.5 )
        end
    end

   
end

return Proc0x2017