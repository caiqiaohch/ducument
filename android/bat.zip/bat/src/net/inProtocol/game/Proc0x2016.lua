local Proc0x2016 = class("Proc0x2016")
local NewbieManager = require("prompt.NewbieManager"):instance()
local war2CardManager = require("war2.war2CardManager"):instance()

function Proc0x2016:ctor()

end

--[0x2016][是否可以献祭 0/1]
function Proc0x2016:FromByteArray(msg)
    --是否可以献祭
    local sacrifice = msg:readByte()
    print(" 2016 "..sacrifice )
    war2CardManager.isSacrifice = (sacrifice == 1) 
    if NewbieManager.CurState == 2 then war2CardManager.isSacrifice = false end
     
    if NewbieManager.CurState == 1 and war2CardManager.isSacrifice == false then
        if war2CardManager.TurnNum == 1 and NewbieManager.UseData.Sacrifice == false then
            NewbieManager:setUseData("Sacrifice", true)
        end
        if war2CardManager.TurnNum == 3 and NewbieManager.UseData.Sacrifice2nd == false then
            NewbieManager:setUseData("Sacrifice2nd", true)
            NewbieWindow:hideWindow()

            if NewbieManager.UseData.UseHand2nd == true then  --如果已经出生物牌了，提醒结束回合
                local funN = function () NewbieWindow:setAndShowType("UseCreature2nd") end
                require("framework.scheduler").performWithDelayGlobal( funN, 2 )   
            end
        end
    end

    war2FightScene:getCharMsgLayout():setXianJiTipsEffShow()
end

return Proc0x2016