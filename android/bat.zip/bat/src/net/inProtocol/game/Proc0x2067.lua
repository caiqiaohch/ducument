local Proc0x2067 = class("Proc0x2067")

function Proc0x2067:ctor()

end

--[0x2067][玩家ID %d][卡牌id %d][pos %c]  卡牌回手
function Proc0x2067:FromByteArray(msg)    
    local war2CardManager = require("war2.war2CardManager"):instance()
    local charID = msg:readInt()
    local cardID = msg:readInt()
    local pos = msg:readByte()   
    print( "2067 "..charID.." "..cardID.." "..pos)

     war2CardManager:addToBattlePhaseList({data = {charID, cardID, pos}, fun = self.process, dtime = 0})    
end

function Proc0x2067:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local charID = data[1]
    local cardID = data[2]
    local pos = data[3]   
    local isMain = war2CardManager:isMainByID( charID )--暂时没用上
    pos = war2CardManager:getBattleIndex( pos )

    local tempCard = require("data.DataManager"):instance():getCardObjByID( cardID, false )
    if tempCard == nil then return end
    --工事
    if tempCard.type == JIEJIE_KA then
        war2CardManager:addOrDelBattleWorkCard( pos, nil, cardID )
        war2FightScene:setFightWorkCard(pos, nil)
    --部队   
    else
        war2CardManager:addOrDelBattleCard( pos, 0 )
        war2FightScene:setFightCard(pos, nil)
    end   
end

return Proc0x2067
