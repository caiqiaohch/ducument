local Proc0x2021 = class("Proc0x2021")

function Proc0x2021:ctor()

end

--[0x2021][pos %c][状态 %c] 0正常,1力竭
function Proc0x2021:FromByteArray(msg)
    local war2CardManager = require("war2.war2CardManager"):instance()

    local pos = msg:readByte()
    local state = msg:readByte()
    print("2021 "..pos.." "..state)
    war2CardManager:addToBattlePhaseList({data = {pos, state}, fun = self.process, dtime = 0})
end

function Proc0x2021:process(data)
    if data == nil then
        data = war2CardManager.bda
    end
    local pos = data[1]
    local state = data[2]
    pos = war2CardManager:getBattleIndex( pos )

    war2CardManager:setBattleCard( pos, nil, state )
    war2FightScene:updateBattleCardState( pos )
end

return Proc0x2021