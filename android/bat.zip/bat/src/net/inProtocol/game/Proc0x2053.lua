local Proc0x2053 = class("Proc0x2053")

function Proc0x2053:ctor()

end

local isWait = false

--普通攻击 源区域默认战场
--[0x2053 %d][8]
--[0x2053%d][玩家ID %d][cardid %d][spos %c][目标区域 %c][dpos %c]
--5对方指挥部 6自己指挥部 7战场--现在加了玩家ID, 不会发6了
--[0x2053 %d][9]
function Proc0x2053:FromByteArray(msg)
    
    local war2CardManager = require("war2.war2CardManager"):instance()
    local charId = msg:readInt()
    if charId == 8 or charId == 9 then return end
    local cardid = msg:readInt()
    local spos = msg:readByte()
    local darea = msg:readByte()
    local dpos = msg:readByte()

    print( "2053  "..charId.." "..cardid.." "..spos.." "..darea.." "..dpos)
    war2CardManager:addToBattlePhaseList({data = {charId, cardid, spos, darea, dpos}, fun = self.process, dtime = 0})
end

function Proc0x2053:process(data)

    if data == nil then
        data = war2CardManager.bda
    end

    local charId = data[1]
    local cardid = data[2]
    local spos = data[3]
    local darea = data[4]
    local dpos = data[5]

    spos = war2CardManager:getBattleIndex( spos )
    dpos = war2CardManager:getBattleIndex( dpos )
    local isMain = war2CardManager:isMainByID( charId )
    war2FightScene:setBattleCardFight( isMain, spos, darea, dpos )

end

return Proc0x2053