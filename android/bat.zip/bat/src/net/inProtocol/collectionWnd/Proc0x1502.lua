local Proc0x1502 = class("Proc0x1502")

function Proc0x1502:ctor()

end

--[0x1502 %d][修改卡组名称id %c]  //修改卡组名称成功保存数据
function Proc0x1502:FromByteArray(msg)
    local CollectionManager = require("collectionWnd.CollectionManager"):instance()
    local num = msg:readByte()
    if num == 1 then
        CollectionManager:EditGroupNameSuccess()   
        if CollectionWnd.isShow == true then
            CollectionTpWnd:updateCardGroupName() 
        end
    end
end

return Proc0x1502