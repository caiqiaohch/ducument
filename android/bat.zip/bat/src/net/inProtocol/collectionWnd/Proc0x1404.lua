local Proc0x1404 = class("Proc0x1404")

function Proc0x1404:ctor()

end

local CollectionManager = require("collectionWnd.CollectionManager"):instance()

--[0x1404 %d][卡包数组 %s]              //玩家拥有卡包数量     卡包编号1,数量1;....
function Proc0x1404:FromByteArray(msg)
    local str = msg:readStringBytes( msg:getAvailable() - 1 )
    local arr = string.split(str, ";")
    local mCardArr = {}
    CollectionManager:initAllHasPackList()
    for i = 1, #arr do
        if arr[i] ~= "" then
            mCardArr = arr[i]:split(",")
            if #mCardArr == 2 then
                CollectionManager:setHasPackNum( tonumber( mCardArr[1] ), tonumber( mCardArr[2] ) )
            end
        end
    end
    require("framework.scheduler").performWithDelayGlobal( function () CollectionManager:handlePack() end, 1.5 )
--    CollectionManager:handlePack()
    

    if OpenPackWindow.isShow == true then
        OpenPackWindow:UpDataMsg()
    end
    if MainWindow.isShow == true then
        MainWindow:updataSummonMsg()
    end

    print( "   1404 "..str)
end

return Proc0x1404