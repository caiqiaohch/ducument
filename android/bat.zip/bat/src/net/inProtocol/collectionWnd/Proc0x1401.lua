local Proc0x1401 = class("Proc0x1401")

function Proc0x1401:ctor()

end
local CollectionManager = require("collectionWnd.CollectionManager"):instance()

--[0x1401 %d][1 %c]                     //开始
--[0x1401 %d][所有普通卡的数组信息 %s]    //所有普通卡牌的数组信息   普通卡id1：数量1,......
--[0x1401 %d][2 %c]                     //结束
function Proc0x1401:FromByteArray(msg)
    local index = msg:readByte()
    if index == 1 then
--        CollectionManager.Bol0x1400 = true
    elseif index == 2 then  
        CollectionManager:SendOpenCardInfo(true)
    end

    local cardId
    local num
--    local cardIdArr = {}
--    local str = ""
    while msg:getAvailable() >= 5 do
        cardId = msg:readInt()
        num = msg:readByte()
--        print("1401 "..cardId..","..num)
        if cardId ~= 0 then
            CollectionManager:setHasCardNum( cardId, num )
        end
--        str = str.." "..cardId.." "..objId
    end


--    local index = msg:readByte()
--    if index == 1 then

--    elseif index == 2 then

--    else
--        msg:setPos( msg:getPos() - 1 )
--        local str = msg:readStringBytes( msg:getAvailable() - 1 )
--        local arr = string.split(str, ";")
--        local mCardArr = {}
--        for i = 1, #arr do
--            if arr[i] ~= "" then
--                mCardArr = string.split(arr[i], ",")
--                --if mCardArr[1] ~= nil and mCardArr[1]  ~= "" and mCardArr[2] ~= nil and mCardArr[2] ~= "" then
--                if tonumber( mCardArr[1] ) ~= nil and tonumber( mCardArr[2] ) ~= nil and tonumber( mCardArr[2] ) ~= 0 then
--                    --print(mCardArr[1],mCardArr[2])
--                    CollectionManager:setHasCardNum( tonumber( mCardArr[1] ), tonumber( mCardArr[2] ) )
--                end
--            end
--        end
--        print( "1401  "..str)
--    end
end

return Proc0x1401