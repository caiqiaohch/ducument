local Proc0x1402 = class("Proc0x1402")

function Proc0x1402:ctor()

end

--[0x1402 %d][卡背数组 %s]              //玩家拥有的卡背的数组    卡背id1,卡背id2,....
function Proc0x1402:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local str = msg:readStringBytes( msg:getAvailable() - 1 )
    local char = CharacterManager:getMainPlayer()
    char.AllCardBgArr = string.split(str, ",")
end

return Proc0x1402