local Proc0x1406 = class("Proc0x1406")

function Proc0x1406:ctor()

end
local CollectionManager = require("collectionWnd.CollectionManager"):instance()

--[0x1406 %d][普通卡牌id %d][数量 %c]    //单独更新卡牌数量 
function Proc0x1406:FromByteArray(msg)
    local id = msg:readInt()
    local num = msg:readByte()
    if CollectionManager:getHasCardNum(id) == 0 then
        CollectionManager:setNewCardList(id) --如果没有这张卡牌,则加到新卡数组里面
    end

    CollectionManager:setHasCardNum(id, num)
    CollectionManager:updataHasCard()
    if MainWindow.isShow == true then
        MainWindow:updataCollectMsg()
    end

    if CollectionWnd.isShow == true then
        if CollectionWnd.winshow == SHOW_TP_WN then
            CollectionManager:updateCurGpvCardNumArr()
        end
        CollectionScWnd.UpDataCardMsg()
    end

    if CollectionYzWnd.isShow == true then
        CollectionYzWnd:updateGpvCardList()
    end

    if id == ShopManager:getCurBuyId() and CardXiangXi.isShow == true and id == CardXiangXi:getCardId() then
        CardXiangXi:addBuyEffect()    
    end 

    if CardXiangXi.isShow == true then
        CardXiangXi:updateShopBtn()
    end 
end

return Proc0x1406