local Proc0x1400 = class("Proc0x1400")

function Proc0x1400:ctor()

end

local CollectionManager = require("collectionWnd.CollectionManager"):instance()

--[0x1400 %d][1 %c]                     //开始
--[0x1400 %d][所有圣物(圣物)卡数组信息 %s]    //所有圣物(圣物)卡牌数组信息   圣物(圣物)卡id1：数量1,......
--[0x1400 %d][2 %c]                     //结束
function Proc0x1400:FromByteArray(msg)
    local index = msg:readByte()
    if index == 1 then
        CollectionManager.Bol0x1400 = true
    elseif index == 2 then
        local b = CollectionManager.BolSellCard
        CollectionManager:updataHasCard()

        if CollectionWnd.isShow == true then 
            CollectionWnd:updateGpvCardList(true)
        end

        if FightWnd.isShow == true then
            FightWnd:updateGroup()
        end

        if CharacterWindow.isShow == true then
            CharacterWindow:updateMsg()
        end
    else
        local cardId
        local num
    --    local cardIdArr = {}
    --    local str = ""
        while msg:getAvailable() >= 5 do
            cardId = msg:readInt()
            num = msg:readByte()
--            print("1400 "..cardId..","..num)
            if cardId ~= 0 then
                CollectionManager:setHasCardNum( cardId, num )
            end
    --        str = str.." "..cardId.." "..objId
        end

--        msg:setPos( msg:getPos() - 1 )

--        local str = msg:readStringBytes( msg:getAvailable() - 1 )
--        local arr = string.split(str, ";")
----        print("1400  "..str)
--        local mCardArr = {}
--        for i = 1, #arr do
--            if arr[i] ~= "" then
--                mCardArr = arr[i]:split(",")
--                CollectionManager:setHasCardNum( tonumber( mCardArr[1] ), tonumber( mCardArr[2] ) )
--            end
--        end
    end
end

return Proc0x1400