local Proc0x1501 = class("Proc0x1501")

function Proc0x1501:ctor()

end

--[0x1501 %d][组成卡组成功1/不成功0 %c]  //1组成卡牌成功保存数据，0不成功
function Proc0x1501:FromByteArray(msg)
    local CollectionManager = require("collectionWnd.CollectionManager"):instance()
    local num = msg:readByte()
    print("1501 "..num)
    if num == 0 then
        if CollectionWnd.isShow == true then
            require("prompt.PromptManager"):instance():SetPromptMsg(4024, nil, CollectionManager.SendGroupMsg , CollectionTpWnd.saveDeckCallback, 4025, 4026)
        end
--        CollectionTpWnd:updataCardGroupMsg()
    else
        if CollectionWnd.isShow == true then
            CollectionManager:SaveGroupSuccess() 
            CollectionTpWnd.saveDeckCallback()  
            CollectionTpWnd:updataCardGroupMsg() 
        end
    end
end

return Proc0x1501