local Proc0x1503 = class("Proc0x1503")

function Proc0x1503:ctor()

end

--[0x1503 %d][id %c]  // 成功删除卡组id
function Proc0x1503:FromByteArray(msg)
    local CollectionManager = require("collectionWnd.CollectionManager"):instance()
    local num = msg:readByte()
    if num == 1 then
        CollectionManager:DelGroupSuccess()
        if CollectionWnd.isShow == true then
            CollectionTpWnd:updataCardGroupMsg()
        end
    end
    print("del deck"..num)
end

return Proc0x1503