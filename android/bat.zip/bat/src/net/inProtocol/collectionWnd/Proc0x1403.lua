local Proc0x1403 = class("Proc0x1403")

function Proc0x1403:ctor()

end

--[0x1403 %d][正在使用卡背id %w]        //正在使用的卡背id为0，使用默认卡背。
function Proc0x1403:FromByteArray(msg)
    local CharacterManager = require("characters.CharacterManager"):instance()
    local num = msg:readUShort()
    local char = CharacterManager:getMainPlayer()
    char.UsingCarBg = num
end

return Proc0x1403