local Proc0x1500 = class("Proc0x1500")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()
local ArenaManager = require("arena.ArenaManager"):instance()

function Proc0x1500:ctor()

end


--[0x1500 %d][卡组编号 %c][卡组信息 %s]  //卡组信息  %s#%s%s  卡组名称#圣物卡组#普通卡牌数组--数组用,分隔
function Proc0x1500:FromByteArray(msg)
    local DataManager = require("data.DataManager"):instance()
    local id = msg:readByte()
    local msg = msg:readStringBytes( msg:getAvailable() - 1 )

    local msgArr = string.split(msg, "#")--msgArr[1]：名字，msgArr[2]:圣物卡牌数组，msgArr[3]:普通卡牌数组
    if msgArr[1] == "" and msgArr[2] == "0" and msgArr[3] == "0" then return end
    print("1500 "..msg)
    if msgArr[3] == "999999" then msgArr[3] = "" end
    local EqArr = string.split( msgArr[2], "," )--卡牌 id:数量,...
    local mCardArr = string.split( msgArr[3], "," )--卡牌 id:数量,...
    local cardNumArr = {}
    local obj = nil

    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
    local sign = false
-------------------------------全部拥有卡牌-卡组拥有卡牌------------------
    local gpEqList = {}
    for i = 1, #EqArr do
        if EqArr[i] ~= "," and EqArr[i] ~= "" and EqArr[i] ~= "0" then
            obj = DataManager:getEq(EqArr[i])
            table.insert(gpEqList, obj)
        end
    end

    local gpCardList = {}
    for i = 1, #mCardArr do
        if mCardArr[i] ~= "," and mCardArr[i] ~= "" and mCardArr[i] ~= "0" then
            if string.find( mCardArr[i], "|" ) ~= nil then  --新保存卡组的 处理
                local tempArr = string.split( mCardArr[i], "|" )
                local cardId = tempArr[1]
                local num = tempArr[2]
                obj = DataManager:getCardObjByID(cardId)
                cardNumArr[obj.id] = {data = obj, num = num}
                table.insert(gpCardList, {data = obj, num = num})
            else
                obj = DataManager:getCardObjByID(mCardArr[i])
                if obj  ~= nil then 
                    if cardNumArr[obj.id] == nil then
                        cardNumArr[obj.id] = {data = obj, num = 1}
                    else
                        cardNumArr[obj.id] = {data = obj, num = cardNumArr[obj.id].num + 1}
                    end
                else
                    print(mCardArr[i]) 
                end
            end
        end
    end

    for k, v in pairs(cardNumArr) do
        obj = DataManager:getCardObjByID(k)
        table.insert(gpCardList, v)
    end
-------------------------------全部拥有卡牌-卡组拥有卡牌------------------//
    ------解析名字字符串------------------
    local nameArr = string.split(msgArr[1], "$")--nameArr[1]：名字，nameArr[2]:头像id
    if tonumber(nameArr[2]) == nil or tonumber(nameArr[2]) == 0 then nameArr[2] = 1 end
    ------解析名字字符串------------------

    obj = {}
    obj.id = id
    obj.name = string.gsub(nameArr[1], "_", " ")
    obj.headId = tonumber(nameArr[2])
    obj.save = true
    obj.getInfo = true
    obj.GroupEquipArr = gpEqList
    obj.GroupCardArr = gpCardList

    if ArenaManager:checkCurDeckId(id) == true then --竞技场卡组特殊处理 
        ArenaManager:setCurDeckData( obj )
        if ArenaWindow.isShow == true then
            ArenaWindow:updateEqMsg()
            ArenaWindow:updateMsg()
            ArenaWindow:updateGpvCardList()
        end
        return 
    end 

    CollectionManager:AddToCardGroupList( obj )
    if CollectionManager.ComposeShowId == id then 
        CollectionManager.ComposeShowId = 0
        if CollectionWnd.isShow == true then CollectionTpWnd.EditCardGroup(id) end
    end
    if CollectionWnd.isShow == true then 
        CollectionTpWnd:updataCardGroupMsg() 
        CollectionWnd:showPage(SHOW_TP_WN)
    end    
end

return Proc0x1500