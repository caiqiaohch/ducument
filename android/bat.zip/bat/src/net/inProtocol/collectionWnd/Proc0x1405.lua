local Proc0x1405 = class("Proc0x1405")

function Proc0x1405:ctor()

end
local CollectionManager = require("collectionWnd.CollectionManager"):instance()

--[0x1405 %d][圣物卡id %d][数量 %c]      //单独更新卡牌数量
function Proc0x1405:FromByteArray(msg)
    local id = msg:readInt()
    local num = msg:readByte()
    if id == 0 then return end

    if CollectionManager:getHasCardNum(id) == 0 then
        CollectionManager:setNewCardList(id)  --如果没有这张卡牌,则加到新卡数组里面
    end
    
    CollectionManager:setHasCardNum( id, num )
    CollectionManager:updataHasCard()

    if MainWindow.isShow == true then
        MainWindow:updataCollectMsg()
    end

    if CollectionWnd.isShow == true then
        CollectionScWnd.UpDataCardMsg()
    end
end

return Proc0x1405