local Proc0x1504 = class("Proc0x1504")
local CollectionManager = require("collectionWnd.CollectionManager"):instance()

function Proc0x1504:ctor()

end


--[0x1504 %d][卡组编号 %c][卡组信息 %s]  //卡组信息  %s#%s%s  卡组名称#圣物卡组--数组用,分隔
function Proc0x1504:FromByteArray(msg)
    local DataManager = require("data.DataManager"):instance()
    local id = msg:readByte()
    local msg = msg:readStringBytes( msg:getAvailable() - 1 )
    print("1504 "..id.." "..msg)
    local msgArr = string.split(msg, "#")--msgArr[1]：名字，msgArr[2]:圣物卡牌数组, msgArr[3]:头像ID
    if msgArr[1] == "" and msgArr[2] == "0" then return end
    if ArenaManager:checkCurDeckId(id) == true then return end --竞技场卡组不在这里处理
    local EqArr = string.split( msgArr[2], "," )--卡牌 id:数量,...
    local obj = nil
    local CharacterManager = require("characters.CharacterManager"):instance()
    local char = CharacterManager:getMainPlayer()
-------------------------------全部拥有卡牌-卡组拥有卡牌------------------
    local gpEqList = {}
    for i = 1, #EqArr do
        if EqArr[i] ~= "," and EqArr[i] ~= "" and EqArr[i] ~= "0" then
            obj = DataManager:getEq(EqArr[i])
            table.insert(gpEqList, obj)
        end
    end

    CollectionManager.Bol0x1504 = true
-------------------------------全部拥有卡牌-卡组拥有卡牌------------------//
    ------解析名字字符串------------------
    local nameArr = string.split(msgArr[1], "$")--nameArr[1]：名字，nameArr[2]:头像id
    if tonumber(nameArr[2]) == nil or tonumber(nameArr[2]) == 0 then nameArr[2] = 1 end
    ------解析名字字符串------------------

    obj = {}
    obj.id = id
    obj.name = string.gsub(nameArr[1], "_", " ")
    obj.headId = tonumber(nameArr[2])
    obj.save = true
    obj.getInfo = false
    obj.GroupEquipArr = gpEqList
    obj.GroupCardArr = {}
    CollectionManager:AddToCardGroupList( obj )
    if CollectionWnd.isShow == true then CollectionTpWnd:updataCardGroupMsg() end
    if FightWnd.isShow == true then  FightWnd:updateGroup()  end
end

return Proc0x1504