local Crypt = class()

    --初始密钥
    C_KEY_CPT_MOVE = 3
    C_KEY_CPT_VALU = "abcd"
    
    --消息密钥
    C_MSG_CPT_MOVE = 3
    C_MSG_CPT_VALU = "abcd"
    
    --字节变换类型
    C_OPT_TYPE = 2
    
    --明文字节缓冲区
    iniBA = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
    --密文字节缓冲区
    encodeBA = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
    --解密字节缓冲区
    decodeBA = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)
    --计算校验码的字节缓冲区
    testBA = cc.utils.ByteArrayVarint.new(cc.utils.ByteArray.ENDIAN_LITTLE)

function Crypt:setMsgKey( move, key )
    C_MSG_CPT_MOVE = move
    C_MSG_CPT_VALU = key
end

--加密循环移位操作
function encodeOptValue( value, move )
    b = bit.band( bit.blshift(value, 8-move), 0xff )
    c = bit.brshift(value, move)
    value = bit.bor(c, b)
    return value
end

--解密循环移位操作
function decodeOptValue( value, move )
    local b = bit.brshift(value, 8-move)
    local c = bit.band( bit.blshift(value, move), 0xff )
    value = bit.bor(c, b)
    return value
end

--打印缓冲区的数据
function printBA( ba )
    
--    var buf:String = "";
--    ba.position = 0;
--    while( ba.bytesAvailable )
--    {
--        buf += ba.readUnsignedByte().toString(16) + ",";
--    }
--    trace( "=====缓冲区数据:\n" + buf + "\n=====\n" );

end

--[[/**
 * 加密 
 * @param msg : 明文
 * @param isMsgType : 是否消息协议的解密
 * @return 
 * 
 */
 ]]--
function Crypt:Encode( msg, isMsgType )
    isMsgType = isMsgType or true
    iniBA:clear()
	encodeBA:clear()
	local encodeSTR = ""
    local i = 0
	local id = 0
    local iniValuei = 0
    local keyCode = 0
    local tmpValue = 0
    local keyStr = ""
    if isMsgType == true then
        keyStr = C_MSG_CPT_VALU
    else
        keyStr = C_KEY_CPT_VALU
    end

    local moveValue = 0
    if isMsgType == true then
        moveValue = C_MSG_CPT_MOVE
    else
        moveValue = C_KEY_CPT_MOVE
    end
	local chgv = 0
			
	----------------
	--计算校验码
	testBA:clear()
	testBA:writeStringBytes( msg )
	testBA:setPos(1)
	local count = 0
	while testBA:getAvailable() ~= 0 do
		count = count + testBA:readUByte()
    end
	count = count % 254 + 1
    count = bit.band(count,0xff)	
	----------------			
			
	--写入明文字符串
	iniBA:writeStringBytes(msg)
			
	----------------
	--写入校验和
	iniBA:writeByte( count )
	----------------
			
	--写入结束符
	iniBA:writeByte( 0 )
			
	iniBA:setPos(1)
	local codestr = ""
	--遍历所有字节
    while iniBA:getAvailable() ~= 0 do
        --读当前字节
		iniValue = bit.band(iniBA:readByte(), 0xff)		
		--取反
		if C_OPT_TYPE == 1 then
			chgv = bit.bnot(chgv, iniValue)
		--加密循环移位操作
		else
			chgv = encodeOptValue( iniValue, moveValue )	
        end
		id = i % string.len(keyStr) + 1
        i = i + 1
		keyCode = string.byte( keyStr, id )
        tmpValue = bit.bxor(chgv, keyCode)
        tmpValue = bit.band(tmpValue, 0xff)
		--写入密文字节
		encodeBA:writeByte( tmpValue )
    end
	encodeBA:setPos(1)
	encodeSTR = encodeBA:readStringBytes( encodeBA:getAvailable() )
				
	return { encodeBA = encodeBA, encodeSTR = encodeSTR }
end

--[[
/**
 * 解密 
 * @param encodeBA : 密文字节缓冲
 * @param isMsgType : 是否消息协议的解密
 * @return 
 * 
 */
 ]]--
function Crypt:DecodeBA( encodeBA, isMsgType )
    local keyStr = ""
    if isMsgType == true then
        keyStr = C_MSG_CPT_VALU
    else
        keyStr = C_KEY_CPT_VALU
    end
    local moveValue = 0
    if isMsgType == true then
        moveValue = PT_MOVE
    else
        moveValue = C_KEY_CPT_MOVE
    end
    local i = 0
    local id = 0
    local iniValue = 0
    local keyCode = 0
    local tmpValue = 0
    decodeBA:clear()
    local decodeSTR = ""
    local chgv = 0
    
    i = 0
    encodeBA:setPos(1)
    --遍历所有的字节
    while encodeBA:getAvailable() > 0 do
        --取字节
        iniValue = bit.band(encodeBA:readByte(),0xff)
        
        id = i % string.len(keyStr) + 1
        i = i + 1
        keyCode = string.byte( keyStr, id )
        tmpValue = bit.bxor(iniValue, keyCode)
        
        --取反
        if C_OPT_TYPE == 1 then
            chgv = bit.bnot(chgv, tmpValue)
        --解密循环移位操作
        else
            chgv = decodeOptValue( tmpValue, moveValue )
        end
        
        chgv = bit.band(chgv, 0xff)
        
        --写入明文字节
        decodeBA:writeByte( chgv )
    end
    decodeBA:setPos(1)
    --读取明文字符串
    decodeSTR = decodeBA:readStringBytes( decodeBA:getAvailable() )
    
    return decodeSTR
end     

return Crypt
