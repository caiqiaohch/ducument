local Network = require("net.Network")
local ServMsgTransponder = require("net.ServMsgTransponder")
local CharacterManager = require("characters.CharacterManager")
local LoginSer = class()-- 定义一个类 test 继承于 base_type

function LoginSer:ctor()

	print("LoginSer:ctor --------------------------")
	
end

function LoginSer:instance()
    local o = _G.LoginSer
    if o then
    	return o
	end
 
    o = LoginSer:new()
	_G.LoginSer = o
    LoginSer:init()
    return o
end

function LoginSer:init()
    --账户名
    self.accounts      =   ""
    --连接服务器状态 0没连接  1登录服  2游戏服
    self.mServerState   =   0
    --可选游戏服务器线路
    self.mServers      =   {}
    --成功连接服务器回调
    local function connected()
        ServMsgTransponder:SMTGetEcryptKey()
    end
    self.connected = connected

    self.f001Time = 0
end

--游戏服务器断开回调
local function onConnectClose()
--    require("prompt.PromptManager"):instance():SetReConnectMsg()
end

--设置服务器状态
function LoginSer:setServerState( state )
    self.mServerState = state
    if self.mServerState == 2 then
        Network.instance():setCallBackFuncOnClose(onConnectClose)
    end
end
--获取服务器状态
function LoginSer:getServerState()
    return self.mServerState
end 

 --连接登录服务器
function LoginSer:onLuaSocketConnect()
	local mNetwork = Network.instance()
    if mNetwork:getIsConnected() == false then
	    mNetwork:connect( LOGIN_SERVER_DOMAIN, LOGIN_SERVER_PORT )
	    mNetwork:setCallBackFuncOnConnect(self.connected)
    end
end

local mSendTimes = 3
 --没角色帐号发送创号命令
function LoginSer:SendCreateChar( charName )
     if mSendTimes == 0 then 
        require("prompt.PromptManager"):instance():SetNotice( 4103 ) 
        return
    end
    mSendTimes = mSendTimes - 1
     ServMsgTransponder:SMTCreateCharacter( charName )	
end

--请求服务器列表
function LoginSer:SendGetGame()
    ServMsgTransponder:SMTGetGameServerList()
end

--加入可选游戏服务器线路
function LoginSer:addServerList( lineID, playerCount, ip, port, tip )
	local serverObj = {}
	serverObj.lineID = lineID
	serverObj.playerCount = playerCount
	serverObj.ip = ip
	serverObj.port = port
	serverObj.tip = tip

    self.mServers[#self.mServers + 1] = serverObj	
end

--自动选线 连接游戏服务器
function LoginSer:autoSelectLine()
	--切换到主界面
--    MainWindow.isShow = true
    replaceScene("MainWindow")
			
	local serverObj = nil
	local lineList = {}--可以进的线号
	for i = 1, #self.mServers do
		serverObj = self.mServers[i]
		if serverObj and serverObj.playerCount < C_DENY_LIMIT then
			lineList[#lineList+1] = serverObj
		end
	end
	
    --所有线路已经满人
	if #lineList < 1 then
		print("Player Full!!")
		return
	end
			
	local num = math.random( 1, #lineList )
	local selectLine = lineList[ num ]
			
	--断开登录服务器的连接
    local mNetwork = Network.instance()
    
    if mNetwork:getIsConnected() == true then
        mNetwork:close()
    end
			
	--连接到游戏服务器
    if mNetwork:getIsConnected() == false then
	    mNetwork:connect( selectLine.ip, selectLine.port )
	    mNetwork:setCallBackFuncOnConnect(self.connected)        
    end
end

 --发送进入场景的协议
function LoginSer:SendEnterGame()
     local CharacterManager = CharacterManager:instance()
     local char = CharacterManager:getMainPlayer()
     ServMsgTransponder:SMTEnterGame( self.accounts, char.CharID )	
end


--返回登录界面重登游戏,bolOut是否登出帐号
function LoginSer:onReConnectClick( bolOut )
    if bolOut == true then
        require("data.UserDefaultManager"):instance():setStringForKey( "UserName", " " )  
        require("data.UserDefaultManager"):instance():setStringForKey( "UserPWD", " " )  
    end
    if device.platform == "android" then
        cc.Director:getInstance():endToLua()  --直接退出
    else
        local sharedApplication = cc.Application:getInstance()
        sharedApplication:reStartGame()
    end
    

--    Network.instance():close()
--    self:setServerState( 0 )
----    self:onLuaSocketConnect()
--    Network.instance():init()
--    popAllScene()
--    if bolOut == true then
--        require("data.UserDefaultManager"):instance():setStringForKey( "UserName", " " )  
--        require("data.UserDefaultManager"):instance():setStringForKey( "UserPWD", " " )  
--    end
--    require("collectionWnd.CollectionManager"):instance():init()
--    require("arena.ArenaManager"):instance():clear()
--    replaceScene("LoginWindow")
end


return LoginSer