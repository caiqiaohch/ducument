local loader = require("loader.loader")
local display = require("loader.display")
--local luaj = require("loader.luaj")  --不能这样直接引用,电脑端会报错

local scene = cc.Scene:create()
scene.name = "LoadScene"
--local updater = {
--    bg_sprite_name = "images/login.png",  -- 热更时的背景图
--    progress_bg_name = "images/progress_bg.png",  -- 热更进度条的背景资源
--    progress_fg_name = "images/progress.png",  -- 热更进度条的前景资源

--    app_entrance = "game_ui",   -- 游戏入口，在热更新完成后会被require
--    work_path = cc.FileUtils:getInstance():getWritablePath() .. "dotdata/dotloader/",  -- 热更新工作目录 更新模块的工作目录
--    preload_zips = PRE_LOAD_ZIPS,   -- 需要加载的代码zip文件列表
--    design_width = 1280,    -- 设计宽
--    design_height = 720,  -- 设计高
--    seconds = 3000, 					-- 超时时间
--    slient_size = 5 * 1024 * 1024,  -- 静默下载数据网络下的提示大小

--    java_channel_params = {"common/Bridge", "getChannelId", {}, "()I"},   -- java 获得渠道号的参数
--    java_env_params = {"common/Bridge","getMetaData", {"VerType"}, "(Ljava/lang/String;)Ljava/lang/String;"},  -- java 获得环境信息

--    oc_channel_params = {"iOSBridge", "getNativeInfo", {key = "ChannelID"}}, -- ios 获取渠道号的参数
--    oc_env_params = {"iOSBridge", "getNativeInfo", {key = "VerType"}}, -- ios 获取环境信息
--}


-----------googele

local mObbFilePath = ""
local mObbRawPath = cc.FileUtils:getInstance():getWritablePath() .."dotdata/dotloader/"
--获取obb路径参数回调
local function onCallObbPath(pathStr)
    mObbFilePath = pathStr
    print(" onCallObbPath "..mObbFilePath.."  "..DEBUG_WRITEMSGURL)

end

--解压obb文件
function unObbFile()
    if cc.FileUtils:getInstance():isFileExist(mObbFilePath) == true then
       print("obbFile is exists start uncompress")        
       print( cc.FileUtils:getInstance():getWritablePath() .. "dotdata/dotloader/"..SCRIPT_VERSION_ID.."/" )
       local t = Zip.ZipUtils:uncompressDir(mObbFilePath, mObbRawPath)--"dotdata/dotloader/".."obb".."/")
       if t == true then
            print("uncompressDir success")
            return true
        else
           print("uncompressDir fail")  
       end

    else
       print("obbFile is not exists")  
    end    
    return false
end


--定义java里面回调lua的函数
function callJavaCallBackLua()
    local className = "org/cocos2dx/lua/AppActivity"
    local args = { "obbPath", onCallObbPath }
    local sigs = "(Ljava/lang/String;I)V"
    local ok = require("loader.luaj").callStaticMethod(className,"callObbPathMethod",args)    
end

--调用java函数,获取obb文件路径
function getObbFilepath()
    print("getObbFileFullpath")
    local pathStr = ""
    local javaClassName = "org/cocos2dx/lua/AppActivity"
    local javaMethodName = "getObbFileFullpath"
    local javaParams = {}
    local javaMethodSig = "()Ljava/lang/String;"

    local ok = require("loader.luaj").callStaticMethod(javaClassName, javaMethodName, javaParams, javaMethodSig)
end

function loadObbFile()    
--    cc.UserDefault:getInstance():setStringForKey( "OBB_VER", "1" )  
    if IS_GOOGLE_LOGIN == true then
        local curObbVer = SCRIPT_VERSION_ID + 1
        local obbVer = tonumber(cc.UserDefault:getInstance():getStringForKey( "OBB_VER" ))
        if obbVer == nil then obbVer = 0 end  
        if curObbVer <= obbVer then
            return 
        end       

        callJavaCallBackLua()
        getObbFilepath()
        local t = unObbFile() 
        if t == true then
--            cc.FileUtils:getInstance():addSearchPath(mObbRawPath..(SCRIPT_VERSION_ID+1).."/",true)
            cc.FileUtils:getInstance():addSearchPath(updater.work_path ..(SCRIPT_VERSION_ID+1).."/obb_file",true)
--            updater.work_path .. indexInfoCurr.scriptVersion .. '/' .. index
            print("addSearchPath "..mObbRawPath..updater.work_path .."/")
            cc.UserDefault:getInstance():setStringForKey( "OBB_VER", curObbVer )  
        end
--        if UserDefaultManager:getBoolForKey( "bolObbInit" ) == false or true then
--            GoogleManager:callJavaLogin()

--            GoogleManager:getObbFilepath()
----            local t = GoogleManager:unObbFile() 
----            if t == true then
----                UserDefaultManager:setBoolForKey( "bolObbInit", true ) 
----            end
--        end        
    end
end
---------------------


function scene._addUI()
    print("scene._addUI")
    local bg_sprite_name = updater.bg_sprite_name or "splash/splash_bg.jpg"
    if bg_sprite_name and string.len(bg_sprite_name) > 0 then
        local __bg = cc.Sprite:create(bg_sprite_name)
        if CONFIG_SCREEN_AUTOSCALE == "FIXED_HEIGHT" then
            __bg:setScale(display.height / updater.design_height)
        elseif CONFIG_SCREEN_AUTOSCALE == "FIXED_WIDTH" then
            __bg:setScale(display.width / updater.design_width)
        end
        display.align(__bg, display.CENTER, display.cx, display.cy)
        scene:addChild(__bg, 0)
    end

    local __label = cc.LabelTTF:create("Loading... 0％", "Arial", 22)
    __label:setColor(display.c3b(230, 230, 230))
    scene._label = __label
    display.align(__label, display.CENTER, display.cx, display.bottom + 120)
    scene:addChild(__label, 10)

    local progress_bg_name = updater.progress_bg_name or "splash/loading_bar_bg.png"
    local progress_fg_name = updater.progress_fg_name or "splash/loading_bar.png"
    if progress_bg_name and progress_fg_name and string.len(progress_fg_name) > 0 and string.len(progress_bg_name) > 0 then
        local x, y = display.cx, display.cy - 273
        local bg = cc.Sprite:create(progress_bg_name)
        bg:setPosition(x, y)
        scene:addChild(bg, 9)

        local progress = cc.ProgressTimer:create(cc.Sprite:create(progress_fg_name))
        progress:setType(1)
        progress:setMidpoint({x = 0, y = 0.5})
        progress:setBarChangeRate({x = 1, y = 0})
        progress:setPosition(x, y)
        scene:addChild(progress, 10)
        scene.progress_ = progress
    end

    scene.labelDebug_ = cc.LabelTTF:create("", "Arial", 22)
    scene.labelDebug_:setColor(display.c3b(230, 230, 230))
    display.align(scene.labelDebug_, display.CENTER, display.cx, display.bottom + 60)
    scene:addChild(scene.labelDebug_, 10)

--    require("loader.scheduler").performWithDelayGlobal(function() loadObbFile() end, 0.5)
    
end

function scene._sceneHandler(event)
    if event == "enter" then
        scene.onEnter()
    elseif event == "cleanup" then
        scene.onCleanup()
    elseif event == "exit" then
        scene.onExit()
    end
end

local function dump(tbl)
    for k,v in pairs(tbl) do
        print(k, "\t", v)
    end
end
local bolUcom = false
--更新事件处理
function scene._updateHandler(event, ...)
    if bolUcom == false then
        bolUcom = true
        loadObbFile()
    end
    if scene.labelDebug_ == nil or tolua.isnull(scene.labelDebug_) == true then return end
    local vars = {...}
    local str = table.concat(vars, ", ")
    if DEBUG and DEBUG > 0 then
        str = event .. "@" .. str
        scene.labelDebug_:setString(str)
    end

    if event == 'fail' then
        scene.labelDebug_:setString(str)
        BOL_UPDATE_FAIL = true
    elseif event == 'success' then
        BOL_UPDATE_FAIL = false
    end
    if event == "success" or event == "fail" then
        scene.setProgress_(100)
        scene.enterGameApp()
    elseif event == 'progress' then
        scene.setProgress_(vars[1])
    end
end

function scene.setProgress_(percent)
    if scene.progress_ then
        scene.progress_:setPercentage(percent)
    end
    if scene._label then
        local str = string.format("Loading... %s％", tostring(percent))
        scene._label:setString(str)
    end
end

--
function scene.enterGameApp()
    for i,v in ipairs(updater.preload_zips) do
        cc.LuaLoadChunksFromZIP(v)
    end
        require("app.game_ui")
        game_ui.startup()
end



--更新游戏代码
function scene.onEnter()
    loader.update(scene._updateHandler)
end

function scene.onExit()
    loader.clean()
    scene:unregisterScriptHandler()
end

function scene.onCleanup()
end

scene:registerScriptHandler(scene._sceneHandler)
scene._addUI()

return scene
