local MovRotate = class( "MovRotate" )

--���� ������(1��������ת 2�������ת)�� ��ת�Ƕȣ���תʱ�䣬��ת����,��ת�ٶ�
function MovRotate:init( sp, Type, rotate, times, AddTime)
    self.mSp = sp
    self.mRotate = rotate
    self.mType = Type
    self.mTimes = times
    self.mAddTime = AddTime
    self.mSpRotate = self.mSp:getRotation()
     --���������ص�
    self.callBackFucFinished = nil
    --������ʼ�ص�(ִ�е�һ�α仯)
    self.callBackFucStart = nil
end

function MovRotate:update()
    if self.callBackFucStart ~= nil then
        self.callBackFucStart( self )
        self.callBackFucStart = nil
    end

    if self.mType == 1 then
        if self.mSp:getRotation() < self.mRotate then
            self.mSp:setRotation( self.mRotate + 1 )
        end
    else
        if(self.mTimes <= 0)then 
            if(self.mSp:getRotation() < 0)then
                self.mSp:setRotation( self.mSp:getRotation() + self.mAddTime )
                return false
            elseif(self.mSp:getRotation() > 0)then
                self.mSp:setRotation( self.mSp:getRotation() - self.mAddTime )
                return false
            else
                if self.callBackFucFinished ~= nil then
                    self.callBackFucFinished( self )
                    self.callBackFucFinished = nil
                end
                return true 
            end
        end

        if self.mTimes%2 == 1 then
            if(self.mSp:getRotation() > self.mRotate * -1)then
                 self.mSp:setRotation( self.mSp:getRotation() - self.mAddTime )
            else
                 self.mTimes = self.mTimes - 1
            end
        else
            if(self.mSp:getRotation() < self.mRotate)then
                 self.mSp:setRotation( self.mSp:getRotation() + self.mAddTime )
            else
                 self.mTimes = self.mTimes - 1
            end
        end
    end

end

function MovRotate:clear()
    self.mSp = nil
    self.mRotate = nil
    self.mType = nil
    self.mTimes = nil
    self.mAddTime = nil
    self.mSpRotate = nil
    self.callBackFucStart = nil
    self.callBackFucFinished = nil
end

return MovRotate