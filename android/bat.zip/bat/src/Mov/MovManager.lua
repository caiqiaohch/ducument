local MovManager = class()-- 定义一个类 test 继承于 base_type

function MovManager:ctor()

	print("MovManager:ctor --------------------------")
	
end

function MovManager:instance()
    local o = _G.MovManager
    if o then
    	return o
	end
 
    o = MovManager:new()
	_G.MovManager = o
    MovManager:init()
    return o
end

local scheduler = require("framework.scheduler")

function MovManager:init()
    MovManager.MovList = {}
    MovManager.mTimer = nil
end

--更新动画
local function updateMov()
    local mov = nil
    local sub = 0
    for i = 1, #MovManager.MovList do
        i = i - sub
        mov = MovManager.MovList[i]
        if mov:update() == true then
            mov:clear()
            table.remove( MovManager.MovList, i )
            sub = sub + 1
        end
    end

    if #MovManager.MovList == 0 then
        scheduler.unscheduleGlobal( MovManager.mTimer )
        MovManager.mTimer = nil
    end
end

--增加动画到更新列表
function MovManager:pushMov( mov )
    MovManager.MovList[#MovManager.MovList+1] = mov

    if MovManager.mTimer == nil then
        MovManager.mTimer = scheduler.scheduleGlobal( updateMov, 0.03 )
    end
end

--删除指定动画
function MovManager:delMov( mov )
    local tempMov = nil
    for i = 1, #MovManager.MovList do
        tempMov = MovManager.MovList[i]
        if tempMov == mov then
            mov:clear()
            table.remove( MovManager.MovList, i )
            break
        end
    end
end

--删除全部动画
function MovManager:clearAll()
    local tempMov = nil
    for i = 1, #MovManager.MovList do
        tempMov = MovManager.MovList[i]
        tempMov:clear()
        MovManager.MovList[i] = nil
    end
    MovManager.MovList = {}

    if MovManager.mTimer ~= nil then
        scheduler.unscheduleGlobal( MovManager.mTimer )
        MovManager.mTimer = nil
    end
end

return MovManager