local MovMove = class( "MovMove" )

--精灵 传入是否增量(否就是固定坐标) x坐标或增量 y坐标或增量 持续时间(毫秒) _gType加速类型(0匀速,-1减速,1加速)
function MovMove:init( sp, isAdd, _x, _y, _t, _gType )

    --动画结束回调
    self.callBackFucFinished = nil
    --动画开始回调(执行第一次变化)
    self.callBackFucStart = nil
    self.mSp = sp
    self.isAdd = isAdd
    self.mX = _x
    self.mY = _y
    self.mGType = _gType

    local addX,addY = sp:getPosition()
    if isAdd == true then
        addX = _x
        addY = _y
    else
        addX = _x - addX
        addY = _y - addY
    end
    
    self.mCurT = 0
    _t = math.floor(_t/33)
    self.mT = _t
    self.mAddX = addX/_t
    self.mAddY = addY/_t

    --加速运动
    if self.mGType == 1 then
        self.mAddX = self.mAddX*0.5
        self.mAddY = self.mAddY*0.5
        self.mGX = 2*( addX - self.mAddX*_t )/(_t*_t)
        self.mGY = 2*( addY - self.mAddY*_t )/(_t*_t)
    --减速运动
    elseif self.mGType == -1 then
        self.mAddX = self.mAddX*1.5
        self.mAddY = self.mAddY*1.5
        self.mGX = 2*( addX - self.mAddX*_t )/(_t*_t)
        self.mGY = 2*( addY - self.mAddY*_t )/(_t*_t)
    --匀速运动
    else
        self.mGX = 0
        self.mGY = 0
    end
end

--动画更新方法  返回是否完成动画
function MovMove:update()
    local mx,my = self.mSp:getPosition()
    mx = mx + self.mAddX
    my = my + self.mAddY
    self.mSp:setPosition( mx, my )

    self.mAddX = self.mAddX + self.mGX
    self.mAddY = self.mAddY + self.mGY 

    if self.mCurT == 0 and self.callBackFucStart ~= nil then
        self.callBackFucStart( self )
        self.callBackFucStart = nil
    end

	self.mCurT = self.mCurT + 1
    local isEnd = self.mCurT >= self.mT
    if isEnd == true then
        if self.isAdd == false then
            self.mSp:setPosition( self.mX, self.mY )
        end
        if self.callBackFucFinished ~= nil then
            self.callBackFucFinished( self )
            self.callBackFucFinished = nil
        end
    end 

    return isEnd
end

function MovMove:clear()
    self.mSp = nil  
    self.mCurT = nil
    self.mT = nil
    self.mAddX = nil
    self.mAddY = nil
    self.isAdd = nil
    self.mX = nil
    self.mY = nil
    self.mGType = nil
    self.mGX = nil
    self.mGY = nil
    self.callBackFucStart = nil
    self.callBackFucFinished = nil
end

return MovMove