local MovAlpha = class( "MovAlpha" )
--精灵 目标透明度 执行透明度 透明度变化率
function MovAlpha:init( tempSelf, AlphaNum, AddAlpha, dely)
    --动画结束回调
    self.callBackFucFinished = nil
    --动画开始回调(执行第一次变化)
    self.callBackFucStart = nil
    self.Sp = tempSelf
    self.AlphaNum = AlphaNum
    self.mDely = dely

    if self.Sp:getOpacity() > self.AlphaNum then
        self.AddAlpha = -1*AddAlpha
    else
        self.AddAlpha = AddAlpha
    end
end

function MovAlpha:update()
    if self.mDely ~= nil then
        self.mDely = self.mDely - 1
        if self.mDely == 0 then self.mDely = nil end
        return
    end

    if self.callBackFucStart ~= nil then
        self.callBackFucStart( self )
        self.callBackFucStart = nil
    end

    if self.Sp == nil then  --如果已经清理了,返回true
        if self.callBackFucFinished ~= nil then
            self.callBackFucFinished( self )
            self.callBackFucFinished = nil
        end
        return true
    end

    local isEnd = false
    local curAlpha = self.Sp:getOpacity()
    --递加
    if self.AddAlpha > 0 then
        if( curAlpha < self.AlphaNum )then
            if curAlpha + self.AddAlpha >= self.AlphaNum then curAlpha = self.AlphaNum - self.AddAlpha end
            self.Sp:setOpacity( curAlpha + self.AddAlpha )
        else
            isEnd = true
        end
    --递减
    else
        if( curAlpha > self.AlphaNum )then
            if curAlpha + self.AddAlpha <= self.AlphaNum then curAlpha = self.AlphaNum - self.AddAlpha end
            self.Sp:setOpacity( curAlpha + self.AddAlpha )
        else
            isEnd = true
        end
    end

    if isEnd == true then
        if self.callBackFucFinished ~= nil then
            self.callBackFucFinished( self )
            self.callBackFucFinished = nil
        end
    end
    
    return isEnd
end

function MovAlpha:clear()
    self.AlphaNum = nil
    self.AddAlpha = nil
    self.Sp = nil
    self.callBackFucStart = nil
    self.callBackFucFinished = nil
end

return MovAlpha