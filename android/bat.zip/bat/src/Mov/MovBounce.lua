local MovBounce = class( "MovBounce" )

--精灵
function MovBounce:init( sp, _x, _y )

    --动画结束回调
    self.callBackFucFinished = nil
    --动画开始回调(执行第一次变化)
    self.callBackFucStart = nil
    self.mSp = sp 
    self.mX = _x
    self.mY = _y

    local mx,my = self.mSp:getPosition() 
    self.mVX = (self.mX - mx)*0.05
    self.mVY = (self.mY - my)*0.05
    self.mTempVX = self.mVX
    self.mTempVY = self.mVY
    self.mGX = self.mVX*0.5
    self.mGY = self.mVY*0.5
end

--动画更新方法  返回是否完成动画
function MovBounce:update()
    if self.callBackFucStart ~= nil then
        self.callBackFucStart( self )
        self.callBackFucStart = nil
    end

    local mx,my = self.mSp:getPosition()
    mx = mx + self.mTempVX
    my = my + self.mTempVY
    self.mSp:setPosition( mx, my ) 
    
    --0普通 1到达目标点 2速度为0 4本身没速度
    local typeX = 0
    local typeY = 0

    --X方向初始速度大于0
    if self.mVX > 0 then
        --朝目标方向
        if self.mTempVX > 0 then
            --到达目标点
            if mx >= self.mX then typeX = 1
            else self.mTempVX = self.mTempVX + self.mGX end
        --朝目标反方向
        elseif self.mTempVX < 0 then
            self.mTempVX = self.mTempVX + self.mGX
            if self.mTempVX >= 0 then self.mTempVX = 0 typeX = 2 end
        else
            typeX = 2
        end
    --X方向初始速度小于0
    elseif self.mVX < 0 then
        --朝目标方向
        if self.mTempVX < 0 then
            --到达目标点
            if mx <= self.mX then typeX = 1
            else self.mTempVX = self.mTempVX + self.mGX end
        --朝目标反方向
        elseif self.mTempVX > 0 then
            self.mTempVX = self.mTempVX + self.mGX
            if self.mTempVX <= 0 then self.mTempVX = 0 typeX = 2 end
        else
            typeX = 2
        end
    --X方向初始速度等于0
    else
        typeX = 4
    end

    --Y方向初始速度大于0
    if self.mVY > 0 then
        --朝目标方向
        if self.mTempVY > 0 then
            --到达目标点
            if my >= self.mY then typeY = 1
            else self.mTempVY = self.mTempVY + self.mGY end
        --朝目标反方向
        elseif self.mTempVY < 0 then
            self.mTempVY = self.mTempVY + self.mGY
            if self.mTempVY >= 0 then self.mTempVY = 0 typeY = 2 end
        else
            typeY = 2
        end
    --Y方向初始速度小于0
    elseif self.mVY < 0 then
        --朝目标方向
        if self.mTempVY < 0 then
            --到达目标点
            if my <= self.mY then typeY = 1
            else self.mTempVY = self.mTempVY + self.mGY end
        --朝目标反方向
        elseif self.mTempVY > 0 then
            self.mTempVY = self.mTempVY + self.mGY
            if self.mTempVY <= 0 then self.mTempVY = 0 typeY = 2 end
        else
            typeY = 2
        end
    --Y方向初始速度等于0
    else
        typeY = 4
    end

    local isEnd = false
    --到达目标点
    if (typeX == 1 or typeX == 4) and (typeY == 1 or typeY == 4) then
        self.mTempVX = -self.mTempVX*0.5
        self.mTempVY = -self.mTempVY*0.5
        --停止
        if math.abs(self.mTempVX) <= math.abs(self.mGX) and math.abs(self.mTempVY) <= math.abs(self.mGY) then
            self.mSp:setPosition( self.mX, self.mY )
            isEnd = true
        end
    --速度为0
    elseif(typeX == 2 or typeX == 4) and (typeY == 2 or typeY == 4) then
        self.mTempVX = self.mTempVX + self.mGX
        self.mTempVY = self.mTempVY + self.mGY
    end

    if isEnd == true then
        if self.callBackFucFinished ~= nil then
            self.callBackFucFinished( self )
        end
    end 

    return isEnd
end

function MovBounce:clear()
    self.callBackFucFinished = nil
    self.callBackFucStart = nil
    self.mSp = nil 
    self.mX = nil
    self.mY = nil
    self.mVX = nil
    self.mVY = nil
    self.mTempVX = nil
    self.mTempVY = nil
    self.mGX = nil
    self.mGY = nil
end

return MovBounce