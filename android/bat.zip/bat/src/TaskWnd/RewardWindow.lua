require "tagMap.Tag_rewardwnd"
RewardWindow = class("RewardWindow",function()
	return TuiBase:create()
end)

local DataManager = require("data.DataManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()

local __instance = nil
--总容器
local window = nil
--宝箱, 金币, 宝石用图片
local mImgPrizeIcon
--卡包用图片
local mImgPack

local mTxtTitle
local mTxtName
local mTxtGoldNum
local mTxtNum
local mTxtTips


local mLayoutReward

--卡牌奖励UI
local cardUI
--开箱特效
local mOpenEffect
--底层特效
local mEffect
--是否特效播放中
local mBolPlaying = false

local mRewardObjList = {}

local mCurObjList = {}

--点击回调函数
local callBackClick

local resArr = { PLIST_CARDUI_URL, PLIST_CARDMIDDLEUI_URL }

local mBolPlayed = false

RewardWindow.isShow = false

function RewardWindow:create()
	local ret = RewardWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function RewardWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end


function RewardWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

function RewardWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

local function closeWindow()    
    PopScene(__instance)
    if TaskManager.BolOpenMainTask == true then
        RunScene("TaskWindow")
    end
end


local function runRewardAction()
    mLayoutReward:setScale(0.1)
    mLayoutReward:setOpacity(0)
    local vbgFI = cc.FadeIn:create(0.3)
    local vbgSC = cc.EaseBackOut:create(cc.ScaleTo:create(0.5, 1))
    local vbgASP = cc.Spawn:create(vbgFI, vbgSC)
    mLayoutReward:runAction(vbgASP)
end

        
--播放界面打开动态效果
local function playOpenEffect()
--    if mBolPlaying == true then return end
--    mBolPlaying = true
--    local sp = TextureManager:getSprite( mLayoutReward )
--    local tx2d = sp:getTexture()
--    diy = TextureManager:getDiyEffect(100688 , tx2d)
--    effect = EffectManager:createHnyEffect( 100688 , {x = 0, y = 0}, nil, diy ) 
--    window:addChild(effect)
--    mLayoutReward:setVisible(false)
--    EffectManager:startHnyEffect( effect, { key = function () mLayoutReward:setVisible(true) mBolPlaying = false end } )
    runRewardAction()
end

--播放界面关闭动态效果
local function playCloseEffect()
    if mBolPlaying == true then return end
    mBolPlaying = true
    local sp = TextureManager:getSprite( mLayoutReward )
    local tx2d = sp:getTexture()
    diy = TextureManager:getDiyEffect(100689 , tx2d)
    effect = EffectManager:createHnyEffect( 100689 , {x = 0, y = 0}, nil, diy ) 
    window:addChild(effect)
    local close
    if #TaskManager.RewardDataList == 0 and #mCurObjList == 0 then
        close = function () mBolPlaying = false closeWindow() end 
    else
        close = function () mBolPlaying = false mLayoutReward:setVisible(true) playOpenEffect() end
    end
    
    mLayoutReward:setVisible(false)
    EffectManager:startHnyEffect( effect, { close = close} )
end


local function callBackOpenBox()
    if mBolPlaying == true then return end
    mBolPlaying = true
    mImgPrizeIcon:setVisible(false)
    mOpenEffect = EffectManager:createHnyEffect( 100601, {x = 0, y = 60} )
    window:addChild( mOpenEffect )    
    EffectManager:startHnyEffect( mOpenEffect )
		require("Music.MusicManager"):instance():PlaySound( 106 )
    mOpenEffect:close( function () mBolPlaying = false RewardWindow:updateAll() end )
    callBackClick = nil
end

--界面外点击关闭事件
local function onBtnBlackClick(p_sender)
    if mBolPlaying == true then return end
    if callBackClick ~= nil then 
        callBackClick() 
    else
         RewardWindow:updateAll()
         runRewardAction()
    end   
end

--界面点击事件
local function onWindowClick(p_sender)
    if callBackClick ~= nil then callBackClick() end
end

--设置关闭界面回调
function RewardWindow:setCloseFun(fun)
	mCloseFun = fun
end

function RewardWindow:updateAll()
    if #TaskManager.RewardDataList == 0 and #mCurObjList == 0 then
--        playCloseEffect()
        closeWindow()
        return 
    end
    local rewardObj
    if #mCurObjList == 0 then
        rewardObj = table.remove( TaskManager.RewardDataList, 1 )
        mCurObjList = rewardObj.rewardList      
        if mBolPlayed == true then
--            playCloseEffect()  
--        closeWindow()
        end
        if #TaskManager.RewardDataList == 0 and #mCurObjList == 0 then
            mBolPlaying = false closeWindow()        
        else
            mBolPlaying = false playOpenEffect()
        end
    end

    local reward = table.remove( mCurObjList, 1 )
    if reward.Icon == 1 then --宝箱
        callBackClick = callBackOpenBox
        mImgPrizeIcon:setVisible(true)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
        mImgPrizeIcon:setTexture( "other/img_PrizeIcon+1.png" )
        require("Music.MusicManager"):instance():PlaySound( 111 )
		mTxtTitle:setString( reward.TxtTitle )    
        mTxtTips:setString( reward.TxtTips )
    elseif reward.Icon == 2 then --金币
        mImgPrizeIcon:setVisible(true)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
    	mImgPrizeIcon:setTexture( "other/img_PrizeIcon+3.png" )
		require("Music.MusicManager"):instance():PlaySound( 102 )
	elseif reward.Icon == 3 then --宝石
        mImgPrizeIcon:setVisible(true)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
        mImgPrizeIcon:setTexture( "other/img_PrizeIcon+2.png" )
		require("Music.MusicManager"):instance():PlaySound( 102 )
    elseif reward.Icon == 4 then --卡牌
        mImgPrizeIcon:setVisible(false)
        mImgPack:setVisible(false)
        cardUI:setVisible(true)
        cardUI:init(reward.cardId)
		require("Music.MusicManager"):instance():PlaySound( 103 )
    elseif reward.Icon == 5 then --卡包
        mImgPrizeIcon:setVisible(false)
        mImgPack:setVisible(true)
        cardUI:setVisible(false)
        mImgPack:setTexture( reward.imgUrl )
		require("Music.MusicManager"):instance():PlaySound( 103 )
    elseif reward.Icon == 6 then --竞技场点券
        mImgPrizeIcon:setVisible(true)
        mImgPack:setVisible(false)
        cardUI:setVisible(false)
        mImgPrizeIcon:setTexture( "other/img_PrizeIcon+4.png" )
    end    

    mTxtName:setString( "" )--reward.TxtName )
    if reward.Icon == 1 then
        mTxtGoldNum:setString("")
        mTxtNum:setString( "" )
    elseif reward.Icon == 4 or reward.Icon == 5 then
        mTxtGoldNum:setString("")
        mTxtNum:setString( "X"..reward.TxtNum )
	else
        mTxtGoldNum:setString( "X"..reward.TxtNum )
        mTxtNum:setString("")
    end
end

function RewardWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_REWARDWND)
--    cc.Director:getInstance():getTextureCache():setAliasTexParameters()
    window = self:getPanel(Tag_rewardwnd.PANEL_MAIN)
    mLayoutReward = self:getControl(Tag_rewardwnd.PANEL_MAIN, Tag_rewardwnd.LAYOUT_REWARD)
     --覆盖战场关闭按钮
    local btnBlackBack = self:getControl(Tag_rewardwnd.PANEL_MAIN, Tag_rewardwnd.BTN_WINDOWBACK)
    btnBlackBack:setOnClickScriptHandler( onBtnBlackClick )
    local imgBg = mLayoutReward:getChildByTag(Tag_rewardwnd.IMG_BG)

    mImgPrizeIcon = mLayoutReward:getChildByTag(Tag_rewardwnd.IMG_PRIZEICON)  
    mImgPack = mLayoutReward:getChildByTag(Tag_rewardwnd.IMG_PACK)  

    mTxtTitle = mLayoutReward:getChildByTag(Tag_rewardwnd.LABEL_TITLE) 
    mTxtName = mLayoutReward:getChildByTag(Tag_rewardwnd.LABEL_NAME) 
    mTxtName:enableOutline(cc.c4b(0,0,0,255),2)
    mTxtNum = mLayoutReward:getChildByTag(Tag_rewardwnd.LABBMF_NUM) 
    mTxtGoldNum = mLayoutReward:getChildByTag(Tag_rewardwnd.LABBMF_GOLDNUM)  
    mTxtTips = mLayoutReward:getChildByTag(Tag_rewardwnd.LABEL_TIPS)
    
    cardUI = require("war2.cardMiddle").new()
    mLayoutReward:addChild( cardUI )
    cardUI:setPosition( 235, 400 )

    mEffect = EffectManager:createHnyEffect( 100636, {x = 226, y = 375} )
    imgBg:addChild( mEffect )    
    EffectManager:startHnyEffect( mEffect )
	self:updateAll()
    RewardWindow.isShow = true  
    playOpenEffect()
    mBolPlayed = true    
end

function RewardWindow:onExitScene()
    window = nil
    UILoadManager:delResByArr( resArr )
    RewardWindow.isShow = false
    callBackClick = nil
    mBolPlaying = false
    mBolPlayed = false
    if EndGameWindow.isShow == true then
        EndGameWindow:updateState()
    end
    if mCloseFun ~= nil then
        mCloseFun()
    end
    mCloseFun = nil
end