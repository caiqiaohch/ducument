require "tagMap.Tag_rewardwnd"
LadderRewardWindow = class("LadderRewardWindow",function()
	return TuiBase:create()
end)

local DataManager = require("data.DataManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()

local __instance = nil
--总容器
local window = nil
--段位图片
local mImgIcon

local mTxtTitle
local mTxtScore

local mBtnBlackBack
local mBtnOk

--当前状态 0:显示上赛季积分 1:显示奖励内容 2:显示当前积分
local mCurState = 0

local mBoxList = {}
local resArr = { PLIST_CARDUI_URL, PLIST_CARDMIDDLEUI_URL }


LadderRewardWindow.isShow = false

function LadderRewardWindow:create()
	local ret = LadderRewardWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function LadderRewardWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end


function LadderRewardWindow:getControl(tagPanel,tagControl)
	local ret = nil
	ret = self:getPanel(tagPanel):getChildByTag(tagControl)
	return ret
end

function LadderRewardWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

local function closeWindow()    
    PopScene(__instance)
end


local function updateAll()
    local char = CharacterManager:getMainPlayer()

    if mCurState == 1 then
        for i = 1, #mBoxList do
            mBoxList[i]:setVisible(true)
        end
        mImgIcon:setVisible(false)
        mTxtTitle:setString(DataManager:getStringDataTxt( 4007, true ))
        mTxtScore:setString("")
    elseif mCurState == 2 then
        for i = 1, #mBoxList do
            mBoxList[i]:setVisible(false)
        end

        local honour = char.CharMaxHonour
        local rankData
        local rankList = DataManager:getDataRank()
        for i=1, #rankList do        
            if rankList[i] and rankList[i].integral >= honour then
                rankData = rankList[i]
                break
            end      
        end
        if rankData then
            mImgIcon:setTexture("other/rankIcon/"..rankData.icon..".png")
        end
        mImgIcon:setVisible(true)
        mTxtTitle:setString(DataManager:getStringDataTxt( 4109, true ))
        mTxtScore:setString(DataManager:getStringDataTxt( 4108, true ).."\n"..honour)
    end
    
end


local function onBtnOkClick(p_sender)
    if p_sender == mBtnBlackBack and mCurState < 2 then return end
    mCurState = mCurState + 1
    if mCurState > 2 then
        PopScene(__instance)
        return
    end
    updateAll()
end

--打开宝箱特效
local function playOpenEff( box )
    if box.mIsOpened == true then return end
    box.mIsOpened = true

    box:setVisible(false)
    box:updateByState(1)
--    box.mBoxVec:setVisible(false)
    local tx2d = TextureManager:getSprite( box.mBoxVec ):getTexture()
    local diy = TextureManager:getDiyEffect(100840 , tx2d)
    local hyDiy = EffectManager:createHnyEffect( 100840, {x = box:getPositionX(), y = box:getPositionY()}, {x = box:getPositionX(), y = box:getPositionY()}, diy )

    window:addChild( hyDiy, 99 )    
    EffectManager:startHnyEffect( hyDiy, {close = function () box.mBoxVec:setVisible(true) end} )
    box:setVisible(true)
    box.mBoxVec:setVisible(false)
    require("Music.MusicManager"):instance():PlaySound( 106 )
end


local function clickRewardImg(p_sender)
    playOpenEff( p_sender )
end



function LadderRewardWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_ladder",PATH_REWARDWND)
--    cc.Director:getInstance():getTextureCache():setAliasTexParameters()
    window = self:getPanel(Tag_rewardwnd.PANEL_LADDER)

     --覆盖战场关闭按钮
    mBtnBlackBack = window:getChildByTag(Tag_rewardwnd.BTN_LADDERBACK) 
    mBtnBlackBack:setOnClickScriptHandler( onBtnOkClick )

    mBtnOk  = window:getChildByTag(Tag_rewardwnd.BTN_LADDEROK) 
    mBtnOk:setOnClickScriptHandler( onBtnOkClick )

    mImgIcon = window:getChildByTag(Tag_rewardwnd.IMG_LADDERICON)  

    mTxtTitle = window:getChildByTag(Tag_rewardwnd.LABEL_LADDERTITLE) 
    mTxtTitle:setString(DataManager:getStringDataTxt( 4106, true ))
    mTxtScore = window:getChildByTag(Tag_rewardwnd.LABEL_LADDERSCORE) 
--    mTxtScore:setString(DataManager:getStringDataTxt( 4107, true ).."\n"..)

    mCurState = 0
    local char = CharacterManager:getMainPlayer()

    local honour = tonumber(UserDefaultManager:getStringForKey( "LadderReward" ))
    mTxtScore:setString(DataManager:getStringDataTxt( 4107, true ).."\n"..honour)

    local rankList = DataManager:getDataRank()
    local rankData

    local rankData
    for i=1, #rankList do        
        if rankList[i] and rankList[i].integral >= honour then
            rankData = rankList[i]
            break
        end      
    end
    if rankData then
        mImgIcon:setTexture("other/rankIcon/"..rankData.icon..".png")
    end

    local rewardList = {}
    local rewardData = DataManager:getDataReward(rankData.reward_id)   

    local obj = {rewardType = 3, id = rewardData.gold_reward, num = rewardData.gold_reward}
    table.insert(rewardList, obj)

    local card_reward =  string.split(rewardData.card__reward, ",")
    if card_reward[1]~=nil and card_reward[1]~="" then
        local cardDataStr = string.split(card_reward[1], "#")
        obj = {rewardType = 2, id = tonumber( cardDataStr[1] ), num = tonumber( cardDataStr[2] )}
        table.insert(rewardList, obj)
    end

    local pack_reward =  string.split(rewardData.pack__reward, ",")
    for i = 1, #pack_reward do
         if pack_reward[i]~=nil and pack_reward[i]~="" then
            local packData = string.split(pack_reward[i], "#")
            obj = {rewardType = 1, id = tonumber( packData[1] ), num = tonumber( packData[2] )}
            table.insert(rewardList, obj)
         end        
    end
   
   mBoxList = {}
       --初始化宝箱
    local tempBox = require("TaskWnd.LadderRewardImg")
    local box
    for i = 1, #rewardList do
        box = tempBox.new()
        box:init(rewardList[i])
--        box:setPosition(-700 + i*200, -93)
--        box:setPosition(-715 + i*205, 88)
        box:setPosition( -640 + 102 + (1280 - 205 * #rewardList) * 0.5 + 205 * (i - 1), 0 )
        box.oldPos = { x = box:getPositionX(), y = box:getPositionY() }
--        box:setOpacity(1)
        window:addChild(box)
        box:setOnClickScriptHandler( clickRewardImg )
        box:setVisible(false)
        table.insert(mBoxList, box)
    end

    UserDefaultManager:setStringForKey("LadderReward", "0")
    LadderRewardWindow.isShow = true  
end


function LadderRewardWindow:onExitScene()
    window = nil
--    UILoadManager:delResByArr( resArr )
    LadderRewardWindow.isShow = false
    if TaskWindow.isShow == true then
        TaskWindow:close()
    end
--    UserDefaultManager:setStringForKey("LadderReward", "0")
end