LadderRewardImg = class("LadderRewardImg", function() 
    return CImageView:create()
--    return ccui.Widget:create()
end)

local war2CardManager = require("war2.war2CardManager"):instance()

--点击自身
local function clickThis( tempSelf )
    tempSelf:updateByState( 3 )
end

------------战斗结束后的开宝箱界面的宝箱元件--------------
--初始化
function LadderRewardImg:init( reward )
    self.mReward = reward
    --是否显示状态
    self.mIsVisible = true
    --是否已经打开了
    self.mIsOpened = false
    --容器
    self.mBoxVec = cc.Sprite:create()
    local size = {width = 190, height = 250}

    local posX = size.width * 0.5
    local posY = size.height * 0.5

    self.mBoxImage = cc.Sprite:create("openbox/img_Box.png")
    self.mBoxImage:setPosition(posX, posY)
    self.mBoxVec:addChild(self.mBoxImage)

    self.cardUI = require("war2.cardMiddle").new()
    self.cardUI:setScale(1)
    self.cardUI:init(0)
--    self.cardUI:setRotation(15)
    self.cardUI:setPosition( posX, posY )
    self.mBoxVec:addChild( self.cardUI )

    self.GoldImg = cc.Sprite:create("other/img_FewGold.png")
    self.GoldImg:setPosition(posX, posY - 40)
    self.mBoxVec:addChild(self.GoldImg)

    self.StoneImg = cc.Sprite:create("other/img_MoreGold.png")
    self.StoneImg:setPosition(posX, posY - 25)
    self.mBoxVec:addChild(self.StoneImg)

    self.PackImg = cc.Sprite:create("other/img_test.png")
    self.PackImg:setPosition(posX, posY)
    self.PackImg:setScale(0.8)
    self.mBoxVec:addChild(self.PackImg)

    self.mTxtGold = CLabelBMFont:create( 0, "fonts/labBmf_BitFont+02.fnt" )--TextManager:createTxt( "", 26, TXTFONTNAME, 0, 0, 1, 1, cc.c4b(229,185,108,255) )
    self.mTxtGold:setAlignment( 1, 0 )
    self.mTxtGold:setDimensions(80, 30)
    self.mTxtGold:setPosition(20+ posX, -100+ posY)
    self.mBoxVec:addChild( self.mTxtGold )

    self:addChild(self.mBoxVec)
    self.mBoxVec:setContentSize( size.width, size.height )
    self.mBoxVec:setPosition( posX, posY )
    self:setContentSize(size.width, size.height)
--    self:setOnClickScriptHandler( clickThis )
    self:updateByState(2)
end

--更新
function LadderRewardImg:updateByReaward()
    local reward = self.mReward

    if reward.rewardType == 1 then         --是卡包的时候
        self.cardUI:setVisible(false)
        self.GoldImg:setVisible(false)
        self.StoneImg:setVisible(false)
        self.mTxtGold:setVisible(true)
        self.PackImg:setVisible(true)

        self.PackImg:setTexture("other/img_Pack_"..reward.id..".png")
        self.mTxtGold:setString( "X"..reward.num )
    elseif reward.rewardType == 2 then         --是卡牌的时候
        self.cardUI:setVisible(true)
        self.GoldImg:setVisible(false)
        self.StoneImg:setVisible(false)
        self.mTxtGold:setVisible(false)
        self.PackImg:setVisible(false)

        self.cardUI:setCard( reward.id )
    elseif reward.rewardType == 3 then        --是金币的时候
         self.cardUI:setVisible(false)
         self.GoldImg:setVisible(true)
         self.StoneImg:setVisible(false)
         self.mTxtGold:setVisible(true)
         self.PackImg:setVisible(false)

         self.mTxtGold:setString( "X"..reward.num )
    elseif reward.rewardType == 4 then        --是宝石的时候
         self.cardUI:setVisible(false)
         self.GoldImg:setVisible(false)
         self.StoneImg:setVisible(true)
         self.mTxtGold:setVisible(true)
         self.PackImg:setVisible(false)

         self.mTxtGold:setString( "X"..reward.num )
    end

end

--更新
function LadderRewardImg:updateByState( state )
    if state == nil or self.mIsOpened == true then state = OpenBoxManager.State end--0初始，1初始道具 2选择宝箱道具 3钻石选择宝箱道具 4已经开过箱子了
    if self.mIsOpened == true then state = 1 end  --如果已经是打开了,则直接显示初始状态即可
    if state == 0 then
        return 
    end
    self.mBoxImage:setVisible(false)
    self.cardUI:setVisible(false)
    self.GoldImg:setVisible(false)
    self.StoneImg:setVisible(false)
    self.mTxtGold:setVisible(false)

    if state == 1 then
        self:updateByReaward()
    elseif state == 2 then
        self.mBoxImage:setVisible(true)
    elseif state == 3 then
        self.mBoxImage:setVisible(true)
    end
end

--清空、删除
function LadderRewardImg:clear()

end

--翻转效果
function LadderRewardImg:playTurnEff()
    local mLayEnd=war2FightScene:getmLayEnd()
    sp = TextureManager:getSprite( self.mBoxVec )

    local tx2d = sp:getTexture()
    local diy = TextureManager:getDiyEffect(100598, tx2d)
    local hyDiy = EffectManager:createHnyEffect( 100598, {x = 128, y = 128}, {x = 0, 0}, diy )

    self:addChild( hyDiy, 99 ) 
--    self.mBoxVec:setVisible(false)
    EffectManager:startHnyEffect( hyDiy )
end



return LadderRewardImg