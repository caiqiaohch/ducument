local TaskManager = class()-- 定义一个类 test 继承于 base_type

function TaskManager:ctor()

	print("TaskManager:ctor --------------------------")
	
end

DataManager = require("data.DataManager"):instance()

function TaskManager:instance()
    local o = _G.TaskManager
    if o then
    	return o
	end
 
    o = TaskManager:new()
	_G.TaskManager = o
    TaskManager:init()
    return o
end

--初始化
function TaskManager:init()
    --删除成功数组
    self.mIsDelArr = {}
    --[任务ID %d][目标数量 %c]   {id=任务ID num=当前的目标数量}
    self.TaskDataArr = {}
    --[任务ID %d][目标数量 %c]   [id:任务ID]=目标数量: num
    self.TaskOldDataArr = {}
    --是否是等待4102发送结束标记
    self.BolWaiting = false

     --是否是等待5102发送结束标记
    self.BolAchWaiting = false
    --[成就ID %d][目标数量 %c]   {id:成就ID, num:目标数量}
    self.AchieveDataArr = {}

    --是否要打开MainTaskWindow
    self.BolOpenMainTask = false

    --是否已经刷新过任务
    self.isRefreshTask = false


    --奖励列表
    self.RewardDataList = {}
end

--获取已完成成就ID列表
function TaskManager:getFinishedAchList()
    local list = {}
    for k, v in pairs(DataManager.DataAchieveClass) do
        table.insert(list, k)
    end
    local data
    local class
    for i = 1, #self.AchieveDataArr do
        data = DataManager:getAchieve( self.AchieveDataArr[i].id )
        if data then
            class = data.class
            if table.indexof(list, class) ~= false then
                table.remove(list, table.indexof(list, class))
            end
        end
    end
    table.sort(list)  --从小到大排序

    local rList = {}
    for i = 1, #list do
--        print(list[i])
        data = DataManager.DataAchieveClass[list[i]][#DataManager.DataAchieveClass[list[i]]]
        table.insert( rList, {id = data.quest_id, num = data.amount, isFinished = true} )        
    end
    return rList
end

--根据成就ID判断成就是否已经完成
function TaskManager:getAchFinished( id )
    local achData = DataManager:getAchieve( id )
    if achData == nil then return false end
    local list = {}
    for i = 1, #self.AchieveDataArr do
        data = DataManager:getAchieve( self.AchieveDataArr[i].id )
        if data and achData.class == data.class then
            if achData.quest_id < data.quest_id then  --如果成就ID比较小,这表示是之前已经完成的成就
                return true
            elseif self.AchieveDataArr[i].num == data.amount and achData.quest_id == data.quest_id then  --如果是已经完成了的成就,成就ID一样也可以是已经完成的成就    
                return true
            else
                return false --否则同种类的成就就是未完成的成就
            end
        end
    end
    return true  --不属于现在有后台发送数据的成就的同种类成就都是已经完成了的成就
end


--修改一个任务已完成的数量, 不存在的话增加,num为nil表示的是要删除
function TaskManager:setTaskData( id, num )
    if num == nil then
        for i = 1, #self.TaskDataArr do
            if self.TaskDataArr[i].id == id then
                table.remove( self.TaskDataArr, i )
                return
            end
        end
        return
    end
    for i = 1, #self.TaskDataArr do
        if self.TaskDataArr[i].id == id then
            self.TaskDataArr[i].num = num
            return
        end
    end
    table.insert( self.TaskDataArr, {id = id, num = num} )
end

--根据ID获取一个任务数据{id=任务ID num=当前的目标数量}
function TaskManager:getTaskData( id )
    for i = 1, #self.TaskDataArr do
        if self.TaskDataArr[i].id == id then
            return self.TaskDataArr[i]
        end
    end
    return nil
end



--判断是否在套组区域内，并返回位置,传入坐标基于舞台左下角为0点
function TaskManager:checkTouchBattle( _x, _y )
    if CollectionScWnd.mIsLeave == false then return false end
     if _x < 943 or _x > 1263 or _y < 97 or _y > 607 then return false end
    return true
end


--mType  1:npc, npcid, 2:任务, 任务id, 3:成就, 成就Id， 4竞技场奖励 5新手礼包 6 月卡每日奖励
function TaskManager:setRewardData( mType, id )
    print( "setRewardData "..mType..","..id)
    local strList
    local reward
    local nameStr
    local str
    if mType == 1 then --npc奖励
        reward = DataManager:getDataMapNpcbyDi( id )
        if reward == nil then return end
        strList = { "g_cash", "g_gem", "g_card", "g_pack" }
        str = DataManager:getStringDataTxt(4008, true)
        nameStr = DataManager:getStringDataTxt(4007, true)
        str = string.gsub(str,"$1", reward.npc_name)
    elseif mType == 2 then --任务奖励
        reward = DataManager:getTask( id )
        if reward == nil then return end
        strList = { "gold_reward", "gem_reward", "card__reward", "pack__reward", "arenapoint_reward" }
        nameStr = DataManager:getStringDataTxt(4014, true)
        str = reward.quest_name.."\n"..string.gsub(reward.quest_require,"$1", reward.amount)
    elseif mType == 3 then --成就奖励
        reward = DataManager:getAchieve( id )
        if reward == nil then return end
        strList = { "gold_reward", "gem_reward", "card__reward", "pack__reward", "arenapoint_reward" }
        nameStr = DataManager:getStringDataTxt(4013, true)
        str = reward.quest_name.."\n"..string.gsub(reward.quest_require,"$1", reward.amount)
    elseif mType == 4 then --竞技场奖励
        reward = DataManager:getDataReward( id )
        if reward == nil then return end
        strList = { "gold_reward", "gem_reward", "card__reward", "pack__reward", "arenapoint_reward" }
        nameStr = DataManager:getStringDataTxt(4007, true)
        local winNum = 0
        if id > 5050 then
            winNum = id - 5054 --因为编号写死的,所以直接通过奖励ID获取胜场
            if winNum > 5 then winNum = 5 end
        else
            winNum = id - 5030 --因为编号写死的,所以直接通过奖励ID获取胜场
            if winNum > 5 then winNum = 5 end
        end
        str = string.gsub(DataManager:getStringDataTxt(4068, true),"$1", winNum)

        RewardWindow:setCloseFun( function() 
            require("framework.scheduler").performWithDelayGlobal( function () 
            if ArenaWindow.isShow == true then
                ArenaWindow:closeWindow() end end, 0.5 )
             end)
    elseif mType == 5 then --新手礼包奖励
        reward = {}
        if reward == nil then return end
        strList = { "gold_reward", "gem_reward", "card__reward", "pack__reward", "arenapoint_reward" }
        reward.gold_reward = 0
        reward.gem_reward = 0
        reward.card__reward = ""
        reward.pack__reward = "101003#1,100011#20,100013#6"
        nameStr = DataManager:getStringDataTxt(4118, true)
        str = ""--reward.quest_name.."\n"..string.gsub(reward.quest_require,"$1", reward.amount)
    elseif mType == 6 then --月卡每日奖励
        reward = {}
        if reward == nil then return end
        strList = { "gold_reward", "gem_reward", "card__reward", "pack__reward", "arenapoint_reward" }
        reward.gold_reward = 0
        reward.gem_reward = id
        reward.card__reward = ""
        reward.pack__reward = ""
        nameStr = DataManager:getStringDataTxt(4119, true)
        str = ""
    end
    if reward == nil then return end

    local rewardObj = {}
    rewardObj.rewardList = {}
    local obj = {}
    obj.Icon = 1
    obj.TxtTitle = nameStr
    obj.TxtName = DataManager:getStringDataTxt(4009, true)
    obj.TxtNum = ""
    obj.TxtTips = str 
    table.insert( rewardObj.rewardList, obj ) 

    if reward[ strList[1] ] > 0 then --有金币奖励
        obj = {}
        obj.Icon = 2
--        obj.TxtName = DataManager:getStringDataTxt(5002, true)  
        obj.TxtNum = "×"..reward[ strList[1] ]
        table.insert( rewardObj.rewardList, obj ) 
    end  
    if reward[ strList[2] ] > 0 then --有宝石奖励         
        obj = {}
        obj.Icon = 3
--        obj.TxtName = DataManager:getStringDataTxt(5003, true)  
        obj.TxtNum = "×"..reward[ strList[2] ]
        table.insert( rewardObj.rewardList, obj )   
    end
    if reward[ strList[3] ] ~= "" then --有卡牌奖励         
        obj = {}
        obj.Icon = 4
        local cardReward = string.split( reward[ strList[3] ],  "," )
        for i = 1, #cardReward do
            obj = {}
            obj.Icon = 4
            local cardStr = string.split( cardReward[i], "#" )
            local cardData = DataManager:getCardObjByID( cardStr[1] )
            if cardData == nil then cardData = DataManager:getEq( cardStr[1] ) end
    --        obj.TxtName = cardData["name_text_"..LANGUAGE]
            obj.TxtNum = "×"..cardStr[2]
            obj.cardId = tonumber(cardStr[1])
            table.insert( rewardObj.rewardList, obj )   
        end     
    end
    if reward[ strList[4] ] ~= "" then --有卡包奖励   
        local packReward = string.split( reward[ strList[4] ],  "," )
        for i = 1, #packReward do
            obj = {}
            obj.Icon = 5
            local packStr = string.split( packReward[i], "#" )
            local item = ItemManager:getItemData( packStr[1] )
--        obj.TxtName = item.item_name_id
            obj.TxtNum = "×"..packStr[2]
            obj.imgUrl = "other/img_Pack_"..item.item_id..".png"        
            table.insert( rewardObj.rewardList, obj )   
        end         
    end

    if reward[ strList[5] ] and reward[ strList[5] ] > 0 then --有竞技场点券奖励         
        obj = {}
        obj.Icon = 6
--        obj.TxtName = DataManager:getStringDataTxt(5003, true)  
        obj.TxtNum = "×"..reward[ strList[5] ]
        table.insert( rewardObj.rewardList, obj )   
    end

    if #rewardObj.rewardList > 1 then  --大于1表示有奖励
        table.insert( self.RewardDataList, rewardObj )
        if (MainWindow.isShow == true or StoryWindow.isShow == true or ArenaWindow.isShow == true) and RewardWindow.isShow == false then
            if mType == 2 and reward.quest_type == 5 and FightWnd.isShow == true then 
                return  --特殊类型特殊处理
            end
            RunScene("RewardWindow")
        end  
    end
end

return TaskManager