require "tagMap.Tag_taskwnd"
TaskWindow = class("TaskWindow",function()
	return TuiBase:create()
end)

local CharacterManager = require("characters.CharacterManager"):instance()
local DataManager = require("data.DataManager"):instance()
local TaskManager = require("TaskWnd.TaskManager"):instance()
local ServMsgTransponder = require("net.ServMsgTransponder")
local TextManager = require("ui.TextManager"):instance()

local resArr = { PLIST_TASK_URL, PLIST_WAR2_URL, PLIST_CARDMIDDLEUI_URL, PLIST_CARDUI_URL }
local __instance = nil
--总容器
local window = nil
--任务容器数组
local mTaskArr = {}

local mLayoutMain
local mMoveAlpha

local mBolPlaying = false

--上次点击要更换的任务ID与排序索引
local mChangeObj

TaskWindow.isShow = false
TaskWindow.open = false

function TaskWindow:create()
	local ret = TaskWindow.new()
    ret:setAutoRemoveUnusedSpriteFrame(true)
	__instance = ret
	ret:setOnLoadSceneScriptHandler(function() ret:onLoadScene() end)
    ret:setOnExitSceneScriptHandler(function() ret:onExitScene() end)
	return ret
end

function TaskWindow:getPanel(tagPanel)
	local ret = nil
		ret = self:getChildByTag(tagPanel)
	return ret
end


function TaskWindow:close()
    PopScene(__instance)
end

        
--播放界面打开动态效果
local function playOpenEffect()
    if mBolPlaying == true then return end
   
    local sp
    local tx2d
    local tList = {0.01, 0.1, 0.3}
    for i = 1, 3 do
        if TaskManager.TaskDataArr[i] == nil then
             mTaskArr[i].layout:setVisible(false)
        else
            mBolPlaying = true
            sp = TextureManager:getSprite( mTaskArr[i].layout  ) --mTaskArr[i].sprite  --TextureManager:getSprite( sp2 )
            tx2d = sp:getTexture()
            diy = TextureManager:getDiyEffect(100681 , tx2d)
            effect = EffectManager:createHnyEffect( 100681 , {x = mTaskArr[i].layout:getPositionX(), y = mTaskArr[i].layout:getPositionY()}, nil, diy ) 
            window:addChild(effect)
            mTaskArr[i].layout:setVisible(false)
            EffectManager:startHnyEffect( effect, { time = tList[i], key = function () mTaskArr[i].layout:setVisible(true) end } )
        end
    end
    mLayoutMain:setOpacity(0)
    local fun = function ()    
        mMoveAlpha = require("Mov.MovAlpha").new()
        mMoveAlpha:init( mLayoutMain, 255,  15 )
        mMoveAlpha.callBackFucFinished = function() mBolPlaying = false end
        require("Mov.MovManager"):instance():pushMov( mMoveAlpha )        
    end

    require("framework.scheduler").performWithDelayGlobal( function () fun() end, 0.5 )
    if LadderRewardWindow.isShow == true then
        __instance:setVisible(false)
    end
end

--播放界面关闭动态效果
local function playCloseEffect()
    if mBolPlaying == true then return end
    local sp
    local tx2d    
    local tList = {0.01, 0.1, 0.3}
    for i = 1, 3 do
        if TaskManager.TaskDataArr[i] == nil then
             mTaskArr[i].layout:setVisible(false)
        else
            mBolPlaying = true
            sp = TextureManager:getSprite( mTaskArr[i].layout  ) --mTaskArr[i].sprite  --TextureManager:getSprite( sp2 )
            tx2d = sp:getTexture()
            diy = TextureManager:getDiyEffect(100694 , tx2d)
            effect = EffectManager:createHnyEffect( 100694 , {x = mTaskArr[i].layout:getPositionX(), y = mTaskArr[i].layout:getPositionY()}, nil, diy ) 
            window:addChild(effect)
--            effect:close( function () mBolPlaying = false TaskWindow:close() end )
            mTaskArr[i].layout:setVisible(false)
            EffectManager:startHnyEffect( effect, { time = tList[i] } )
        end
    end
    if mBolPlaying == false then
        TaskWindow:close()--如果已经没有特效需要播放了,直接关闭
    end

    local fun = function ()    
        if mLayoutMain then
            mMoveAlpha = require("Mov.MovAlpha").new()
            mMoveAlpha:init( mLayoutMain, 0,  25 )
            mMoveAlpha.callBackFucFinished = function() mBolPlaying = false TaskWindow:close() end
            require("Mov.MovManager"):instance():pushMov( mMoveAlpha )            
        end
    end

    require("framework.scheduler").performWithDelayGlobal( function () fun() end, 0.3 )
end

--播放任务变更动态效果
function TaskWindow:playChangeEffect()
    if mBolPlaying == true or mChangeObj == nil then return end
    mBolPlaying = true


    local taskObj = mTaskArr[mChangeObj.idx]
    taskObj.layout:setVisible(true)
    taskObj.changeImg = TextureManager:getSprite( taskObj.layout  )

    local tx2d = taskObj.changeImg:getTexture()
    local diy = TextureManager:getDiyEffect(100693 , tx2d)
    local effect = EffectManager:createHnyEffect( 100693 , {x = taskObj.layout:getPositionX(), y = taskObj.layout:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    EffectManager:startHnyEffect( effect )
    taskObj.changeImg:release()
    taskObj.changeImg = nil
    mChangeObj = nil

    TaskWindow:UpDataTaskMsg(true)

    taskObj.layout:setVisible(true)
    local sp = TextureManager:getSprite( taskObj.layout  )

    tx2d = sp:getTexture()
    diy = TextureManager:getDiyEffect(100681 , tx2d)
    effect = EffectManager:createHnyEffect( 100681 , {x = taskObj.layout:getPositionX(), y = taskObj.layout:getPositionY()}, nil, diy ) 
    window:addChild(effect)
    taskObj.layout:setVisible(false)
    EffectManager:startHnyEffect( effect, {time = 0.6, key = function () taskObj.layout:setVisible(true) mBolPlaying = false end })
end


--任务刷新按钮点击事件
local function onBtnClick(p_sender)
    local i = tonumber(p_sender:getName())
    mChangeObj = { idx = i, id = TaskManager.TaskDataArr[i].id }
    ServMsgTransponder:SMTDailyRefresh( TaskManager.TaskDataArr[i].id ) 
    TaskManager.isRefreshTask = true   
--require("framework.scheduler").performWithDelayGlobal( function () TaskWindow:UpDataTaskMsg() end, 0.2 )
end


--初始层
local function initLay( tempSelf )
    window = tempSelf:getChildByTag(Tag_taskwnd.PANEL_MAIN)
    mLayoutMain = window:getChildByTag(Tag_taskwnd.LAYOUT_MAIN)

    mTaskArr = {}
    local mLayoutTask
    for i = 1, 3 do
        mLayoutTask = window:getChildByTag(Tag_taskwnd["LAYOUT_TASK"..i])
--        table.insert( mTaskArr, mLayoutTask )
        mTaskArr[i] = {}

        mTaskArr[i].layout = mLayoutTask        

        mTaskArr[i].img_PrizeIcon = mLayoutTask:getChildByTag(Tag_taskwnd["IMG_PRIZEICON"..i])
        mTaskArr[i].img_Pack = mLayoutTask:getChildByTag(Tag_taskwnd["IMG_PACKICON"..i])

        mTaskArr[i].label_taskName = mLayoutTask:getChildByTag(Tag_taskwnd["LABEL_TASKNAME"..i])
        mTaskArr[i].labBmf_num = mLayoutTask:getChildByTag(Tag_taskwnd["LABBMF_NUM"..i])
        mTaskArr[i].labBmf_Pack_num = mLayoutTask:getChildByTag(Tag_taskwnd["LABBMF_PACK_NUM"..i])
        mTaskArr[i].label_msg = mLayoutTask:getChildByTag(Tag_taskwnd["LABEL_MSG"..i])
        mTaskArr[i].labbmf_taskNum = mLayoutTask:getChildByTag(Tag_taskwnd["LABBMF_TASKNUM"..i])

        mTaskArr[i].btn_reset = mLayoutMain:getChildByTag(Tag_taskwnd["BTN_RESET"..i])
        mTaskArr[i].btn_reset:setName(i)
        mTaskArr[i].btn_reset:setOnClickScriptHandler(onBtnClick)

        mTaskArr[i].cardUI = require("war2.cardMiddle").new()
        mTaskArr[i].layout:addChild( mTaskArr[i].cardUI )
        mTaskArr[i].cardUI:setPosition( 0, 0 )
    end
end
-----------------------------点击触发事件--------------------------
--遮罩按钮点击事件
local function onCloseClick(p_sender)
    playCloseEffect()
end
-----------------------------点击触发事件--------------------------//

--更新任务内容
function TaskWindow:UpDataTaskMsg( bolUpdate )
    if bolUpdate ~= true and (mChangeObj ~= nil or mBolPlaying == true) then
--        TaskWindow:playChangeEffect()
        return
    end
    local arr = TaskManager.TaskDataArr
    showNum = 0 --显示数量
    for i = 1, 3 do
        if TaskManager.TaskDataArr[i] == nil then
             mTaskArr[i].layout:setVisible(false)
             mTaskArr[i].btn_reset:setVisible(false)
        else
            if TaskManager.isRefreshTask == true then
                mTaskArr[i].btn_reset:setVisible(false)
            else
                mTaskArr[i].btn_reset:setVisible(true)
            end
            mTaskArr[i].layout:setVisible(true)
            reward = DataManager:getTask( TaskManager.TaskDataArr[i].id )
            mTaskArr[i].label_taskName:setString( reward.quest_name )
            local str = string.gsub(reward.quest_require,"$1", reward.amount)
            mTaskArr[i].label_msg:setString( str ) 
            mTaskArr[i].labbmf_taskNum:setString( TaskManager.TaskDataArr[i].num.."/"..reward.amount)
            

            mImgPrizeIcon = mTaskArr[i].img_PrizeIcon
            mImgPack = mTaskArr[i].img_Pack
            cardUI = mTaskArr[i].cardUI
            txtNum = mTaskArr[i].labBmf_Pack_num

            mImgPrizeIcon:setVisible(false)
            mImgPack:setVisible(false)
            cardUI:setVisible(false)
            if reward.gold_reward > 0 then --金币                
                mImgPrizeIcon:setVisible(true)
                mImgPrizeIcon:setTexture( "other/img_PrizeIcon+3.png" )
                mTaskArr[i].labBmf_num:setString( "x"..reward.gold_reward )
		        require("Music.MusicManager"):instance():PlaySound( 102 )   
	        elseif reward.gem_reward > 0 then --宝石
                mImgPrizeIcon:setVisible(true)
                mImgPrizeIcon:setTexture( "other/img_PrizeIcon+2.png" )
                mTaskArr[i].labBmf_num:setString( "x"..reward.gem_reward )
		        require("Music.MusicManager"):instance():PlaySound( 102 )
            elseif reward.card__reward ~= "" then --卡牌
                local cardStr = string.split( reward.card__reward, "#" )
                local cardData = DataManager:getCardObjByID( cardStr[1] )
                if cardData == nil then cardData = DataManager:getEq( cardStr[1] ) end
--                obj.TxtName = cardData["name_text_"..LANGUAGE]

                mImgPrizeIcon:setVisible(false)
                cardUI:setVisible(true)
                cardUI:init(cardData.id)
                txtNum:setString( "x"..cardStr[2] )
            elseif reward.arenapoint_reward and reward.arenapoint_reward > 0 then --竞技场点券                
                mImgPrizeIcon:setVisible(true)
                mImgPrizeIcon:setTexture( "other/img_PrizeIcon+4.png" )
                mTaskArr[i].labBmf_num:setString( "x"..reward.arenapoint_reward )
		        require("Music.MusicManager"):instance():PlaySound( 102 )               
            end    
            if reward.pack__reward ~= "" then --卡包
                local packReward = string.split( reward.pack__reward, "," )
                for i = 1, #packReward do
                    local packStr = string.split( packReward[i], "#" )
                    local item = ItemManager:getItemData( packStr[1] )
                    local imgUrl
                    imgUrl = "other/img_Pack_"..item.item_id..".png"
                    mImgPack:setVisible(true)
                    mImgPack:setTexture( imgUrl )
                    txtNum:setString( "x"..packStr[2] )
                end     
            end 

            if mImgPack:isVisible() == true and mImgPrizeIcon:isVisible() == false then
                mTaskArr[i].labBmf_num:setString( "" )
                mImgPack:setPositionX(150)
                txtNum:setPositionX(105)
            elseif mImgPack:isVisible() == false and mImgPrizeIcon:isVisible() == true then
                txtNum:setString( "" )
                mImgPrizeIcon:setPositionX(150)
                mTaskArr[i].labBmf_num:setPositionX(105)
            end

            showNum = showNum + 1
        end        
    end
    --排版
    for i = 1, showNum do
        mTaskArr[i].layout:setPositionX( -600 + (900 - 300 * showNum) * 0.5 + 300 * i )
        mTaskArr[i].btn_reset:setPositionX( mTaskArr[i].layout:getPositionX() + mLayoutMain:getContentSize().width * 0.5  - 130)
    end
end

function TaskWindow:onLoadScene()
    UILoadManager:loadResByArrAsync( resArr, function () self:onEnterScene() end )
end

function TaskWindow:onEnterScene()
    TuiManager:getInstance():parseScene(self,"panel_main",PATH_TASKWND)
    initLay( self )

    local Btn = window:getChildByTag(Tag_taskwnd.BTN_WINDOWBACK)
    Btn:setOnClickScriptHandler(onCloseClick)

    Btn = mLayoutMain:getChildByTag(Tag_taskwnd.BTN_CLOSE)
    Btn:setOnClickScriptHandler(onCloseClick)

    self:UpDataTaskMsg()

    TaskWindow.isShow = true
    TaskWindow.open = false
    TaskManager.BolOpenMainTask = false
    playOpenEffect()
end


function TaskWindow:onExitScene()
    window = nil
    UILoadManager:delResByArr( resArr )
    TaskWindow.isShow = false
    mBolPlaying = false
    mChangeObj = nil
    mLayoutMain = nil
    if mMoveAlpha ~= nil then
        require("Mov.MovManager"):instance():delMov( mMoveAlpha )
        mMoveAlpha = nil
    end
end