CharModel = class("CharModel", function() 
    return cc.Sprite:create()
end)

local UPDATETIME = { 100, 200, 200, 200 }
local ATKANDHPFONT = "fonts/labBmf_MpNumberFont48.fnt"

--模型各个方向的合并好的sprite列表
function CharModel:init()
    --底盘
--    self.mChassisImage = cc.Sprite:create( "model/59003/1.png" )
--    self.SpContain = cc.Sprite:create()
--    self.SpContain:addChild( self.mChassisImage )

--    self.mImage = cc.Sprite:create()
----    self.mImage:addChild( self.mChassisImage )
--    self.SpContain:addChild( self.mImage )
--    self:addChild(self.SpContain)
    self.mChassis = require("model.config."..59003)
    self.mChassisID = 59003
    self.DirSpriteList = {}
    self.hp = 0
    self.curAtk = 0
    self:setShowParent( self.mPos )
end

--设置显示模型 模型ID
function CharModel:setModel( id )
    if self.ModelID == id then return end
    self:reset()
    if id == 0 then return end
    self.ModelID = id
    local Manager = require("model.CharModelManager"):instance()
    self.ModelData = Manager:getCharData(id)
    if self.ModelData == nil then print(123123) return end
    Manager = require("data.DataManager"):instance()
    self.ModelControlData = Manager:getModelData(id)
    self.curFrame = 0
--    self.mImage:setVisible(true)
    self.mAction = 1
end

function CharModel:getModelTexture()
    return self.SpContain:getTexture()
end

--设置模型所在位置 1战场 2卡牌
function CharModel:setShowParent( mPos )
    self.mPos = mPos
    local _sc = 1
    if self.ModelControlData~= nil and mPos ~= 0 then _sc = self.ModelControlData["ratio"..mPos]/100 end
--    self:setScale( _sc )
--    self.mChassisImage:setVisible( self.mPos == 1 )
end

--重置定位坐标
function CharModel:resPos()
    self.initX,self.initY = self:getPosition()
end

--设置模型动作
function CharModel:setAction( action, isHold, isResFrame )
    --清理内存
    self:clearMemory()

    self.mAction = action
    self.isHold = isHold == true or action == 1
    self.curFrame = 0
    if isResFrame == true then
        self:update()
    end
end

--设置模型方向
function CharModel:setDir( dir, isResFrame )
    self.mDir = dir
    self.curFrame = 0
    if isResFrame == true then 
        self:update()
    end
end


--更新模型
function CharModel:update( time, bolNewModel )
--if self.bmake == true or self.bmake == nil then 
--return
--end
    if self.ModelData == nil then return end
    local updateTime = 0 
    if self.ModelControlData~= nil then updateTime = self.ModelControlData["act"..self.mAction.."_fps"] end
    if updateTime == nil or updateTime == 0 then updateTime = UPDATETIME[self.mAction] end

    local data = self.ModelData[self.mAction][self.mDir]
    local totalFrame = data.Frames
    if self.curFrame + 1 > totalFrame then   
        if self.isHold == false then
            self:setAction( 1 )
            self.isHold = true
            data = self.ModelData[self.mAction][self.mDir]
        end
        self.curFrame = 1
    else
        self.curFrame = self.curFrame + 1
    end
    data = data[self.curFrame]
    local msgStr = self.ModelData.resID..";"..self.mAction..";"..self.mDir..";"..self.curFrame

    self:setName( msgStr.."="..data.BangPointStr )
    if self.DirSpriteList[msgStr] == nil or bolNewModel == true then
        if self.SpContain ~= nil then
            if self.SpContain:getParent() then
                self.SpContain:removeFromParent()
            end
            self.SpContain:release()
            self.SpContain = nil
        end
        local addPos = data.BangPoint[0]
        data = { x = data[1], y = data[2], width = data[3], height = data[4] }
        --self:setTexture( getTexture( self.ModelID.."A1A7A1", "model/50001/1.png", data ) )
        local mImg = cc.Sprite:create()
        mImg:setTexture( "model/"..self.ModelID.."/"..self.mAction..".png" )
        mImg:setTextureRect( data )
--        data = { x = data[1], y = data[2], width = data[3], height = data[4] }
        mImg:setPosition( addPos[1] , addPos[2]  )
         --底盘**************
        data = self.mChassis[1][self.mDir][1]
        addPos = data.BangPoint[6]
        --模型位置加上坐点
        local addSpPos = {x = 420, y = 420} --偏移位置,暂时写死420
        mImg:setPosition( mImg:getPositionX() + addPos[1] + addSpPos.x, mImg:getPositionY() + addPos[2] + addSpPos.y )
        addPos = data.BangPoint[0]
        data = { x = data[1], y = data[2], width = data[3], height = data[4] }
        local mChassisImg = cc.Sprite:create( "model/"..self.mChassisID.."/1.png" )
        mChassisImg:setTextureRect( data )
        mChassisImg:setPosition( addPos[1] + addSpPos.x, addPos[2] + addSpPos.y)

        --攻、血底图
        local mAtkImage = CImageView:createWithSpriteFrameName("war2/cardUI/middle/AttackCardM.png")
        local mHpImage = CImageView:createWithSpriteFrameName("war2/cardUI/middle/HpCardM.png")

        --文本框
        if self.hpFont == nil then self.hpFont = ATKANDHPFONT end
        if self.atkFont == nil then self.atkFont = ATKANDHPFONT end
        local mTxtAtk = CLabelBMFont:create( self.curAtk, self.atkFont )
        mTxtAtk:setAlignment( 1, 0 )
        mTxtAtk:setDimensions(72, 40)

        local mTxtHp = CLabelBMFont:create( self.hp, self.hpFont )
        mTxtHp:setAlignment( 1, 0 )
        mTxtHp:setDimensions(72, 40)

        mAtkImage:setPosition( mChassisImg:getPositionX() - 50, mChassisImg:getPositionY()-10 )
        mHpImage:setPosition( mChassisImg:getPositionX() + 40, mChassisImg:getPositionY()-10 )
        mTxtAtk:setPosition( mChassisImg:getPositionX() - 50, mChassisImg:getPositionY() )
        mTxtHp:setPosition( mChassisImg:getPositionX() + 50, mChassisImg:getPositionY() )
--        local chsRec = { width = data.width + addPos[1] + rec.x, height = data.height + addPos[2] + rec.y }
        --底盘**************


--        rec.width =  rec.width + data.width
        local rec = {x=0, y=0, width = 500, height = 500}
        local _sc = 1
        if self.ModelControlData~= nil and self.mPos ~= 0 then _sc = self.ModelControlData["ratio"..self.mPos]/100 end
        local spCon = cc.Sprite:create()
        spCon:setContentSize(rec)
        spCon:addChild(mChassisImg)
        spCon:addChild(mImg)
        spCon:addChild( mAtkImage, 1 )
        spCon:addChild( mHpImage, 1 )
        spCon:addChild( mTxtAtk, 1 )
        spCon:addChild( mTxtHp, 1 )

        mAtkImage:setScale(1.3)
        mHpImage:setScale(1.3)
        mTxtAtk:setScale(1.3)
        mTxtHp:setScale(1.3)

        spCon:retain()
        self.SpContain = TextureManager:getSprite(spCon, _sc, _sc)
        spCon:release()
        self.SpContain:removeFromParent()
        self:addChild( self.SpContain )
--        self.SpContain:setPosition(100, 100)
--        self.SpContain:setFlippedY(true)
       self.DirSpriteList[msgStr] = 1
    end


--    self.mImage:setTexture( "model/"..self.ModelID.."/"..self.mAction..".png" )
--    local rec = data
--    self.mImage:setTextureRect( data )
--    data = { x = data[1], y = data[2], width = data[3], height = data[4] }
--    self.mImage:setPosition( addPos[1], addPos[2] )

--    --底盘**************
--    data = mChassis[1][self.mDir][1]
--    local addPos = data.BangPoint[6]
--    --模型位置加上坐点
--    self.mImage:setPosition( self.mImage:getPositionX() + addPos[1], self.mImage:getPositionY() + addPos[2] )
--    addPos = data.BangPoint[0]
--    data = { x = data[1], y = data[2], width = data[3], height = data[4] }
--    self.mChassisImage:setTextureRect( data )
--    self.mChassisImage:setPosition( addPos[1], addPos[2] )
--    --底盘**************
--    if self.bmake == false then
--         local _sc = 1
--        if self.ModelControlData~= nil and self.mPos ~= 0 then _sc = self.ModelControlData["ratio"..self.mPos]/100 end
----        self.mImage:setScale(_sc)
--         self.SpContain:setContentSize(data)
--        self.SpContain:retain()
--        self.SpContain:removeFromParent()
--        local ssp = TextureManager:getSprite(self.SpContain, _sc, _sc)
--        self.SpContain:release()
--        ssp:removeFromParent()
----        self.mImage = ssp
--        self:addChild( ssp )
--        self.bmake = true
--        self.SpContain2 = ssp
--    end
end

--设置底盘编号
function CharModel:setChassis(id)
    if self.mChassisID == id then return end
    --底盘数据
    self.mChassisID = id
    self.mChassis = require("model.config."..id)
end

--设置卡牌文字 bol是否要update
function CharModel:setTxt(curAtk, atk, hp, maxHp, dataHp, bol)
    self.curAtk = curAtk
    self.atk = atk
    self.hp = hp
    self.maxHp = maxHp
    self.dataHp = dataHp
    --满血
    if self.hp == self.maxHp then
        if self.maxHp > self.dataHp then
            self.hpFont = "fonts/labBmf_GpNumberFont48.fnt"
        else
            self.hpFont = ATKANDHPFONT
        end
    --扣血了
    else
        self.hpFont = "fonts/labBmf_HpNumberFont48.fnt"
    end

    --攻击力提高
    if self.curAtk > self.atk then
        self.atkFont = "fonts/labBmf_GpNumberFont48.fnt"
    else
        self.atkFont = ATKANDHPFONT
    end

    if bol == true then
        self:update(0, true)
    end
end

--获取模型绑定点
function CharModel:getBandPos( id )
    if ModelData == nil then return 0,0 end
    local data = self.ModelData[self.mAction][self.mDir]
    data = data[self.curFrame]
    ZeroPos = data.BangPoint[0]
    data = data.BangPoint[id]
    if data == nil then return 0,0 end

    return ZeroPos[1] + data[1],ZeroPos[2] + data[2]
end

--清理内存
function CharModel:clearMemory()
    if self.ModelID == nil or self.ModelID <= 0 then return end
    cc.Director:getInstance():getTextureCache():removeTextureForKey( "model/"..self.ModelID.."/1.png" )
    --cc.Director:getInstance():getTextureCache():removeTextureForKey( "model/"..self.ModelID.."/3.png" )
end

--重置
function  CharModel:reset()
    --清理内存
    self:clearMemory()

    self.ModelID = 0
    self.curFrame = 0
    self.ModelData = nil
    self.ModelControlData = nil
--    self.mImage:setVisible(false)
end

--清空、删除
function CharModel:clear()
    
    self:removeAllChildrenWithCleanup(true)
    --清理内存
    self:clearMemory()
end

return CharModel