CharModelOld = class("CharModelOld", function() 
    return cc.Sprite:create()
end)
local MovMove = require("Mov.MovMove")
local MovManager = require("Mov.MovManager"):instance()
local UPDATETIME = { 100, 200, 200, 200 }

function CharModelOld:init()
    --底盘
    self.mChassisID = 59003
    self.mChassis = require("model.config.59003")
    self.mChassisImage = cc.Sprite:create("model/59003/1.png")
    
    self.mImage = cc.Sprite:create()


	self.SpContain = cc.Sprite:create()
	self:addChild( self.SpContain )

	self.SpContain:addChild( self.mChassisImage )
	self.SpContain:addChild( self.mImage )

    self.mov1 = nil
    self.movFun1= nil
    self.mov2 = nil
    self.movFun2= nil
end

--设置显示模型 模型ID
function CharModelOld:setModel( id )
    if self.ModelID == id then return end
    self:reset()
    if id == 0 then return end
    self.ModelID = id
    local Manager = require("model.CharModelManager"):instance()
    self.ModelData = Manager:getCharData(id)
    Manager = require("data.DataManager"):instance()
    self.ModelControlData = Manager:getModelData(id)
    self.curFrame = 0
    self.mImage:setVisible(true)
    self.mAction = 1

    self:setShowParent( self.mPos )
end

--设置模型所在位置 1战场 2卡牌
function CharModelOld:setShowParent( mPos )
    self.mPos = mPos
    local _sc = 1
    if self.ModelControlData~= nil and mPos ~= 0 then _sc = self.ModelControlData["ratio"..mPos]/100 end
    self:setScale( _sc )
    self.mChassisImage:setVisible( self.mPos == 1 )
end

--重置定位坐标
function CharModelOld:resPos()
    self.initX,self.initY = self:getPosition()
end

--设置模型方向
function CharModelOld:setDir( dir, isResFrame )
    self.mDir = dir
    self.curFrame = 0
    if isResFrame == true then 
        self:update()
    end
end


--设置模型透明度
function CharModelOld:setModelOpacity( value )
    self.mImage:setOpacity(value)         
end


--更新模型
function CharModelOld:update( time )
    if self.ModelData == nil then return end

    local data = self.ModelData[self.mAction][self.mDir]
    local totalFrame = data.Frames
    if self.curFrame + 1 > totalFrame then   
        self.curFrame = 1
        if self.actionTimer then
            self:setAction(1, true)  --动作执行一次后，重新设回站立
            return
        end
    else
        self.curFrame = self.curFrame + 1
    end
    data = data[self.curFrame]
    local msgStr = self.ModelData.resID..";"..self.mAction..";"..self.mDir..";"..self.curFrame
    self:setName( msgStr.."="..data.BangPointStr )
    local addPos = data.BangPoint[0]
    data = { x = data[1], y = data[2], width = data[3], height = data[4] }

    --固定只有1动作了
    local pathf = cc.FileUtils:getInstance():fullPathForFilename("model/"..self.ModelID.."/"..self.mAction..".png")    
    self.mImage:setTexture( "model/"..self.ModelID.."/"..self.mAction..".png" )
    TextureManager:addToTx2dClearList( pathf )
    self.mImage:setTextureRect( data )
    data = { x = data[1], y = data[2], width = data[3], height = data[4] }
    self.mImage:setPosition( addPos[1], addPos[2] )
--    self.mImage:setColor(cc.c4b(255,255,255,255))
--    EffectManager:setGrayFilter(self.mImage, true)
    --底盘**************
    data = self.mChassis[1][self.mDir][1]
    local addPos = data.BangPoint[6]
    --模型位置加上坐点
    self.mImage:setPosition( self.mImage:getPositionX() + addPos[1], self.mImage:getPositionY() + addPos[2] )
    addPos = data.BangPoint[0]
    data = { x = data[1], y = data[2], width = data[3], height = data[4] }
    self.mChassisImage:setTextureRect( data )
    self.mChassisImage:setPosition( addPos[1], addPos[2] )
    --底盘**************
    if self.bolFly == true then
        self:setFly(true)
    end       
end

--漂浮动画*****
function CharModelOld:setFly( bolFly )
    self.bolFly = bolFly
    if self.bolFly == true then
        if self.mov1 == nil then
            self.movFun1 = function (posX, posY)
                self.mov1 = MovMove.new()
                self.mov1:init( self.mImage, false, posX, posY+10, 1000, -1 )
                self.mov1.callBackFucFinished = function () self.movFun2(posX, posY) end
                MovManager:pushMov( self.mov1 )
            end

            self.movFun2 = function (posX, posY)
                self.mov2 = MovMove.new()
                self.mov2:init( self.mImage, false, posX, posY-10, 1000, -1 )
                self.mov2.callBackFucFinished = function () self.movFun1(posX, posY) end
                MovManager:pushMov( self.mov2 )
            end
            self.movFun1(self.mImage:getPositionX(), self.mImage:getPositionY())
        end
    else
        MovManager:delMov( self.mov1 )
        MovManager:delMov( self.mov2 )
        self.mov1 = nil
        self.mov2 = nil
        self.movFun1 = nil
        self.movFun2 = nil
        self:update()
    end
end
     

--设置底盘编号
function CharModelOld:setChassis(id)
    if self.mChassisID == id then return end
    --底盘数据
    self.mChassisID = id
    self.mChassis = require("model.config."..id)
    self.mChassisImage:setTexture("model/"..id.."/1.png")
end

--获取模型绑定点
function CharModelOld:getBandPos( id )
    if ModelData == nil then return 0,0 end
    local data = self.ModelData[self.mAction][self.mDir]
    data = data[self.curFrame]
    ZeroPos = data.BangPoint[0]
    data = data.BangPoint[id]
    if data == nil then return 0,0 end

    return ZeroPos[1] + data[1],ZeroPos[2] + data[2]
end

--清理内存
function CharModelOld:clearMemory()
    if self.ModelID == nil or self.ModelID <= 0 then return end
    cc.Director:getInstance():getTextureCache():removeTextureForKey( "model/"..self.ModelID.."/1.png" )
    if self.actionTimer then
        require("framework.scheduler").unscheduleGlobal( self.actionTimer )
        self.actionTimer = nil
    end
end

--设置模型动作
function CharModelOld:setAction( action, isResFrame )
    --清理内存
    self:clearMemory()

    self.mAction = action
--    self.isHold = isHold == true or action == 1
    self.curFrame = 0
    self.mCurTime = 10000
    if isResFrame == true then
        self:update()
    end
    if action > 1 then
        self.actionTimer = require("framework.scheduler").scheduleGlobal( function () self:update() end, 0.2 ) --站立以外的会播放动作
    end
end


--设置模型动作
function CharModelOld:startAction()
    self.actionTimer = require("framework.scheduler").scheduleGlobal( function () self:update() end, 0.2 )
end


--重置
function  CharModelOld:reset()
    --清理内存
    self:clearMemory()

    self.ModelID = 0
    self.curFrame = 0
    self.ModelData = nil
    self.ModelControlData = nil
    self.mImage:setVisible(false)

    --删除指定动画
    MovManager:delMov( self.mov1 )
    MovManager:delMov( self.mov2 )
    self.mov1 = nil
    self.mov2 = nil
    self.movFun1 = nil
    self.movFun2 = nil
end

--清空、删除
function CharModelOld:clear()
    
    self:removeAllChildrenWithCleanup(true)
    --清理内存
    self:clearMemory()
end

return CharModelOld