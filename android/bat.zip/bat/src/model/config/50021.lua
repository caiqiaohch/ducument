--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50021
modelData = {
resID = 50021,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {155,0,155,283}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-25#115=1#5#152=2#-1#207=5#0#232=8#-4#64=7#20#32=9#28#153=4#-12#165=3#-8#171"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {25,115}
modelData[1][3][1].BangPoint[1] = {5,152}
modelData[1][3][1].BangPoint[2] = {-1,207}
modelData[1][3][1].BangPoint[5] = {0,232}
modelData[1][3][1].BangPoint[8] = {-4,64}
modelData[1][3][1].BangPoint[7] = {20,32}
modelData[1][3][1].BangPoint[9] = {28,153}
modelData[1][3][1].BangPoint[4] = {-12,165}
modelData[1][3][1].BangPoint[3] = {-8,171}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,155,290}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#25#105=1#-5#147=2#1#195=5#0#232=8#3#68=7#-21#-39=9#-28#105=4#11#150=3#8#147"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-25,105}
modelData[1][7][1].BangPoint[1] = {-5,147}
modelData[1][7][1].BangPoint[2] = {1,195}
modelData[1][7][1].BangPoint[5] = {0,232}
modelData[1][7][1].BangPoint[8] = {3,68}
modelData[1][7][1].BangPoint[7] = {-21,-39}
modelData[1][7][1].BangPoint[9] = {-28,105}
modelData[1][7][1].BangPoint[4] = {11,150}
modelData[1][7][1].BangPoint[3] = {8,147}

return modelData