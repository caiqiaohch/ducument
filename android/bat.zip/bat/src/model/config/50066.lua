--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50066
modelData = {
resID = 50066,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,204,185}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#33#70=1#3#98=2#0#161=5#0#164=4#40#63=3#-65#110"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-33,70}
modelData[1][3][1].BangPoint[1] = {3,98}
modelData[1][3][1].BangPoint[2] = {0,161}
modelData[1][3][1].BangPoint[5] = {0,164}
modelData[1][3][1].BangPoint[4] = {40,63}
modelData[1][3][1].BangPoint[3] = {-65,110}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,185,204,184}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-33#74=1#-4#102=2#-1#163=5#0#164=4#-41#45=3#64#82"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {33,74}
modelData[1][7][1].BangPoint[1] = {-4,102}
modelData[1][7][1].BangPoint[2] = {-1,163}
modelData[1][7][1].BangPoint[5] = {0,164}
modelData[1][7][1].BangPoint[4] = {-41,45}
modelData[1][7][1].BangPoint[3] = {64,82}

return modelData