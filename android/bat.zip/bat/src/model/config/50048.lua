--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50048
modelData = {
resID = 50048,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,257,333}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#140=1#0#137=2#-8#215=5#0#123=8#0#0=7#0#0=9#0#0=4#109#272=3#-116#106"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,140}
modelData[1][3][1].BangPoint[1] = {0,137}
modelData[1][3][1].BangPoint[2] = {-8,215}
modelData[1][3][1].BangPoint[5] = {0,123}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {109,272}
modelData[1][3][1].BangPoint[3] = {-116,106}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {257,0,257,257}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#102=1#0#137=2#8#203=5#0#123=8#-1#0=7#-1#0=9#-1#0=4#-109#201=3#115#87"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,102}
modelData[1][7][1].BangPoint[1] = {0,137}
modelData[1][7][1].BangPoint[2] = {8,203}
modelData[1][7][1].BangPoint[5] = {0,123}
modelData[1][7][1].BangPoint[8] = {-1,0}
modelData[1][7][1].BangPoint[7] = {-1,0}
modelData[1][7][1].BangPoint[9] = {-1,0}
modelData[1][7][1].BangPoint[4] = {-109,201}
modelData[1][7][1].BangPoint[3] = {115,87}

return modelData