--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50157
modelData = {
resID = 50157,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,237,277}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#17#124=1#0#156=2#-4#221=5#0#220=4#73#152=3#-73#151"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-17,124}
modelData[1][3][1].BangPoint[1] = {0,156}
modelData[1][3][1].BangPoint[2] = {-4,221}
modelData[1][3][1].BangPoint[5] = {0,220}
modelData[1][3][1].BangPoint[4] = {73,152}
modelData[1][3][1].BangPoint[3] = {-73,151}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {237,0,234,234}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-16#106=1#0#155=2#3#218=5#0#220=4#-73#125=3#73#118"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {16,106}
modelData[1][7][1].BangPoint[1] = {0,155}
modelData[1][7][1].BangPoint[2] = {3,218}
modelData[1][7][1].BangPoint[5] = {0,220}
modelData[1][7][1].BangPoint[4] = {-73,125}
modelData[1][7][1].BangPoint[3] = {73,118}

return modelData