--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50162
modelData = {
resID = 50162,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {113,0,111,140}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#103=1#-2#116=2#2#138=5#0#144=4#-13#137=3#-16#135"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,103}
modelData[1][3][1].BangPoint[1] = {-2,116}
modelData[1][3][1].BangPoint[2] = {2,138}
modelData[1][3][1].BangPoint[5] = {0,144}
modelData[1][3][1].BangPoint[4] = {-13,137}
modelData[1][3][1].BangPoint[3] = {-16,135}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,113,152}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#7#106=1#2#113=2#-2#140=5#0#144=4#13#122=3#16#123"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-7,106}
modelData[1][7][1].BangPoint[1] = {2,113}
modelData[1][7][1].BangPoint[2] = {-2,140}
modelData[1][7][1].BangPoint[5] = {0,144}
modelData[1][7][1].BangPoint[4] = {13,122}
modelData[1][7][1].BangPoint[3] = {16,123}

return modelData