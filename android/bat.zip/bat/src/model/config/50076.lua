--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50076
modelData = {
resID = 50076,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,165,160}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#4#41=1#0#46=2#-13#79=5#0#88=4#-39#29=3#9#53"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-4,41}
modelData[1][3][1].BangPoint[1] = {0,46}
modelData[1][3][1].BangPoint[2] = {-13,79}
modelData[1][3][1].BangPoint[5] = {0,88}
modelData[1][3][1].BangPoint[4] = {-39,29}
modelData[1][3][1].BangPoint[3] = {9,53}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,160,165,100}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-4#23=1#-1#46=2#12#67=5#0#88=4#39#38=3#-10#14"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {4,23}
modelData[1][7][1].BangPoint[1] = {-1,46}
modelData[1][7][1].BangPoint[2] = {12,67}
modelData[1][7][1].BangPoint[5] = {0,88}
modelData[1][7][1].BangPoint[4] = {39,38}
modelData[1][7][1].BangPoint[3] = {-10,14}

return modelData