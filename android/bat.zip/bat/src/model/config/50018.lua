--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50018
modelData = {
resID = 50018,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {143,0,142,244}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#86=1#0#140=2#-6#210=5#0#214=8#-25#163=7#-24#110=9#-29#134=4#-27#154=3#8#167"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,86}
modelData[1][3][1].BangPoint[1] = {0,140}
modelData[1][3][1].BangPoint[2] = {-6,210}
modelData[1][3][1].BangPoint[5] = {0,214}
modelData[1][3][1].BangPoint[8] = {-25,163}
modelData[1][3][1].BangPoint[7] = {-24,110}
modelData[1][3][1].BangPoint[9] = {-29,134}
modelData[1][3][1].BangPoint[4] = {-27,154}
modelData[1][3][1].BangPoint[3] = {8,167}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,143,244}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#86=1#-1#141=2#5#204=5#0#214=8#24#160=7#23#106=9#28#133=4#26#148=3#-8#145"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,86}
modelData[1][7][1].BangPoint[1] = {-1,141}
modelData[1][7][1].BangPoint[2] = {5,204}
modelData[1][7][1].BangPoint[5] = {0,214}
modelData[1][7][1].BangPoint[8] = {24,160}
modelData[1][7][1].BangPoint[7] = {23,106}
modelData[1][7][1].BangPoint[9] = {28,133}
modelData[1][7][1].BangPoint[4] = {26,148}
modelData[1][7][1].BangPoint[3] = {-8,145}

return modelData