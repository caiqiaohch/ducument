--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50046
modelData = {
resID = 50046,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {162,158,162,144}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#3#61=1#3#66=2#-2#134=5#0#136=4#65#84=3#-43#73"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-3,61}
modelData[1][3][1].BangPoint[1] = {3,66}
modelData[1][3][1].BangPoint[2] = {-2,134}
modelData[1][3][1].BangPoint[5] = {0,136}
modelData[1][3][1].BangPoint[4] = {65,84}
modelData[1][3][1].BangPoint[3] = {-43,73}
--帧数2
modelData[1][3][2] = {0,158,162,144}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#3#61=1#3#66=2#-2#134=5#0#136=4#65#84=3#-43#73"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {-3,61}
modelData[1][3][2].BangPoint[1] = {3,66}
modelData[1][3][2].BangPoint[2] = {-2,134}
modelData[1][3][2].BangPoint[5] = {0,136}
modelData[1][3][2].BangPoint[4] = {65,84}
modelData[1][3][2].BangPoint[3] = {-43,73}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {162,0,162,158}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-3#69=1#-3#68=2#2#121=5#0#136=4#-66#99=3#43#54"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {3,69}
modelData[1][7][1].BangPoint[1] = {-3,68}
modelData[1][7][1].BangPoint[2] = {2,121}
modelData[1][7][1].BangPoint[5] = {0,136}
modelData[1][7][1].BangPoint[4] = {-66,99}
modelData[1][7][1].BangPoint[3] = {43,54}
--帧数2
modelData[1][7][2] = {0,0,162,158}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#-3#69=1#-3#68=2#2#121=5#0#136=4#-66#99=3#43#54"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {3,69}
modelData[1][7][2].BangPoint[1] = {-3,68}
modelData[1][7][2].BangPoint[2] = {2,121}
modelData[1][7][2].BangPoint[5] = {0,136}
modelData[1][7][2].BangPoint[4] = {-66,99}
modelData[1][7][2].BangPoint[3] = {43,54}

return modelData