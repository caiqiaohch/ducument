--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50074
modelData = {
resID = 50074,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {239,0,239,234}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-24#92=1#2#109=2#16#203=5#0#216=8#0#0=7#0#0=9#0#0=4#111#165=3#33#158"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {24,92}
modelData[1][3][1].BangPoint[1] = {2,109}
modelData[1][3][1].BangPoint[2] = {16,203}
modelData[1][3][1].BangPoint[5] = {0,216}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {111,165}
modelData[1][3][1].BangPoint[3] = {33,158}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,239,268}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#24#109=1#-3#136=2#-16#167=5#0#216=8#0#0=7#0#0=9#0#0=4#-111#204=3#-34#55"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-24,109}
modelData[1][7][1].BangPoint[1] = {-3,136}
modelData[1][7][1].BangPoint[2] = {-16,167}
modelData[1][7][1].BangPoint[5] = {0,216}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-111,204}
modelData[1][7][1].BangPoint[3] = {-34,55}

return modelData