--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50077
modelData = {
resID = 50077,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,324,303}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#17#73=1#6#78=2#-124#162=5#0#185=8#0#0=7#0#0=9#0#0=4#5#36=3#-84#14"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-17,73}
modelData[1][3][1].BangPoint[1] = {6,78}
modelData[1][3][1].BangPoint[2] = {-124,162}
modelData[1][3][1].BangPoint[5] = {0,185}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {5,36}
modelData[1][3][1].BangPoint[3] = {-84,14}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,303,324,232}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-17#76=1#-7#81=2#124#45=5#0#185=8#0#0=7#0#0=9#0#0=4#-6#-25=3#83#-3"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {17,76}
modelData[1][7][1].BangPoint[1] = {-7,81}
modelData[1][7][1].BangPoint[2] = {124,45}
modelData[1][7][1].BangPoint[5] = {0,185}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-6,-25}
modelData[1][7][1].BangPoint[3] = {83,-3}

return modelData