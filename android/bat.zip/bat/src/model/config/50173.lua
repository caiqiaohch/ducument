--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50173
modelData = {
resID = 50173,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {86,0,86,143}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#1#69=1#-2#72=2#-12#140=5#0#136=4#15#58=3#-20#18"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-1,69}
modelData[1][3][1].BangPoint[1] = {-2,72}
modelData[1][3][1].BangPoint[2] = {-12,140}
modelData[1][3][1].BangPoint[5] = {0,136}
modelData[1][3][1].BangPoint[4] = {15,58}
modelData[1][3][1].BangPoint[3] = {-20,18}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,86,160}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-1#70=1#1#68=2#12#121=5#0#136=4#-15#38=3#20#44"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {1,70}
modelData[1][7][1].BangPoint[1] = {1,68}
modelData[1][7][1].BangPoint[2] = {12,121}
modelData[1][7][1].BangPoint[5] = {0,136}
modelData[1][7][1].BangPoint[4] = {-15,38}
modelData[1][7][1].BangPoint[3] = {20,44}

return modelData