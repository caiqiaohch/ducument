--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50107
modelData = {
resID = 50107,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,204,287}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-2#117=1#-6#157=2#-21#218=5#0#227=4#56#153=3#-84#138"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {2,117}
modelData[1][3][1].BangPoint[1] = {-6,157}
modelData[1][3][1].BangPoint[2] = {-21,218}
modelData[1][3][1].BangPoint[5] = {0,227}
modelData[1][3][1].BangPoint[4] = {56,153}
modelData[1][3][1].BangPoint[3] = {-84,138}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {204,0,204,282}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#2#115=1#5#148=2#21#189=5#0#227=4#-57#112=3#84#138"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-2,115}
modelData[1][7][1].BangPoint[1] = {5,148}
modelData[1][7][1].BangPoint[2] = {21,189}
modelData[1][7][1].BangPoint[5] = {0,227}
modelData[1][7][1].BangPoint[4] = {-57,112}
modelData[1][7][1].BangPoint[3] = {84,138}

return modelData