--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50060
modelData = {
resID = 50060,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,164,288}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-31#118=1#-6#161=2#-13#221=5#0#239=8#59#158=7#89#142=9#68#157=4#66#156=3#-33#211"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {31,118}
modelData[1][3][1].BangPoint[1] = {-6,161}
modelData[1][3][1].BangPoint[2] = {-13,221}
modelData[1][3][1].BangPoint[5] = {0,239}
modelData[1][3][1].BangPoint[8] = {59,158}
modelData[1][3][1].BangPoint[7] = {89,142}
modelData[1][3][1].BangPoint[9] = {68,157}
modelData[1][3][1].BangPoint[4] = {66,156}
modelData[1][3][1].BangPoint[3] = {-33,211}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {164,0,165,270}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#30#109=1#6#156=2#13#209=5#0#239=8#-60#161=7#-90#21=9#-69#112=4#-67#111=3#32#192"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-30,109}
modelData[1][7][1].BangPoint[1] = {6,156}
modelData[1][7][1].BangPoint[2] = {13,209}
modelData[1][7][1].BangPoint[5] = {0,239}
modelData[1][7][1].BangPoint[8] = {-60,161}
modelData[1][7][1].BangPoint[7] = {-90,21}
modelData[1][7][1].BangPoint[9] = {-69,112}
modelData[1][7][1].BangPoint[4] = {-67,111}
modelData[1][7][1].BangPoint[3] = {32,192}

return modelData