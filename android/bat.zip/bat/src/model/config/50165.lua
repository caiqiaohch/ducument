--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50165
modelData = {
resID = 50165,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,395,400}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-86#93=1#-2#153=2#-8#211=5#0#216=4#92#178=3#-30#113"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {86,93}
modelData[1][3][1].BangPoint[1] = {-2,153}
modelData[1][3][1].BangPoint[2] = {-8,211}
modelData[1][3][1].BangPoint[5] = {0,216}
modelData[1][3][1].BangPoint[4] = {92,178}
modelData[1][3][1].BangPoint[3] = {-30,113}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,400,393,389}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#89#179=1#1#151=2#7#203=5#0#216=4#-93#146=3#29#207"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-89,179}
modelData[1][7][1].BangPoint[1] = {1,151}
modelData[1][7][1].BangPoint[2] = {7,203}
modelData[1][7][1].BangPoint[5] = {0,216}
modelData[1][7][1].BangPoint[4] = {-93,146}
modelData[1][7][1].BangPoint[3] = {29,207}

return modelData