--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50178
modelData = {
resID = 50178,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {89,0,89,133}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#53=1#2#83=2#2#103=5#0#119=4#19#86=3#-15#69"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,53}
modelData[1][3][1].BangPoint[1] = {2,83}
modelData[1][3][1].BangPoint[2] = {2,103}
modelData[1][3][1].BangPoint[5] = {0,119}
modelData[1][3][1].BangPoint[4] = {19,86}
modelData[1][3][1].BangPoint[3] = {-15,69}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,89,137}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#59=1#-2#86=2#-2#105=5#0#119=4#-19#71=3#15#88"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,59}
modelData[1][7][1].BangPoint[1] = {-2,86}
modelData[1][7][1].BangPoint[2] = {-2,105}
modelData[1][7][1].BangPoint[5] = {0,119}
modelData[1][7][1].BangPoint[4] = {-19,71}
modelData[1][7][1].BangPoint[3] = {15,88}

return modelData