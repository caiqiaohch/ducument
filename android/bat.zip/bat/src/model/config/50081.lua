--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50081
modelData = {
resID = 50081,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,244,306}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#40#127=1#-33#125=2#-105#178=5#0#165=8#0#0=7#0#0=9#0#0=4#-20#34=3#-80#39"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-40,127}
modelData[1][3][1].BangPoint[1] = {-33,125}
modelData[1][3][1].BangPoint[2] = {-105,178}
modelData[1][3][1].BangPoint[5] = {0,165}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-20,34}
modelData[1][3][1].BangPoint[3] = {-80,39}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {244,0,244,259}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-40#95=1#33#92=2#105#75=5#0#165=8#0#0=7#0#0=9#0#0=4#20#-12=3#80#-15"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {40,95}
modelData[1][7][1].BangPoint[1] = {33,92}
modelData[1][7][1].BangPoint[2] = {105,75}
modelData[1][7][1].BangPoint[5] = {0,165}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {20,-12}
modelData[1][7][1].BangPoint[3] = {80,-15}

return modelData