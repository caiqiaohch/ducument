--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50087
modelData = {
resID = 50087,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {270,0,259,315}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#119=1#-2#51=2#-17#138=5#0#278=8#0#0=7#0#0=9#0#0=4#46#44=3#-29#-7"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,119}
modelData[1][3][1].BangPoint[1] = {-2,51}
modelData[1][3][1].BangPoint[2] = {-17,138}
modelData[1][3][1].BangPoint[5] = {0,278}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {46,44}
modelData[1][3][1].BangPoint[3] = {-29,-7}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,270,320}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-1#132=1#1#54=2#16#130=5#0#278=8#0#0=7#0#0=9#0#0=4#-47#10=3#29#26"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {1,132}
modelData[1][7][1].BangPoint[1] = {1,54}
modelData[1][7][1].BangPoint[2] = {16,130}
modelData[1][7][1].BangPoint[5] = {0,278}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-47,10}
modelData[1][7][1].BangPoint[3] = {29,26}

return modelData