--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：59001
modelData = {
resID = 59001,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {0,150,246,133}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#7=6#0#27"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,7}
modelData[1][3][1].BangPoint[6] = {0,27}
--帧数2
modelData[1][3][2] = {246,150,246,133}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#0#7=6#0#27"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {0,7}
modelData[1][3][2].BangPoint[6] = {0,27}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {0,0,246,150}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#16=6#0#27"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,16}
modelData[1][7][1].BangPoint[6] = {0,27}
--帧数2
modelData[1][7][2] = {246,0,246,150}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#0#16=6#0#27"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {0,16}
modelData[1][7][2].BangPoint[6] = {0,27}

return modelData