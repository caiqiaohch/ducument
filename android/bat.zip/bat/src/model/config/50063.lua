--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50063
modelData = {
resID = 50063,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,113,358}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-5#148=1#-5#180=2#-19#256=5#0#258=8#16#41=7#19#287=9#17#219=4#20#215=3#-43#124"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {5,148}
modelData[1][3][1].BangPoint[1] = {-5,180}
modelData[1][3][1].BangPoint[2] = {-19,256}
modelData[1][3][1].BangPoint[5] = {0,258}
modelData[1][3][1].BangPoint[8] = {16,41}
modelData[1][3][1].BangPoint[7] = {19,287}
modelData[1][3][1].BangPoint[9] = {17,219}
modelData[1][3][1].BangPoint[4] = {20,215}
modelData[1][3][1].BangPoint[3] = {-43,124}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {113,0,114,291}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#5#101=1#4#176=2#18#237=5#0#258=8#-17#-42=7#-20#190=9#-18#128=4#-21#130=3#42#147"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-5,101}
modelData[1][7][1].BangPoint[1] = {4,176}
modelData[1][7][1].BangPoint[2] = {18,237}
modelData[1][7][1].BangPoint[5] = {0,258}
modelData[1][7][1].BangPoint[8] = {-17,-42}
modelData[1][7][1].BangPoint[7] = {-20,190}
modelData[1][7][1].BangPoint[9] = {-18,128}
modelData[1][7][1].BangPoint[4] = {-21,130}
modelData[1][7][1].BangPoint[3] = {42,147}

return modelData