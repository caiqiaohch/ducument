--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50062
modelData = {
resID = 50062,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {159,153,159,153}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#6#71=1#-4#70=2#-8#140=5#0#136=4#49#79=3#-65#82"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-6,71}
modelData[1][3][1].BangPoint[1] = {-4,70}
modelData[1][3][1].BangPoint[2] = {-8,140}
modelData[1][3][1].BangPoint[5] = {0,136}
modelData[1][3][1].BangPoint[4] = {49,79}
modelData[1][3][1].BangPoint[3] = {-65,82}
--帧数2
modelData[1][3][2] = {0,0,159,153}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#6#71=1#-4#70=2#-8#140=5#0#136=4#49#79=3#-65#82"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {-6,71}
modelData[1][3][2].BangPoint[1] = {-4,70}
modelData[1][3][2].BangPoint[2] = {-8,140}
modelData[1][3][2].BangPoint[5] = {0,136}
modelData[1][3][2].BangPoint[4] = {49,79}
modelData[1][3][2].BangPoint[3] = {-65,82}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {159,0,159,153}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-3#63=1#3#66=2#8#113=5#0#136=4#-50#53=3#64#53"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {3,63}
modelData[1][7][1].BangPoint[1] = {3,66}
modelData[1][7][1].BangPoint[2] = {8,113}
modelData[1][7][1].BangPoint[5] = {0,136}
modelData[1][7][1].BangPoint[4] = {-50,53}
modelData[1][7][1].BangPoint[3] = {64,53}
--帧数2
modelData[1][7][2] = {0,153,159,153}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#-3#63=1#3#66=2#8#113=5#0#136=4#-50#53=3#64#53"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {3,63}
modelData[1][7][2].BangPoint[1] = {3,66}
modelData[1][7][2].BangPoint[2] = {8,113}
modelData[1][7][2].BangPoint[5] = {0,136}
modelData[1][7][2].BangPoint[4] = {-50,53}
modelData[1][7][2].BangPoint[3] = {64,53}

return modelData