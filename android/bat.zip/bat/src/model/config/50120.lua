--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50120
modelData = {
resID = 50120,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,327,288,222}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-73#85=1#-4#137=2#-17#206=5#0#230=4#55#110=3#-56#149"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {73,85}
modelData[1][3][1].BangPoint[1] = {-4,137}
modelData[1][3][1].BangPoint[2] = {-17,206}
modelData[1][3][1].BangPoint[5] = {0,230}
modelData[1][3][1].BangPoint[4] = {55,110}
modelData[1][3][1].BangPoint[3] = {-56,149}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,288,327}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#73#137=1#3#133=2#17#185=5#0#230=4#-56#89=3#55#115"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-73,137}
modelData[1][7][1].BangPoint[1] = {3,133}
modelData[1][7][1].BangPoint[2] = {17,185}
modelData[1][7][1].BangPoint[5] = {0,230}
modelData[1][7][1].BangPoint[4] = {-56,89}
modelData[1][7][1].BangPoint[3] = {55,115}

return modelData