--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50086
modelData = {
resID = 50086,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,150,229}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#15#90=1#-6#132=2#-20#200=5#0#217=8#-29#177=7#-77#197=9#-59#179=4#27#148=3#-49#176"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-15,90}
modelData[1][3][1].BangPoint[1] = {-6,132}
modelData[1][3][1].BangPoint[2] = {-20,200}
modelData[1][3][1].BangPoint[5] = {0,217}
modelData[1][3][1].BangPoint[8] = {-29,177}
modelData[1][3][1].BangPoint[7] = {-77,197}
modelData[1][3][1].BangPoint[9] = {-59,179}
modelData[1][3][1].BangPoint[4] = {27,148}
modelData[1][3][1].BangPoint[3] = {-49,176}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {150,0,150,218}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-15#85=1#6#131=2#19#180=5#0#217=8#28#158=7#77#106=9#58#134=4#-27#104=3#48#146"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {15,85}
modelData[1][7][1].BangPoint[1] = {6,131}
modelData[1][7][1].BangPoint[2] = {19,180}
modelData[1][7][1].BangPoint[5] = {0,217}
modelData[1][7][1].BangPoint[8] = {28,158}
modelData[1][7][1].BangPoint[7] = {77,106}
modelData[1][7][1].BangPoint[9] = {58,134}
modelData[1][7][1].BangPoint[4] = {-27,104}
modelData[1][7][1].BangPoint[3] = {48,146}

return modelData