--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50014
modelData = {
resID = 50014,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {105,0,105,200}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-1#81=1#-1#119=2#5#179=5#0#189=4#22#114=3#-43#105"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {1,81}
modelData[1][3][1].BangPoint[1] = {-1,119}
modelData[1][3][1].BangPoint[2] = {5,179}
modelData[1][3][1].BangPoint[5] = {0,189}
modelData[1][3][1].BangPoint[4] = {22,114}
modelData[1][3][1].BangPoint[3] = {-43,105}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,105,206}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#1#83=1#0#118=2#-5#184=5#0#189=4#-22#86=3#43#107"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-1,83}
modelData[1][7][1].BangPoint[1] = {0,118}
modelData[1][7][1].BangPoint[2] = {-5,184}
modelData[1][7][1].BangPoint[5] = {0,189}
modelData[1][7][1].BangPoint[4] = {-22,86}
modelData[1][7][1].BangPoint[3] = {43,107}

return modelData