--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50010
modelData = {
resID = 50010,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,169,195}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#14#76=1#-7#103=2#-25#174=5#0#163=4#42#66=3#-58#90"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-14,76}
modelData[1][3][1].BangPoint[1] = {-7,103}
modelData[1][3][1].BangPoint[2] = {-25,174}
modelData[1][3][1].BangPoint[5] = {0,163}
modelData[1][3][1].BangPoint[4] = {42,66}
modelData[1][3][1].BangPoint[3] = {-58,90}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {169,0,169,170}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-14#64=1#6#96=2#24#146=5#0#163=4#-42#43=3#58#44"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {14,64}
modelData[1][7][1].BangPoint[1] = {6,96}
modelData[1][7][1].BangPoint[2] = {24,146}
modelData[1][7][1].BangPoint[5] = {0,163}
modelData[1][7][1].BangPoint[4] = {-42,43}
modelData[1][7][1].BangPoint[3] = {58,44}

return modelData