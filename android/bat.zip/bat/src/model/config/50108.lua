--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50108
modelData = {
resID = 50108,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {219,0,219,255}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-10#103=1#-7#123=2#-24#199=5#0#216=4#61#192=3#-76#121"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {10,103}
modelData[1][3][1].BangPoint[1] = {-7,123}
modelData[1][3][1].BangPoint[2] = {-24,199}
modelData[1][3][1].BangPoint[5] = {0,216}
modelData[1][3][1].BangPoint[4] = {61,192}
modelData[1][3][1].BangPoint[3] = {-76,121}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,219,274}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#10#113=1#6#121=2#24#158=5#0#216=4#-62#134=3#76#90"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-10,113}
modelData[1][7][1].BangPoint[1] = {6,121}
modelData[1][7][1].BangPoint[2] = {24,158}
modelData[1][7][1].BangPoint[5] = {0,216}
modelData[1][7][1].BangPoint[4] = {-62,134}
modelData[1][7][1].BangPoint[3] = {76,90}

return modelData