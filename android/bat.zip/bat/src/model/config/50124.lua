--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50124
modelData = {
resID = 50124,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {178,0,178,200}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#54=1#-12#85=2#-38#128=5#0#120=4#3#48=3#-63#15"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,54}
modelData[1][3][1].BangPoint[1] = {-12,85}
modelData[1][3][1].BangPoint[2] = {-38,128}
modelData[1][3][1].BangPoint[5] = {0,120}
modelData[1][3][1].BangPoint[4] = {3,48}
modelData[1][3][1].BangPoint[3] = {-63,15}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,178,205}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#59=1#12#73=2#37#91=5#0#120=4#-3#-15=3#62#18"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,59}
modelData[1][7][1].BangPoint[1] = {12,73}
modelData[1][7][1].BangPoint[2] = {37,91}
modelData[1][7][1].BangPoint[5] = {0,120}
modelData[1][7][1].BangPoint[4] = {-3,-15}
modelData[1][7][1].BangPoint[3] = {62,18}

return modelData