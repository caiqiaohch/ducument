--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50093
modelData = {
resID = 50093,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,128,244}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#12#96=1#0#159=2#-9#216=5#0#227=8#0#154=7#-60#128=9#-36#138=4#-7#151=3#-43#133"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-12,96}
modelData[1][3][1].BangPoint[1] = {0,159}
modelData[1][3][1].BangPoint[2] = {-9,216}
modelData[1][3][1].BangPoint[5] = {0,227}
modelData[1][3][1].BangPoint[8] = {0,154}
modelData[1][3][1].BangPoint[7] = {-60,128}
modelData[1][3][1].BangPoint[9] = {-36,138}
modelData[1][3][1].BangPoint[4] = {-7,151}
modelData[1][3][1].BangPoint[3] = {-43,133}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {128,0,128,235}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-12#91=1#0#158=2#9#202=5#0#227=8#-1#128=7#59#100=9#35#111=4#7#127=3#43#112"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {12,91}
modelData[1][7][1].BangPoint[1] = {0,158}
modelData[1][7][1].BangPoint[2] = {9,202}
modelData[1][7][1].BangPoint[5] = {0,227}
modelData[1][7][1].BangPoint[8] = {-1,128}
modelData[1][7][1].BangPoint[7] = {59,100}
modelData[1][7][1].BangPoint[9] = {35,111}
modelData[1][7][1].BangPoint[4] = {7,127}
modelData[1][7][1].BangPoint[3] = {43,112}

return modelData