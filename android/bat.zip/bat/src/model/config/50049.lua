--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50049
modelData = {
resID = 50049,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,166,215}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-2#87=1#-1#108=2#-11#173=5#0#185=4#72#123=3#-35#89"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {2,87}
modelData[1][3][1].BangPoint[1] = {-1,108}
modelData[1][3][1].BangPoint[2] = {-11,173}
modelData[1][3][1].BangPoint[5] = {0,185}
modelData[1][3][1].BangPoint[4] = {72,123}
modelData[1][3][1].BangPoint[3] = {-35,89}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {166,0,166,207}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#2#82=1#1#107=2#11#160=5#0#185=4#-72#110=3#34#71"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-2,82}
modelData[1][7][1].BangPoint[1] = {1,107}
modelData[1][7][1].BangPoint[2] = {11,160}
modelData[1][7][1].BangPoint[5] = {0,185}
modelData[1][7][1].BangPoint[4] = {-72,110}
modelData[1][7][1].BangPoint[3] = {34,71}

return modelData