--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50041
modelData = {
resID = 50041,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {154,0,154,162}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-11#48=1#5#67=2#6#134=5#0#136=4#70#56=3#-48#81"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {11,48}
modelData[1][3][1].BangPoint[1] = {5,67}
modelData[1][3][1].BangPoint[2] = {6,134}
modelData[1][3][1].BangPoint[5] = {0,136}
modelData[1][3][1].BangPoint[4] = {70,56}
modelData[1][3][1].BangPoint[3] = {-48,81}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,154,176}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#11#50=1#-6#62=2#-6#118=5#0#136=4#-71#85=3#47#42"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-11,50}
modelData[1][7][1].BangPoint[1] = {-6,62}
modelData[1][7][1].BangPoint[2] = {-6,118}
modelData[1][7][1].BangPoint[5] = {0,136}
modelData[1][7][1].BangPoint[4] = {-71,85}
modelData[1][7][1].BangPoint[3] = {47,42}

return modelData