--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50092
modelData = {
resID = 50092,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {210,0,207,323}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-26#122=1#10#135=2#-33#192=5#0#278=8#0#0=7#0#0=9#0#0=4#46#112=3#-51#63"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {26,122}
modelData[1][3][1].BangPoint[1] = {10,135}
modelData[1][3][1].BangPoint[2] = {-33,192}
modelData[1][3][1].BangPoint[5] = {0,278}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {46,112}
modelData[1][3][1].BangPoint[3] = {-51,63}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,210,356}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#27#135=1#-11#146=2#32#157=5#0#278=8#0#0=7#0#0=9#0#0=4#-47#61=3#50#110"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-27,135}
modelData[1][7][1].BangPoint[1] = {-11,146}
modelData[1][7][1].BangPoint[2] = {32,157}
modelData[1][7][1].BangPoint[5] = {0,278}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-47,61}
modelData[1][7][1].BangPoint[3] = {50,110}

return modelData