--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50155
modelData = {
resID = 50155,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,222,314}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#5#116=1#-6#158=2#-5#220=5#0#243=4#-2#180=3#-65#129"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-5,116}
modelData[1][3][1].BangPoint[1] = {-6,158}
modelData[1][3][1].BangPoint[2] = {-5,220}
modelData[1][3][1].BangPoint[5] = {0,243}
modelData[1][3][1].BangPoint[4] = {-2,180}
modelData[1][3][1].BangPoint[3] = {-65,129}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {222,0,222,284}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-5#121=1#5#152=2#4#216=5#0#243=4#2#104=3#65#140"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {5,121}
modelData[1][7][1].BangPoint[1] = {5,152}
modelData[1][7][1].BangPoint[2] = {4,216}
modelData[1][7][1].BangPoint[5] = {0,243}
modelData[1][7][1].BangPoint[4] = {2,104}
modelData[1][7][1].BangPoint[3] = {65,140}

return modelData