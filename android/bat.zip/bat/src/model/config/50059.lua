--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50059
modelData = {
resID = 50059,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,257,299}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-35#120=1#-15#160=2#-47#242=5#0#262=8#159#124=7#-20#184=9#72#151=4#83#152=3#-76#140"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {35,120}
modelData[1][3][1].BangPoint[1] = {-15,160}
modelData[1][3][1].BangPoint[2] = {-47,242}
modelData[1][3][1].BangPoint[5] = {0,262}
modelData[1][3][1].BangPoint[8] = {159,124}
modelData[1][3][1].BangPoint[7] = {-20,184}
modelData[1][3][1].BangPoint[9] = {72,151}
modelData[1][3][1].BangPoint[4] = {83,152}
modelData[1][3][1].BangPoint[3] = {-76,140}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {257,0,251,252}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#38#97=1#14#137=2#46#172=5#0#262=8#-160#178=7#19#13=9#-73#90=4#-83#107=3#75#76"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-38,97}
modelData[1][7][1].BangPoint[1] = {14,137}
modelData[1][7][1].BangPoint[2] = {46,172}
modelData[1][7][1].BangPoint[5] = {0,262}
modelData[1][7][1].BangPoint[8] = {-160,178}
modelData[1][7][1].BangPoint[7] = {19,13}
modelData[1][7][1].BangPoint[9] = {-73,90}
modelData[1][7][1].BangPoint[4] = {-83,107}
modelData[1][7][1].BangPoint[3] = {75,76}

return modelData