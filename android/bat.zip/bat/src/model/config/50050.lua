--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50050
modelData = {
resID = 50050,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,263,270}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-7#86=1#-37#85=2#-27#139=5#0#199=8#0#0=7#0#0=9#0#0=4#-5#51=3#26#25"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {7,86}
modelData[1][3][1].BangPoint[1] = {-37,85}
modelData[1][3][1].BangPoint[2] = {-27,139}
modelData[1][3][1].BangPoint[5] = {0,199}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-5,51}
modelData[1][3][1].BangPoint[3] = {26,25}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,270,263,246}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#7#98=1#36#48=2#26#112=5#0#199=8#0#0=7#0#0=9#0#0=4#5#46=3#-26#92"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-7,98}
modelData[1][7][1].BangPoint[1] = {36,48}
modelData[1][7][1].BangPoint[2] = {26,112}
modelData[1][7][1].BangPoint[5] = {0,199}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {5,46}
modelData[1][7][1].BangPoint[3] = {-26,92}

return modelData