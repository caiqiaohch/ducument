--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50163
modelData = {
resID = 50163,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {241,0,234,301}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-44#111=1#-10#157=2#4#212=5#0#217=4#39#138=3#-35#104"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {44,111}
modelData[1][3][1].BangPoint[1] = {-10,157}
modelData[1][3][1].BangPoint[2] = {4,212}
modelData[1][3][1].BangPoint[5] = {0,217}
modelData[1][3][1].BangPoint[4] = {39,138}
modelData[1][3][1].BangPoint[3] = {-35,104}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,241,342}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#48#147=1#9#147=2#-5#217=5#0#217=4#-39#105=3#34#142"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-48,147}
modelData[1][7][1].BangPoint[1] = {9,147}
modelData[1][7][1].BangPoint[2] = {-5,217}
modelData[1][7][1].BangPoint[5] = {0,217}
modelData[1][7][1].BangPoint[4] = {-39,105}
modelData[1][7][1].BangPoint[3] = {34,142}

return modelData