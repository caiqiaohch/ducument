--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50036
modelData = {
resID = 50036,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {133,0,134,253}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-20#106=1#-2#159=2#0#226=5#0#230=4#20#187=3#-42#98"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {20,106}
modelData[1][3][1].BangPoint[1] = {-2,159}
modelData[1][3][1].BangPoint[2] = {0,226}
modelData[1][3][1].BangPoint[5] = {0,230}
modelData[1][3][1].BangPoint[4] = {20,187}
modelData[1][3][1].BangPoint[3] = {-42,98}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,133,277}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#19#100=1#1#157=2#0#226=5#0#230=4#-20#108=3#41#131"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-19,100}
modelData[1][7][1].BangPoint[1] = {1,157}
modelData[1][7][1].BangPoint[2] = {0,226}
modelData[1][7][1].BangPoint[5] = {0,230}
modelData[1][7][1].BangPoint[4] = {-20,108}
modelData[1][7][1].BangPoint[3] = {41,131}

return modelData