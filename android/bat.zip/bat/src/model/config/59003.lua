--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：59003
modelData = {
resID = 59003,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {0,101,190,101}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#0=6#0#10"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,0}
modelData[1][3][1].BangPoint[6] = {0,10}
--帧数2
modelData[1][3][2] = {190,101,190,101}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#0#0=6#0#10"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {0,0}
modelData[1][3][2].BangPoint[6] = {0,10}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {0,0,190,101}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#0=6#0#10"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,0}
modelData[1][7][1].BangPoint[6] = {0,10}
--帧数2
modelData[1][7][2] = {190,0,190,101}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#0#0=6#0#10"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {0,0}
modelData[1][7][2].BangPoint[6] = {0,10}

return modelData