--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50017
modelData = {
resID = 50017,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,144,218}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#73=1#-4#124=2#-12#183=5#0#203=8#0#0=7#0#0=9#0#0=4#42#166=3#-62#165"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,73}
modelData[1][3][1].BangPoint[1] = {-4,124}
modelData[1][3][1].BangPoint[2] = {-12,183}
modelData[1][3][1].BangPoint[5] = {0,203}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {42,166}
modelData[1][3][1].BangPoint[3] = {-62,165}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {144,0,143,211}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#69=1#3#119=2#12#167=5#0#203=8#0#0=7#0#0=9#0#0=4#-42#126=3#61#108"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,69}
modelData[1][7][1].BangPoint[1] = {3,119}
modelData[1][7][1].BangPoint[2] = {12,167}
modelData[1][7][1].BangPoint[5] = {0,203}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-42,126}
modelData[1][7][1].BangPoint[3] = {61,108}

return modelData