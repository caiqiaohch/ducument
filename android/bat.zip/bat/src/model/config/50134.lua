--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50134
modelData = {
resID = 50134,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,219,270}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#29#110=1#1#173=2#2#245=5#0#246=4#36#159=3#-98#172"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-29,110}
modelData[1][3][1].BangPoint[1] = {1,173}
modelData[1][3][1].BangPoint[2] = {2,245}
modelData[1][3][1].BangPoint[5] = {0,246}
modelData[1][3][1].BangPoint[4] = {36,159}
modelData[1][3][1].BangPoint[3] = {-98,172}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {219,0,219,263}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-29#115=1#-1#171=2#-2#246=5#0#246=4#-36#149=3#97#150"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {29,115}
modelData[1][7][1].BangPoint[1] = {-1,171}
modelData[1][7][1].BangPoint[2] = {-2,246}
modelData[1][7][1].BangPoint[5] = {0,246}
modelData[1][7][1].BangPoint[4] = {-36,149}
modelData[1][7][1].BangPoint[3] = {97,150}

return modelData