--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50024
modelData = {
resID = 50024,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {203,0,203,324}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-13#146=1#7#159=2#9#224=5#0#230=4#82#159=3#-54#127"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {13,146}
modelData[1][3][1].BangPoint[1] = {7,159}
modelData[1][3][1].BangPoint[2] = {9,224}
modelData[1][3][1].BangPoint[5] = {0,230}
modelData[1][3][1].BangPoint[4] = {82,159}
modelData[1][3][1].BangPoint[3] = {-54,127}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,203,324}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#13#136=1#-7#164=2#-9#230=5#0#230=4#-82#142=3#54#123"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-13,136}
modelData[1][7][1].BangPoint[1] = {-7,164}
modelData[1][7][1].BangPoint[2] = {-9,230}
modelData[1][7][1].BangPoint[5] = {0,230}
modelData[1][7][1].BangPoint[4] = {-82,142}
modelData[1][7][1].BangPoint[3] = {54,123}

return modelData