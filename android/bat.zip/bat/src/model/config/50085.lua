--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50085
modelData = {
resID = 50085,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,122,218}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#10#83=1#-3#127=2#-15#194=5#0#231=8#45#125=7#4#154=9#30#135=4#35#133=3#-64#126"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-10,83}
modelData[1][3][1].BangPoint[1] = {-3,127}
modelData[1][3][1].BangPoint[2] = {-15,194}
modelData[1][3][1].BangPoint[5] = {0,231}
modelData[1][3][1].BangPoint[8] = {45,125}
modelData[1][3][1].BangPoint[7] = {4,154}
modelData[1][3][1].BangPoint[9] = {30,135}
modelData[1][3][1].BangPoint[4] = {35,133}
modelData[1][3][1].BangPoint[3] = {-64,126}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {122,0,123,205}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-9#76=1#3#124=2#15#174=5#0#231=8#-45#81=7#-4#92=9#-31#84=4#-36#89=3#64#105"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {9,76}
modelData[1][7][1].BangPoint[1] = {3,124}
modelData[1][7][1].BangPoint[2] = {15,174}
modelData[1][7][1].BangPoint[5] = {0,231}
modelData[1][7][1].BangPoint[8] = {-45,81}
modelData[1][7][1].BangPoint[7] = {-4,92}
modelData[1][7][1].BangPoint[9] = {-31,84}
modelData[1][7][1].BangPoint[4] = {-36,89}
modelData[1][7][1].BangPoint[3] = {64,105}

return modelData