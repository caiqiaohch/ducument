--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50016
modelData = {
resID = 50016,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,171,388}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#5#168=1#-12#157=2#-18#219=5#0#229=8#54#167=7#-86#365=9#-4#252=4#-65#111=3#-9#247"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-5,168}
modelData[1][3][1].BangPoint[1] = {-12,157}
modelData[1][3][1].BangPoint[2] = {-18,219}
modelData[1][3][1].BangPoint[5] = {0,229}
modelData[1][3][1].BangPoint[8] = {54,167}
modelData[1][3][1].BangPoint[7] = {-86,365}
modelData[1][3][1].BangPoint[9] = {-4,252}
modelData[1][3][1].BangPoint[4] = {-65,111}
modelData[1][3][1].BangPoint[3] = {-9,247}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {171,0,171,244}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-5#96=1#11#148=2#18#213=5#0#229=8#-55#124=7#86#193=9#3#157=4#64#138=3#8#161"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {5,96}
modelData[1][7][1].BangPoint[1] = {11,148}
modelData[1][7][1].BangPoint[2] = {18,213}
modelData[1][7][1].BangPoint[5] = {0,229}
modelData[1][7][1].BangPoint[8] = {-55,124}
modelData[1][7][1].BangPoint[7] = {86,193}
modelData[1][7][1].BangPoint[9] = {3,157}
modelData[1][7][1].BangPoint[4] = {64,138}
modelData[1][7][1].BangPoint[3] = {8,161}

return modelData