--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50032
modelData = {
resID = 50032,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,299,283}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-78#46=1#-6#141=2#5#187=5#0#220=8#0#0=7#0#0=9#0#0=4#-17#166=3#-19#164"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {78,46}
modelData[1][3][1].BangPoint[1] = {-6,141}
modelData[1][3][1].BangPoint[2] = {5,187}
modelData[1][3][1].BangPoint[5] = {0,220}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-17,166}
modelData[1][3][1].BangPoint[3] = {-19,164}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,283,300,278}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#79#103=1#6#135=2#-5#192=5#0#220=8#0#0=7#0#0=9#0#0=4#17#149=3#19#150"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-79,103}
modelData[1][7][1].BangPoint[1] = {6,135}
modelData[1][7][1].BangPoint[2] = {-5,192}
modelData[1][7][1].BangPoint[5] = {0,220}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {17,149}
modelData[1][7][1].BangPoint[3] = {19,150}

return modelData