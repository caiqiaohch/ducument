--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50039
modelData = {
resID = 50039,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,217,234}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-5#94=1#-4#144=2#-10#208=5#0#204=8#38#136=7#113#31=9#63#101=4#64#115=3#-62#119"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {5,94}
modelData[1][3][1].BangPoint[1] = {-4,144}
modelData[1][3][1].BangPoint[2] = {-10,208}
modelData[1][3][1].BangPoint[5] = {0,204}
modelData[1][3][1].BangPoint[8] = {38,136}
modelData[1][3][1].BangPoint[7] = {113,31}
modelData[1][3][1].BangPoint[9] = {63,101}
modelData[1][3][1].BangPoint[4] = {64,115}
modelData[1][3][1].BangPoint[3] = {-62,119}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {217,0,217,221}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#5#74=1#3#121=2#10#172=5#0#204=8#-39#121=7#-114#-30=9#-64#71=4#-65#89=3#61#85"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-5,74}
modelData[1][7][1].BangPoint[1] = {3,121}
modelData[1][7][1].BangPoint[2] = {10,172}
modelData[1][7][1].BangPoint[5] = {0,204}
modelData[1][7][1].BangPoint[8] = {-39,121}
modelData[1][7][1].BangPoint[7] = {-114,-30}
modelData[1][7][1].BangPoint[9] = {-64,71}
modelData[1][7][1].BangPoint[4] = {-65,89}
modelData[1][7][1].BangPoint[3] = {61,85}

return modelData