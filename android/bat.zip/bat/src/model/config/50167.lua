--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50167
modelData = {
resID = 50167,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,171,163,134}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-1#30=1#0#48=2#-14#65=5#0#117=4#-8#71=3#-43#54"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {1,30}
modelData[1][3][1].BangPoint[1] = {0,48}
modelData[1][3][1].BangPoint[2] = {-14,65}
modelData[1][3][1].BangPoint[5] = {0,117}
modelData[1][3][1].BangPoint[4] = {-8,71}
modelData[1][3][1].BangPoint[3] = {-43,54}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,163,171}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#1#50=1#-1#48=2#13#52=5#0#117=4#8#28=3#43#46"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-1,50}
modelData[1][7][1].BangPoint[1] = {-1,48}
modelData[1][7][1].BangPoint[2] = {13,52}
modelData[1][7][1].BangPoint[5] = {0,117}
modelData[1][7][1].BangPoint[4] = {8,28}
modelData[1][7][1].BangPoint[3] = {43,46}

return modelData