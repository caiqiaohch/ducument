--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50174
modelData = {
resID = 50174,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {165,0,165,157}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#7#75=1#-10#71=2#-28#139=5#0#136=4#60#86=3#-72#76"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-7,75}
modelData[1][3][1].BangPoint[1] = {-10,71}
modelData[1][3][1].BangPoint[2] = {-28,139}
modelData[1][3][1].BangPoint[5] = {0,136}
modelData[1][3][1].BangPoint[4] = {60,86}
modelData[1][3][1].BangPoint[3] = {-72,76}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,165,189}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-7#75=1#10#62=2#27#103=5#0#136=4#-60#92=3#72#39"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {7,75}
modelData[1][7][1].BangPoint[1] = {10,62}
modelData[1][7][1].BangPoint[2] = {27,103}
modelData[1][7][1].BangPoint[5] = {0,136}
modelData[1][7][1].BangPoint[4] = {-60,92}
modelData[1][7][1].BangPoint[3] = {72,39}

return modelData