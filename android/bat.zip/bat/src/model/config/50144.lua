--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50144
modelData = {
resID = 50144,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,180,235}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#30#103=1#-4#142=2#-34#220=5#0#211=4#5#195=3#-44#73"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-30,103}
modelData[1][3][1].BangPoint[1] = {-4,142}
modelData[1][3][1].BangPoint[2] = {-34,220}
modelData[1][3][1].BangPoint[5] = {0,211}
modelData[1][3][1].BangPoint[4] = {5,195}
modelData[1][3][1].BangPoint[3] = {-44,73}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {180,0,181,205}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-29#91=1#3#136=2#34#190=5#0#211=4#-6#75=3#44#111"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {29,91}
modelData[1][7][1].BangPoint[1] = {3,136}
modelData[1][7][1].BangPoint[2] = {34,190}
modelData[1][7][1].BangPoint[5] = {0,211}
modelData[1][7][1].BangPoint[4] = {-6,75}
modelData[1][7][1].BangPoint[3] = {44,111}

return modelData