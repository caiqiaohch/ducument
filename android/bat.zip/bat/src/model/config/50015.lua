--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50015
modelData = {
resID = 50015,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,176,297}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#115=1#-8#142=2#-13#215=5#0#226=8#88#246=7#7#239=9#57#244=4#67#241=3#-55#125"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,115}
modelData[1][3][1].BangPoint[1] = {-8,142}
modelData[1][3][1].BangPoint[2] = {-13,215}
modelData[1][3][1].BangPoint[5] = {0,226}
modelData[1][3][1].BangPoint[8] = {88,246}
modelData[1][3][1].BangPoint[7] = {7,239}
modelData[1][3][1].BangPoint[9] = {57,244}
modelData[1][3][1].BangPoint[4] = {67,241}
modelData[1][3][1].BangPoint[3] = {-55,125}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {176,0,176,273}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#103=1#7#143=2#13#202=5#0#226=8#-89#171=7#-8#223=9#-58#192=4#-68#185=3#54#108"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,103}
modelData[1][7][1].BangPoint[1] = {7,143}
modelData[1][7][1].BangPoint[2] = {13,202}
modelData[1][7][1].BangPoint[5] = {0,226}
modelData[1][7][1].BangPoint[8] = {-89,171}
modelData[1][7][1].BangPoint[7] = {-8,223}
modelData[1][7][1].BangPoint[9] = {-58,192}
modelData[1][7][1].BangPoint[4] = {-68,185}
modelData[1][7][1].BangPoint[3] = {54,108}

return modelData