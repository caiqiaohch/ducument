--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50097
modelData = {
resID = 50097,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,128,224}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#78=1#4#100=2#-20#188=5#0#166=4#15#113=3#-15#97"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,78}
modelData[1][3][1].BangPoint[1] = {4,100}
modelData[1][3][1].BangPoint[2] = {-20,188}
modelData[1][3][1].BangPoint[5] = {0,166}
modelData[1][3][1].BangPoint[4] = {15,113}
modelData[1][3][1].BangPoint[3] = {-15,97}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {128,0,128,174}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#62=1#-5#73=2#19#138=5#0#166=4#-15#66=3#15#80"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,62}
modelData[1][7][1].BangPoint[1] = {-5,73}
modelData[1][7][1].BangPoint[2] = {19,138}
modelData[1][7][1].BangPoint[5] = {0,166}
modelData[1][7][1].BangPoint[4] = {-15,66}
modelData[1][7][1].BangPoint[3] = {15,80}

return modelData