--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50009
modelData = {
resID = 50009,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,155,137}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#2#28=1#6#39=2#-38#89=5#0#100=8#0#0=7#0#0=9#0#0=4#16#16=3#-38#5"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-2,28}
modelData[1][3][1].BangPoint[1] = {6,39}
modelData[1][3][1].BangPoint[2] = {-38,89}
modelData[1][3][1].BangPoint[5] = {0,100}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {16,16}
modelData[1][3][1].BangPoint[3] = {-38,5}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,137,156,123}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-3#23=1#-6#45=2#38#51=5#0#100=8#0#0=7#0#0=9#0#0=4#-16#-11=3#38#4"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {3,23}
modelData[1][7][1].BangPoint[1] = {-6,45}
modelData[1][7][1].BangPoint[2] = {38,51}
modelData[1][7][1].BangPoint[5] = {0,100}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-16,-11}
modelData[1][7][1].BangPoint[3] = {38,4}

return modelData