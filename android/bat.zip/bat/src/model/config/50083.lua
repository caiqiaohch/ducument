--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50083
modelData = {
resID = 50083,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,268,302}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#22#105=1#8#156=2#-48#205=5#0#274=8#0#0=7#0#0=9#0#0=4#63#153=3#-108#83"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-22,105}
modelData[1][3][1].BangPoint[1] = {8,156}
modelData[1][3][1].BangPoint[2] = {-48,205}
modelData[1][3][1].BangPoint[5] = {0,274}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {63,153}
modelData[1][3][1].BangPoint[3] = {-108,83}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {268,0,268,284}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-22#107=1#-9#164=2#47#141=5#0#274=8#0#0=7#0#0=9#0#0=4#-63#58=3#107#90"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {22,107}
modelData[1][7][1].BangPoint[1] = {-9,164}
modelData[1][7][1].BangPoint[2] = {47,141}
modelData[1][7][1].BangPoint[5] = {0,274}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-63,58}
modelData[1][7][1].BangPoint[3] = {107,90}

return modelData