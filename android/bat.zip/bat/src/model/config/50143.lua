--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50143
modelData = {
resID = 50143,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {145,0,145,142}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#66=1#2#44=2#2#90=5#0#119=4#69#119=3#-66#70"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,66}
modelData[1][3][1].BangPoint[1] = {2,44}
modelData[1][3][1].BangPoint[2] = {2,90}
modelData[1][3][1].BangPoint[5] = {0,119}
modelData[1][3][1].BangPoint[4] = {69,119}
modelData[1][3][1].BangPoint[3] = {-66,70}
--帧数2
modelData[1][3][2] = {0,0,145,142}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#-3#66=1#2#44=2#2#90=5#0#119=4#69#119=3#-66#70"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {3,66}
modelData[1][3][2].BangPoint[1] = {2,44}
modelData[1][3][2].BangPoint[2] = {2,90}
modelData[1][3][2].BangPoint[5] = {0,119}
modelData[1][3][2].BangPoint[4] = {69,119}
modelData[1][3][2].BangPoint[3] = {-66,70}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {145,142,145,134}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#64=1#-3#46=2#-3#92=5#0#119=4#-70#55=3#65#106"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,64}
modelData[1][7][1].BangPoint[1] = {-3,46}
modelData[1][7][1].BangPoint[2] = {-3,92}
modelData[1][7][1].BangPoint[5] = {0,119}
modelData[1][7][1].BangPoint[4] = {-70,55}
modelData[1][7][1].BangPoint[3] = {65,106}
--帧数2
modelData[1][7][2] = {0,142,145,134}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#3#64=1#-3#46=2#-3#92=5#0#119=4#-70#55=3#65#106"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {-3,64}
modelData[1][7][2].BangPoint[1] = {-3,46}
modelData[1][7][2].BangPoint[2] = {-3,92}
modelData[1][7][2].BangPoint[5] = {0,119}
modelData[1][7][2].BangPoint[4] = {-70,55}
modelData[1][7][2].BangPoint[3] = {65,106}

return modelData