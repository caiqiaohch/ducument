--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50072
modelData = {
resID = 50072,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,242,214}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-34#10=1#-18#68=2#-67#82=5#0#131=8#0#0=7#0#0=9#0#0=4#-8#28=3#-60#21"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {34,10}
modelData[1][3][1].BangPoint[1] = {-18,68}
modelData[1][3][1].BangPoint[2] = {-67,82}
modelData[1][3][1].BangPoint[5] = {0,131}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-8,28}
modelData[1][3][1].BangPoint[3] = {-60,21}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,214,242,150}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#34#42=1#17#51=2#66#17=5#0#131=8#0#0=7#0#0=9#0#0=4#8#-14=3#59#-5"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-34,42}
modelData[1][7][1].BangPoint[1] = {17,51}
modelData[1][7][1].BangPoint[2] = {66,17}
modelData[1][7][1].BangPoint[5] = {0,131}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {8,-14}
modelData[1][7][1].BangPoint[3] = {59,-5}

return modelData