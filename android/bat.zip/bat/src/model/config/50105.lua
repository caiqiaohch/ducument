--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50105
modelData = {
resID = 50105,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,128,169}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-5#67=1#-6#91=2#-18#152=5#0#149=4#33#74=3#-29#98"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {5,67}
modelData[1][3][1].BangPoint[1] = {-6,91}
modelData[1][3][1].BangPoint[2] = {-18,152}
modelData[1][3][1].BangPoint[5] = {0,149}
modelData[1][3][1].BangPoint[4] = {33,74}
modelData[1][3][1].BangPoint[3] = {-29,98}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {128,0,128,161}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#5#59=1#6#86=2#17#131=5#0#149=4#-34#49=3#29#66"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-5,59}
modelData[1][7][1].BangPoint[1] = {6,86}
modelData[1][7][1].BangPoint[2] = {17,131}
modelData[1][7][1].BangPoint[5] = {0,149}
modelData[1][7][1].BangPoint[4] = {-34,49}
modelData[1][7][1].BangPoint[3] = {29,66}

return modelData