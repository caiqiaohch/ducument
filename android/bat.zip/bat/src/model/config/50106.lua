--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50106
modelData = {
resID = 50106,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {258,0,257,285}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#128=1#-3#177=2#-9#257=5#0#261=4#86#153=3#-107#162"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,128}
modelData[1][3][1].BangPoint[1] = {-3,177}
modelData[1][3][1].BangPoint[2] = {-9,257}
modelData[1][3][1].BangPoint[5] = {0,261}
modelData[1][3][1].BangPoint[4] = {86,153}
modelData[1][3][1].BangPoint[3] = {-107,162}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,258,295}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#118=1#2#174=2#8#248=5#0#261=4#-86#141=3#106#171"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,118}
modelData[1][7][1].BangPoint[1] = {2,174}
modelData[1][7][1].BangPoint[2] = {8,248}
modelData[1][7][1].BangPoint[5] = {0,261}
modelData[1][7][1].BangPoint[4] = {-86,141}
modelData[1][7][1].BangPoint[3] = {106,171}

return modelData