--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50170
modelData = {
resID = 50170,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,164,299}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-1#107=1#0#88=2#0#226=5#0#227=4#34#165=3#-34#131"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {1,107}
modelData[1][3][1].BangPoint[1] = {0,88}
modelData[1][3][1].BangPoint[2] = {0,226}
modelData[1][3][1].BangPoint[5] = {0,227}
modelData[1][3][1].BangPoint[4] = {34,165}
modelData[1][3][1].BangPoint[3] = {-34,131}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {164,0,163,298}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#1#109=1#0#88=2#0#226=5#0#227=4#-34#131=3#33#165"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-1,109}
modelData[1][7][1].BangPoint[1] = {0,88}
modelData[1][7][1].BangPoint[2] = {0,226}
modelData[1][7][1].BangPoint[5] = {0,227}
modelData[1][7][1].BangPoint[4] = {-34,131}
modelData[1][7][1].BangPoint[3] = {33,165}

return modelData