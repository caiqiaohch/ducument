--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50068
modelData = {
resID = 50068,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {212,0,212,231}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#88=1#1#141=2#-3#203=5#0#231=8#0#0=7#0#0=9#0#0=4#-10#182=3#-74#156"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,88}
modelData[1][3][1].BangPoint[1] = {1,141}
modelData[1][3][1].BangPoint[2] = {-3,203}
modelData[1][3][1].BangPoint[5] = {0,231}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-10,182}
modelData[1][3][1].BangPoint[3] = {-74,156}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,212,238}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#90=1#-1#142=2#2#201=5#0#231=8#0#0=7#0#0=9#0#0=4#10#114=3#73#147"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,90}
modelData[1][7][1].BangPoint[1] = {-1,142}
modelData[1][7][1].BangPoint[2] = {2,201}
modelData[1][7][1].BangPoint[5] = {0,231}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {10,114}
modelData[1][7][1].BangPoint[3] = {73,147}

return modelData