--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50095
modelData = {
resID = 50095,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,149,248}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-1#100=1#-15#177=2#-48#225=5#0#229=4#-12#142=3#-58#93"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {1,100}
modelData[1][3][1].BangPoint[1] = {-15,177}
modelData[1][3][1].BangPoint[2] = {-48,225}
modelData[1][3][1].BangPoint[5] = {0,229}
modelData[1][3][1].BangPoint[4] = {-12,142}
modelData[1][3][1].BangPoint[3] = {-58,93}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {149,0,149,220}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#1#86=1#15#162=2#48#177=5#0#229=4#11#70=3#57#108"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-1,86}
modelData[1][7][1].BangPoint[1] = {15,162}
modelData[1][7][1].BangPoint[2] = {48,177}
modelData[1][7][1].BangPoint[5] = {0,229}
modelData[1][7][1].BangPoint[4] = {11,70}
modelData[1][7][1].BangPoint[3] = {57,108}

return modelData