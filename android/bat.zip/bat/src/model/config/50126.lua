--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50126
modelData = {
resID = 50126,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {306,0,102,272}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-2#118=1#-5#172=2#-7#255=5#0#252=4#-22#169=3#-39#177"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {2,118}
modelData[1][3][1].BangPoint[1] = {-5,172}
modelData[1][3][1].BangPoint[2] = {-7,255}
modelData[1][3][1].BangPoint[5] = {0,252}
modelData[1][3][1].BangPoint[4] = {-22,169}
modelData[1][3][1].BangPoint[3] = {-39,177}
--帧数2
modelData[1][3][2] = {204,0,102,272}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#-2#118=1#-5#172=2#-7#255=5#0#252=4#-22#169=3#-39#177"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {2,118}
modelData[1][3][2].BangPoint[1] = {-5,172}
modelData[1][3][2].BangPoint[2] = {-7,255}
modelData[1][3][2].BangPoint[5] = {0,252}
modelData[1][3][2].BangPoint[4] = {-22,169}
modelData[1][3][2].BangPoint[3] = {-39,177}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {102,0,102,273}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#2#111=1#4#168=2#7#248=5#0#252=4#22#133=3#38#158"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-2,111}
modelData[1][7][1].BangPoint[1] = {4,168}
modelData[1][7][1].BangPoint[2] = {7,248}
modelData[1][7][1].BangPoint[5] = {0,252}
modelData[1][7][1].BangPoint[4] = {22,133}
modelData[1][7][1].BangPoint[3] = {38,158}
--帧数2
modelData[1][7][2] = {0,0,102,273}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#2#111=1#4#168=2#7#248=5#0#252=4#22#133=3#38#158"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {-2,111}
modelData[1][7][2].BangPoint[1] = {4,168}
modelData[1][7][2].BangPoint[2] = {7,248}
modelData[1][7][2].BangPoint[5] = {0,252}
modelData[1][7][2].BangPoint[4] = {22,133}
modelData[1][7][2].BangPoint[3] = {38,158}

return modelData