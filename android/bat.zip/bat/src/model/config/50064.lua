--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50064
modelData = {
resID = 50064,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,169,267}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-12#107=1#-5#151=2#-30#226=5#0#258=8#95#193=7#7#219=9#89#198=4#85#202=3#-40#151"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {12,107}
modelData[1][3][1].BangPoint[1] = {-5,151}
modelData[1][3][1].BangPoint[2] = {-30,226}
modelData[1][3][1].BangPoint[5] = {0,258}
modelData[1][3][1].BangPoint[8] = {95,193}
modelData[1][3][1].BangPoint[7] = {7,219}
modelData[1][3][1].BangPoint[9] = {89,198}
modelData[1][3][1].BangPoint[4] = {85,202}
modelData[1][3][1].BangPoint[3] = {-40,151}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {169,0,169,256}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#12#102=1#5#144=2#29#187=5#0#258=8#-95#201=7#-7#94=9#-90#183=4#-85#182=3#40#93"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-12,102}
modelData[1][7][1].BangPoint[1] = {5,144}
modelData[1][7][1].BangPoint[2] = {29,187}
modelData[1][7][1].BangPoint[5] = {0,258}
modelData[1][7][1].BangPoint[8] = {-95,201}
modelData[1][7][1].BangPoint[7] = {-7,94}
modelData[1][7][1].BangPoint[9] = {-90,183}
modelData[1][7][1].BangPoint[4] = {-85,182}
modelData[1][7][1].BangPoint[3] = {40,93}

return modelData