--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50147
modelData = {
resID = 50147,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {175,0,175,183}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#12#73=1#13#90=2#-2#114=5#0#198=4#-56#62=3#14#137"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-12,73}
modelData[1][3][1].BangPoint[1] = {13,90}
modelData[1][3][1].BangPoint[2] = {-2,114}
modelData[1][3][1].BangPoint[5] = {0,198}
modelData[1][3][1].BangPoint[4] = {-56,62}
modelData[1][3][1].BangPoint[3] = {14,137}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,175,196}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-12#109=1#-13#64=2#1#83=5#0#198=4#56#55=3#-15#138"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {12,109}
modelData[1][7][1].BangPoint[1] = {-13,64}
modelData[1][7][1].BangPoint[2] = {1,83}
modelData[1][7][1].BangPoint[5] = {0,198}
modelData[1][7][1].BangPoint[4] = {56,55}
modelData[1][7][1].BangPoint[3] = {-15,138}

return modelData