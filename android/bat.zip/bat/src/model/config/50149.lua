--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50149
modelData = {
resID = 50149,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {114,0,114,110}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#6#30=1#-1#37=2#-18#77=5#0#72=4#-6#25=3#-46#5"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-6,30}
modelData[1][3][1].BangPoint[1] = {-1,37}
modelData[1][3][1].BangPoint[2] = {-18,77}
modelData[1][3][1].BangPoint[5] = {0,72}
modelData[1][3][1].BangPoint[4] = {-6,25}
modelData[1][3][1].BangPoint[3] = {-46,5}
--帧数2
modelData[1][3][2] = {0,0,114,110}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#6#30=1#-1#37=2#-18#77=5#0#72=4#-6#25=3#-46#5"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {-6,30}
modelData[1][3][2].BangPoint[1] = {-1,37}
modelData[1][3][2].BangPoint[2] = {-18,77}
modelData[1][3][2].BangPoint[5] = {0,72}
modelData[1][3][2].BangPoint[4] = {-6,25}
modelData[1][3][2].BangPoint[3] = {-46,5}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {0,110,114,96}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-6#17=1#1#36=2#17#59=5#0#72=4#6#-20=3#46#0"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {6,17}
modelData[1][7][1].BangPoint[1] = {1,36}
modelData[1][7][1].BangPoint[2] = {17,59}
modelData[1][7][1].BangPoint[5] = {0,72}
modelData[1][7][1].BangPoint[4] = {6,-20}
modelData[1][7][1].BangPoint[3] = {46,0}
--帧数2
modelData[1][7][2] = {114,110,114,96}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#-6#17=1#1#36=2#17#59=5#0#72=4#6#-20=3#46#0"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {6,17}
modelData[1][7][2].BangPoint[1] = {1,36}
modelData[1][7][2].BangPoint[2] = {17,59}
modelData[1][7][2].BangPoint[5] = {0,72}
modelData[1][7][2].BangPoint[4] = {6,-20}
modelData[1][7][2].BangPoint[3] = {46,0}

return modelData