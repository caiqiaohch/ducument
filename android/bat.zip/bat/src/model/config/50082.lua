--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50082
modelData = {
resID = 50082,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {235,0,235,175}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-33#42=1#6#69=2#-64#134=5#0#120=4#-26#37=3#-34#11"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {33,42}
modelData[1][3][1].BangPoint[1] = {6,69}
modelData[1][3][1].BangPoint[2] = {-64,134}
modelData[1][3][1].BangPoint[5] = {0,120}
modelData[1][3][1].BangPoint[4] = {-26,37}
modelData[1][3][1].BangPoint[3] = {-34,11}
--帧数2
modelData[1][3][2] = {0,0,235,175}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#-33#42=1#6#69=2#-64#134=5#0#120=4#-26#37=3#-34#11"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {33,42}
modelData[1][3][2].BangPoint[1] = {6,69}
modelData[1][3][2].BangPoint[2] = {-64,134}
modelData[1][3][2].BangPoint[5] = {0,120}
modelData[1][3][2].BangPoint[4] = {-26,37}
modelData[1][3][2].BangPoint[3] = {-34,11}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {0,175,235,165}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#33#43=1#-7#76=2#63#71=5#0#120=4#25#-20=3#33#7"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-33,43}
modelData[1][7][1].BangPoint[1] = {-7,76}
modelData[1][7][1].BangPoint[2] = {63,71}
modelData[1][7][1].BangPoint[5] = {0,120}
modelData[1][7][1].BangPoint[4] = {25,-20}
modelData[1][7][1].BangPoint[3] = {33,7}
--帧数2
modelData[1][7][2] = {235,175,235,165}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#33#43=1#-7#76=2#63#71=5#0#120=4#25#-20=3#33#7"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {-33,43}
modelData[1][7][2].BangPoint[1] = {-7,76}
modelData[1][7][2].BangPoint[2] = {63,71}
modelData[1][7][2].BangPoint[5] = {0,120}
modelData[1][7][2].BangPoint[4] = {25,-20}
modelData[1][7][2].BangPoint[3] = {33,7}

return modelData