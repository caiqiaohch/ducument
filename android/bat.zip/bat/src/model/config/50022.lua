--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50022
modelData = {
resID = 50022,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,142,247}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#87=1#-4#146=2#-1#206=5#0#217=8#-26#186=7#-24#12=9#-26#148=4#-29#159=3#-23#171"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,87}
modelData[1][3][1].BangPoint[1] = {-4,146}
modelData[1][3][1].BangPoint[2] = {-1,206}
modelData[1][3][1].BangPoint[5] = {0,217}
modelData[1][3][1].BangPoint[8] = {-26,186}
modelData[1][3][1].BangPoint[7] = {-24,12}
modelData[1][3][1].BangPoint[9] = {-26,148}
modelData[1][3][1].BangPoint[4] = {-29,159}
modelData[1][3][1].BangPoint[3] = {-23,171}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {142,0,143,245}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#86=1#4#142=2#0#206=5#0#217=8#25#160=7#24#-12=9#25#123=4#28#137=3#22#144"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,86}
modelData[1][7][1].BangPoint[1] = {4,142}
modelData[1][7][1].BangPoint[2] = {0,206}
modelData[1][7][1].BangPoint[5] = {0,217}
modelData[1][7][1].BangPoint[8] = {25,160}
modelData[1][7][1].BangPoint[7] = {24,-12}
modelData[1][7][1].BangPoint[9] = {25,123}
modelData[1][7][1].BangPoint[4] = {28,137}
modelData[1][7][1].BangPoint[3] = {22,144}

return modelData