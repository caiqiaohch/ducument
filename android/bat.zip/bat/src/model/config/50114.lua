--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50114
modelData = {
resID = 50114,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,180,219}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#24#71=1#-44#96=2#-75#142=5#0#137=4#13#164=3#-54#29"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-24,71}
modelData[1][3][1].BangPoint[1] = {-44,96}
modelData[1][3][1].BangPoint[2] = {-75,142}
modelData[1][3][1].BangPoint[5] = {0,137}
modelData[1][3][1].BangPoint[4] = {13,164}
modelData[1][3][1].BangPoint[3] = {-54,29}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {180,0,180,156}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-24#27=1#43#51=2#74#52=5#0#137=4#-13#51=3#53#-21"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {24,27}
modelData[1][7][1].BangPoint[1] = {43,51}
modelData[1][7][1].BangPoint[2] = {74,52}
modelData[1][7][1].BangPoint[5] = {0,137}
modelData[1][7][1].BangPoint[4] = {-13,51}
modelData[1][7][1].BangPoint[3] = {53,-21}

return modelData