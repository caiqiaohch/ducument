--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50013
modelData = {
resID = 50013,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,115,241}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#6#94=1#-3#158=2#0#213=5#0#214=4#-13#165=3#-49#148"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-6,94}
modelData[1][3][1].BangPoint[1] = {-3,158}
modelData[1][3][1].BangPoint[2] = {0,213}
modelData[1][3][1].BangPoint[5] = {0,214}
modelData[1][3][1].BangPoint[4] = {-13,165}
modelData[1][3][1].BangPoint[3] = {-49,148}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {115,0,115,234}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-6#98=1#3#155=2#0#213=5#0#214=4#13#117=3#48#135"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {6,98}
modelData[1][7][1].BangPoint[1] = {3,155}
modelData[1][7][1].BangPoint[2] = {0,213}
modelData[1][7][1].BangPoint[5] = {0,214}
modelData[1][7][1].BangPoint[4] = {13,117}
modelData[1][7][1].BangPoint[3] = {48,135}

--动作3******
modelData[3] = {}
--方向3
modelData[3][3] = {}
modelData[3][3].Frames = 3
--帧数1
modelData[3][3][1] = {254,0,115,241}--x,y,w,h
modelData[3][3][1].BangPointStr = "0#6#94=1#-3#158=2#0#213=5#0#214=4#-13#165=3#-49#148"
modelData[3][3][1].BangPoint = {}
modelData[3][3][1].BangPoint[0] = {-6,94}
modelData[3][3][1].BangPoint[1] = {-3,158}
modelData[3][3][1].BangPoint[2] = {0,213}
modelData[3][3][1].BangPoint[5] = {0,214}
modelData[3][3][1].BangPoint[4] = {-13,165}
modelData[3][3][1].BangPoint[3] = {-49,148}
--帧数2
modelData[3][3][2] = {132,0,122,263}--x,y,w,h
modelData[3][3][2].BangPointStr = "0#12#106=1#-2#158=2#-1#211=5#0#214=4#39#124=3#-58#222"
modelData[3][3][2].BangPoint = {}
modelData[3][3][2].BangPoint[0] = {-12,106}
modelData[3][3][2].BangPoint[1] = {-2,158}
modelData[3][3][2].BangPoint[2] = {-1,211}
modelData[3][3][2].BangPoint[5] = {0,214}
modelData[3][3][2].BangPoint[4] = {39,124}
modelData[3][3][2].BangPoint[3] = {-58,222}
--帧数3
modelData[3][3][3] = {0,0,132,283}--x,y,w,h
modelData[3][3][3].BangPointStr = "0#20#115=1#-2#158=2#-2#211=5#0#214=4#24#103=3#-45#239"
modelData[3][3][3].BangPoint = {}
modelData[3][3][3].BangPoint[0] = {-20,115}
modelData[3][3][3].BangPoint[1] = {-2,158}
modelData[3][3][3].BangPoint[2] = {-2,211}
modelData[3][3][3].BangPoint[5] = {0,214}
modelData[3][3][3].BangPoint[4] = {24,103}
modelData[3][3][3].BangPoint[3] = {-45,239}
--方向7
modelData[3][7] = {}
modelData[3][7].Frames = 3
--帧数1
modelData[3][7][1] = {0,283,115,234}--x,y,w,h
modelData[3][7][1].BangPointStr = "0#-6#98=1#3#155=2#0#213=5#0#214=4#13#117=3#48#135"
modelData[3][7][1].BangPoint = {}
modelData[3][7][1].BangPoint[0] = {6,98}
modelData[3][7][1].BangPoint[1] = {3,155}
modelData[3][7][1].BangPoint[2] = {0,213}
modelData[3][7][1].BangPoint[5] = {0,214}
modelData[3][7][1].BangPoint[4] = {13,117}
modelData[3][7][1].BangPoint[3] = {48,135}
--帧数2
modelData[3][7][2] = {115,283,122,233}--x,y,w,h
modelData[3][7][2].BangPointStr = "0#-12#99=1#2#155=2#0#215=5#0#214=4#-40#117=3#57#188"
modelData[3][7][2].BangPoint = {}
modelData[3][7][2].BangPoint[0] = {12,99}
modelData[3][7][2].BangPoint[1] = {2,155}
modelData[3][7][2].BangPoint[2] = {0,215}
modelData[3][7][2].BangPoint[5] = {0,214}
modelData[3][7][2].BangPoint[4] = {-40,117}
modelData[3][7][2].BangPoint[3] = {57,188}
--帧数3
modelData[3][7][3] = {369,0,132,239}--x,y,w,h
modelData[3][7][3].BangPointStr = "0#-20#103=1#1#155=2#2#216=5#0#214=4#-25#128=3#45#210"
modelData[3][7][3].BangPoint = {}
modelData[3][7][3].BangPoint[0] = {20,103}
modelData[3][7][3].BangPoint[1] = {1,155}
modelData[3][7][3].BangPoint[2] = {2,216}
modelData[3][7][3].BangPoint[5] = {0,214}
modelData[3][7][3].BangPoint[4] = {-25,128}
modelData[3][7][3].BangPoint[3] = {45,210}

return modelData