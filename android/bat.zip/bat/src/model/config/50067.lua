--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50067
modelData = {
resID = 50067,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,126,270}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-10#109=1#0#134=2#-6#201=5#0#231=8#62#15=7#66#216=9#63#100=4#65#153=3#-33#113"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {10,109}
modelData[1][3][1].BangPoint[1] = {0,134}
modelData[1][3][1].BangPoint[2] = {-6,201}
modelData[1][3][1].BangPoint[5] = {0,231}
modelData[1][3][1].BangPoint[8] = {62,15}
modelData[1][3][1].BangPoint[7] = {66,216}
modelData[1][3][1].BangPoint[9] = {63,100}
modelData[1][3][1].BangPoint[4] = {65,153}
modelData[1][3][1].BangPoint[3] = {-33,113}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {126,0,126,237}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#10#92=1#0#134=2#6#195=5#0#231=8#-63#-23=7#-66#179=9#-63#60=4#-66#127=3#33#115"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-10,92}
modelData[1][7][1].BangPoint[1] = {0,134}
modelData[1][7][1].BangPoint[2] = {6,195}
modelData[1][7][1].BangPoint[5] = {0,231}
modelData[1][7][1].BangPoint[8] = {-63,-23}
modelData[1][7][1].BangPoint[7] = {-66,179}
modelData[1][7][1].BangPoint[9] = {-63,60}
modelData[1][7][1].BangPoint[4] = {-66,127}
modelData[1][7][1].BangPoint[3] = {33,115}

return modelData