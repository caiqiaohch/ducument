--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50089
modelData = {
resID = 50089,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,341,337}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-29#99=1#5#104=2#-59#187=5#0#187=8#194#207=7#-62#257=9#85#231=4#80#230=3#-104#4"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {29,99}
modelData[1][3][1].BangPoint[1] = {5,104}
modelData[1][3][1].BangPoint[2] = {-59,187}
modelData[1][3][1].BangPoint[5] = {0,187}
modelData[1][3][1].BangPoint[8] = {194,207}
modelData[1][3][1].BangPoint[7] = {-62,257}
modelData[1][3][1].BangPoint[9] = {85,231}
modelData[1][3][1].BangPoint[4] = {80,230}
modelData[1][3][1].BangPoint[3] = {-104,4}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,337,341,228}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#29#88=1#-6#104=2#58#111=5#0#187=8#-195#195=7#62#22=9#-86#117=4#-81#124=3#103#14"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-29,88}
modelData[1][7][1].BangPoint[1] = {-6,104}
modelData[1][7][1].BangPoint[2] = {58,111}
modelData[1][7][1].BangPoint[5] = {0,187}
modelData[1][7][1].BangPoint[8] = {-195,195}
modelData[1][7][1].BangPoint[7] = {62,22}
modelData[1][7][1].BangPoint[9] = {-86,117}
modelData[1][7][1].BangPoint[4] = {-81,124}
modelData[1][7][1].BangPoint[3] = {103,14}

return modelData