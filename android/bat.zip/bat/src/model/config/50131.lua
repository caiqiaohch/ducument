--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50131
modelData = {
resID = 50131,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 2
--帧数1
modelData[1][3][1] = {150,232,150,228}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-3#84=1#4#100=2#9#183=5#0#185=4#53#132=3#-48#77"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {3,84}
modelData[1][3][1].BangPoint[1] = {4,100}
modelData[1][3][1].BangPoint[2] = {9,183}
modelData[1][3][1].BangPoint[5] = {0,185}
modelData[1][3][1].BangPoint[4] = {53,132}
modelData[1][3][1].BangPoint[3] = {-48,77}
--帧数2
modelData[1][3][2] = {0,232,150,228}--x,y,w,h
modelData[1][3][2].BangPointStr = "0#-3#84=1#4#100=2#9#183=5#0#185=4#53#132=3#-48#77"
modelData[1][3][2].BangPoint = {}
modelData[1][3][2].BangPoint[0] = {3,84}
modelData[1][3][2].BangPoint[1] = {4,100}
modelData[1][3][2].BangPoint[2] = {9,183}
modelData[1][3][2].BangPoint[5] = {0,185}
modelData[1][3][2].BangPoint[4] = {53,132}
modelData[1][3][2].BangPoint[3] = {-48,77}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 2
--帧数1
modelData[1][7][1] = {150,0,150,232}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#3#90=1#-5#96=2#-10#180=5#0#185=4#-54#78=3#48#124"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-3,90}
modelData[1][7][1].BangPoint[1] = {-5,96}
modelData[1][7][1].BangPoint[2] = {-10,180}
modelData[1][7][1].BangPoint[5] = {0,185}
modelData[1][7][1].BangPoint[4] = {-54,78}
modelData[1][7][1].BangPoint[3] = {48,124}
--帧数2
modelData[1][7][2] = {0,0,150,232}--x,y,w,h
modelData[1][7][2].BangPointStr = "0#3#90=1#-5#96=2#-10#180=5#0#185=4#-54#78=3#48#124"
modelData[1][7][2].BangPoint = {}
modelData[1][7][2].BangPoint[0] = {-3,90}
modelData[1][7][2].BangPoint[1] = {-5,96}
modelData[1][7][2].BangPoint[2] = {-10,180}
modelData[1][7][2].BangPoint[5] = {0,185}
modelData[1][7][2].BangPoint[4] = {-54,78}
modelData[1][7][2].BangPoint[3] = {48,124}

return modelData