--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50075
modelData = {
resID = 50075,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,218,188}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#36#65=1#-10#61=2#-118#96=5#0#125=8#0#0=7#0#0=9#0#0=4#-7#34=3#-71#17"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-36,65}
modelData[1][3][1].BangPoint[1] = {-10,61}
modelData[1][3][1].BangPoint[2] = {-118,96}
modelData[1][3][1].BangPoint[5] = {0,125}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-7,34}
modelData[1][3][1].BangPoint[3] = {-71,17}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,188,218,144}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-36#36=1#10#51=2#117#-21=5#0#125=8#0#0=7#0#0=9#0#0=4#7#-24=3#70#-9"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {36,36}
modelData[1][7][1].BangPoint[1] = {10,51}
modelData[1][7][1].BangPoint[2] = {117,-21}
modelData[1][7][1].BangPoint[5] = {0,125}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {7,-24}
modelData[1][7][1].BangPoint[3] = {70,-9}

return modelData