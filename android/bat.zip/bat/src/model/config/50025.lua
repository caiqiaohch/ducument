--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50025
modelData = {
resID = 50025,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,240,243}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-38#85=1#-12#150=2#-27#209=5#0#220=8#159#78=7#77#102=9#106#94=4#65#110=3#-65#149"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {38,85}
modelData[1][3][1].BangPoint[1] = {-12,150}
modelData[1][3][1].BangPoint[2] = {-27,209}
modelData[1][3][1].BangPoint[5] = {0,220}
modelData[1][3][1].BangPoint[8] = {159,78}
modelData[1][3][1].BangPoint[7] = {77,102}
modelData[1][3][1].BangPoint[9] = {106,94}
modelData[1][3][1].BangPoint[4] = {65,110}
modelData[1][3][1].BangPoint[3] = {-65,149}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,243,240,232}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#38#80=1#11#137=2#26#187=5#0#220=8#-159#-17=7#-78#101=9#-106#60=4#-66#123=3#65#95"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-38,80}
modelData[1][7][1].BangPoint[1] = {11,137}
modelData[1][7][1].BangPoint[2] = {26,187}
modelData[1][7][1].BangPoint[5] = {0,220}
modelData[1][7][1].BangPoint[8] = {-159,-17}
modelData[1][7][1].BangPoint[7] = {-78,101}
modelData[1][7][1].BangPoint[9] = {-106,60}
modelData[1][7][1].BangPoint[4] = {-66,123}
modelData[1][7][1].BangPoint[3] = {65,95}

return modelData