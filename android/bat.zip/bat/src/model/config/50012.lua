--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50012
modelData = {
resID = 50012,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,85,314}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-6#144=1#0#164=2#1#228=5#0#230=4#28#165=3#-29#93"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {6,144}
modelData[1][3][1].BangPoint[1] = {0,164}
modelData[1][3][1].BangPoint[2] = {1,228}
modelData[1][3][1].BangPoint[5] = {0,230}
modelData[1][3][1].BangPoint[4] = {28,165}
modelData[1][3][1].BangPoint[3] = {-29,93}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {85,0,85,256}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#6#102=1#0#164=2#-1#229=5#0#230=4#-28#103=3#28#128"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-6,102}
modelData[1][7][1].BangPoint[1] = {0,164}
modelData[1][7][1].BangPoint[2] = {-1,229}
modelData[1][7][1].BangPoint[5] = {0,230}
modelData[1][7][1].BangPoint[4] = {-28,103}
modelData[1][7][1].BangPoint[3] = {28,128}

return modelData