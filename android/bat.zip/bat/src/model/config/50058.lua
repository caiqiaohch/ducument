--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50058
modelData = {
resID = 50058,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,165,364}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#30#156=1#0#158=2#-1#223=5#0#228=8#-6#119=7#-88#313=9#-53#230=4#-45#232=3#3#99"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-30,156}
modelData[1][3][1].BangPoint[1] = {0,158}
modelData[1][3][1].BangPoint[2] = {-1,223}
modelData[1][3][1].BangPoint[5] = {0,228}
modelData[1][3][1].BangPoint[8] = {-6,119}
modelData[1][3][1].BangPoint[7] = {-88,313}
modelData[1][3][1].BangPoint[9] = {-53,230}
modelData[1][3][1].BangPoint[4] = {-45,232}
modelData[1][3][1].BangPoint[3] = {3,99}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {165,0,165,294}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-30#120=1#-1#158=2#1#218=5#0#228=8#6#81=7#87#214=9#52#157=4#44#159=3#-4#152"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {30,120}
modelData[1][7][1].BangPoint[1] = {-1,158}
modelData[1][7][1].BangPoint[2] = {1,218}
modelData[1][7][1].BangPoint[5] = {0,228}
modelData[1][7][1].BangPoint[8] = {6,81}
modelData[1][7][1].BangPoint[7] = {87,214}
modelData[1][7][1].BangPoint[9] = {52,157}
modelData[1][7][1].BangPoint[4] = {44,159}
modelData[1][7][1].BangPoint[3] = {-4,152}

return modelData