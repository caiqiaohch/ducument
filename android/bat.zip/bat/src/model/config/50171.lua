--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50171
modelData = {
resID = 50171,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {134,0,134,247}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#0#89=1#0#88=2#0#200=5#0#201=4#49#195=3#-49#146"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {0,89}
modelData[1][3][1].BangPoint[1] = {0,88}
modelData[1][3][1].BangPoint[2] = {0,200}
modelData[1][3][1].BangPoint[5] = {0,201}
modelData[1][3][1].BangPoint[4] = {49,195}
modelData[1][3][1].BangPoint[3] = {-49,146}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,134,247}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#0#89=1#0#88=2#0#200=5#0#201=4#-49#146=3#49#195"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {0,89}
modelData[1][7][1].BangPoint[1] = {0,88}
modelData[1][7][1].BangPoint[2] = {0,200}
modelData[1][7][1].BangPoint[5] = {0,201}
modelData[1][7][1].BangPoint[4] = {-49,146}
modelData[1][7][1].BangPoint[3] = {49,195}

return modelData