--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50135
modelData = {
resID = 50135,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,105,237}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#22#102=1#-2#155=2#3#219=5#0#222=4#7#182=3#-64#189"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-22,102}
modelData[1][3][1].BangPoint[1] = {-2,155}
modelData[1][3][1].BangPoint[2] = {3,219}
modelData[1][3][1].BangPoint[5] = {0,222}
modelData[1][3][1].BangPoint[4] = {7,182}
modelData[1][3][1].BangPoint[3] = {-64,189}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {105,0,106,236}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-22#106=1#1#151=2#-4#222=5#0#222=4#-7#159=3#64#159"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {22,106}
modelData[1][7][1].BangPoint[1] = {1,151}
modelData[1][7][1].BangPoint[2] = {-4,222}
modelData[1][7][1].BangPoint[5] = {0,222}
modelData[1][7][1].BangPoint[4] = {-7,159}
modelData[1][7][1].BangPoint[3] = {64,159}

return modelData