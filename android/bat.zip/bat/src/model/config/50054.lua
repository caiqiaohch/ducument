--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50054
modelData = {
resID = 50054,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,241,196}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#11#58=1#-2#-1=2#-102#94=5#0#144=8#0#0=7#0#0=9#0#0=4#6#44=3#-93#14"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-11,58}
modelData[1][3][1].BangPoint[1] = {-2,-1}
modelData[1][3][1].BangPoint[2] = {-102,94}
modelData[1][3][1].BangPoint[5] = {0,144}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {6,44}
modelData[1][3][1].BangPoint[3] = {-93,14}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,196,241,176}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-11#36=1#2#1=2#101#0=5#0#144=8#0#0=7#0#0=9#0#0=4#-7#-27=3#92#0"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {11,36}
modelData[1][7][1].BangPoint[1] = {2,1}
modelData[1][7][1].BangPoint[2] = {101,0}
modelData[1][7][1].BangPoint[5] = {0,144}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-7,-27}
modelData[1][7][1].BangPoint[3] = {92,0}

return modelData