--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50118
modelData = {
resID = 50118,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,201,324}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#8#116=1#0#134=2#-63#272=5#0#246=4#-30#122=3#-70#100"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-8,116}
modelData[1][3][1].BangPoint[1] = {0,134}
modelData[1][3][1].BangPoint[2] = {-63,272}
modelData[1][3][1].BangPoint[5] = {0,246}
modelData[1][3][1].BangPoint[4] = {-30,122}
modelData[1][3][1].BangPoint[3] = {-70,100}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {201,0,201,262}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-8#106=1#0#134=2#62#210=5#0#246=4#30#120=3#70#138"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {8,106}
modelData[1][7][1].BangPoint[1] = {0,134}
modelData[1][7][1].BangPoint[2] = {62,210}
modelData[1][7][1].BangPoint[5] = {0,246}
modelData[1][7][1].BangPoint[4] = {30,120}
modelData[1][7][1].BangPoint[3] = {70,138}

return modelData