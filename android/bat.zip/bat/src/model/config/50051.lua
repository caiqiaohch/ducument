--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50051
modelData = {
resID = 50051,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {244,0,243,280}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-37#92=1#6#110=2#-19#183=5#0#192=8#0#0=7#0#0=9#0#0=4#100#196=3#-39#70"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {37,92}
modelData[1][3][1].BangPoint[1] = {6,110}
modelData[1][3][1].BangPoint[2] = {-19,183}
modelData[1][3][1].BangPoint[5] = {0,192}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {100,196}
modelData[1][3][1].BangPoint[3] = {-39,70}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,244,308}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#38#40=1#-7#117=2#19#175=5#0#192=8#0#0=7#0#0=9#0#0=4#-100#104=3#39#110"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-38,40}
modelData[1][7][1].BangPoint[1] = {-7,117}
modelData[1][7][1].BangPoint[2] = {19,175}
modelData[1][7][1].BangPoint[5] = {0,192}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {-100,104}
modelData[1][7][1].BangPoint[3] = {39,110}

return modelData