--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50047
modelData = {
resID = 50047,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {160,0,159,290}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-7#119=1#0#123=2#-13#216=5#0#123=8#0#0=7#0#0=9#0#0=4#42#243=3#-25#210"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {7,119}
modelData[1][3][1].BangPoint[1] = {0,123}
modelData[1][3][1].BangPoint[2] = {-13,216}
modelData[1][3][1].BangPoint[5] = {0,123}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {42,243}
modelData[1][3][1].BangPoint[3] = {-25,210}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,160,303}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#8#125=1#-1#123=2#12#206=5#0#123=8#-1#0=7#-1#0=9#-1#0=4#-43#194=3#25#251"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-8,125}
modelData[1][7][1].BangPoint[1] = {-1,123}
modelData[1][7][1].BangPoint[2] = {12,206}
modelData[1][7][1].BangPoint[5] = {0,123}
modelData[1][7][1].BangPoint[8] = {-1,0}
modelData[1][7][1].BangPoint[7] = {-1,0}
modelData[1][7][1].BangPoint[9] = {-1,0}
modelData[1][7][1].BangPoint[4] = {-43,194}
modelData[1][7][1].BangPoint[3] = {25,251}

return modelData