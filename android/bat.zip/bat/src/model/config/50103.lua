--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50103
modelData = {
resID = 50103,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,228,250}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-8#98=1#1#140=2#-32#219=5#0#214=4#84#152=3#-51#88"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {8,98}
modelData[1][3][1].BangPoint[1] = {1,140}
modelData[1][3][1].BangPoint[2] = {-32,219}
modelData[1][3][1].BangPoint[5] = {0,214}
modelData[1][3][1].BangPoint[4] = {84,152}
modelData[1][3][1].BangPoint[3] = {-51,88}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {228,0,228,243}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#8#89=1#-1#133=2#31#180=5#0#214=4#-85#113=3#50#94"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-8,89}
modelData[1][7][1].BangPoint[1] = {-1,133}
modelData[1][7][1].BangPoint[2] = {31,180}
modelData[1][7][1].BangPoint[5] = {0,214}
modelData[1][7][1].BangPoint[4] = {-85,113}
modelData[1][7][1].BangPoint[3] = {50,94}

return modelData