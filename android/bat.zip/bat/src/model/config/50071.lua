--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50071
modelData = {
resID = 50071,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,132,245}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#15#96=1#-2#158=2#-12#217=5#0#227=8#6#156=7#-82#104=9#-40#121=4#5#152=3#-43#127"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-15,96}
modelData[1][3][1].BangPoint[1] = {-2,158}
modelData[1][3][1].BangPoint[2] = {-12,217}
modelData[1][3][1].BangPoint[5] = {0,227}
modelData[1][3][1].BangPoint[8] = {6,156}
modelData[1][3][1].BangPoint[7] = {-82,104}
modelData[1][3][1].BangPoint[9] = {-40,121}
modelData[1][3][1].BangPoint[4] = {5,152}
modelData[1][3][1].BangPoint[3] = {-43,127}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {132,0,133,234}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-14#91=1#1#155=2#11#200=5#0#227=8#-7#114=7#81#43=9#40#101=4#-6#113=3#42#105"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {14,91}
modelData[1][7][1].BangPoint[1] = {1,155}
modelData[1][7][1].BangPoint[2] = {11,200}
modelData[1][7][1].BangPoint[5] = {0,227}
modelData[1][7][1].BangPoint[8] = {-7,114}
modelData[1][7][1].BangPoint[7] = {81,43}
modelData[1][7][1].BangPoint[9] = {40,101}
modelData[1][7][1].BangPoint[4] = {-6,113}
modelData[1][7][1].BangPoint[3] = {42,105}

return modelData