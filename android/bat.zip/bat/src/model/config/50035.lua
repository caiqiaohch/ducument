--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50035
modelData = {
resID = 50035,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,324,337,282}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-40#108=1#-5#157=2#-10#213=5#0#237=8#-42#132=7#158#87=9#45#110=4#46#115=3#-36#98"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {40,108}
modelData[1][3][1].BangPoint[1] = {-5,157}
modelData[1][3][1].BangPoint[2] = {-10,213}
modelData[1][3][1].BangPoint[5] = {0,237}
modelData[1][3][1].BangPoint[8] = {-42,132}
modelData[1][3][1].BangPoint[7] = {158,87}
modelData[1][3][1].BangPoint[9] = {45,110}
modelData[1][3][1].BangPoint[4] = {46,115}
modelData[1][3][1].BangPoint[3] = {-36,98}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,320,324}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#26#111=1#5#152=2#9#203=5#0#237=8#41#212=7#-159#-52=9#-45#97=4#-47#107=3#36#123"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-26,111}
modelData[1][7][1].BangPoint[1] = {5,152}
modelData[1][7][1].BangPoint[2] = {9,203}
modelData[1][7][1].BangPoint[5] = {0,237}
modelData[1][7][1].BangPoint[8] = {41,212}
modelData[1][7][1].BangPoint[7] = {-159,-52}
modelData[1][7][1].BangPoint[9] = {-45,97}
modelData[1][7][1].BangPoint[4] = {-47,107}
modelData[1][7][1].BangPoint[3] = {36,123}

return modelData