--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50038
modelData = {
resID = 50038,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,175,245}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#-20#97=1#0#117=2#-3#195=5#0#214=8#105#134=7#13#201=9#85#148=4#88#145=3#-11#152"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {20,97}
modelData[1][3][1].BangPoint[1] = {0,117}
modelData[1][3][1].BangPoint[2] = {-3,195}
modelData[1][3][1].BangPoint[5] = {0,214}
modelData[1][3][1].BangPoint[8] = {105,134}
modelData[1][3][1].BangPoint[7] = {13,201}
modelData[1][3][1].BangPoint[9] = {85,148}
modelData[1][3][1].BangPoint[4] = {88,145}
modelData[1][3][1].BangPoint[3] = {-11,152}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {175,0,176,207}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#21#79=1#0#120=2#2#175=5#0#213=8#-106#160=7#-14#64=9#-86#138=4#-88#149=3#10#88"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {-21,79}
modelData[1][7][1].BangPoint[1] = {0,120}
modelData[1][7][1].BangPoint[2] = {2,175}
modelData[1][7][1].BangPoint[5] = {0,213}
modelData[1][7][1].BangPoint[8] = {-106,160}
modelData[1][7][1].BangPoint[7] = {-14,64}
modelData[1][7][1].BangPoint[9] = {-86,138}
modelData[1][7][1].BangPoint[4] = {-88,149}
modelData[1][7][1].BangPoint[3] = {10,88}

return modelData