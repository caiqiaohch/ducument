--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50110
modelData = {
resID = 50110,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,216,234}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#41#91=1#-7#148=2#-23#209=5#0#221=4#19#161=3#-75#131"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-41,91}
modelData[1][3][1].BangPoint[1] = {-7,148}
modelData[1][3][1].BangPoint[2] = {-23,209}
modelData[1][3][1].BangPoint[5] = {0,221}
modelData[1][3][1].BangPoint[4] = {19,161}
modelData[1][3][1].BangPoint[3] = {-75,131}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {216,0,216,232}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-41#90=1#6#147=2#22#188=5#0#221=4#-20#99=3#75#133"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {41,90}
modelData[1][7][1].BangPoint[1] = {6,147}
modelData[1][7][1].BangPoint[2] = {22,188}
modelData[1][7][1].BangPoint[5] = {0,221}
modelData[1][7][1].BangPoint[4] = {-20,99}
modelData[1][7][1].BangPoint[3] = {75,133}

return modelData