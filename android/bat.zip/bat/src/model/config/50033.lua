--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50033
modelData = {
resID = 50033,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {185,0,185,284}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#19#116=1#0#151=2#0#212=5#0#228=8#0#0=7#-11#200=9#-5#203=4#22#183=3#-91#219"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-19,116}
modelData[1][3][1].BangPoint[1] = {0,151}
modelData[1][3][1].BangPoint[2] = {0,212}
modelData[1][3][1].BangPoint[5] = {0,228}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {-11,200}
modelData[1][3][1].BangPoint[9] = {-5,203}
modelData[1][3][1].BangPoint[4] = {22,183}
modelData[1][3][1].BangPoint[3] = {-91,219}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,185,295}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-19#109=1#0#151=2#0#212=5#0#228=8#0#0=7#10#195=9#4#193=4#-23#128=3#91#185"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {19,109}
modelData[1][7][1].BangPoint[1] = {0,151}
modelData[1][7][1].BangPoint[2] = {0,212}
modelData[1][7][1].BangPoint[5] = {0,228}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {10,195}
modelData[1][7][1].BangPoint[9] = {4,193}
modelData[1][7][1].BangPoint[4] = {-23,128}
modelData[1][7][1].BangPoint[3] = {91,185}

return modelData