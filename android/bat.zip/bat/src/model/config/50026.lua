--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50026
modelData = {
resID = 50026,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,121,253}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#9#100=1#-6#156=2#-15#220=5#0#228=8#0#0=7#0#0=9#0#0=4#-22#190=3#-47#154"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-9,100}
modelData[1][3][1].BangPoint[1] = {-6,156}
modelData[1][3][1].BangPoint[2] = {-15,220}
modelData[1][3][1].BangPoint[5] = {0,228}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,0}
modelData[1][3][1].BangPoint[9] = {0,0}
modelData[1][3][1].BangPoint[4] = {-22,190}
modelData[1][3][1].BangPoint[3] = {-47,154}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {121,0,122,237}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-9#92=1#5#151=2#14#205=5#0#228=8#0#0=7#0#0=9#0#0=4#22#135=3#46#127"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {9,92}
modelData[1][7][1].BangPoint[1] = {5,151}
modelData[1][7][1].BangPoint[2] = {14,205}
modelData[1][7][1].BangPoint[5] = {0,228}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,0}
modelData[1][7][1].BangPoint[9] = {0,0}
modelData[1][7][1].BangPoint[4] = {22,135}
modelData[1][7][1].BangPoint[3] = {46,127}

return modelData