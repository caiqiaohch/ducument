--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50045
modelData = {
resID = 50045,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,207,272}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#47#110=1#-3#140=2#-15#229=5#0#255=8#0#0=7#0#-26=9#0#-26=4#-2#179=3#-72#162"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-47,110}
modelData[1][3][1].BangPoint[1] = {-3,140}
modelData[1][3][1].BangPoint[2] = {-15,229}
modelData[1][3][1].BangPoint[5] = {0,255}
modelData[1][3][1].BangPoint[8] = {0,0}
modelData[1][3][1].BangPoint[7] = {0,-26}
modelData[1][3][1].BangPoint[9] = {0,-26}
modelData[1][3][1].BangPoint[4] = {-2,179}
modelData[1][3][1].BangPoint[3] = {-72,162}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {207,0,207,271}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-47#109=1#3#138=2#14#207=5#0#255=8#0#0=7#0#-26=9#0#-26=4#1#103=3#71#130"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {47,109}
modelData[1][7][1].BangPoint[1] = {3,138}
modelData[1][7][1].BangPoint[2] = {14,207}
modelData[1][7][1].BangPoint[5] = {0,255}
modelData[1][7][1].BangPoint[8] = {0,0}
modelData[1][7][1].BangPoint[7] = {0,-26}
modelData[1][7][1].BangPoint[9] = {0,-26}
modelData[1][7][1].BangPoint[4] = {1,103}
modelData[1][7][1].BangPoint[3] = {71,130}

return modelData