--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50011
modelData = {
resID = 50011,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {274,0,275,333}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#17#140=1#-19#167=2#-8#222=5#0#232=8#37#87=7#-135#149=9#-43#116=4#39#156=3#-43#116"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-17,140}
modelData[1][3][1].BangPoint[1] = {-19,167}
modelData[1][3][1].BangPoint[2] = {-8,222}
modelData[1][3][1].BangPoint[5] = {0,232}
modelData[1][3][1].BangPoint[8] = {37,87}
modelData[1][3][1].BangPoint[7] = {-135,149}
modelData[1][3][1].BangPoint[9] = {-43,116}
modelData[1][3][1].BangPoint[4] = {39,156}
modelData[1][3][1].BangPoint[3] = {-43,116}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,274,353}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-18#149=1#18#155=2#7#215=5#0#232=8#-37#72=7#134#208=9#43#135=4#-40#113=3#42#135"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {18,149}
modelData[1][7][1].BangPoint[1] = {18,155}
modelData[1][7][1].BangPoint[2] = {7,215}
modelData[1][7][1].BangPoint[5] = {0,232}
modelData[1][7][1].BangPoint[8] = {-37,72}
modelData[1][7][1].BangPoint[7] = {134,208}
modelData[1][7][1].BangPoint[9] = {43,135}
modelData[1][7][1].BangPoint[4] = {-40,113}
modelData[1][7][1].BangPoint[3] = {42,135}

return modelData