--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50037
modelData = {
resID = 50037,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,127,315}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#5#150=1#-3#162=2#-5#227=5#0#223=4#11#171=3#-5#160"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-5,150}
modelData[1][3][1].BangPoint[1] = {-3,162}
modelData[1][3][1].BangPoint[2] = {-5,227}
modelData[1][3][1].BangPoint[5] = {0,223}
modelData[1][3][1].BangPoint[4] = {11,171}
modelData[1][3][1].BangPoint[3] = {-5,160}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {127,0,127,278}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-5#124=1#2#152=2#4#216=5#0#223=4#-11#118=3#4#107"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {5,124}
modelData[1][7][1].BangPoint[1] = {2,152}
modelData[1][7][1].BangPoint[2] = {4,216}
modelData[1][7][1].BangPoint[5] = {0,223}
modelData[1][7][1].BangPoint[4] = {-11,118}
modelData[1][7][1].BangPoint[3] = {4,107}

return modelData