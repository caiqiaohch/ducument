--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50117
modelData = {
resID = 50117,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,180,299}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#22#123=1#-4#179=2#-30#203=5#0#260=4#47#88=3#-67#81"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-22,123}
modelData[1][3][1].BangPoint[1] = {-4,179}
modelData[1][3][1].BangPoint[2] = {-30,203}
modelData[1][3][1].BangPoint[5] = {0,260}
modelData[1][3][1].BangPoint[4] = {47,88}
modelData[1][3][1].BangPoint[3] = {-67,81}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {180,0,180,268}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-22#84=1#3#141=2#30#116=5#0#260=4#-48#48=3#67#77"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {22,84}
modelData[1][7][1].BangPoint[1] = {3,141}
modelData[1][7][1].BangPoint[2] = {30,116}
modelData[1][7][1].BangPoint[5] = {0,260}
modelData[1][7][1].BangPoint[4] = {-48,48}
modelData[1][7][1].BangPoint[3] = {67,77}

return modelData