--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50161
modelData = {
resID = 50161,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,185,190,161}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#14#103=1#19#117=2#7#145=5#0#157=4#51#113=3#-8#119"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-14,103}
modelData[1][3][1].BangPoint[1] = {19,117}
modelData[1][3][1].BangPoint[2] = {7,145}
modelData[1][3][1].BangPoint[5] = {0,157}
modelData[1][3][1].BangPoint[4] = {51,113}
modelData[1][3][1].BangPoint[3] = {-8,119}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,190,185}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-11#102=1#-20#136=2#-8#155=5#0#157=4#-52#135=3#8#137"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {11,102}
modelData[1][7][1].BangPoint[1] = {-20,136}
modelData[1][7][1].BangPoint[2] = {-8,155}
modelData[1][7][1].BangPoint[5] = {0,157}
modelData[1][7][1].BangPoint[4] = {-52,135}
modelData[1][7][1].BangPoint[3] = {8,137}

return modelData