--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50156
modelData = {
resID = 50156,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {87,0,87,238}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#8#91=1#5#141=2#-2#207=5#0#211=4#-19#191=3#-12#94"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-8,91}
modelData[1][3][1].BangPoint[1] = {5,141}
modelData[1][3][1].BangPoint[2] = {-2,207}
modelData[1][3][1].BangPoint[5] = {0,211}
modelData[1][3][1].BangPoint[4] = {-19,191}
modelData[1][3][1].BangPoint[3] = {-12,94}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {0,0,87,250}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-8#89=1#-5#152=2#2#210=5#0#211=4#18#124=3#11#143"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {8,89}
modelData[1][7][1].BangPoint[1] = {-5,152}
modelData[1][7][1].BangPoint[2] = {2,210}
modelData[1][7][1].BangPoint[5] = {0,211}
modelData[1][7][1].BangPoint[4] = {18,124}
modelData[1][7][1].BangPoint[3] = {11,143}

return modelData