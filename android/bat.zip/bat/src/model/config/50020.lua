--站立(1)移动(2)攻击1(3)死亡(4) 
--资源编号：50020
modelData = {
resID = 50020,
dirarr = {3,7}
}

--动作1******
modelData[1] = {}
--方向3
modelData[1][3] = {}
modelData[1][3].Frames = 1
--帧数1
modelData[1][3][1] = {0,0,148,329}--x,y,w,h
modelData[1][3][1].BangPointStr = "0#15#139=1#4#141=2#8#211=5#0#229=4#18#189=3#-65#222"
modelData[1][3][1].BangPoint = {}
modelData[1][3][1].BangPoint[0] = {-15,139}
modelData[1][3][1].BangPoint[1] = {4,141}
modelData[1][3][1].BangPoint[2] = {8,211}
modelData[1][3][1].BangPoint[5] = {0,229}
modelData[1][3][1].BangPoint[4] = {18,189}
modelData[1][3][1].BangPoint[3] = {-65,222}
--方向7
modelData[1][7] = {}
modelData[1][7].Frames = 1
--帧数1
modelData[1][7][1] = {148,0,148,288}--x,y,w,h
modelData[1][7][1].BangPointStr = "0#-15#119=1#-4#151=2#-9#228=5#0#229=4#-18#186=3#65#156"
modelData[1][7][1].BangPoint = {}
modelData[1][7][1].BangPoint[0] = {15,119}
modelData[1][7][1].BangPoint[1] = {-4,151}
modelData[1][7][1].BangPoint[2] = {-9,228}
modelData[1][7][1].BangPoint[5] = {0,229}
modelData[1][7][1].BangPoint[4] = {-18,186}
modelData[1][7][1].BangPoint[3] = {65,156}

return modelData