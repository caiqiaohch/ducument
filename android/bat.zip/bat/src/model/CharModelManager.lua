local CharModelManager = class()-- 定义一个类 test 继承于 base_type

function CharModelManager:ctor()

	print("CharModelManager:ctor --------------------------")
	
end

function CharModelManager:instance()
    local o = _G.CharModelManager
    if o then
    	return o
	end
 
    o = CharModelManager:new()
	_G.CharModelManager = o
    CharModelManager:init()
    return o
end

function CharModelManager:init()
    --NPC资源数据列表
    self.CharDataArr = {}
end

--获取指定资源数据
function CharModelManager:getCharData( id )
    local data = self.CharDataArr[id]
    if data == nil then
        pcall( function () data = require("model.config."..id) end )
        if data == nil then return nil end
        self.CharDataArr[id] = data
    end

    return data
end

return CharModelManager