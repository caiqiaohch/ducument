local MusicManager = class( "MusicManager" )

function MusicManager:ctor()

	print("MusicManager:ctor --------------------------")
	
end

local curMusicId 
local lastMusicId

function MusicManager:instance()
    local o = _G.MusicManager
    if o then
    	return o
	end
 
    o = MusicManager:new()
	_G.MusicManager = o
    MusicManager:init()
    return o
end

function MusicManager:init( )

end

--获取音效路径
function MusicManager:getMusic(id)
    if DataManager:getMusic(id) ~= nil then
        return DataManager:getMusic(id).DubbingMusic
    else
        return ""
    end
end

--播放音效
function MusicManager:PlaySound( id )
    local Sp = self:getMusic( id )
    if Sp == "" then return end    
    local music_type = DataManager:getMusic(id).music_type
    local PlayMode = DataManager:getMusic(id).PlayMode == 1
    if music_type == 1 then
        lastMusicId = curMusicId
        curMusicId = id
        if IS_OPEN_MUSIC == false then 
        return end
        AudioEngine.playMusic(Sp, PlayMode);   
    else
        if IS_OPEN_SOUND == false then 
        return end
        AudioEngine.playEffect(Sp, PlayMode);
    end
end

--播放上一个界面的音效
function MusicManager:PlayLastSound()
    MusicManager:PlaySound( lastMusicId )
end

--停止音乐
function MusicManager:StopMusic( id )
    --local Sp = self:getMusic( id )
    --if Sp == "" then return end
    AudioEngine.stopMusic()
--    AudioEngine.destroyInstance() 
end

--停止音效
function MusicManager:StopSound()
    AudioEngine.stopAllEffects()
end

--恢复播放音乐
function MusicManager:ResumeMusic()
    MusicManager:PlaySound(curMusicId)
end

--设置是否可以播放音乐
function MusicManager:setBolOpenMusic()
    AudioEngine.setBolOpenMusic()
end
--设置是否可以播放音效
function MusicManager:setBolOpenSound()
    AudioEngine.setBolOpenSound()
end


--根据地图id获取音乐ID
function MusicManager:getMusicIdByMap(mapId)
    for k, v in pairs(DataManager.DataMusic) do
        if mapId == v.MapMusic_desc then
            return k
        end
    end
    return 0
end

return MusicManager